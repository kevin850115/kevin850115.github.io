package com.alibaba.crm.demo.dto;

import com.alibaba.sofa.dto.Query;

public class CustomerFindByCriteriaQry extends Query{

}
