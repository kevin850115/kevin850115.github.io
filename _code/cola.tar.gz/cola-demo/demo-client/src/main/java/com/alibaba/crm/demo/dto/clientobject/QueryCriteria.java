package com.alibaba.crm.demo.dto.clientobject;

import com.alibaba.sofa.dto.ClientObject;

public class QueryCriteria extends ClientObject{

}
