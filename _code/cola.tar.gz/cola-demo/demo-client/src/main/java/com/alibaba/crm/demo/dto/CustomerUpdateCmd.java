package com.alibaba.crm.demo.dto;

import com.alibaba.sofa.dto.Command;

public class CustomerUpdateCmd extends Command{

}
