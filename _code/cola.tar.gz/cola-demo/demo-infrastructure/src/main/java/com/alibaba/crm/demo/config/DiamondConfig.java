package com.alibaba.crm.demo.config;

public class DiamondConfig {
    public final static String DummyConfig = "DummyConfig";
}