package com.alibaba.crm.demo.common;

public class BizCode {

    public final static String DD = "DD"; //钉钉的bizCode

    public final static String BAMBOO = "B_001"; //为知树的bizCode

    public final static String CGS = "CGS"; //中供的bizCode

    public final static String TP = "TP"; //诚信通的bizCode

    public final static String ICBU = "ICBU"; //icbu的bizCode
}
