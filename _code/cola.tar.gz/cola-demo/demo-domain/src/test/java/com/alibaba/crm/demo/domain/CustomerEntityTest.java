package com.alibaba.crm.demo.domain;


public class CustomerEntityTest {

    public void testCustomerConflict() {
        System.out.println("Please mock tunnel, test pure Domain Knowledge");
    }
}
