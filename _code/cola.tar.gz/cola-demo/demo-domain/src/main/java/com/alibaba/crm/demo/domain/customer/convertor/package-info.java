/**
 * Convertor classes are used to convert Objects among Client Object, Domain Object and Data Object.
 * 
 * @author fulan.zjf
 */
package com.alibaba.crm.demo.domain.customer.convertor;