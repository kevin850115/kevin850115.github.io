package com.alibaba.crm.demo.domain.customer.entity;

import com.alibaba.sofa.domain.Entity;


public class ContactE extends Entity {

}
