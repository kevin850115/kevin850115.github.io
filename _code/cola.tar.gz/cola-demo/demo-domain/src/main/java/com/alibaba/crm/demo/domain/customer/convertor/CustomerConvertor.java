package com.alibaba.crm.demo.domain.customer.convertor;

import com.alibaba.crm.demo.tunnel.dataobject.CustomerDO;
import com.alibaba.crm.demo.domain.customer.entity.CustomerE;
import com.alibaba.crm.demo.domain.customer.valueobject.CompanyType;
import com.alibaba.crm.demo.dto.clientobject.CustomerCO;
import com.alibaba.crm.demo.dto.clientobject.CustomerType;
import com.alibaba.sofa.common.ApplicationContextHelper;
import com.alibaba.sofa.convertor.ConvertorI;
import org.springframework.stereotype.Component;

/**
 * CustomerConvertor
 *
 * @author Frank Zhang
 * @date 2018-01-07 3:08 AM
 */
@Component
public class CustomerConvertor implements ConvertorI {

    public CustomerE clientToEntity(Object clientObject){
        CustomerCO customerCO = (CustomerCO)clientObject;
        CustomerE customerEntity = (CustomerE) ApplicationContextHelper.getBean(CustomerE.class);
        customerEntity.setCompanyName(customerCO.getCompanyName());
        customerEntity.setCompanyType(CompanyType.valueOf(customerCO.getCustomerType().name()));
        return customerEntity;
    }

    public CustomerCO dataToClient(Object dataObject) {
        CustomerDO customerDo = (CustomerDO) dataObject;
        CustomerCO customerCO = new CustomerCO();
        customerCO.setCustomerName(customerDo.getCompanyName());
        customerCO.setCustomerType(CustomerType.valueOf(customerDo.getCompanyType()));
        customerCO.setMemberId(customerDo.getMemberId());
        customerCO.setCustomerId(customerDo.getCustomerId());
        return customerCO;
    }
}
