package com.alibaba.crm.demo.domain.customer.valueobject;

import com.alibaba.sofa.domain.ValueObject;

/**
 * Address Value Object 
 * @author fulan.zjf 2017年10月22日 下午10:32:46
 */
public class AddressV extends ValueObject{

}
