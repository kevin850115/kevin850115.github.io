/**
 * Service is the facade of application API
 * 
 * @author fulan.zjf
 */
package com.alibaba.crm.demo.service;