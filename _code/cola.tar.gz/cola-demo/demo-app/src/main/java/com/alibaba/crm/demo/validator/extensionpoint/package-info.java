/**
 * Validator Extension Point are used to declare the point needs extension per different tenant.
 * 
 * @author fulan.zjf
 */
package com.alibaba.crm.demo.validator.extensionpoint;