/**
 * Validator Extensions are used to do different validation per different tenant.
 * 
 * @author fulan.zjf
 */
package com.alibaba.crm.demo.validator.extension;