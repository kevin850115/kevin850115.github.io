package com.alibaba.saas.dto.clientobject;

import com.alibaba.cola.dto.ClientObject;

public class QueryCriteria extends ClientObject{

}
