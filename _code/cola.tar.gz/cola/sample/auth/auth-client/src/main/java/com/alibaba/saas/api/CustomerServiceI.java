package com.alibaba.saas.api;

import com.alibaba.saas.dto.CustomerAddCmd;
import com.alibaba.saas.dto.CustomerListByNameQry;
import com.alibaba.cola.dto.MultiResponse;
import com.alibaba.cola.dto.Response;
import com.alibaba.saas.dto.clientobject.CustomerCO;

public interface CustomerServiceI {

    public Response addCustomer(CustomerAddCmd customerAddCmd);
        
    public MultiResponse<CustomerCO> listByName(CustomerListByNameQry customerListByNameQry);
}
