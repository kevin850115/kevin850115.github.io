package com.alibaba.saas.dto;

import com.alibaba.saas.dto.clientobject.CustomerCO;
import com.alibaba.cola.dto.Command;
import lombok.Data;

@Data
public class CustomerAddCmd extends Command{

    private CustomerCO customerCO;
    
}
