package com.alibaba.saas.tunnel.search;

import org.springframework.stereotype.Component;
import com.alibaba.cola.tunnel.DataTunnelI;

@Component
public class CustomerSearchTunnel implements DataTunnelI {

}
