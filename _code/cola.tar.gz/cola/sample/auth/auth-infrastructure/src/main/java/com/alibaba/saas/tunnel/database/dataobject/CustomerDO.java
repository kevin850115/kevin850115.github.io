package com.alibaba.saas.tunnel.database.dataobject;

import com.alibaba.cola.dto.DataObject;
import lombok.Data;

@Data
public class CustomerDO extends DataObject {
    private String customerId;
    private String memberId;
    private String globalId;
    private String companyName;
    private String source;
    private String companyType;
}
