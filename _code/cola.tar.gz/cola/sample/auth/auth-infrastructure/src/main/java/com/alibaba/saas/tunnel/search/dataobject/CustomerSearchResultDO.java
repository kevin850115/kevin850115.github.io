package com.alibaba.saas.tunnel.search.dataobject;

import com.alibaba.cola.dto.DataObject;
import lombok.Data;

@Data
public class CustomerSearchResultDO extends DataObject {

}

