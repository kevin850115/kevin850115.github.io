package com.alibaba.saas.tunnel.rpc.dataobject;

import com.alibaba.cola.dto.DataObject;
import lombok.Data;

@Data
public class AccountDO extends DataObject {

}

