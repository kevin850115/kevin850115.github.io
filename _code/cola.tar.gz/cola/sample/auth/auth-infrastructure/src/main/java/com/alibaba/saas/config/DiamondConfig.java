package com.alibaba.saas.config;

public class DiamondConfig {
    public final static String DummyConfig = "DummyConfig";
}