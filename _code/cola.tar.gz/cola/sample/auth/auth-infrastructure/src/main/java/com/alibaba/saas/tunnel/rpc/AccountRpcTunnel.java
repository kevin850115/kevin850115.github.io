package com.alibaba.saas.tunnel.rpc;

import org.springframework.stereotype.Component;
import com.alibaba.cola.tunnel.DataTunnelI;

@Component
public class AccountRpcTunnel implements DataTunnelI {

}
