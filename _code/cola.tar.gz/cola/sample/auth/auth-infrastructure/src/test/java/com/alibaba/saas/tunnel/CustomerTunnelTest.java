package com.alibaba.saas.tunnel;


public class CustomerTunnelTest {

    public void testFindByID() {
        System.out.println("Write your test here");
    }
}
