package com.alibaba.saas.domain.resource;

import com.alibaba.cola.exception.BizException;

import java.util.List;

/**
 * 资源：一个资源对应一个权限项，可以被赋予给Role
 */
public abstract class Resource {
    protected ResouceType type;

    abstract public String getKey();

    abstract public List<Resource> getChildren();

    public ResouceType getType(){
        if(type == null){
            throw new BizException("ResourceType should not be null");
        }
        return type;
    }
}
