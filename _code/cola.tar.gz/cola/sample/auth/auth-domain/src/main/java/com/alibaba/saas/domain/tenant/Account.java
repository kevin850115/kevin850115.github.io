package com.alibaba.saas.domain.tenant;

import com.alibaba.cola.domain.Entity;
import lombok.Data;

/**
 * frank zhang 2019-04-12
 */
@Entity
@Data
public class Account {
    private String id;
    /**
     * 账号
     */
    private String accountNo;

    /**
     * 账号所属的域，可能包括ICBU，钉钉，也可以是自有账号，多个账号可以关联到一个用户（User）
     */
    private String accountDomain;

    /**
     * 账号显示名
     */
    private String accountName;

    /**
     * 密码
     */
    private String password;

    /**
     * 账号状态
     */
    private String status;


}
