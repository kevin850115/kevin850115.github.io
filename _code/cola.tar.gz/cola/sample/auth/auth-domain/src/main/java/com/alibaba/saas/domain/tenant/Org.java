package com.alibaba.saas.domain.tenant;

import com.alibaba.cola.domain.Entity;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Org {
    private String id;
    private String name;
    private Org parent;
    private List<Org> children;
    private String tenantId;
}
