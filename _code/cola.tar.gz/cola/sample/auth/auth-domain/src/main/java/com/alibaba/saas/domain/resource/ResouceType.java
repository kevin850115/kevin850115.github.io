package com.alibaba.saas.domain.resource;

public enum ResouceType {
    PRODUCT("产品"),
    FUNCTION_PACKAGE("功能包"),
    FUNCTION("功能"),
    FUNCTION_POINT("功能点");

    private String desc;

    private ResouceType(String desc){
        this.desc = desc;
    }
}
