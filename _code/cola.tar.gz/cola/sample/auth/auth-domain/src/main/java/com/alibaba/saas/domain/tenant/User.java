package com.alibaba.saas.domain.tenant;

import com.alibaba.cola.domain.Entity;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Entity
@Data
public class User {
    private String id;
    /**
     * 可以用来做User的唯一标识 ？
     */
    private String cellPhone;
    private String email;
    private User manager;//主管，关于主管可以查看下属的客户的权限要如何设计呢？我觉得这个不应该在Auth里面做，这里只需要维护主管-员工关系就好了
    private Map<String, Role> roleMap;// 一个人可能会承担多个角色，但是在一个场景下，只会有一个角色
    private Org org;
    private String tenantId;

    public Role getRole(String scenario){
        return roleMap.get(scenario);
    }

    public void addRole(String scenario, Role role){
        if(roleMap == null){
            roleMap = new HashMap<>();
        }
        roleMap.put(scenario, role);
    }
}
