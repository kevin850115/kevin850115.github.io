package com.alibaba.saas.domain.tenant;

import com.alibaba.cola.domain.Entity;
import com.alibaba.saas.domain.resource.Resource;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@EqualsAndHashCode(of = {"id"})
public class Role {
    private String id;
    /**
     * 角色名
     */
    private String name;
    /**
     * 描述
     */
    private String description;

    /**
     * 角色所拥有的资源集合, FunctionPackage ？
     */
    private List<Resource> resourceList;


    public List getMenu(){
        return null;
    }

    public boolean checkPermission(String resourceKey){
        for(Resource resource : resourceList){
            if (resource.getKey().equals(resourceKey)){
                return true;
            }
        }
        return false;
    }

    public void assignResource(Resource resource){
        checkNull();
        resourceList.add(resource);
        assignChildren(resource);
    }

    private void checkNull() {
        if(resourceList == null) {
            resourceList = new ArrayList<>();
        }
    }

    /**
     * 扁平化处理children resource
     * @param resource
     */
    private void assignChildren(Resource resource) {
        if (resource.getChildren().isEmpty()){
            return;
        }
        resource.getChildren().forEach(r -> {this.assignResource(r);});
    }
}
