package com.alibaba.saas.domain.tenant;

import com.alibaba.cola.domain.Entity;
import lombok.Data;

@Entity
@Data
public class Tenant {
    private String tenantId;
    private String companyName;
    private String companyPortal;
    private String companyEmail;
    private String rootOrgId;
}
