package com.alibaba.saas.domain.resource;

import com.alibaba.cola.domain.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 功能(Function)对应界面叶子菜单项。
 *
 * 一个Function可以包含多个FunctionPoint（功能点）
 *
 * 比如"查看客户"是一个Function，着这个功能下面可以包含一些列FunctionPoint：
 * FunctionPoint 1 ： 是否"可以看到银行卡号"，不同的角色对敏感信息的查看权限是不一样的。
 * FunctionPoint 2 ： 是否"展示修改客户"这个行动点，也是权限问题
 *
 * frank zhang 2019-04-10
 */
@Entity
@Data
@EqualsAndHashCode(of = {"key"})
public class Function extends Resource{
    private String id;
    private String key;
    private String name;
    private String menuItemName; //该功能（叶子菜单项）对应的菜单名称
    private int menuItemOrder; //该功能在菜单中显示位置
    private List<Resource> functionPoints = Collections.EMPTY_LIST;

    public Function(){
        super.type = ResouceType.FUNCTION;
    }

    public Function(String key){
        this();
        this.key = key;
    }

    public void addFunctionPoint(FunctionPoint functionPoint){
        if(functionPoints.isEmpty()){
            functionPoints = new ArrayList<>();
        }
        functionPoints.add(functionPoint);
    }

    @Override
    public List<Resource> getChildren() {
        return functionPoints;
    }
}
