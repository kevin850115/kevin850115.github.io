package com.alibaba.saas.domain.resource;

import com.alibaba.cola.domain.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能包(FunctionPackage)对应界面上的父级菜单。
 *
 * 一个FunctionPackage可以包含多个Function。虽然也支持Child FunctionPackage，但是最好不要用，会弄的很复杂。
 *
 * 注意：
 *
 * 菜单和功能包合用一套概念，前提是用户不需要自定义"菜单名称"，如果需要自定，那么就需要拆开。
 *
 * 因为功能是SaaS提供方提供的，是租户无关的。 而"菜单名称"可能每个租户都不同。
 */
@Entity
@Data
@EqualsAndHashCode(of = {"key"})
public class FunctionPackage extends Resource{
    private String id;
    private String key;
    private String name;
    private String menuName; //该功能包（父级菜单）对应的菜单名称
    private int menuOrder; //该功能包在菜单中显示位置
    private FunctionPackage parent;
    private List<Resource> includeFunctionPackages;
    private List<Resource> includeFunctions;

    public FunctionPackage(){
        super.type = ResouceType.FUNCTION_PACKAGE;
    }

    public FunctionPackage(String key){
        this();
        this.key = key;
    }

    @Override
    public List<Resource> getChildren() {
        return includeFunctions;
    }

    public void addFunction(Function function){
        if (includeFunctions == null){
            includeFunctions = new ArrayList<>();
        }
        includeFunctions.add(function);
    }
}
