package com.alibaba.saas.domain.resource;

import com.alibaba.cola.domain.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Collections;
import java.util.List;

/**
 * FunctionPoint（功能点）是最细粒度的资源（权限项）
 *
 * frank zhang 2019-04-10
 */
@Entity
@Data
@EqualsAndHashCode(of = {"key"})
public class FunctionPoint extends Resource{
    private String id;
    private String key;
    private String name;

    public FunctionPoint(){
        super.type = ResouceType.FUNCTION_POINT;
    }

    public FunctionPoint(String key){
        this();
        this.key = key;
    }

    @Override
    public List<Resource> getChildren() {
        return Collections.EMPTY_LIST;
    }
}
