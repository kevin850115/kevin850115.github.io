package com.alibaba.saas.domain.resource;

import com.alibaba.cola.domain.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@EqualsAndHashCode(of = {"key"})
public class Product extends Resource{
    private String id;
    private String key;
    private String name;
    private List<Resource> includeFunctionPackages;

    public Product(){
        super.type = ResouceType.PRODUCT;
    }

    public Product(String key){
        this();
        this.key = key;
    }

    @Override
    public List<Resource> getChildren() {
        return includeFunctionPackages;
    }

    public void addFunctionPackage(FunctionPackage functionPackage){
        if(includeFunctionPackages == null){
            includeFunctionPackages = new ArrayList<>();
        }
        includeFunctionPackages.add(functionPackage);
    }
}
