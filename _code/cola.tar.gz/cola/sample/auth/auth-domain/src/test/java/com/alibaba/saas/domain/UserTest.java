package com.alibaba.saas.domain;

import com.alibaba.saas.domain.tenant.User;
import org.junit.Assert;
import org.junit.Test;

public class UserTest {

    @Test
    public void testScenarioRole(){
        User sales = new User();
        sales.addRole("sales", RoleTest.buildSalesRole());
        sales.addRole("admin", RoleTest.buidAdminRole());

        Assert.assertTrue(sales.getRole("sales").checkPermission("Func_createCustomer"));
        Assert.assertFalse(sales.getRole("sales").checkPermission("Func_roleManagement"));

        Assert.assertTrue(sales.getRole("admin").checkPermission("Func_createCustomer"));
        Assert.assertTrue(sales.getRole("admin").checkPermission("Func_roleManagement"));
    }
}
