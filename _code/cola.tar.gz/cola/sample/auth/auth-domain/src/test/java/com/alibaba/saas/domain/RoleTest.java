package com.alibaba.saas.domain;

import com.alibaba.saas.domain.resource.Function;
import com.alibaba.saas.domain.resource.FunctionPackage;
import com.alibaba.saas.domain.resource.FunctionPoint;
import com.alibaba.saas.domain.resource.Product;
import com.alibaba.saas.domain.tenant.Role;
import org.junit.Assert;
import org.junit.Test;

public class RoleTest {

    @Test
    public void testAssginProduct(){
        Role adminRole = buidAdminRole();

        Assert.assertTrue(adminRole.checkPermission("Func_orgManagement"));
        Assert.assertTrue(adminRole.checkPermission("Func_createCustomer"));
        Assert.assertTrue(adminRole.checkPermission("FuncPnt_viewDebitCard"));
    }

    @Test
    public void testAssignFunctionPackage(){
        Role salesRole = buildSalesRole();

        Assert.assertFalse(salesRole.checkPermission("Func_orgManagement"));
        Assert.assertTrue(salesRole.checkPermission("Func_createCustomer"));
        Assert.assertTrue(salesRole.checkPermission("FuncPnt_showUpdateButton"));
    }

    public static Role buidAdminRole() {
        Product basicVersion = new Product("product_basic_version");
        basicVersion.addFunctionPackage(buildBasicManagementFP());
        basicVersion.addFunctionPackage(buildCustomerManagmentFP());

        Role adminRole = new Role();
        adminRole.assignResource(basicVersion);
        return adminRole;
    }

    public static Role buildSalesRole() {
        Role salesRole = new Role();
        salesRole.assignResource(buildCustomerManagmentFP());
        return salesRole;
    }

    public static FunctionPackage buildBasicManagementFP(){
        //基础管理包
        FunctionPackage basicManagement = new FunctionPackage("FuncPac_basicManagement");
        //组织管理
        Function orgManagement = new Function("Func_orgManagement");
        basicManagement.addFunction(orgManagement);
        //角色管理
        Function roleManagement = new Function("Func_roleManagement");
        basicManagement.addFunction(roleManagement);
        //人员管理
        Function employeeManagement = new Function("Func_employeeManagement");
        basicManagement.addFunction(employeeManagement);
        return basicManagement;
    }

    public static FunctionPackage buildCustomerManagmentFP(){
        //客户管理包
        FunctionPackage customerManagement = new FunctionPackage("FuncPac_customerManagement");
        //新建客户
        Function createCustomer = new Function("Func_createCustomer");
        customerManagement.addFunction(createCustomer);
        //修改客户
        Function updateCustomer = new Function("Func_updateCustomer");
        customerManagement.addFunction(updateCustomer);
        //客户列表
        Function listCustomer = new Function("Func_listCustomer");
        customerManagement.addFunction(listCustomer);
        //客户详情
        Function customerDetail = new Function("Func_customerDetail");
        customerManagement.addFunction(customerDetail);
        //功能点
        FunctionPoint viewDebitCard = new FunctionPoint("FuncPnt_viewDebitCard");
        customerDetail.addFunctionPoint(viewDebitCard);
        FunctionPoint showUpdateButton = new FunctionPoint("FuncPnt_showUpdateButton");
        customerDetail.addFunctionPoint(showUpdateButton);

        //导出客户
        Function exportCustomers = new Function("Func_exportCustomers");
        customerManagement.addFunction(exportCustomers);
        return customerManagement;
    }
}
