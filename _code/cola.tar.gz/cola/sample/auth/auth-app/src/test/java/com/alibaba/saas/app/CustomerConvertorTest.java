package com.alibaba.saas.app;

import com.alibaba.saas.dto.clientobject.CustomerCO;
import org.junit.Before;
import org.junit.Test;

public class CustomerConvertorTest {


    private CustomerCO customerCO;

    @Before
    public void setup(){
        customerCO = new CustomerCO();
        customerCO.setCompanyName("TestCompany");
    }

    @Test
    public void testConvert(){

    }

}
