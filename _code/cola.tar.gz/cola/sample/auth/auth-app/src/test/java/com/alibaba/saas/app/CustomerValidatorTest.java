package com.alibaba.saas.app;

import org.junit.Assert;
import org.junit.Test;

public class CustomerValidatorTest {

    @Test
    public void testValidation(){

    }
}