/**
 * Validator classes are used to validate parameters from client.
 * 
 * @author fulan.zjf
 */
package com.alibaba.saas.validator;