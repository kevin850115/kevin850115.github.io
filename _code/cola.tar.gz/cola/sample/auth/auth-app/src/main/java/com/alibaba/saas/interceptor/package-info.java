/**
 * Interceptors are used to do pre-processing and post-processing during invocation of Command.
 * 
 * @author fulan.zjf
 */
package com.alibaba.saas.interceptor;