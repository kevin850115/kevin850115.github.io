package com.alibaba.cola.event;

/**
 * @author shawnzhan.zxy
 * @date 2017/11/20
 */
public interface EventI {
}
