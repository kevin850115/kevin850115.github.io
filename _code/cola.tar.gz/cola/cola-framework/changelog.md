# Changelog
项目的所有变更信息，将会记录到此文件。
changelog格式规范参考：http://keepachangelog.com/
## [1.0.6] - 2018-08-21
### 新增
- SofaContext统一管理所有上下文信息，支持上下文传递、设置及清除等。
- 相应testcase见sofa-framework/sofa-core/src/test/java/com/alibaba/sofa/test/context/TestSofaContext
### 变更
- 移除PvgContext,TenantContext
- 应用上下文由具体业务方定义，Sofa提供统一标准-SofaContextSupport。