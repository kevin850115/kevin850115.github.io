package com.alibaba.cola.mybatis.interceptors;

import com.alibaba.crm.marketing.tunnel.cache.util.LRULocalCache;
import com.alibaba.cola.exception.ColaException;
import com.alibaba.cola.exception.SysException;
import com.alibaba.cola.mybatis.commons.InterceptorUtil;
import com.alibaba.cola.mybatis.commons.SqlParserUtils;
import com.alibaba.cola.optimisticlocker.Lock;
import com.alibaba.cola.optimisticlocker.OptimisticLocker;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.binding.MapperMethod;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;


/**
 * @author shawnzhan.zxy
 * @date 2018/06/07
 */
@Intercepts({@Signature(type = Executor.class, method = "update", args = {
        MappedStatement.class, Object.class }),
        @Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class})})
public class OptimisticLockerInterceptor implements Interceptor {
    private static final Logger logger = LoggerFactory.getLogger(OptimisticLockerInterceptor.class);

    private static final String DELEGATE_MAPPEDSTATEMENT = "delegate.mappedStatement";
    private static final String METHOD_UPDATE = "update";
    private static final String METHOD_PREPARE = "prepare";
    private static final String C_UPDATE_SQL_SUFFIX = "_prepare_update_sql";
    private static final String C_SELECT_SQL_SUFFIX = "_prepare_select_sql";
    private static final String DELEGATE_BOUNDSQL = "delegate.boundSql";
    private static final String DELEGATE_BOUNDSQL_SQL = "delegate.boundSql.sql";

    private LRULocalCache<String, Object> cache = new LRULocalCache<>(1000);

    @Override
    public Object intercept(Invocation invocation) throws Exception {
        String methodName = invocation.getMethod().getName();
        if(methodName.equals(METHOD_PREPARE)){
            StatementHandler handler = (StatementHandler) InterceptorUtil.processTarget(invocation.getTarget());
            MetaObject metaObject = SystemMetaObject.forObject(handler);
            MappedStatement ms = (MappedStatement) metaObject.getValue(DELEGATE_MAPPEDSTATEMENT);
            return prepare(invocation, metaObject, ms);
        }else if(methodName.equals(METHOD_UPDATE)){
            Lock lock = getLock(invocation);
            if(lock != null && lock.updateFailThrowException()){
                return update(invocation);
            }
        }
        return invocation.proceed();
    }

    private Object update(Invocation invocation) throws Exception {
        Object rst = invocation.proceed();
        if(rst == null || (Integer)rst == 0){
            throw new SysException("version error or no data!");
        }
        return rst;
    }

    private Object prepare(Invocation invocation, MetaObject metaObject, MappedStatement ms) throws Exception {
        String key = StringUtils.EMPTY;
        SqlCommandType sqlCommandType = ms.getSqlCommandType();
        Integer originalVersion = 0;
        BoundSql boundSql = null;
        if(SqlCommandType.UPDATE.equals(sqlCommandType)){
            Lock lock = getLock(metaObject, ms);
            if(lock == null){
                return invocation.proceed();
            }
            key = ms.getId() + C_UPDATE_SQL_SUFFIX;

            boundSql = (BoundSql) metaObject.getValue(DELEGATE_BOUNDSQL);
            boundSql.getParameterMappings().add(new ParameterMapping.Builder(ms.getConfiguration(), "version", Integer.class).build());
            originalVersion = (Integer)metaObject.getValue("delegate.boundSql.parameterObject.version");
            if(originalVersion == null || Long.parseLong(originalVersion.toString()) < 0){
                throw new ColaException("value of version field[version]can not be empty");
            }
        }else if(SqlCommandType.SELECT.equals(sqlCommandType)){
            OptimisticLocker optimisticLocker = getOptimisticLocker(metaObject, ms);
            if(optimisticLocker == null){
                return invocation.proceed();
            }
            key = ms.getId() + C_SELECT_SQL_SUFFIX;
            boundSql = (BoundSql) metaObject.getValue(DELEGATE_BOUNDSQL);
        }else{
            return invocation.proceed();
        }

        String originalSql = boundSql.getSql();
        if(logger.isDebugEnabled()) {
            logger.debug("originalSql: " + originalSql);
        }

        String newSql = (String) cache.get(originalSql);
        if (StringUtils.isBlank(newSql)) {
            if(SqlCommandType.UPDATE.equals(sqlCommandType)) {
                newSql = SqlParserUtils.g().addVersionToUpdateSql(originalSql, originalVersion);
            }
            else if(SqlCommandType.SELECT.equals(sqlCommandType)){
                newSql = SqlParserUtils.g().addVersionToSelectSql(originalSql);
            }
            cache.put(originalSql, newSql);
        }

        metaObject.setValue(DELEGATE_BOUNDSQL_SQL, newSql);
        if(logger.isDebugEnabled()) {
            logger.debug("newSql: " + newSql);
        }

        return invocation.proceed();
    }

    private Lock getVersionLocker(MappedStatement ms, Object paramObj) {
        Lock versionLocker;
        Class<?>[] paramCls = null;
        // 1、处理@Param标记的参数
        // 1、Process @Param param
        if(paramObj instanceof MapperMethod.ParamMap<?>) {
            MapperMethod.ParamMap<?> mmp = (MapperMethod.ParamMap<?>) paramObj;
            if(null != mmp && !mmp.isEmpty()) {
                paramCls = new Class<?>[mmp.size() / 2];
                int mmpLen = mmp.size() / 2;
                for(int i=0; i<mmpLen; i++) {
                    Object index = mmp.get("param" + (i + 1));
                    paramCls[i] = index.getClass();
                    if(List.class.isAssignableFrom(paramCls[i])){
                        return null;
                    }
                }
            }

            // 2、处理Map类型参数
            // 2、Process Map param
        } else if (paramObj instanceof Map) {//不支持批量
            @SuppressWarnings("rawtypes")
            Map map = (Map)paramObj;
            paramCls = new Class<?>[] {Map.class};
            // 3、处理POJO实体对象类型的参数
            // 3、Process POJO entity param
        } else {
            paramCls = new Class<?>[] {paramObj.getClass()};
        }

        Class<?> mapper = getMapper(ms);
        if(mapper != null) {
            Method m;
            try {
                m = mapper.getDeclaredMethod(getMapperShortId(ms), paramCls);
            } catch (NoSuchMethodException | SecurityException e) {
                throw new RuntimeException("The Map type param error." + e, e);
            }
            versionLocker = m.getAnnotation(Lock.class);
            return versionLocker;
        } else {
            throw new ColaException("Config info error, maybe you have not config the Mapper interface");
        }
    }


    private Class<?> getMapper(MappedStatement ms){
        String namespace = getMapperNamespace(ms);
        Collection<Class<?>> mappers = ms.getConfiguration().getMapperRegistry().getMappers();
        for(Class<?> clazz : mappers){
            if(clazz.getName().equals(namespace)){
                return clazz;
            }
        }
        return null;
    }

    private String getMapperNamespace(MappedStatement ms){
        String id = ms.getId();
        int pos = id.lastIndexOf(".");
        return id.substring(0, pos);
    }

    private String getMapperShortId(MappedStatement ms){
        String id = ms.getId();
        int pos = id.lastIndexOf(".");
        return id.substring(pos+1);
    }

    @Override
    public Object plugin(Object target) {
        if (target instanceof Executor) {
            return Plugin.wrap(target, this);
        } else if (target instanceof StatementHandler) {
            return Plugin.wrap(target, this);
        } else {
            return target;
        }
    }


    @Override
    public void setProperties(Properties properties) {
    }

    private Lock getLock(Invocation invocation){
        MappedStatement ms = (MappedStatement)invocation.getArgs()[0];
        String key = ms.getId() + "_Locker_update";
        boolean boo = cache.containsKey(key);
        if(boo){
            return (Lock)cache.get(key);
        }

        Lock lock = getVersionLocker(ms, invocation.getArgs()[1]);
        cache.put(ms.getId() + "_Locker_update", lock);
        return lock;
    }

    private Lock getLock(MetaObject metaObject, MappedStatement ms){
        String key = ms.getId() + "_Locker_prepare";
        boolean boo = cache.containsKey(key);
        if(boo){
            return (Lock) cache.get(key);
        }
        SqlCommandType sqlCmdType = ms.getSqlCommandType();
        if(sqlCmdType != SqlCommandType.UPDATE) {
            cache.put(ms.getId() + "_Locker_prepare", null);
            return null;
        }
        BoundSql boundSql = (BoundSql) metaObject.getValue(DELEGATE_BOUNDSQL);
        Lock lock = getVersionLocker(ms, boundSql.getParameterObject());
        cache.put(ms.getId() + "_Locker_prepare", lock);
        return lock;
    }

    private OptimisticLocker getOptimisticLocker(MetaObject metaObject, MappedStatement ms){
        String key = ms.getId() + "_OptimisticLocker_prepare";
        boolean boo = cache.containsKey(key);
        if(boo){
            return (OptimisticLocker) cache.get(key);
        }

        Class<?> cls = getMapper(ms);
        OptimisticLocker optimisticLocker = cls.getAnnotation(OptimisticLocker.class);
        cache.put(ms.getId() + "_OptimisticLocker_prepare", optimisticLocker);
        return optimisticLocker;
    }
}
