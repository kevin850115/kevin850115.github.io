package com.alibaba.cola.eagleeye;

import com.alibaba.cola.logger.Logger;
import com.taobao.eagleeye.EagleEye;

/**
 * @author Timothy Li
 * @date 2018/10/16
 */
public class EagleEyeEnableLoggerProxy implements Logger {

    private Logger logger;
    private boolean enableEagleTrace;

    public EagleEyeEnableLoggerProxy(Logger logger) {
        this.logger = logger;
        this.enableEagleTrace = true;
        //isEagleEyeAvailable = true;
    }

    public EagleEyeEnableLoggerProxy(Logger logger, boolean enableEagleTace) {
        this.logger = logger;
        this.enableEagleTrace = enableEagleTace;
    }


    @Override
    public void debug(String msg) {
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.debug(msg);
    }

    private String ofEagleEyeTracePrefix(String msg) {
        if (enableEagleTrace) {
            msg = this.getEagleTrace() + msg;
        }
        return msg;
    }

    /**
     * Log a message at the DEBUG level. support format.
     *
     * @param msg
     * @param args
     */
    @Override
    public void debug(String msg, Object... args){
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.debug(msg,args);
    }

    /**
     * Log a message at the INFO level.
     *
     * @param msg the message string to be logged
     */
    @Override
    public void info(String msg) {
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.info(msg);
    }

    /**
     * Log a message at the INFO level. support format.
     *
     * @param msg
     * @param args
     */
    @Override
    public void info(String msg, Object... args){
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.info(msg,args);
    }

    /**
     * Log a message at the WARN level.
     *
     * @param msg the message string to be logged
     */
    @Override
    public void warn(String msg) {
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.warn(msg);
    }

    /**
     * Log a message at the WARN level. support format.
     *
     * @param msg
     * @param args
     */
    @Override
    public void warn(String msg, Object... args){
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.warn(msg,args);
    }
    /**
     * Log a message at the ERROR level.
     *
     * @param msg the message string to be logged
     */
    @Override
    public void error(String msg) {
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.error(msg);
    }

    /**
     * Log a message at the ERROR level. support format.
     * @param msg
     * @param args
     */
    @Override
    public void error(String msg, Object... args){
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.error(msg,args);
        //error(String.format(msg, args));
    }

    /**
     * Log an exception (throwable) at the ERROR level with an
     * accompanying message.
     *
     * @param msg the message accompanying the exception
     * @param t   the exception (throwable) to log
     */
    @Override
    public void error(String msg, Throwable t) {
        msg = ofEagleEyeTracePrefix(msg);
        this.logger.error(msg,t);
    }

    /**
     * 打标EagleEye [traceId] [rpcId]
     * @return
     */
    private String getEagleTrace() {
        return String.format("[%s] [%s] ", EagleEye.getTraceId(),EagleEye.getRpcId());
    }
}
