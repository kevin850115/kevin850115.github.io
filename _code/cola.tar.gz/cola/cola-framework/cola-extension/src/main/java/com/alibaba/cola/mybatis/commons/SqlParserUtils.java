package com.alibaba.cola.mybatis.commons;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.JdbcParameter;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.operators.arithmetic.Addition;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;
import net.sf.jsqlparser.statement.update.Update;

import java.util.List;

/**
 * sql处理
 * @author shawnzhan.zxy
 * @date 2018/06/19
 */
public class SqlParserUtils {

    private static SqlParserUtils instance = new SqlParserUtils();

    public static SqlParserUtils g(){
        return instance;
    }

    /**
     * 更新语句添加 version字段
     *   update set **,version=version+1 where version=?
     * @param originalSql
     * @param oldVersion
     * @return
     */
    public String addVersionToUpdateSql(String originalSql, int oldVersion){
        try{
            Statement stmt = CCJSqlParserUtil.parse(originalSql);
            if(!(stmt instanceof Update)){
                return originalSql;
            }
            Update update = (Update)stmt;
            if(!contains(update)){
                buildVersionExpression(update);
            }
            Expression where = update.getWhere();
            if(where != null){
                AndExpression and = new AndExpression(where, buildVersionEquals(oldVersion));
                update.setWhere(and);
            }else{
                update.setWhere(buildVersionEquals(oldVersion));
            }
            return stmt.toString();
        }catch(Exception e){
            e.printStackTrace();
            return originalSql;
        }
    }

    /**
     * 是否包含version字段
     * @param update
     * @return
     */
    public boolean contains(Update update){
        List<Column> columns = update.getColumns();
        for(Column column : columns){
            if(column.getColumnName().equalsIgnoreCase("version")){
                return true;
            }
        }
        return false;
    }

    public void buildVersionExpression(Update update){
        List<Column> columns = update.getColumns();
        Column versionColumn = new Column();
        versionColumn.setColumnName("version");
        columns.add(versionColumn);

        List<Expression> expressions = update.getExpressions();
        Addition add = new Addition();
        add.setLeftExpression(versionColumn);
        add.setRightExpression(new LongValue(1));
        expressions.add(add);
    }

    public Expression buildVersionEquals(int oldVersion){
        EqualsTo equal = new EqualsTo();
        Column column = new Column();
        column.setColumnName("version");
        equal.setLeftExpression(column);
//        equal.setRightExpression(new LongValue(oldVersion + ""));
        equal.setRightExpression(new JdbcParameter());
        return equal;
    }

    /**
     * select语句增加version
     *     select xxx,version from tb
     * @param originalSql
     * @return
     */
    public String addVersionToSelectSql(String originalSql){
        try{
            Statement stmt = CCJSqlParserUtil.parse(originalSql);
            if(!(stmt instanceof Select)){
                return originalSql;
            }
            Select select = (Select)stmt;
            PlainSelect plainSelect = (PlainSelect)select.getSelectBody();
            //不支持关联查询
            if(plainSelect.getJoins() != null && plainSelect.getJoins().size() > 0){
                return originalSql;
            }
            boolean isAddVersion = true;
            for(SelectItem item : plainSelect.getSelectItems()){
                if(!(item instanceof SelectExpressionItem)){
                    isAddVersion = false;
                    break;
                }
                SelectExpressionItem selItem = (SelectExpressionItem)item;
                if(!(selItem.getExpression() instanceof Column)){
                    continue;
                }
                Column column = (Column)selItem.getExpression();
                if("version".equals(column.getColumnName().toLowerCase())){
                    isAddVersion = false;
                    break;
                }
            }
            if(isAddVersion){
                plainSelect.getSelectItems().add(new SelectExpressionItem(new Column(null, "version")));
            }
            return stmt.toString();
        }catch(Exception e){
            e.printStackTrace();
            return originalSql;
        }
    }
}
