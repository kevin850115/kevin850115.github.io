package com.alibaba.cola.mybatis.model;

import java.util.List;

/**
 * @author shawnzhan.zxy
 * @date 2018/06/10
 */
public class PaginationResultModel<T> {

    /** 页号*/
    private int pageStart = 0;
    /** 每页显示数*/
    private int pageSize = 10;
    /** 总条数*/
    private int total = 0;
    /** 当前返回条数*/
    private int curCount = 0;

    private List<T> dataLst;

    public int getPageStart() {
        return pageStart;
    }

    public void setPageStart(int pageStart) {
        this.pageStart = pageStart;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCurCount() {
        return curCount;
    }

    public void setCurCount(int curCount) {
        this.curCount = curCount;
    }

    public List<T> getDataLst() {
        return dataLst;
    }

    public void setDataLst(List<T> dataLst) {
        this.dataLst = dataLst;
    }
}
