package com.alibaba.cola.metaq;

import com.alibaba.cola.domain.DomainEventServiceI;
import com.alibaba.cola.dto.DomainEvent;
import com.alibaba.cola.dto.MetaQEvent;
import com.alibaba.cola.event.DomainEventI;
import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import com.taobao.metaq.client.MetaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * DomainEventMetaQService
 *
 * @author Frank Zhang
 * @date 2018-07-30 12:08 PM
 */
@Component
public class DomainEventMetaQService implements DomainEventServiceI {

    private Logger logger = LoggerFactory.getLogger(DomainEventMetaQService.class);
    public static final String METAQ_SEND_ERROR = "alarm_metaq_send_msg_error: ";

    @Autowired(required = false)
    private MetaProducer metaProducer;

    public void setMetaProducer(MetaProducer metaProducer) {
        this.metaProducer = metaProducer;
    }

    /**
     * 通过MetaQ发布领域事件
     *
     * @param event
     */
    @Override
    public void publish(DomainEventI event) {
        if(!(event instanceof DomainEvent)){
            return;
        }
        DomainEvent domainEvent=(DomainEvent)event;

        String body = eventToJson(domainEvent);

        String uuid = UUID.randomUUID().toString();
        domainEvent.setEventId(uuid);

        Message msg = new Message(domainEvent.getEventTopic(),// topic
                domainEvent.getEventType(),// tag
                uuid,// key，消息的Key字段是为了唯一标识消息的，方便运维排查问题。如果不设置Key，则无法定位消息丢失原因。
                (body).getBytes());// body
        try {
            SendResult sendResult = metaProducer.send(msg);
            logger.info("send message[%s] success!SendResult[msgId:%s,sendStatus:%s]", uuid, sendResult.getMsgId(), sendResult.getSendStatus());
        } catch (Exception e) {
            logger.error(METAQ_SEND_ERROR + " ["+uuid+"] ", e);
        }
    }

    private String eventToJson(MetaQEvent metaQEvent){
        return JSON.toJSONString(metaQEvent);
    }

}
