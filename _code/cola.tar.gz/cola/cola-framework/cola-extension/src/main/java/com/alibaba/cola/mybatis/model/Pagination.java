package com.alibaba.cola.mybatis.model;

public class Pagination {
    //页号
    private int pageStart = 0;
    private int pageSize = 10;

    public Pagination() {
    }

    public Pagination(int pageStart, int pageSize) {
        this.pageStart = pageStart;
        this.pageSize = pageSize;
    }

    public void setPageStart(int pageStart) {
        this.pageStart = pageStart;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public int getPageStart() {
        return pageStart;
    }

    public int getStartRowForMysql() {
        int rowIndex = 0;
        if(this.pageStart > 1) {
            rowIndex = (this.pageStart - 1) * this.pageSize;
        }

        return rowIndex;
    }
}
