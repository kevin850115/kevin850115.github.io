package com.alibaba.cola.dto;

import com.alibaba.cola.event.DomainEventI;

/**
 * @author: caiqiang.w
 * @date: 2019/2/18
 * @description:
 */
public abstract class DomainEvent extends MetaQEvent implements DomainEventI {
    /**
     * 领域的操作人
     */
    private String operator;

    /**
     * EventType 对应MetaQ中的Tag, 默认为Class Type，方便在Consumer中反序列化
     *
     * @return
     */
    @Override
    public String getEventType(){
        return this.getClass().getTypeName();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
