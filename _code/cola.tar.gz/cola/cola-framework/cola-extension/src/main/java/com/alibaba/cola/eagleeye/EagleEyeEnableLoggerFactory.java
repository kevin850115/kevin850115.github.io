package com.alibaba.cola.eagleeye;

import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;

/**
 * @author Timothy Li
 * @date 2018/10/16
 */
public class EagleEyeEnableLoggerFactory {

    private static boolean useEagleEye = true;

    /**
     * This is just for test purpose, don't use it on product!
     */
    public static void activateEagleEyeLogger() {
        useEagleEye = true;
    }

    public static void deactivateEagleEyeLogger() {
        useEagleEye = false;
    }

    public static Logger getLogger(String loggerName, boolean enableEagleEye) {

        Logger logger = LoggerFactory.getLogger(loggerName);
        if(!useEagleEye){
            return logger;
        }
        EagleEyeEnableLoggerProxy eagleEyeEnableLoggerProxy = new EagleEyeEnableLoggerProxy(logger,enableEagleEye);
        return eagleEyeEnableLoggerProxy;

    }

    public static Logger getLogger(String loggerName) {
        return getLogger(loggerName,true);

    }

    public static Logger getLogger(Class<?> clazzName,boolean enableEagleEye) {

        Logger logger = LoggerFactory.getLogger(clazzName);
        if(!useEagleEye){
            return logger;
        }
        EagleEyeEnableLoggerProxy eagleEyeEnableLoggerProxy = new EagleEyeEnableLoggerProxy(logger,enableEagleEye);
        return eagleEyeEnableLoggerProxy;

    }

    public static Logger getLogger(Class<?> clazzName) {
        return getLogger(clazzName,true);
    }
}

