package com.alibaba.cola.dto;

import com.alibaba.cola.event.MessageQueueEventI;

/**
 *
 * @author shawnzhan.zxy
 * @date 2017/11/17
 */
public abstract class MetaQEvent extends DTO implements MessageQueueEventI {
    protected String eventId;
    protected String eventType;
    protected String eventTopic;

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public String getEventType() {
        return eventType;
    }

    @Override
    public String getEventTopic() {
        return eventTopic;
    }

    public void setEventTopic(String eventTopic) {
        this.eventTopic = eventTopic;
    }

}
