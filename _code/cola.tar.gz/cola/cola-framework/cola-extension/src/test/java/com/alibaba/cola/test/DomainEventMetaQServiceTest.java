package com.alibaba.cola.test;

import com.alibaba.cola.TestConfig;
import com.alibaba.cola.metaq.DomainEventMetaQService;
import com.taobao.metaq.client.MetaProducer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * DomainEventMetaQServiceTest
 *
 * @author Frank Zhang
 * @date 2018-07-30 3:07 PM
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {TestConfig.class})
public class DomainEventMetaQServiceTest {

    @Autowired
    private DomainEventMetaQService domainEventMetaQService;

    @Test
    public void testMetaQProducer() throws Exception{
        MetaProducer producer = new MetaProducer("sofaTest");
        producer.start();

        domainEventMetaQService.setMetaProducer(producer);

        CustomerCreatedEvent customerCreatedEvent = new CustomerCreatedEvent();
        customerCreatedEvent.setCustomerId(12213);
        customerCreatedEvent.setKeyPerson("FrankZhang");
        customerCreatedEvent.setName("Alibaba");
        customerCreatedEvent.setRegisterAmount("10000万");

        domainEventMetaQService.publish(customerCreatedEvent);
    }

}
