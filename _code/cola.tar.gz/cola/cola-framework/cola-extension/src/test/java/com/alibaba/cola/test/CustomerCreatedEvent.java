package com.alibaba.cola.test;

import com.alibaba.cola.dto.MetaQEvent;
import com.alibaba.cola.event.DomainEventI;
import lombok.Data;

/**
 * CustomerCreatedEvent
 *
 * @author Frank Zhang
 * @date 2018-07-30 3:31 PM
 */
@Data
public class CustomerCreatedEvent extends MetaQEvent implements DomainEventI {

    public final static String TOPIC = "ALICRM_DOMAIN_EVENT";

    private long customerId;

    private String name;

    private String registerAmount;

    private String keyPerson;

    @Override
    public String getEventTopic() {
        return TOPIC;
    }
}
