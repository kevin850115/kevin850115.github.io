package com.alibaba.cola;

import com.alibaba.cola.boot.Bootstrap;
import org.springframework.context.annotation.*;

/**
 * TestConfig
 *
 * @author Frank Zhang 2018-01-06 7:57 AM
 */
@Configuration
@ComponentScan("com.alibaba.cola")
@PropertySource(value = {"/sample.properties"})
public class TestConfig {

    @Bean(initMethod = "init")
    public Bootstrap bootstrap() {
        System.out.println("Spring Container Started");
        return null;
    }
}
