package com.alibaba.cola.mock.proxy;

/**
 * @author shawnzhan.zxy
 * @date 2019/06/20
 */
public interface ColaProxyI {

    public Object getInstance();
}
