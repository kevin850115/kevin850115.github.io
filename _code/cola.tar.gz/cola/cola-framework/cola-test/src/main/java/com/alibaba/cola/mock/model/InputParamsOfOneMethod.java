package com.alibaba.cola.mock.model;

/**
 * bei.fengb 2018-09-24 08:21
 */
public class InputParamsOfOneMethod {

    private Object[] inutParams;

    public Object[] getInutParams() {
        return inutParams;
    }

    public void setInutParams(Object[] inutParams) {
        this.inutParams = inutParams;
    }
}
