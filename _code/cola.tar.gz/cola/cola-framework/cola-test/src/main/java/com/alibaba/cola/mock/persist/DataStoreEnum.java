package com.alibaba.cola.mock.persist;

/**
 * @author shawnzhan.zxy
 * @date 2018/09/12
 */
public enum DataStoreEnum {
    JSON_STORE,BYTE_STORE
}
