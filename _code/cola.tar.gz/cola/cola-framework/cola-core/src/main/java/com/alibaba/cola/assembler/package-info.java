/**
 * Assembler classes used to assemble parameters to invoke other layer or other services.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.assembler;