/**
 * This package contains {@link CommandExecutorI} and {@link QueryExecutorI} to process {@link com.alibaba.cola.dto.Command} from client.
 *
 * @author fulan.zjf
 */
package com.alibaba.cola.command;
