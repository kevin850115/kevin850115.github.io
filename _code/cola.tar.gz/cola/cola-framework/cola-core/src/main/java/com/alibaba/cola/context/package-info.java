/**
 * Domain objects (Entity) contains the core logic of Domain.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.context;