package com.alibaba.cola.context;

/**
 * SofaContext上下文信息标识接口
 * 所有实现SofaContextSupprot接口的类，均可以通过SofaContext来进行管理
 *
 * @author niexiaolong
 * @date 2018/6/25
 */
public interface ColaContextSupprot {

}
