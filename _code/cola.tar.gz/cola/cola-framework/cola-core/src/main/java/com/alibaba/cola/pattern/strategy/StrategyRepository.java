package com.alibaba.cola.pattern.strategy;

import com.alibaba.cola.exception.ColaException;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * StrategyRepository
 *
 * @author Frank Zhang
 * @date 2018-08-07 11:27 AM
 */
@Component
public class StrategyRepository {

    @Getter
    private Map<Class<? extends StrategyI>, StrategyI> strategyRepo = new HashMap<>();
    @Getter
    private Map<String, StrategyI> namedStrategyRepo = new HashMap<>();

    public StrategyI get(String name){
        StrategyI strategyInstance = namedStrategyRepo.get(name);
        if (strategyInstance == null)
            throw new ColaException("There is no Strategy Registered with name " + name);
        return strategyInstance;
    }
}
