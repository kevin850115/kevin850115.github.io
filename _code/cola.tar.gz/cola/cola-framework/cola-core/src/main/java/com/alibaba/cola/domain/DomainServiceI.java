package com.alibaba.cola.domain;

/**
 * 领域服务，继承自DomainServiceI的接口都认为是DomainAbility
 * @author xueliang.sxl
 *
 */
public interface DomainServiceI {

}
