package com.alibaba.cola.cache.annotation;

import com.alibaba.cola.cache.SupportedCacheTypeEnum;
import com.alibaba.cola.cache.key.CacheKeyGenStrategyEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by damon on 2018/9/11.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface HotCache {
    /**
     * key前缀
     * @return
     */
    String cacheKeyPrefix();

    /**
     * 缓存key生成策略
     * @return
     */
    CacheKeyGenStrategyEnum keyGenStrategy() default CacheKeyGenStrategyEnum.tostring;
    /**
     * null是否需要存储到缓存
     * @return
     */
    boolean nullNeedStored() default false;
    /**
     * 过期时长，单位seconds
     * @return
     */
    int expireTime() default 86400;

    /**
     * 默认支持远程缓存
     * @return
     */
    SupportedCacheTypeEnum cacheType() default SupportedCacheTypeEnum.REMOTE;
}
