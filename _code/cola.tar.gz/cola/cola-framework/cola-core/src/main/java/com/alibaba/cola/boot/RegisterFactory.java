/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.cola.boot;

import com.alibaba.cola.command.*;
import com.alibaba.cola.common.ColaConstant;
import com.alibaba.cola.event.EventHandler;
import com.alibaba.cola.exception.ColaException;
import com.alibaba.cola.extension.Extension;
import com.alibaba.cola.pattern.strategy.Strategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * RegisterFactory
 *
 * @author fulan.zjf 2017-11-04
 */
@Component
public class RegisterFactory{

    @Autowired
    private PreInterceptorRegister preInterceptorRegister;
    @Autowired
    private PostInterceptorRegister postInterceptorRegister;
    @Autowired
    private CommandRegister commandRegister;
    @Autowired
    private ExtensionRegister extensionRegister;
    @Autowired
    private EventRegister eventRegister;
    @Autowired
    private PlainValidatorRegister plainValidatorRegister;
    @Autowired
    private PlainRuleRegister plainRuleRegister;
    @Autowired
    private StrategyRegister strategyRegister;

    public RegisterI getRegister(Class<?> targetClz) {
        PreInterceptor preInterceptorAnn = targetClz.getDeclaredAnnotation(PreInterceptor.class);
        if (preInterceptorAnn != null) {
            return preInterceptorRegister;
        }
        PostInterceptor postInterceptorAnn = targetClz.getDeclaredAnnotation(PostInterceptor.class);
        if (postInterceptorAnn != null) {
            return postInterceptorRegister;
        }
        Command commandAnn = targetClz.getDeclaredAnnotation(Command.class);
        if (commandAnn != null) {
            return commandRegister;
        }
        Extension extensionAnn = targetClz.getDeclaredAnnotation(Extension.class);
        if (extensionAnn != null) {
            return extensionRegister;
        }
        if (isPlainValidator(targetClz)) {
            return plainValidatorRegister;
        }
        if (isPlainRule(targetClz)) {
            return plainRuleRegister;
        }
        EventHandler eventHandlerAnn = targetClz.getDeclaredAnnotation(EventHandler.class);
        if (eventHandlerAnn != null) {
            return eventRegister;
        }
        Strategy strategy = targetClz.getDeclaredAnnotation(Strategy.class);
        if(strategy != null){
            return strategyRegister;
        }
        return null;
    }

    private boolean isPlainRule(Class<?> targetClz) {
        if (ClassInterfaceChecker.check(targetClz, ColaConstant.RULEI_CLASS) && makeSureItsNotExtensionPoint(targetClz)) {
            return true;
        }
        return false;
    }

    private boolean isPlainValidator(Class<?> targetClz) {
        if (ClassInterfaceChecker.check(targetClz, ColaConstant.VALIDATORI_CLASS) && makeSureItsNotExtensionPoint(targetClz)) {
            return true;
        }
        return false;
    }

    private boolean makeSureItsNotExtensionPoint(Class<?> targetClz) {
        if (ClassInterfaceChecker.check(targetClz, ColaConstant.EXTENSIONPOINT_CLASS)) {
            throw new ColaException(
                "Please add @Extension for " + targetClz.getSimpleName() + " since it's a ExtensionPoint");
        }
        return true;
    }
}
