package com.alibaba.cola.boot;

import com.alibaba.cola.common.ApplicationContextHelper;
import com.alibaba.cola.common.ColaConstant;
import com.alibaba.cola.exception.ColaException;
import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import com.alibaba.cola.pattern.strategy.Strategy;
import com.alibaba.cola.pattern.strategy.StrategyI;
import com.alibaba.cola.pattern.strategy.StrategyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * StrategyRegister
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:07 PM
 */
@Component
public class StrategyRegister extends AbstractRegister {
    private Logger logger = LoggerFactory.getLogger(StrategyRegister.class);

    @Autowired
    private StrategyRepository strategyRepository;

    @Override
    public void doRegistration(Class<?> targetClz) {
        StrategyI strategyInstance = (StrategyI)ApplicationContextHelper.getBean(targetClz);
        strategyRepository.getStrategyRepo().put(strategyInstance.getClass(), strategyInstance);

        Strategy strategyAnn = targetClz.getDeclaredAnnotation(Strategy.class);
        String strategyName = strategyAnn.name();
        if(ColaConstant.DEFAULT_STRATEGY_NAME.equals(strategyName))
            return;

        if(strategyRepository.getNamedStrategyRepo().get(strategyName) != null){
            throw new ColaException("Strategy Name ["+strategyName+"] is already registered");
        }
        strategyRepository.getNamedStrategyRepo().put(strategyName, strategyInstance);
        logger.debug("Registered Strategy Name is " + strategyName);

    }

}
