/**
 * This package contains Bootstrap class of Application.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.boot;