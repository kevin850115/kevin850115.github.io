package com.alibaba.cola.cache.key;

import com.alibaba.cola.exception.Preconditions;

/**
 * created by damon on 2018/12/17
 */
public class CacheKeyGenerator {

    public static final String CONNECTOR = "_";
    private static final String NULL_SUB_KEY = "null";
    /**
     * 需要注意如果入参比较复杂，最好是实现了toString方法的
     * 但是一般都是key-value形式的比较适合做缓存，具体使用时，大家要确认一下
     * @return
     */
    public static String generateKeyByParams(String cacheKeyPrefix, Object[] params, CacheKeyGenStrategyEnum strategy){

        Preconditions.checkArgument(strategy != null, "stragegy is null");


        String coreKeyStr = "";

        if(CacheKeyGenStrategyEnum.tostring == strategy){
            coreKeyStr = generateCoreKeyStr(params);
        }

        return cacheKeyPrefix + CONNECTOR + coreKeyStr;
    }

    private static String generateCoreKeyStr(Object[] params) {
        StringBuilder keyBuilder = new StringBuilder();
        String coreKeyStr = null;
        for(Object param : params){
            if(null == param){
                keyBuilder.append(CONNECTOR).append(NULL_SUB_KEY);
            }else {
                keyBuilder.append(CONNECTOR).append(param.toString());
            }
        }

        coreKeyStr = keyBuilder.toString();
        if(coreKeyStr.length()> 0){
            coreKeyStr = coreKeyStr.substring(1,keyBuilder.length());
        }
        return coreKeyStr;
    }
}
