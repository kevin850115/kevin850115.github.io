package com.alibaba.cola.optimisticlocker;

/**
 * @author shawnzhan.zxy
 * @date 2018/06/07
 */
public interface OptimisticLockerCache {

    public boolean obtainLock(String key);

    public void releaseLock(String key);
}
