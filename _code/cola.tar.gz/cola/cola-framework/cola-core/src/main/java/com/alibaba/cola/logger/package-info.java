/**
 * CRM Logger is used to decouple and uniform logger usage with different vendors, typical DIP.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.logger;