/**
 * Use {@link ExtensionPointI} to declare extension point, and use {@link Extension} Annotation to mark specific Extension.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.extension;