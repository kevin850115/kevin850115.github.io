package com.alibaba.cola.cache.aop;

import com.alibaba.cola.cache.annotation.HotCache;
import com.alibaba.cola.cache.annotation.HotCacheEnable;
import com.alibaba.cola.cache.annotation.HotCacheInvalidate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.StaticMethodMatcherPointcut;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * 解决仅有注解打在接口上的情况
 * created by damon on 2018/12/13
 */
public class CacheAnnotationOnInterfacePointCut extends StaticMethodMatcherPointcut implements ClassFilter {

    private static final Logger logger = LoggerFactory.getLogger(CacheAnnotationOnInterfacePointCut.class);
    public static final String IBATIS_MAPPER_PROXY = "com.sun.proxy";
    private String[] basePackages = new String[]{IBATIS_MAPPER_PROXY};

    public CacheAnnotationOnInterfacePointCut(String[] basePackages) {
        setClassFilter(this);
        this.basePackages = basePackages;
    }

    @Override
    public boolean matches(Class clazz) {
        boolean b = matchesImpl(clazz);
        logger.trace("check class match {}: {}", b, clazz);
        return b;
    }

    private boolean matchesImpl(Class clazz) {
        if (matchesThis(clazz)) {
            return true;
        }
        Class[] cs = clazz.getInterfaces();
        if (cs == null) {
            return false;
        }

        for (Class c : cs) {
            if (matchesImpl(c)) {
                return true;
            }
        }

        return false;
    }

    public boolean matchesThis(Class clazz) {
        String name = clazz.getName();
        if (exclude(name)) {
            return false;
        }
        boolean isIncluded = include(name);
        if(!isIncluded){
            return false;
        }

        boolean isNeedCacheEnabled = false;
        Annotation[] classAnnotations = clazz.getAnnotations();

        if(classAnnotations == null || classAnnotations.length==0){
            return isNeedCacheEnabled;
        }

        for(Annotation annotation : classAnnotations){
            if(annotation.annotationType() == HotCacheEnable.class){
                isNeedCacheEnabled = true;
                break;
            }
        }
        return isNeedCacheEnabled;
    }


    private boolean include(String name) {
        if (basePackages == null) {
           return false;
        }

        for (String p : basePackages) {
            if (name.startsWith(p)) {
                return true;
            }
        }

        return false;
    }

    private boolean exclude(String name) {
        if (name.startsWith("java")) {
            return true;
        }
        if (name.startsWith("org.springframework")) {
            return true;
        }
        if (name.indexOf("$$EnhancerBySpringCGLIB$$") >= 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean matches(Method method, Class targetClass) {
        if (!matches(method.getDeclaringClass())) {
            return false;
        }

        Class realClass = getBeingCacheAnnotationedClass(targetClass);
        try {
            Method realMethod = realClass.getDeclaredMethod(method.getName(), method.getParameterTypes());
            Annotation[] methodAnnotations = realMethod.getAnnotations();
            if (methodAnnotations == null || methodAnnotations.length == 0) {
                return false;
            }

            for (Annotation annotation : methodAnnotations) {
                if (annotation.annotationType() == HotCache.class ||
                    annotation.annotationType() == HotCacheInvalidate.class) {
                    return true;
                }
            }
        }catch (NoSuchMethodException e) {
            logger.trace("check class match {}: {}", method.getName(), targetClass.getCanonicalName());
        }

        return false;

    }


    private Class<?> getBeingCacheAnnotationedClass(Class clazz){

        if (matchesThis(clazz)) {
            return clazz;
        }
        Class[] cs = clazz.getInterfaces();
        if(cs == null){
            return null;
        }

        for (Class c : cs) {
            if (matchesImpl(c)) {
                return c;
            }
        }

        return null;
    }


}
