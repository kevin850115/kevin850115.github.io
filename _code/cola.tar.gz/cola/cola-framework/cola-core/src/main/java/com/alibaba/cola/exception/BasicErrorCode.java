package com.alibaba.cola.exception;

/**
 *
 * 参数错误：1000 - 1999
 * 业务错误：2000 - 2999
 * 基础错误：3000 - 3999
 * 系统错误：4000 - 4999
 *
 * Created by fulan.zjf on 2017/12/18.
 */
public enum BasicErrorCode implements ErrorCodeI{
    /**
     *
     * 原来:errCode=1000，PARAM_ERROR
     */
    B_PARAM_ERROR("B_PARAM_ERROR" , "参数错误"),
    /**
     * Business Exception
     *
     * You can extend it by implementing ErrorCodeI in your Application
     * For example:
     *
     * <pre class="code">
     * B_CUSTOMER_NameIsNull("B_CUSTOMER_NameIsNull","客户姓名不能为空")
     * B_CUSTOMER_NameAlreadyExist("B_CUSTOMER_NameAlreadyExist","客户姓名已经存在")
     * </pre>
     * 原来:errCode=2000，BIZ_ERROR
     *
     */
    B_COMMON_ERROR("B_COMMON_ERROR" , "通用的业务逻辑错误"),

    /**
     * System Exception
     * You can extend it by implementing ErrorCodeI in your Application
     * 原来:errCode=3000，INFRA_ERROR
     */
    S_COLA_ERROR("S_COLA_ERROR" , "COLA框架错误"),
    /**
     */
    S_DB_ERROR("S_DB_ERROR", "数据库错误"),
    S_RPC_ERROR("S_RPC_ERROR", "远程方法调用错误"),
    /**
     * 原来:errCode=4000，SYS_ERROR
     */
    S_UNKNOWN("S_UNKNOWN" , "未知的系统错误" );

    private String errCode;
    private String errDesc;

    private BasicErrorCode(String errCode, String errDesc){
        this.errCode = errCode;
        this.errDesc = errDesc;
    }

    @Override
    public String getErrCode() {
        return errCode;
    }

    @Override
    public String getErrDesc() {
        return errDesc;
    }
}
