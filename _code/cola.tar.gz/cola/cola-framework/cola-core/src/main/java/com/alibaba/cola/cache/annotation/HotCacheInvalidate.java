package com.alibaba.cola.cache.annotation;

import com.alibaba.cola.cache.key.CacheKeyGenStrategyEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * created by damon on 2018/12/11
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface HotCacheInvalidate {
    /**
     * 缓存前缀
     * @return
     */
    String cacheKeyPrefix();

    /**
     * 入参生成key策略
     * @return
     */
    CacheKeyGenStrategyEnum keyGenStrategy() default CacheKeyGenStrategyEnum.tostring;

    /**
     * null是否需要存储到缓存
     * @return
     */
    boolean nullNeedStored() default false;

}