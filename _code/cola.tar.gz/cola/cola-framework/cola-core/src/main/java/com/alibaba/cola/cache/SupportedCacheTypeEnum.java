package com.alibaba.cola.cache;

/**
 * created by damon on 2018/12/16
 */
public enum SupportedCacheTypeEnum {
    REMOTE("远程缓存"),
    LOCAL("本地缓存"),
    BOTH("远程+本地量级缓存");
    private String desc;
    SupportedCacheTypeEnum(String desc){
        this.desc = desc;
    }
}
