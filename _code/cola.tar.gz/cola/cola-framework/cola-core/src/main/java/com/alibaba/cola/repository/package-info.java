/**
 * Repository pattern is used to decouple domain layer with different data tunnels.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.repository;