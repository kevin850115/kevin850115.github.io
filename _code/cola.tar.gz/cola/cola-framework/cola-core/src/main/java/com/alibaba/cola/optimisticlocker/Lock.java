package com.alibaba.cola.optimisticlocker;

import java.lang.annotation.*;

/**
 * @author shawnzhan.zxy
 * @date 2018/06/07
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface Lock {
    /** 当使用缓存时需要，key值前缀*/
    String prefix() default "";
    /** 当使用缓存时需要，用hashCode做为key值*/
    boolean useHashCodeForKey() default false;
    /** 更新失败抛异常； 只要返回更新条数为0则认为是失败*/
    boolean updateFailThrowException() default false;
}
