/**
 * Use {@link com.alibaba.cola.rule.RuleI} to declare Rule, and use {@link com.alibaba.cola.extension.Extension} if this Rule needs Extension.
 *
 * @author fulan.zjf
 * @date 2017/12/22
 */
package com.alibaba.cola.rule;