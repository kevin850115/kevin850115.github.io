/**
 * Convertors are used to convert objects among Client Object, Domain Object and Data Object.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.convertor;