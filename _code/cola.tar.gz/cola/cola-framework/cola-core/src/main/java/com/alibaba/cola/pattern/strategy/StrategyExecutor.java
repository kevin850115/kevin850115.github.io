package com.alibaba.cola.pattern.strategy;

import com.alibaba.cola.boot.AbstractComponentExecutor;
import com.alibaba.cola.context.Context;
import com.alibaba.cola.exception.ColaException;
import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * StrategyExecutor
 *
 * @author Frank Zhang
 * @date 2018-08-07 11:28 AM
 */
@Component
public class StrategyExecutor extends AbstractComponentExecutor {
    private Logger logger = LoggerFactory.getLogger(StrategyExecutor.class);

    @Autowired
    private StrategyRepository strategyRepository;


    @Override
    protected <C> C locateComponent(Class<C> targetClz, Context context) {
        logger.debug("Strategy impl class: " + targetClz);
        C strategyImpl =  (C) strategyRepository.getStrategyRepo().get(targetClz);
        if(strategyImpl == null){
            throw new ColaException("Can not find Strategy implementation with: "+targetClz);
        }
        return strategyImpl;
    }
}
