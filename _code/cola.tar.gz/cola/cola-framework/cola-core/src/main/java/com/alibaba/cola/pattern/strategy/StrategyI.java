package com.alibaba.cola.pattern.strategy;

/**
 * StrategyI 策略模式的公共接口
 *
 * @author Frank Zhang
 * @date 2018-08-07 11:25 AM
 */
public interface StrategyI {
}
