package com.alibaba.cola.pattern.strategy;

import com.alibaba.cola.common.ColaConstant;
import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * Strategy
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:06 PM
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Component
public @interface Strategy {
    String name() default ColaConstant.DEFAULT_STRATEGY_NAME;
}
