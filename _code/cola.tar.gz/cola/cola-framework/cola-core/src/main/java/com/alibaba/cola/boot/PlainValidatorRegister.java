package com.alibaba.cola.boot;

import com.alibaba.cola.common.ApplicationContextHelper;
import com.alibaba.cola.validator.PlainValidatorRepository;
import com.alibaba.cola.validator.ValidatorI;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Plain Validator is Validator Component without ExtensionPoint
 * @author fulan.zjf
 * @date 2017/12/21
 */
@Component
public class PlainValidatorRegister implements RegisterI {

    @Autowired
    private PlainValidatorRepository plainValidatorRepository;

    @Override
    public void doRegistration(Class<?> targetClz) {
        ValidatorI plainValidator= (ValidatorI) ApplicationContextHelper.getBean(targetClz);
        plainValidatorRepository.getPlainValidators().put(plainValidator.getClass(), plainValidator);
    }
}
