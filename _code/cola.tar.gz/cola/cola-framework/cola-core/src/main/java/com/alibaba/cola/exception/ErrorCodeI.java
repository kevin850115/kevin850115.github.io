package com.alibaba.cola.exception;

/**
 * Extends your error codes in your App by implements this Interface.
 *
 * Created by fulan.zjf on 2017/12/18.
 */
public interface ErrorCodeI {

    public String getErrCode();

    public String getErrDesc();

}
