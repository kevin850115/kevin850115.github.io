package com.alibaba.cola.cache.aop;

import com.alibaba.cola.cache.Cache;
import com.alibaba.cola.cache.annotation.HotCache;
import com.alibaba.cola.cache.annotation.HotCacheInvalidate;
import com.alibaba.cola.cache.key.CacheKeyGenerator;
import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * 热点缓存持久化/失效拦截器
 * Created by damon on 2018/9/10.
 *
 */
public class HotCacheInterceptor implements MethodInterceptor {

    private Logger logger = LoggerFactory.getLogger(HotCacheInterceptor.class);

    private Cache cacheManager;
    private Map<String, String> dynamicConfig = null;


    private static final String NULL_VALUE = "null_value";


    @Override
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {
        Method m = methodInvocation.getMethod();
        HotCache hotCache = m.getAnnotation(HotCache.class);

        if (hotCache != null) {
            return executeQueryCachable(methodInvocation, hotCache);
        }

        HotCacheInvalidate cacheInvalidate = m.getAnnotation(HotCacheInvalidate.class);
        if (cacheInvalidate != null) {
            return executeUpdateWithCacheInvalidate(methodInvocation, cacheInvalidate);
        }

        return methodInvocation.proceed();
    }

    private Object executeUpdateWithCacheInvalidate(MethodInvocation methodInvocation,
                                                    HotCacheInvalidate cacheInvalidate) throws Throwable {
        String cacheKeyPrefix = cacheInvalidate.cacheKeyPrefix();
        String realKeyPrefix = getRealPrefix(cacheKeyPrefix);
        Object[] params = methodInvocation.getArguments();
        String realKey = CacheKeyGenerator.generateKeyByParams(realKeyPrefix, params,  cacheInvalidate.keyGenStrategy());

        try {
            Object result = cacheManager.get(realKey);
            if (result != null) {
                cacheManager.invalid(realKey);
            }
        } catch (Throwable e) {
            logger.error("invalidate cache error, realKey is : " + realKey, e);
            //出错再试一次
            try {
                for (int i = 0; i < 3; i++) {
                    boolean isSucess = cacheManager.invalid(realKey);
                    if (isSucess) {
                        logger.info("retry invalidate cache success, realKey is : " + realKey);
                        break;
                    }
                }
            } catch (Throwable e2) {
                logger.error("retry failed, realKey is +  " + realKey, e2);
            }

        }

        //返回真正的值
        Object realTimeResult = methodInvocation.proceed();
        return realTimeResult;
    }

    private Object executeQueryCachable(MethodInvocation methodInvocation, HotCache hotCache) throws Throwable {

        int expireTime = hotCache.expireTime();
        String cacheKeyPrefix = hotCache.cacheKeyPrefix();
        int realExpireTime = getRealExpireTime(cacheKeyPrefix,expireTime);
        String realKeyPrefix = getRealPrefix(cacheKeyPrefix);

        Object[] params = methodInvocation.getArguments();
        String realKey = CacheKeyGenerator.generateKeyByParams(realKeyPrefix, params, hotCache.keyGenStrategy());
        try {
            Object result = cacheManager.get(realKey);
            if (result != null) {
                result = restoreNullValueIfNeeded(hotCache, result);
                return result;
            }
        } catch (Throwable e) {
            logger.error("acquire from cache error", e);
        }

        //返回真正的值
        Object realTimeResult = methodInvocation.proceed();

        if (realTimeResult != null) {
            try {
                cacheManager.set(realKey, (Serializable)realTimeResult, realExpireTime);
            } catch (Throwable e) {
                logger.error("set cache error, realkey is:" + realKey, e);
            }
        } else if (hotCache.nullNeedStored()) {
            try {
                cacheManager.set(realKey, NULL_VALUE, realExpireTime);
            } catch (Throwable e) {
                logger.error("set cache error, realkey is:" + realKey, e);
            }
        }

        return realTimeResult;
    }

    /**
     * 将存入的null字符串还原为null
     * @param hotCache
     * @param result
     * @return
     */
    private Object restoreNullValueIfNeeded(HotCache hotCache, Object result) {
        if(hotCache.nullNeedStored() && NULL_VALUE.equals(result.toString())){
            result = null;
        }
        return result;
    }



    public void setCacheManager(Cache cacheManager) {
        this.cacheManager = cacheManager;
    }

    public void setDynamicConfig(Map<String, String> dynamicConfig) {
        this.dynamicConfig = dynamicConfig;
    }

    /**
     * 如有动态前缀优先取动态前缀，可以瞬间失效所有该前缀下的热点缓存
     * @param annotationPrefix
     * @return
     */
    private String getRealPrefix(String annotationPrefix){
        String dynamicPrefix = getDynamicPrefix(annotationPrefix + CacheKeyGenerator.CONNECTOR + "prefix");
        if(dynamicPrefix == null || dynamicPrefix.length() ==0){
            return annotationPrefix;
        }else{
            return dynamicPrefix;
        }
    }

    private int getRealExpireTime(String annotationPrefix, int annotationExpireTime){
        String dynamicExpireTimeStr = getDynamicPrefix(annotationPrefix + CacheKeyGenerator.CONNECTOR + "expireTime");
        if(dynamicExpireTimeStr == null || dynamicExpireTimeStr.length()==0){
            return annotationExpireTime;
        }else{
            return Integer.valueOf(dynamicExpireTimeStr);
        }
    }

    private String getDynamicPrefix(String prefix){
        if(dynamicConfig == null){
            return null;
        }
        String value = dynamicConfig.get(prefix);
        return value;
    }
}
