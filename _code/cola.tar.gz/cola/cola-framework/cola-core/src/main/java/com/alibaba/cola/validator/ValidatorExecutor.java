/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.cola.validator;

import com.alibaba.cola.context.Context;
import com.alibaba.cola.extension.ExtensionExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ValidatorExecutor
 * 
 * @author fulan.zjf 2017-11-04
 */
@Component
public class ValidatorExecutor extends ExtensionExecutor {

    @Autowired
    private PlainValidatorRepository plainValidatorRepository;

    public void validate(Class<? extends ValidatorI> targetClz,Context context,Object candidate) {
        ValidatorI validator = locateComponent(targetClz,context);
        validator.validate(candidate);
    }

    @Override
    protected <C> C locateComponent(Class<C> targetClz, Context context) {
        C validator = (C) plainValidatorRepository.getPlainValidators().get(targetClz);
        return null != validator ? validator : super.locateComponent(targetClz,context);
    }

}