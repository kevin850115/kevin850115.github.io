package com.alibaba.cola.convertor;

/**
 * Convertor  are used to convert Objects among Client Object, Domain Object and Data Object.
 *
 * @author fulan.zjf on 2017/12/16.
 */
public interface ConvertorI{
}

