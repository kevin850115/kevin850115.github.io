package com.alibaba.cola.boot;

import com.alibaba.cola.common.ApplicationContextHelper;
import com.alibaba.cola.rule.PlainRuleRepository;
import com.alibaba.cola.rule.RuleI;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Plain Rule is Rule Component without ExtensionPoint
 * @author fulan.zjf
 * @date 2017/12/21
 */
@Component
public class PlainRuleRegister implements RegisterI {

    @Autowired
    private PlainRuleRepository plainRuleRepository;

    @Override
    public void doRegistration(Class<?> targetClz) {
        RuleI plainRule = (RuleI) ApplicationContextHelper.getBean(targetClz);
        plainRuleRepository.getPlainRules().put(plainRule.getClass(), plainRule);
    }
}
