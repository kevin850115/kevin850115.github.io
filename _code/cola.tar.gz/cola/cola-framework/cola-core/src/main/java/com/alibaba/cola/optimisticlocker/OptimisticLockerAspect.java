package com.alibaba.cola.optimisticlocker;

import com.alibaba.cola.common.ApplicationContextHelper;
import com.alibaba.cola.exception.ColaException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * @author shawnzhan.zxy
 * @date 2018/06/07
 */
@Aspect
@Component
public class OptimisticLockerAspect {
    private static final String OPTIMISTIC_LOCKER_PREFIX = "PL_";

    @Around("@annotation(com.alibaba.cola.optimisticlocker.Lock)")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        Class<?> targetCls = pjp.getTarget().getClass();
        OptimisticLocker optimisticLocker = targetCls.getDeclaredAnnotation(OptimisticLocker.class);
        OptimisticLockerCache cache = getCache(optimisticLocker.cacheName());

        Signature sig = pjp.getSignature();
        MethodSignature msig = null;
        if (!(sig instanceof MethodSignature)) {
            throw new IllegalArgumentException("该注解只能用于方法");
        }
        msig = (MethodSignature) sig;
        Object target = pjp.getTarget();
        Method method = target.getClass().getMethod(msig.getName(), msig.getParameterTypes());
        Lock lock = method.getAnnotation(Lock.class);
        String key = null;
        StringBuilder sbKey = new StringBuilder(OPTIMISTIC_LOCKER_PREFIX + lock.prefix());
        if(lock.useHashCodeForKey()){

            if(pjp.getArgs() != null && pjp.getArgs().length > 0){
                long cnt = 0;
                for(int i = 0; i < pjp.getArgs().length; i++){
                    cnt += pjp.getArgs()[i].hashCode();
                }
                sbKey.append(cnt);
            }
            key = sbKey.toString();
        }

        try {
            if (cache.obtainLock(key)) {
                return pjp.proceed();
            } else {
                throw new ColaException("cannot obtain OptimisticLocker! version conflict");
            }
        }finally {
            cache.releaseLock(key);
        }
    }


    private OptimisticLockerCache getCache(String cacheName){
        OptimisticLockerCache cache = (OptimisticLockerCache)ApplicationContextHelper.getBean(cacheName);
        if(cache == null){
            throw new ColaException(cacheName + " cannot find in spring container ");
        }
        return cache;
    }
}
