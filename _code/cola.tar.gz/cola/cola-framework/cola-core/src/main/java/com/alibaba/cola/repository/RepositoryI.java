package com.alibaba.cola.repository;

/**
 * This is Repository pattern which decouples the data access from concrete data tunnels.
 * 
 * @author fulan.zjf 2017年10月27日 上午11:07:26
 */
public interface RepositoryI {
}
