/**
 * 领域模型抽象层
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.domain;