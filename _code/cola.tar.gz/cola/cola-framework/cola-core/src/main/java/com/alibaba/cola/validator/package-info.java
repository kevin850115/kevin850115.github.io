/**
 * Use {@link com.alibaba.cola.validator.ValidatorI} to declare Validator, and use {@link com.alibaba.cola.extension.Extension} if this Validator needs Extension.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.validator;