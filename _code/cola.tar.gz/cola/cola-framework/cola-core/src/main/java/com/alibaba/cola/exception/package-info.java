/**
 * This package defines all kinds of Exceptions of Application.
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.exception;