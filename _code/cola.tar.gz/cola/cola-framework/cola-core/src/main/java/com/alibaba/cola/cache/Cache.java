package com.alibaba.cola.cache;

import java.io.Serializable;

/**
 * created by damon on 2018/12/11
 */
public interface  Cache{

    void set(String key, Serializable value, int seconds);

    void set(String key, Serializable value);

    <T> T get(String key);

    boolean invalid(String key);
}
