package com.alibaba.cola.cache.key;

/**
 * created by damon on 2018/12/11
 */
public enum CacheKeyGenStrategyEnum {
    /**
     * 将多个入参转为json格式用_串联，若为null，用null字符串串联
     */
   /* fastjson,*/
    /**
     * 利用参数的tostring方法，用_串联各参数的tostring值，若为null，用null字符串串联
     */
    tostring
}
