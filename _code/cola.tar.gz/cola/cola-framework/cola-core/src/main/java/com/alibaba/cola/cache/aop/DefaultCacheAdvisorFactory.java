package com.alibaba.cola.cache.aop;

import com.alibaba.cola.cache.Cache;
import com.alibaba.cola.cache.annotation.HotCache;
import com.alibaba.cola.cache.annotation.HotCacheEnable;
import com.alibaba.cola.cache.annotation.HotCacheInvalidate;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;

import java.util.Map;

import static com.alibaba.cola.cache.aop.CacheAnnotationOnInterfacePointCut.IBATIS_MAPPER_PROXY;

/**
 * Created by damon on 2018/9/12.
 */
public class DefaultCacheAdvisorFactory {

    /**
     * interfaces scan path
     */
    private static String[] basePackage = new String[]{IBATIS_MAPPER_PROXY};

    public DefaultCacheAdvisorFactory(String[] basePackage) {
        this.basePackage = basePackage;
    }

    public DefaultCacheAdvisorFactory() {
    }


    public static DefaultPointcutAdvisor getPersistAdvisor(Cache cacheManager,  Map<String,String> dynamicConfig) {
        DefaultPointcutAdvisor cacheAdvisor = new DefaultPointcutAdvisor();
        AnnotationMatchingPointcut cacheAnnotationPointCut =
            new AnnotationMatchingPointcut(HotCacheEnable.class, HotCache.class);
        cacheAdvisor.setPointcut(cacheAnnotationPointCut);
        HotCacheInterceptor interceptor = new HotCacheInterceptor();
        interceptor.setCacheManager(cacheManager);
        interceptor.setDynamicConfig(dynamicConfig);
        cacheAdvisor.setAdvice(interceptor);
        return cacheAdvisor;
    }


    public static DefaultPointcutAdvisor getInvalidateAdvisor(Cache cacheManager, Map<String,String> dynamicConfig) {
        DefaultPointcutAdvisor cacheAdvisor = new DefaultPointcutAdvisor();
        AnnotationMatchingPointcut cacheAnnotationPointCut =
            new AnnotationMatchingPointcut(HotCacheEnable.class, HotCacheInvalidate.class);
        cacheAdvisor.setPointcut(cacheAnnotationPointCut);
        HotCacheInterceptor interceptor = new HotCacheInterceptor();
        interceptor.setCacheManager(cacheManager);
        interceptor.setDynamicConfig(dynamicConfig);
        cacheAdvisor.setAdvice(interceptor);
        return cacheAdvisor;
    }

    public static DefaultPointcutAdvisor getAdvisorForInterface(Cache cacheManager,  Map<String,String> dynamicConfig) {
        DefaultPointcutAdvisor cacheAdvisor = new DefaultPointcutAdvisor();
        cacheAdvisor.setPointcut(new CacheAnnotationOnInterfacePointCut(basePackage));
        HotCacheInterceptor interceptor = new HotCacheInterceptor();
        interceptor.setCacheManager(cacheManager);
        interceptor.setDynamicConfig(dynamicConfig);
        cacheAdvisor.setAdvice(interceptor);
        return cacheAdvisor;
    }

    public void setBasePackage(String[] basePackage) {
        this.basePackage = basePackage;
    }

}
