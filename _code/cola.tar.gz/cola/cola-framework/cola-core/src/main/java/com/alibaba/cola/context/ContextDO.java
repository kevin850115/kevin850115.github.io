package com.alibaba.cola.context;

/**
 * @author: shangxue
 * @create: 2018-09-21 12:55
 **/
public abstract class ContextDO {

}
