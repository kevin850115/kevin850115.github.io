package com.alibaba.cola.tunnel;

import java.util.List;

/**
 * Data Tunnel is the real Data CRUD Operator may interact with DB, service, cache etc...
 * 
 * @author fulan.zjf 2017年10月27日 上午10:34:17
 */
public interface DataTunnelI {
}
