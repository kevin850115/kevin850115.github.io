/**
 * Tunnel is composed by Repository to persist and provide data to Domain layer
 * 
 * @author fulan.zjf
 */
package com.alibaba.cola.tunnel;