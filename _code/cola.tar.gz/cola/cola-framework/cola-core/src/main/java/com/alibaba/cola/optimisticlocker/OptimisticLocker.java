package com.alibaba.cola.optimisticlocker;

import java.lang.annotation.*;

/**
 * @author shawnzhan.zxy
 * @date 2018/06/06
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface OptimisticLocker {
    boolean useCacheLocker() default false;
    String cacheName() default "";
}
