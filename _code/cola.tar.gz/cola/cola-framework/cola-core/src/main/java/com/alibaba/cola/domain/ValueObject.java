package com.alibaba.cola.domain;

/**
 * 领域值对象
 * @author xueliang.sxl
 *
 */
public interface ValueObject {

}
