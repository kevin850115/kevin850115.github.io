package com.alibaba.cola.test.pattern;

import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import com.alibaba.cola.pattern.strategy.Strategy;

/**
 * IMLeadsBuildStrategy
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:28 PM
 */
@Strategy(name="im")
public class IMLeadsBuildStrategy implements LeadsBuildStrategyI{

    private Logger logger = LoggerFactory.getLogger(IMLeadsBuildStrategy.class);

    @Override
    public String build(String source) {
        logger.debug("IMLeadsBuildStrategy : "+ source);
        return "This is IMLeadsBuildStrategy";
    }
}
