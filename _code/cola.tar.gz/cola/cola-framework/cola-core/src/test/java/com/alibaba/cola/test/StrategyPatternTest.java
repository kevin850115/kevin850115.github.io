package com.alibaba.cola.test;

import com.alibaba.cola.TestConfig;
import com.alibaba.cola.context.Context;
import com.alibaba.cola.exception.ColaException;
import com.alibaba.cola.pattern.strategy.StrategyExecutor;
import com.alibaba.cola.pattern.strategy.StrategyRepository;
import com.alibaba.cola.test.pattern.IMLeadsBuildStrategy;
import com.alibaba.cola.test.pattern.InquiryLeadsBuildStrategy;
import com.alibaba.cola.test.pattern.LeadsBuildStrategyI;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

/**
 * StrategyPatternTest
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:29 PM
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {TestConfig.class})
public class StrategyPatternTest {

    @Autowired
    private StrategyExecutor strategyExecutor;

    @Autowired
    private StrategyRepository strategyRepository;

    @Test(expected = ColaException.class)
    public void testNamedStrategyWithNoRegistration(){
        strategyRepository.get("dummyStrategy");
    }

    @Test
    public void testNamedStrategy(){
        LeadsBuildStrategyI imLeadsBuild = (LeadsBuildStrategyI)strategyRepository.get("im");
        Assert.notNull(imLeadsBuild.build("test"));

        LeadsBuildStrategyI inquiryLeadsBuild = (LeadsBuildStrategyI)strategyRepository.get("inquiry");
        Assert.notNull(inquiryLeadsBuild.build("test"));
    }

    @Test
    public void testImStrategy(){
       String result=  strategyExecutor.execute(IMLeadsBuildStrategy.class,new Context(), s -> s.build("test"));
        Assert.notNull(result);
    }

    @Test
    public void testInquiryStrategy(){
       String result =  strategyExecutor.execute(InquiryLeadsBuildStrategy.class,new Context(), s -> s.build("test"));
       Assert.notNull(result);
    }
}
