package com.alibaba.cola.test.pattern;

import com.alibaba.cola.logger.Logger;
import com.alibaba.cola.logger.LoggerFactory;
import com.alibaba.cola.pattern.strategy.Strategy;

/**
 * InquiryLeadsBuildStrategy
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:28 PM
 */
@Strategy(name="inquiry")
public class InquiryLeadsBuildStrategy implements LeadsBuildStrategyI{
    private Logger logger = LoggerFactory.getLogger(InquiryLeadsBuildStrategy.class);

    @Override
    public String build(String source) {
        logger.debug("InquiryLeadsBuildStrategy : "+ source);
        return "This is InquiryLeadsBuildStrategy";
    }
}
