package com.alibaba.cola.test.pattern;

import com.alibaba.cola.pattern.strategy.StrategyI;

/**
 * LeadsBuildStrategyI
 *
 * @author Frank Zhang
 * @date 2018-08-07 12:26 PM
 */
public interface LeadsBuildStrategyI extends StrategyI{

    public String build(String source);
}
