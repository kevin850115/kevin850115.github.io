#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * Validator classes are used to validate parameters from client.
 * 
 * @author fulan.zjf
 */
package ${package}.validator;