#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.dto.domainevent;

/**
 * @author niexiaolong
 * @date 2019/4/16
 */
public class DomainEventConstant {

	public static final String CUSTOMER_CREATED_TOPIC = "CRM_CUSTOMER_CREATED_DOMAIN_EVENT_TOPIC";

}
