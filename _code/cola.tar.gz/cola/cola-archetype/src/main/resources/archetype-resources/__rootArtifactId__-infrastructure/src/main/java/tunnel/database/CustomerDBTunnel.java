#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.tunnel.database;

import com.alibaba.cola.tunnel.DataTunnelI;
import ${package}.tunnel.database.dataobject.CustomerDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Component
@Mapper
public class CustomerDBTunnel implements DataTunnelI {

    public CustomerDO create(CustomerDO customerDo) {
        return new CustomerDO();
    }

    public void update(CustomerDO customerDo) {
    }

    public CustomerDO get(String id) {
        CustomerDO customerDo = new CustomerDO();//just for ${parentArtifactId}
        return customerDo;
    }

    public CustomerDO getByName(String name) {
        CustomerDO customerDO = new CustomerDO();
        customerDO.setCompanyName("Hello, " + name);
        return customerDO;
    }

}
