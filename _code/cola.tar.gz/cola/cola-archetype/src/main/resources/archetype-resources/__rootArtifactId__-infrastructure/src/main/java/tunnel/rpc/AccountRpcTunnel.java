#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.tunnel.rpc;

import com.alibaba.cola.tunnel.DataTunnelI;
import org.springframework.stereotype.Component;

@Component
public class AccountRpcTunnel implements DataTunnelI {

}
