#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.domain;


public class CustomerEntityTest {

    public void testCustomerConflict() {
        System.out.println("Please mock tunnel, test pure Domain Knowledge");
    }
}
