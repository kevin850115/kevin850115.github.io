#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * Interceptors are used to do pre-processing and post-processing during invocation of Command.
 * 
 * @author fulan.zjf
 */
package ${package}.interceptor;