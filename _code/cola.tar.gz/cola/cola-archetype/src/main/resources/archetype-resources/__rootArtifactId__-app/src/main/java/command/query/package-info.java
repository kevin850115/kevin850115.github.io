#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * This package contains QueryExecutors which are used to process Query Request.
 * 
 * @author fulan.zjf
 */
package ${package}.command.query;