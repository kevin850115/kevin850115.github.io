#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * This is domain module, the core business logic is implemented here.
 * 
 * @author fulan.zjf
 */
package ${package}.domain;