#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.app;

import org.junit.Test;

public class CustomerValidatorTest {

    @Test
    public void testValidation(){

    }
}