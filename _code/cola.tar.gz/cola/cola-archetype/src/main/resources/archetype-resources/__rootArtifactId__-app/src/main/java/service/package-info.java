#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * Service is the facade of application API
 * 
 * @author fulan.zjf
 */
package ${package}.service;