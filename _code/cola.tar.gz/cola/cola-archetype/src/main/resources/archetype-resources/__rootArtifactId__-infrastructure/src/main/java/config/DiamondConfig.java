#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.config;

public class DiamondConfig {
    public final static String DummyConfig = "DummyConfig";
}