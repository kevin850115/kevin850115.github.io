#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.tunnel.rpc.dataobject;

import com.alibaba.cola.dto.DataObject;
import lombok.Data;

@Data
public class AccountDO extends DataObject {

}

