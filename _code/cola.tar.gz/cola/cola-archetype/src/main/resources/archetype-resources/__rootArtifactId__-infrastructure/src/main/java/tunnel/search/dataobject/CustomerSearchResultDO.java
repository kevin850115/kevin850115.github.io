#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.tunnel.search.dataobject;

import com.alibaba.cola.dto.DataObject;
import lombok.Data;

@Data
public class CustomerSearchResultDO extends DataObject {

}

