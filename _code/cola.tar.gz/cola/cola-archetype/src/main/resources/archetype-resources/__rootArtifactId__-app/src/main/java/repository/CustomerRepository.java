#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.repository;

import com.alibaba.cola.repository.RepositoryI;
import ${package}.convertor.CustomerConvertor;
import ${package}.domain.customer.CustomerE;
import ${package}.tunnel.database.CustomerDBTunnel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepository implements RepositoryI{

    @Autowired
    private CustomerDBTunnel customerDBTunnel;

    @Autowired
    private CustomerConvertor customerConvertor;

    public void save(CustomerE customer) {
        customerDBTunnel.create(customerConvertor.entityToData(customer));
    }

}