package com.alibaba.smart.framework.benchmark.delegation;

import com.alibaba.smart.framework.benchmark.constant.ProcessConstant;
import com.alibaba.smart.framework.engine.context.ExecutionContext;
import com.alibaba.smart.framework.engine.delegation.TccDelegation;
import com.alibaba.smart.framework.engine.delegation.TccResult;

/**
 * Created by 高海军 帝奇 74394 on 2017 May  08:41.
 */
public class ProcessFinishedDelegation implements TccDelegation {
    @Override
    public TccResult tryExecute(ExecutionContext executionContext) {
        return TccResult.buildSucessfulResult(executionContext);
    }

    @Override
    public TccResult confirmExecute(ExecutionContext executionContext) {

        return null;
    }

    @Override
    public TccResult cancelExecute(ExecutionContext executionContext) {

        return null;
    }
}
