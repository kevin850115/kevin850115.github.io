package com.alibaba.smart.framework.benchmark.constant;

/**
 * Created by 高海军 帝奇 74394 on 2017 May  20:51.
 */
public interface ProcessConstant {

     String ENGINE_ACTION = "engineAction";

}
