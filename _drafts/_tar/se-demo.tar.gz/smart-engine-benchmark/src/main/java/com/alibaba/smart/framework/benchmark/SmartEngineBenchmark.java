/*
 * Copyright (c) 2005, 2014, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.alibaba.smart.framework.benchmark;

import com.alibaba.smart.framework.engine.SmartEngine;
import com.alibaba.smart.framework.engine.configuration.ProcessEngineConfiguration;
import com.alibaba.smart.framework.engine.configuration.impl.DefaultProcessEngineConfiguration;
import com.alibaba.smart.framework.engine.impl.DefaultSmartEngine;
import com.alibaba.smart.framework.engine.model.assembly.ProcessDefinition;
import com.alibaba.smart.framework.engine.model.instance.ExecutionInstance;
import com.alibaba.smart.framework.engine.model.instance.ProcessInstance;
import com.alibaba.smart.framework.engine.persister.custom.session.PersisterSession;
import com.alibaba.smart.framework.engine.persister.util.InstanceSerializerFacade;
import com.alibaba.smart.framework.engine.service.command.ExecutionCommandService;
import com.alibaba.smart.framework.engine.service.command.ProcessCommandService;
import com.alibaba.smart.framework.engine.service.command.RepositoryCommandService;
import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;

import org.junit.Test;
import org.openjdk.jmh.annotations.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@State(value = Scope.Benchmark)
@BenchmarkMode({Mode.Throughput,Mode.AverageTime})
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@Warmup(iterations = 2, time = 2, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 1, time = 120, timeUnit = TimeUnit.SECONDS)
@Threads(value = 16)
@Fork(value =1,jvmArgsAppend = { "-server","-Xms4g","-Xmx4g","-Xmn1536m","-XX:CMSInitiatingOccupancyFraction=82", "-Xss256k", "-XX:+DisableExplicitGC", "-XX:+UseConcMarkSweepGC", "-XX:+CMSParallelRemarkEnabled","-XX:LargePageSizeInBytes=128m","-XX:+UseFastAccessorMethods","-XX:+UseCMSInitiatingOccupancyOnly","-XX:+CMSClassUnloadingEnabled" })
public class SmartEngineBenchmark {


    private static long orderId = 123456L;

    private static ProcessCommandService processCommandService;
    private static ExecutionQueryService executionQueryService;
    private static  ExecutionCommandService executionCommandService ;
    private static ProcessDefinition processDefinition;

    //模拟应用启动时,加载
    static {
    //1.初始化
    ProcessEngineConfiguration processEngineConfiguration = new DefaultProcessEngineConfiguration();
    processEngineConfiguration.setIdGenerator(new AliPayIdGenerator());

    SmartEngine smartEngine = new DefaultSmartEngine();
    smartEngine.init(processEngineConfiguration);


    //2.获得常用服务
      processCommandService = smartEngine.getProcessCommandService();
      executionQueryService = smartEngine.getExecutionQueryService();
      executionCommandService = smartEngine.getExecutionCommandService();


    //3. 部署流程定义
     RepositoryCommandService repositoryCommandService = smartEngine
            .getRepositoryCommandService();
      processDefinition = repositoryCommandService
            .deploy("alipay-forex.bpmn20.xml");

}

    @Benchmark
    public static  void onlyStartProcessInstance(){
        PersisterSession.create();

        //4.启动流程实例
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("smartEngineAction","pre_order");

        ProcessInstance processInstance = processCommandService.start(
                processDefinition.getId(), processDefinition.getVersion(),request
        );

        //在调用findActiveExecution和signal方法前调用此方法。当然,在实际场景下,persiste通常只需要调用一次;UpdateThreadLocal则很多场景下需要调用。
        persisteAndUpdateThreadLocal(orderId, processInstance);

        PersisterSession.destroySession();

    }


    @Benchmark
    public static  void startProcessInstanceAndSignalFirstActivity(){
        PersisterSession.create();

        //4.启动流程实例
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("smartEngineAction","pre_order");

        ProcessInstance processInstance = processCommandService.start(
                processDefinition.getId(), processDefinition.getVersion(),request
        );

        //在调用findActiveExecution和signal方法前调用此方法。当然,在实际场景下,persiste通常只需要调用一次;UpdateThreadLocal则很多场景下需要调用。
        persisteAndUpdateThreadLocal(orderId, processInstance);

        List<ExecutionInstance> executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        ExecutionInstance firstExecutionInstance = executionInstanceList.get(0);
        //完成预下单,将流程驱动到 下单确认环节。
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), null);

        //测试下是否符合预期
        persisteAndUpdateThreadLocal(orderId, processInstance);
        executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        PersisterSession.destroySession();

    }


    //@Test
    //public   void testStartProcessInstanceAndSignalFirstActivity(){
    //    PersisterSession.create();
    //
    //    //4.启动流程实例
    //    Map<String, Object> request = new HashMap<String, Object>();
    //    request.put("smartEngineAction","pre_order");
    //
    //    ProcessInstance processInstance = processCommandService.start(
    //        processDefinition.getId(), processDefinition.getVersion(),request
    //    );
    //
    //    //在调用findActiveExecution和signal方法前调用此方法。当然,在实际场景下,persiste通常只需要调用一次;UpdateThreadLocal则很多场景下需要调用。
    //    persisteAndUpdateThreadLocal(orderId, processInstance);
    //
    //    List<ExecutionInstance> executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
    //    ExecutionInstance firstExecutionInstance = executionInstanceList.get(0);
    //    //完成预下单,将流程驱动到 下单确认环节。
    //    processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), null);
    //
    //    //测试下是否符合预期
    //    persisteAndUpdateThreadLocal(orderId, processInstance);
    //    executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
    //    PersisterSession.destroySession();
    //
    //}

    @Benchmark
    public static  void executeWholeProcessExcludeParseProcessDefinition() {


        PersisterSession.create();



        //4.启动流程实例
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("smartEngineAction","pre_order");

        ProcessInstance processInstance = processCommandService.start(
                processDefinition.getId(), processDefinition.getVersion(),request
        );

        //在调用findActiveExecution和signal方法前调用此方法。当然,在实际场景下,persiste通常只需要调用一次;UpdateThreadLocal则很多场景下需要调用。
        persisteAndUpdateThreadLocal(orderId, processInstance);

        List<ExecutionInstance> executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        ExecutionInstance firstExecutionInstance = executionInstanceList.get(0);
        //完成预下单,将流程驱动到 下单确认环节。
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), null);

        //测试下是否符合预期
        persisteAndUpdateThreadLocal(orderId, processInstance);
        executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        firstExecutionInstance = executionInstanceList.get(0);

        //完成下单确认,将流程驱动到等待资金到账环节。
        request.put("smartEngineAction", "go_to_pay");
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), request);

        //测试下是否符合预期
        persisteAndUpdateThreadLocal(orderId, processInstance);
        executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        firstExecutionInstance = executionInstanceList.get(0);

        //完成资金到账,将流程驱动到资金交割处理环节。
        request.put("smartEngineAction", "money_into_account");
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), request);

        //测试下是否符合预期
        persisteAndUpdateThreadLocal(orderId, processInstance);
        executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        firstExecutionInstance = executionInstanceList.get(0);

        //完成资金交割处理,将流程驱动到ACK确认环节。
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId());

        //测试下是否符合预期
        persisteAndUpdateThreadLocal(orderId, processInstance);
        executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
        firstExecutionInstance = executionInstanceList.get(0);

        //完成流程驱动。
        processInstance = executionCommandService.signal(firstExecutionInstance.getInstanceId(), request);


        persisteAndUpdateThreadLocal(orderId, processInstance);

        PersisterSession.destroySession();


    }

    private static void persisteAndUpdateThreadLocal(long orderId, ProcessInstance processInstance) {

        // 存储到业务系统里面
        String string =  InstanceSerializerFacade.serialize(processInstance);
        //persisterStrategy.update(orderId,string);

        // 注意:在执行之前,更新下ThreadLocal。另外,在线上环境,使用完毕后需要clean 下 ThreadLocal。
        processInstance =  InstanceSerializerFacade.deserializeAll(string);
        PersisterSession.currentSession().setProcessInstance(processInstance);
    }

//    public static void main(String[] args)  throws RunnerException {
//        Options options = new OptionsBuilder()
//                .include(".*" + SmartEngineBenchmark.class.getSimpleName() + ".*")
//                .forks(2).mode(Mode.SampleTime)
//                .jvmArgs(" -server -Xss256k -XX:+DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+UseCMSCompactAtFullCollection -XX:LargePageSizeInBytes=128m -XX:+UseFastAccessorMethods -XX:+UseCMSInitiatingOccupancyOnly -XX:+CMSClassUnloadingEnabled -Xms4g -Xmx4g -XX:PermSize=296m -XX:MaxPermSize=296m -Xmn1536m -XX:CMSInitiatingOccupancyFraction=82 -Djava.awt.headless=true -Djava.net.preferIPv4Stack=true -XX:+PrintGCDetails ")
//                .build();
//        new Runner(options).run();
//    }
}
