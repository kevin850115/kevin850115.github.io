package com.alibaba.smart.framework.benchmark.trade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.alibaba.smart.framework.benchmark.constant.ProcessConstant;
import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;
import com.alibaba.smart.framework.benchmark.db.service.BusinessProcessService;
import com.alibaba.smart.framework.engine.SmartEngine;
import com.alibaba.smart.framework.engine.model.instance.ExecutionInstance;
import com.alibaba.smart.framework.engine.model.instance.ProcessInstance;
import com.alibaba.smart.framework.engine.persister.custom.session.PersisterSession;
import com.alibaba.smart.framework.engine.persister.util.InstanceSerializerFacade;
import com.alibaba.smart.framework.engine.service.command.ExecutionCommandService;
import com.alibaba.smart.framework.engine.service.command.ProcessCommandService;
import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/**
 * Created by 高海军 帝奇 74394 on 2017 May  07:05.
 */
@Service
public class TradeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TradeService.class);


    @Resource
    private SmartEngine smartEngine;

    @Resource
    private BusinessProcessService businessProcessService;


    public   static  final  Long id = 123L;


    public  void mockCreateOrder(){

        try {
            PersisterSession.create();

        Map<String, Object> request = new HashMap<>();
        request.put(ProcessConstant.ENGINE_ACTION,"seller_create_trade");

        ProcessCommandService processCommandService = smartEngine.getProcessCommandService();
        ProcessInstance processInstance= processCommandService.start("trade-assurance","1.0.0",request);

        BusinessProcess  businessProcess = new BusinessProcess();
        businessProcess.setId(id);
        String serializedProcessInstance = InstanceSerializerFacade.serialize(processInstance);
        businessProcess.setSerializedProcessInstance(serializedProcessInstance);

        businessProcessService.addBusinessProcess(businessProcess);
        } finally {
            PersisterSession.destroySession();
        }
    }


    public  void mockSignalPayment(){

        signal(id,"process_payment");

    }

    public  void mockSignalDelivery(){
        signal(id,"process_delivery");


    }

    public  void mockSignalAssurance(){

        signal(id,"process_assurance");

    }

    public  void mockSignalProcessComplete(Map<String, Object>   map ){

        signal(id,"wait_process_complete",  map );

    }

    public void signal(Long tradeId, String activityId ){

        signal(tradeId,activityId,null);

    }


    public void signal(Long businessInstanceId, String activityId,Map<String, Object>   map ){
        try {
            PersisterSession.create();

            ExecutionQueryService executionQueryService = smartEngine.getExecutionQueryService();
            ExecutionCommandService executionCommandService = smartEngine.getExecutionCommandService();

            BusinessProcess tradeProcess = businessProcessService.findById(businessInstanceId);
            ProcessInstance processInstance =  InstanceSerializerFacade.deserializeAll(tradeProcess.getSerializedProcessInstance());

            PersisterSession.currentSession().setProcessInstance(processInstance);

            List<ExecutionInstance>  executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
            boolean found = false;
            if(!CollectionUtils.isEmpty(executionInstanceList)){
                for (ExecutionInstance executionInstance : executionInstanceList) {
                    if( executionInstance.getProcessDefinitionActivityId().equals(activityId)){
                        found = true;

                        ProcessInstance newProcessInstance = executionCommandService.signal(executionInstance.getInstanceId(),map);

                        BusinessProcess  businessProcess = new BusinessProcess();
                        String serializedProcessInstance = InstanceSerializerFacade.serialize(newProcessInstance);
                        businessProcess.setSerializedProcessInstance(serializedProcessInstance);

                        businessProcessService.updateBusinessProcess(businessProcess);

                    }
                }
                if(!found){
                    LOGGER.error("No active executionInstance found for businessInstanceId "+businessInstanceId +",activityId "+activityId);
                }

            }else{
                LOGGER.error("No active executionInstance found for businessInstanceId "+businessInstanceId +",activityId "+activityId);
            }

        } finally {
            PersisterSession.destroySession();
        }
    }


}
