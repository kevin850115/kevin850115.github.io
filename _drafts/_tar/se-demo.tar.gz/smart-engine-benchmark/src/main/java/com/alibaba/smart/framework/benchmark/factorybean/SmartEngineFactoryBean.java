package com.alibaba.smart.framework.benchmark.factorybean;

import java.io.InputStream;

import com.alibaba.smart.framework.benchmark.AliPayIdGenerator;
import com.alibaba.smart.framework.engine.SmartEngine;
import com.alibaba.smart.framework.engine.configuration.IdGenerator;
import com.alibaba.smart.framework.engine.configuration.InstanceAccessor;
import com.alibaba.smart.framework.engine.configuration.ProcessEngineConfiguration;
import com.alibaba.smart.framework.engine.configuration.impl.DefaultProcessEngineConfiguration;
import com.alibaba.smart.framework.engine.exception.EngineException;
import com.alibaba.smart.framework.engine.impl.DefaultSmartEngine;
import com.alibaba.smart.framework.engine.instance.util.ClassLoaderUtil;
import com.alibaba.smart.framework.engine.configuration.impl.DefaultInstanceAccessor;
import com.alibaba.smart.framework.engine.instance.util.IOUtil;
import com.alibaba.smart.framework.engine.service.command.RepositoryCommandService;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

/**
 * Created by 高海军 帝奇 74394 on 2017 April  10:27.
 */
@Component
public class SmartEngineFactoryBean implements FactoryBean<SmartEngine>, InitializingBean {

    private SmartEngine smartEngine;

    private InstanceAccessor defaultInstanceAccessor = new DefaultInstanceAccessor();


    @Override
    public void afterPropertiesSet() throws Exception {
        ProcessEngineConfiguration processEngineConfiguration = new DefaultProcessEngineConfiguration();
        processEngineConfiguration.setInstanceAccessor(new CustomInstanceAccessor());
        processEngineConfiguration.setIdGenerator(new AliPayIdGenerator());


        smartEngine = new DefaultSmartEngine();
        smartEngine.init(processEngineConfiguration);

        deployProcessDefinition();
    }

    private void deployProcessDefinition() {
        RepositoryCommandService repositoryCommandService = smartEngine
            .getRepositoryCommandService();

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        try {
            Resource[] resources = resolver.getResources("classpath*:/smart-engine/*.xml");
            for (Resource resource : resources) {
                InputStream inputStream = resource.getInputStream();
                repositoryCommandService.deploy(inputStream);
                IOUtil.closeQuietly(inputStream);
            }
        } catch (Exception e) {
            throw new EngineException(e);
        }

    }

    private class CustomInstanceAccessor implements InstanceAccessor {

        @Override
        public Object access(String classNameOrBeanName) {
            try {
                Class clazz = ClassLoaderUtil.getContextClassLoader().loadClass(classNameOrBeanName);
                Object bean = ApplicationContextUtil.getBean(clazz);
                return bean;
            } catch (NoSuchBeanDefinitionException e) {
                Object bean = defaultInstanceAccessor.access(classNameOrBeanName);
                return bean;
            }catch (ClassNotFoundException e) {
               throw  new RuntimeException(e);
            }

        }
    }



    @Override
    public SmartEngine getObject() throws Exception {
        return smartEngine;
    }

    @Override
    public Class<?> getObjectType() {
        return SmartEngine.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

}
