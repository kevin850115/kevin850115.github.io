package com.alibaba.smart.framework.benchmark.db.entity;

import java.util.Date;

import lombok.Data;

/**
 *
 * @author 高海军 帝奇 74394
 * @date 2017 May  06:05
 */
@Data
public class BusinessProcess {

    private Long id;

    private Date createdAt;

    private Date updatedAt;


    private String serializedProcessInstance;

}
