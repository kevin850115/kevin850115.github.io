package com.alibaba.smart.framework.benchmark;


import java.util.concurrent.atomic.AtomicLong;

import com.alibaba.smart.framework.engine.configuration.IdGenerator;

/**
 * Created by 高海军 帝奇 74394 on 2017 February  00:02.
 */

public class AliPayIdGenerator implements IdGenerator {

    private static  AtomicLong atomicLong = new AtomicLong(4233L);

    @Override
    public Long getId() {
        return atomicLong.getAndIncrement();
    }
}
