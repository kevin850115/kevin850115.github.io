package com.alibaba.smart.framework.benchmark;

import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;
import com.alibaba.smart.framework.benchmark.db.service.BusinessProcessService;
import com.alibaba.smart.framework.benchmark.trade.TradeService;
import com.alibaba.smart.framework.engine.configuration.PersisterStrategy;
import com.alibaba.smart.framework.engine.model.instance.ProcessInstance;
import com.alibaba.smart.framework.engine.persister.util.InstanceSerializerFacade;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 *
 * @author 高海军 帝奇 74394
 * @date 2017 February  11:17
 */
@Service("customPersistStrategy")
public class CustomPersistStrategy implements PersisterStrategy {

    @Resource
    private BusinessProcessService businessProcessService;


    @Override
    public String insert(ProcessInstance processInstance) {

        String serializedProcessInstance =  InstanceSerializerFacade.serialize(processInstance);
        BusinessProcess businessProcess = new BusinessProcess();
        businessProcess.setId(TradeService.id);
        businessProcess.setSerializedProcessInstance(serializedProcessInstance);
        businessProcessService.addBusinessProcess(businessProcess);
        return serializedProcessInstance;

    }

    @Override
    public String update(ProcessInstance processInstance) {

        String serializedProcessInstance =  InstanceSerializerFacade.serialize(processInstance);
        BusinessProcess businessProcess = new BusinessProcess();
        businessProcess.setId(TradeService.id);
        businessProcess.setSerializedProcessInstance(serializedProcessInstance);
        businessProcessService.updateBusinessProcess(businessProcess);
        return serializedProcessInstance;

    }

    @Override
    public ProcessInstance getProcessInstance(Long businessId){

        BusinessProcess businessProcess=  businessProcessService.findById(businessId);

        String serializedProcessInstance = businessProcess.getSerializedProcessInstance();
        ProcessInstance  processInstance =   InstanceSerializerFacade.deserializeAll(serializedProcessInstance);

        return processInstance;

    }

    @Override
    public ProcessInstance getProcessInstanceByExecutionInstanceId(Long executionInstanceId){
        throw new IllegalAccessError("SHOULD NOT TOUCH HERE NOW");

        //// 应该考虑存储下来eid 和pid的映射关系,这样就不用再特意查找了。
        //// 本次示例里,通过遍历processInstanceMap来获取,实际中并不可取。
        //
        //ProcessInstance machedProcessInstance = null;
        //boolean matched= false;
        //
        //
        //for (String str : processInstanceMap.values()) {
        //
        //    ProcessInstance processInstance= InstanceSerializerFacade.deserializeAll(str);
        //
        //    List<ActivityInstance> activityInstances =  processInstance.getNewActivityInstances();
        //
        //
        //    if(null == activityInstances ||activityInstances.isEmpty() ){
        //
        //        continue;
        //    }else{
        //        int size = activityInstances.size();
        //        for (int i = size-1; i>=0;i--) {
        //            ActivityInstance activityInstance = activityInstances.get(i);
        //            ExecutionInstance tempExecutionInstance = activityInstance.getExecutionInstance();
        //            if(null!= tempExecutionInstance && tempExecutionInstance.getInstanceId().equals(executionInstanceId)){
        //                machedProcessInstance = processInstance;
        //                matched = true;
        //                break;
        //
        //            }
        //        }
        //
        //    }
        //
        //
        //
        //
        //}
        //
        //if(!matched){
        //    throw new EngineException("No processInstance found for executionInstanceId : "+executionInstanceId);
        //}
        //
        //
        //PersisterSession.currentSession().setProcessInstance(machedProcessInstance);
        //
        //
        //
        //return machedProcessInstance;

    }



}
