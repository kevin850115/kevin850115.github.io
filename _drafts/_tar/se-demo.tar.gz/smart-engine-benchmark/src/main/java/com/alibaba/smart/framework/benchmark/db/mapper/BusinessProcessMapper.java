package com.alibaba.smart.framework.benchmark.db.mapper;

import java.util.List;

import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


/**
 * @author ghj
 */
public interface BusinessProcessMapper {

    @Select("SELECT * FROM business_process WHERE id = #{id}")
     BusinessProcess findById(@Param("id") Long id);

    @Insert("insert into business_process (id,created_At, updated_At,serialized_process_instance) "
        + "  values (#{id}, now(),now(), #{serializedProcessInstance} )")
      void addBusinessProcess(BusinessProcess activity);

    @Update("update  business_process set   updated_At = #{updatedAt},serialized_process_instance=#{serializedProcessInstance} "
        + " where id = #{id}")
      int updateBusinessProcess(BusinessProcess businessProcess);

}
