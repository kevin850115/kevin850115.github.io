package com.alibaba.smart.framework.benchmark.delegation;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.smart.framework.benchmark.constant.ProcessConstant;
import com.alibaba.smart.framework.engine.context.ExecutionContext;
import com.alibaba.smart.framework.engine.delegation.TccDelegation;
import com.alibaba.smart.framework.engine.delegation.TccResult;

/**
 * Created by 高海军 帝奇 74394 on 2017 May  08:41.
 */
public class TradeCompletedCheckPrivilegeDelegation implements TccDelegation {

    @Override
    public TccResult tryExecute(ExecutionContext executionContext) {
        //executionContext.getRequest().put(ProcessConstant.ENGINE_ACTION,"can_finish");
        Map<String, Object> request = executionContext.getRequest();
        if(request == null){
            request = new HashMap<String, Object>();
            executionContext.setRequest(request);
        }
        request.put(ProcessConstant.ENGINE_ACTION,"can_finish");

        return TccResult.buildSucessfulResult(executionContext);
    }

    @Override
    public TccResult confirmExecute(ExecutionContext executionContext) {
        return null;
    }

    @Override
    public TccResult cancelExecute(ExecutionContext executionContext) {
        return null;
    }
}
