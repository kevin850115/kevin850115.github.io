package com.alibaba.smart.framework.benchmark.db.service;

import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;
import com.alibaba.smart.framework.benchmark.db.mapper.BusinessProcessMapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by 高海军 帝奇 74394 on 2017 May  06:11.
 */
@Service
public class BusinessProcessService {

    @Autowired
    private BusinessProcessMapper businessProcessMapper;


   public BusinessProcess findById( Long id){
        return businessProcessMapper.findById(id);
    }

    public void addBusinessProcess(BusinessProcess businessProcess){
        businessProcessMapper.addBusinessProcess(businessProcess);

    }

    public int updateBusinessProcess(BusinessProcess businessProcess){
        return businessProcessMapper.updateBusinessProcess(businessProcess);

    }



}
