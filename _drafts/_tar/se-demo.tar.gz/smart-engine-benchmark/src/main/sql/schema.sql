        CREATE TABLE IF NOT EXISTS business_process
             (
                          id                     BIGINT(64) UNSIGNED PRIMARY KEY ,
                          created_at DATETIME,
                          updated_at DATETIME,
                          serialized_process_instance                 VARCHAR(4000)
             );

