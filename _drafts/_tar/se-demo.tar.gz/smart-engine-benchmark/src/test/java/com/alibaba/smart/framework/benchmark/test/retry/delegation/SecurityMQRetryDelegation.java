package com.alibaba.smart.framework.benchmark.test.retry.delegation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.shade.com.alibaba.fastjson.JSON;
import com.alibaba.smart.framework.benchmark.test.retry.AbstractMQCallBack;
import com.alibaba.smart.framework.benchmark.test.retry.bean.PayLoad;
import com.alibaba.smart.framework.engine.context.ExecutionContext;
import com.alibaba.smart.framework.engine.delegation.JavaDelegation;
import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;
import com.alibaba.smart.framework.engine.service.query.RepositoryQueryService;

import lombok.Getter;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Created by 高海军 帝奇 74394 on 2017 November  11:03.
 */
@Service("SecurityCheckActivity")
public class SecurityMQRetryDelegation extends AbstractMQCallBack implements  JavaDelegation {
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityMQRetryDelegation.class);

    @Getter
    private  static List<PayLoad> arrayList = new ArrayList<PayLoad>();

    @Override
    public void consumeMessage(MessageExt messageExt) {
        ExecutionQueryService executionQueryService = smartEngine.getExecutionQueryService();
        RepositoryQueryService repositoryQueryService = smartEngine.getRepositoryQueryService();

        byte[] body = messageExt.getBody();
        String bodyString = new String(body);
        LOGGER.info("request json "+bodyString);

        PayLoad payLoad = JSON.parseObject(bodyString,PayLoad.class);


        checkCurrentIsMatched(executionQueryService,payLoad.getOrderId(),"SecurityCheckActivity");

        Map<String,Object> request = new HashMap();

        request.put("payLoad",payLoad);

        super.signalAndPersistLatestProcess(payLoad.getOrderId(),request);

        boolean shouldSendMQManually =  super.shouldSendMQManually(executionQueryService, repositoryQueryService, payLoad.getOrderId());

        if(shouldSendMQManually){

            sendMq(payLoad);
        }
    }

    private void sendMq( PayLoad load) {
        //do nothing here
    }


    @Override
    public Object execute(ExecutionContext executionContext) {

        Map<String, Object> request = executionContext.getRequest();
        PayLoad payLoad = (PayLoad)request.get("payLoad");
        Assert.assertEquals(payLoad.getCurrentActivityId(),"SecurityCheckActivity");
        arrayList.add(payLoad);

        executionContext.getRequest().put("securityStatus","WAIT_PEOPLE_CHECK");


        return null;
    }

}