//package com.alibaba.smart.framework.benchmark.test.retry.delegation;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import com.alibaba.rocketmq.common.message.Message;
//import com.alibaba.rocketmq.common.message.MessageExt;
//import com.alibaba.rocketmq.shade.com.alibaba.fastjson.JSON;
//import com.alibaba.smart.framework.benchmark.test.retry.AbstractMQCallBack;
//import com.alibaba.smart.framework.benchmark.test.retry.MQConsumer;
//import com.alibaba.smart.framework.benchmark.test.retry.MetaQBasedEventualConsistencyProcessTest;
//import com.alibaba.smart.framework.benchmark.test.retry.bean.PayLoad;
//import com.alibaba.smart.framework.engine.context.ExecutionContext;
//import com.alibaba.smart.framework.engine.delegation.JavaDelegation;
//import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;
//import com.alibaba.smart.framework.engine.service.query.RepositoryQueryService;
//
//import lombok.Getter;
//import org.junit.Assert;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Service;
//
//import static com.alibaba.smart.framework.benchmark.test.retry.MetaQBasedEventualConsistencyProcessTest.TOPIC;
//
///**
// * Created by 高海军 帝奇 74394 on 2017 November  11:03.
// */
//@Service("WaitPayCallBackActivity")
//public class PaymentMQRetryDelegation extends AbstractMQCallBack implements  JavaDelegation {
//    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentMQRetryDelegation.class);
//
//    @Getter
//    private  static List<PayLoad> arrayList = new ArrayList<PayLoad>();
//
//    @Override
//    public void consumeMessage(MessageExt messageExt) {
//        ExecutionQueryService executionQueryService = smartEngine.getExecutionQueryService();
//        RepositoryQueryService repositoryQueryService = smartEngine.getRepositoryQueryService();
//
//        byte[] body = messageExt.getBody();
//        String bodyString = new String(body);
//        LOGGER.info("request json "+bodyString);
//
//        PayLoad payLoad = JSON.parseObject(bodyString,PayLoad.class);
//
//
//        checkCurrentIsMatched(executionQueryService,payLoad.getOrderId(),"WaitPayCallBackActivity");
//
//        Map<String,Object> request = new HashMap();
//
//        request.put("payLoad",payLoad);
//
//        super.signalAndPersistLatestProcess(payLoad.getOrderId(),request);
//
//        boolean shouldSendMQManually =  super.shouldSendMQManually(executionQueryService, repositoryQueryService, payLoad.getOrderId());
//
//        if(shouldSendMQManually){
//
//            sendMq(payLoad);
//        }
//    }
//
//    private void sendMq( PayLoad load) {
//        PayLoad payLoad = new PayLoad();
//        payLoad.setCurrentActivityId("SecurityCheckActivity");
//        payLoad.setOrderId(load.getOrderId());
//        String letter = JSON.toJSONString(payLoad);
//
//        Message msg = new Message(TOPIC, "SecurityCheckActivity",letter.getBytes());
//        try {
//            MetaQBasedEventualConsistencyProcessTest.getProducer().send(msg);
//            LOGGER.info("mock start signal SecurityCheckActivity :"+JSON.toJSONString(payLoad));
//
//        } catch (Throwable e) {
//            throw  new RuntimeException(e);
//        }
//    }
//
//
//    @Override
//    public Object execute(ExecutionContext executionContext) {
//        Map<String, Object> request = executionContext.getRequest();
//        PayLoad payLoad = (PayLoad)request.get("payLoad");
//        Assert.assertEquals(payLoad.getCurrentActivityId(),"WaitPayCallBackActivity");
//        arrayList.add(payLoad);
//        return null;
//    }
//
//}