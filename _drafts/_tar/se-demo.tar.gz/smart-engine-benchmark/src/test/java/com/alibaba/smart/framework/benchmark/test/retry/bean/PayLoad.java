package com.alibaba.smart.framework.benchmark.test.retry.bean;

import lombok.Data;

/**
 * Created by 高海军 帝奇 74394 on 2017 November  14:41.
 */
@Data
public class PayLoad implements  java.io.Serializable{
    private Long   orderId;
    private String currentActivityId;
    private String content;
}