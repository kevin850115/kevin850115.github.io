package com.alibaba.smart.framework.benchmark.test.retry;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;
import com.alibaba.smart.framework.benchmark.db.service.BusinessProcessService;
import com.alibaba.smart.framework.engine.SmartEngine;
import com.alibaba.smart.framework.engine.model.assembly.BaseElement;
import com.alibaba.smart.framework.engine.model.assembly.ProcessDefinition;
import com.alibaba.smart.framework.engine.model.instance.ExecutionInstance;
import com.alibaba.smart.framework.engine.model.instance.ProcessInstance;
import com.alibaba.smart.framework.engine.modules.bpmn.assembly.task.ReceiveTask;
import com.alibaba.smart.framework.engine.persister.custom.session.PersisterSession;
import com.alibaba.smart.framework.engine.persister.util.InstanceSerializerFacade;
import com.alibaba.smart.framework.engine.service.command.ExecutionCommandService;
import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;
import com.alibaba.smart.framework.engine.service.query.RepositoryQueryService;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/**
 * Created by 高海军 帝奇 74394 on 2017 November  21:02.
 */
@Service
public abstract class AbstractMQCallBack implements   MQCallBack {
     private static final Logger LOGGER = LoggerFactory.getLogger(AbstractMQCallBack.class);


     @Autowired
     protected SmartEngine smartEngine;

     @Resource
     protected BusinessProcessService businessProcessService;

     protected void signalAndPersistLatestProcess(Long businessInstanceId, Map<String, Object> map ){
          try {
               PersisterSession.create();

               ExecutionQueryService executionQueryService = smartEngine.getExecutionQueryService();
               ExecutionCommandService executionCommandService = smartEngine.getExecutionCommandService();

               BusinessProcess businessProcess = businessProcessService.findById(businessInstanceId);
               ProcessInstance processInstance =  InstanceSerializerFacade.deserializeAll(businessProcess.getSerializedProcessInstance());

               PersisterSession.currentSession().setProcessInstance(processInstance);

               List<ExecutionInstance> executionInstanceList =executionQueryService.findActiveExecutionList(processInstance.getInstanceId());

               if(!CollectionUtils.isEmpty(executionInstanceList)){
                    for (ExecutionInstance executionInstance : executionInstanceList) {

                         ProcessInstance newProcessInstance = executionCommandService.signal(executionInstance.getInstanceId(),map);

                         String serializedProcessInstance = InstanceSerializerFacade.serialize(newProcessInstance);
                         businessProcess.setSerializedProcessInstance(serializedProcessInstance);

                         businessProcessService.updateBusinessProcess(businessProcess);

                    }
               }else{
                    LOGGER.error("No active executionInstance found for businessInstanceId "+businessInstanceId );
               }

          } finally {
               PersisterSession.destroySession();
          }
     }

     protected void checkCurrentIsMatched(ExecutionQueryService executionQueryService,  Long orderId,String processDefinitionActivityId) {
          try{
               PersisterSession.create();
               BusinessProcess businessProcess = businessProcessService.findById(orderId);
               String processInstance1 =  businessProcess.getSerializedProcessInstance();
               ProcessInstance processInstance = InstanceSerializerFacade.deserializeAll(processInstance1);
               PersisterSession.currentSession().setProcessInstance(
                   processInstance);
               List<ExecutionInstance> executionInstanceList =   executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
               Assert.assertEquals(1,executionInstanceList.size());
               ExecutionInstance  executionInstance =   executionInstanceList.get(0);
               Assert.assertEquals(processDefinitionActivityId,executionInstance.getProcessDefinitionActivityId());
          }finally {
               PersisterSession.destroySession();
          }
     }


     protected ExecutionInstance findActiveExecutionList(ExecutionQueryService executionQueryService, Long orderId) {
          try{
               PersisterSession.create();
               BusinessProcess businessProcess = businessProcessService.findById(orderId);
               String processInstance1 =  businessProcess.getSerializedProcessInstance();
               ProcessInstance processInstance = InstanceSerializerFacade.deserializeAll(processInstance1);
               PersisterSession.currentSession().setProcessInstance(
                   processInstance);
               List<ExecutionInstance> executionInstanceList =   executionQueryService.findActiveExecutionList(processInstance.getInstanceId());

               if(1 != executionInstanceList.size()){
                    throw new IllegalStateException(executionInstanceList.size()+"");
               }
               return  executionInstanceList.get(0);
          }finally {
               PersisterSession.destroySession();
          }
     }

     protected boolean shouldSendMQManually(ExecutionQueryService executionQueryService, RepositoryQueryService repositoryQueryService,
                                            Long orderId) {
          ExecutionInstance executionInstance =  findActiveExecutionList(executionQueryService,orderId);

          ProcessDefinition processDefinition = repositoryQueryService.getCachedProcessDefinition(executionInstance.getProcessDefinitionIdAndVersion());

          List<BaseElement> baseElements =  processDefinition.getProcess().getElements();
          for (BaseElement baseElement : baseElements) {
               if(baseElement instanceof ReceiveTask){
                    ReceiveTask receiveTask = (ReceiveTask)baseElement;
                    Map<String, String> properties = receiveTask.getProperties();
                    String needListenerNormalMQMessage = null;
                    if(null != properties){
                         needListenerNormalMQMessage =  properties.get("needListenerNormalMQMessage");
                    }
                    if(executionInstance.getProcessDefinitionActivityId().equals(receiveTask.getId()) && "no".equals(needListenerNormalMQMessage)){
                         return true;
                    }

               }
          }
          return false;
     }
}