package com.alibaba.smart.framework.benchmark.test.retry;

import com.alibaba.rocketmq.common.message.MessageExt;

/**
 * Created by 高海军 帝奇 74394 on 2017 November  21:02.
 */
public interface MQCallBack {
     void consumeMessage(MessageExt messageExt);
}