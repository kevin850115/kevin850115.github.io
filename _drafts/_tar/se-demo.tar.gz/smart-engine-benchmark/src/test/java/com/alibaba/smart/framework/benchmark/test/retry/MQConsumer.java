//package com.alibaba.smart.framework.benchmark.test.retry;
//
//import java.util.List;
//
//import javax.annotation.Resource;
//
//import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
//import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
//import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
//import com.alibaba.rocketmq.common.message.MessageExt;
//import com.alibaba.rocketmq.shade.com.alibaba.fastjson.JSON;
//import com.alibaba.smart.framework.benchmark.db.service.BusinessProcessService;
//import com.alibaba.smart.framework.benchmark.factorybean.ApplicationContextUtil;
//import com.alibaba.smart.framework.benchmark.test.retry.bean.PayLoad;
//import com.alibaba.smart.framework.engine.SmartEngine;
//
//import com.taobao.metaq.client.MetaPushConsumer;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
///**
// * Created by 高海军 帝奇 74394 on 2017 November  10:39.
// */
//@Service
//public   class MQConsumer implements MessageListenerConcurrently,InitializingBean {
//    private static final Logger LOGGER = LoggerFactory.getLogger(MQConsumer.class);
//
//
//    @Override
//    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
//
//        for (MessageExt messageExt : msgs) {
//
//
//            try {
//                byte[] body = messageExt.getBody();
//                String bodyString = new String(body);
//                //LOGGER.info("request json "+bodyString);
//
//                PayLoad payLoad = JSON.parseObject(bodyString,PayLoad.class);
//
//                // A LITTLE HACK!
//                MQCallBack bean =(MQCallBack) ApplicationContextUtil.getBean(payLoad.getCurrentActivityId());
//                bean.consumeMessage(messageExt);
//
//            } catch (Throwable throwable) {
//                LOGGER.error(throwable.getMessage(),throwable);
//                //如果抛出异常，默认通过metaQ来重试
//                //FIXME 发生产环境时，改一下。
//                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//            }
//        }
//        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//    }
//
//
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//
//        //TODO 可以增加自动化一些。
//        buildConsumer(MetaQBasedEventualConsistencyProcessTest.GROUP,MetaQBasedEventualConsistencyProcessTest.TOPIC,"WaitPayCallBackActivity || SecurityCheckActivity || WaitPeopleCheckActivity");
//
//    }
//
//
//    private void buildConsumer(String consumerGroup,String topic,String tag) {
//
//        try {
//            //TODO 多个连接是否有问题
//
//
//            MetaPushConsumer consumer = new MetaPushConsumer(consumerGroup);
//
//            consumer.subscribe(topic, tag);
//            consumer.registerMessageListener(this);
//            consumer.start();
//            LOGGER.info("Init MetaQ Consumer success.");
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//
//
//
//
//}