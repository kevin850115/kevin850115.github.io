package com.alibaba.smart.framework.benchmark.test;

import com.alibaba.smart.framework.benchmark.trade.TradeService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import static org.junit.Assert.assertEquals;

@ContextConfiguration("/spring.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class TradeAssuranceProcessTest {

    @Resource
    private TradeService tradeService;


    @Test
    public void testProcess() throws Exception {

        tradeService.mockCreateOrder();
        tradeService.mockSignalPayment();
        tradeService.mockSignalDelivery();


        tradeService.mockSignalAssurance();

        //Map<String, Object>   map  = new HashMap<>();
        //map.put("engineAction","can_finish");
        //tradeService.mockSignalProcessComplete(map);

    }


    @Test
    public void testProcess2() throws Exception {

        tradeService.mockCreateOrder();
        tradeService.mockSignalAssurance();

        tradeService.mockSignalPayment();
        tradeService.mockSignalDelivery();

    }




}