//package com.alibaba.smart.framework.benchmark.test.retry;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Random;
//
//import javax.annotation.Resource;
//
//import com.alibaba.rocketmq.common.message.Message;
//import com.alibaba.rocketmq.shade.com.alibaba.fastjson.JSON;
//import com.alibaba.smart.framework.benchmark.db.entity.BusinessProcess;
//import com.alibaba.smart.framework.benchmark.db.service.BusinessProcessService;
//import com.alibaba.smart.framework.benchmark.test.retry.bean.PayLoad;
//import com.alibaba.smart.framework.benchmark.test.retry.delegation.AutoBusinessServiceDelegation;
//import com.alibaba.smart.framework.engine.SmartEngine;
//import com.alibaba.smart.framework.engine.model.instance.ExecutionInstance;
//import com.alibaba.smart.framework.engine.model.instance.ProcessInstance;
//import com.alibaba.smart.framework.engine.persister.custom.session.PersisterSession;
//import com.alibaba.smart.framework.engine.persister.util.InstanceSerializerFacade;
//import com.alibaba.smart.framework.engine.service.command.ExecutionCommandService;
//import com.alibaba.smart.framework.engine.service.command.ProcessCommandService;
//import com.alibaba.smart.framework.engine.service.query.ExecutionQueryService;
//
//import com.taobao.metaq.client.MetaProducer;
//import lombok.Getter;
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.transaction.annotation.Transactional;
//
//@ContextConfiguration("/spring.xml")
//@RunWith(SpringJUnit4ClassRunner.class)
////@Transactional
//
////FIXME :事务隔离级别。
//public class MetaQBasedEventualConsistencyProcessTest {
//
//    public static final String GROUP = "group_74394_diqi0";
//    public static final String TOPIC = "topic_74394_diqi3";
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(MetaQBasedEventualConsistencyProcessTest.class);
//
//    @Getter
//    private static MetaProducer producer;
//
//    @Resource
//    private BusinessProcessService businessProcessService;
//
//    @Autowired
//    private SmartEngine smartEngine;
//
//    @Getter
//    private  static List<String> holder = new ArrayList<String>();
//
//    @Getter
//    private  static Map<Long,ProcessInstance> mockDB = new HashMap<Long, ProcessInstance>();
//
//    @Getter
//    public    static  Long ORDER_ID = 123456789L;
//
//    @Before
//    public void before(){
//        long random = new Random().nextLong();
//        if(random<0){
//            random = -random;
//        }
//        ORDER_ID = Long.valueOf(random);
//        try {
//            producer = new MetaProducer(GROUP);
//
//            producer.start();
//
//            LOGGER.info("Init MetaQ produce success.");
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//
//    }
//
//
//
//    @Test
//    public void test() throws Exception {
//
//
//
//        ProcessCommandService processService = smartEngine.getProcessCommandService();
//        ExecutionQueryService executionQueryService = smartEngine.getExecutionQueryService();
//        ExecutionCommandService executionCommandService = smartEngine.getExecutionCommandService();
//
//        createOrderAndCheckCurrentActivityIsPayment(processService, executionQueryService);
//
//        ProcessInstance processInstance;
//
//        PayLoad payLoad = new PayLoad();
//        payLoad.setContent("pay_success");
//        payLoad.setCurrentActivityId("WaitPayCallBackActivity");
//        payLoad.setOrderId(ORDER_ID);
//        String letter = JSON.toJSONString(payLoad);
//
//        Message msg = new Message(TOPIC, "WaitPayCallBackActivity",letter.getBytes());
//        producer.send(msg);
//        LOGGER.info("mock payment message:"+JSON.toJSONString(payLoad));
//
//        Thread.currentThread().sleep(5000L);
//
//        checkCurrentIsMatched(executionQueryService,ORDER_ID,"WaitPeopleCheckActivity");
//
//
//
//    }
//
//    private void createOrderAndCheckCurrentActivityIsPayment(ProcessCommandService processService,
//                                                             ExecutionQueryService executionQueryService) {
//        Map<String, Object> request = new HashMap<String, Object>();
//        request.put("input", "first");
//        ProcessInstance processInstance = startProcessOnly(processService, request);
//        BusinessProcess businessProcess = new BusinessProcess();
//        businessProcess.setId(ORDER_ID);
//        String serializedProcessInstance = InstanceSerializerFacade.serialize(processInstance);
//        businessProcess.setSerializedProcessInstance(serializedProcessInstance);
//
//        businessProcessService.addBusinessProcess(businessProcess);
//
//        List<String> arrayList = 	AutoBusinessServiceDelegation.getArrayList();
//        Assert.assertEquals(2,arrayList.size());
//        Assert.assertEquals("first",arrayList.get(0));
//        Assert.assertEquals("first",arrayList.get(1));
//
//        checkCurrentIsMatched(executionQueryService,ORDER_ID,"WaitPayCallBackActivity");
//    }
//
//
//    private ProcessInstance startProcessOnly(ProcessCommandService processService, Map<String, Object> request) {
//        ProcessInstance processInstance = null;
//        try{
//            PersisterSession.create();
//            processInstance = processService.start(
//                "lazada", "1.0.0",
//                request);
//        }finally {
//            PersisterSession.destroySession();
//
//        }
//        return processInstance;
//    }
//
//
//    protected void checkCurrentIsMatched(ExecutionQueryService executionQueryService, Long orderId,String processDefinitionActivityId) {
//        try{
//            PersisterSession.create();
//            BusinessProcess businessProcess = businessProcessService.findById(orderId);
//            String processInstance1 =  businessProcess.getSerializedProcessInstance();
//            ProcessInstance processInstance = InstanceSerializerFacade.deserializeAll(processInstance1);
//            PersisterSession.currentSession().setProcessInstance(
//                processInstance);
//            List<ExecutionInstance> executionInstanceList =   executionQueryService.findActiveExecutionList(processInstance.getInstanceId());
//            Assert.assertEquals(1,executionInstanceList.size());
//            ExecutionInstance  executionInstance =   executionInstanceList.get(0);
//            Assert.assertEquals(processDefinitionActivityId,executionInstance.getProcessDefinitionActivityId());
//        }finally {
//            PersisterSession.destroySession();
//        }
//    }
//
//    @After
//    public void tearDown(){
//    }
//
//
//}