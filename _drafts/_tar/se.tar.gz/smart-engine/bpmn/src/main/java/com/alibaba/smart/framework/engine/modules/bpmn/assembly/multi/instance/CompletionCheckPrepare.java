package com.alibaba.smart.framework.engine.modules.bpmn.assembly.multi.instance;

import com.alibaba.smart.framework.engine.model.assembly.Performable;

/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
public interface CompletionCheckPrepare extends Performable {

}
