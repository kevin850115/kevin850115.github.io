package com.alibaba.smart.framework.engine.modules.bpmn.assembly.multi.instance;

import com.alibaba.smart.framework.engine.model.assembly.BaseElement;
import com.alibaba.smart.framework.engine.model.assembly.impl.AbstractPerformable;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
public interface LoopCollection extends BaseElement {

}
