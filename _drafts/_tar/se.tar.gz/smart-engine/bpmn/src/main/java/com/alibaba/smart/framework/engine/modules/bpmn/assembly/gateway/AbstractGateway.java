package com.alibaba.smart.framework.engine.modules.bpmn.assembly.gateway;

import com.alibaba.smart.framework.engine.model.assembly.impl.AbstractActivity;

/**
 * @author 高海军 帝奇 Apr 14, 2016 2:50:20 PM
 */
public abstract class AbstractGateway extends AbstractActivity {

    /**
     *
     */
    private static final long serialVersionUID = 2096892589768688904L;

}
