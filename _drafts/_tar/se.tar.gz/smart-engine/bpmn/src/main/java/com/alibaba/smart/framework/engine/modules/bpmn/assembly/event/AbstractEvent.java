package com.alibaba.smart.framework.engine.modules.bpmn.assembly.event;

import com.alibaba.smart.framework.engine.model.assembly.impl.AbstractActivity;

/**
 * @author 高海军 帝奇 Apr 14, 2016 2:50:20 PM
 */
public abstract class AbstractEvent extends AbstractActivity {

    private static final long serialVersionUID = 5371998393204140551L;
}
