package com.alibaba.smart.framework.engine.modules.bpmn.constant;

public interface BpmnNameSpaceConstant {

    String NAME_SPACE = "http://www.omg.org/spec/BPMN/20100524/MODEL";

    String BPMNDI_NAME_SPACE = "http://www.omg.org/spec/BPMN/20100524/DI";


}
