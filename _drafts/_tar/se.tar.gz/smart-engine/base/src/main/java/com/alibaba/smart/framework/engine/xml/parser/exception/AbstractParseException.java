package com.alibaba.smart.framework.engine.xml.parser.exception;

/**
 * Created by ettear on 16-4-12.
 */
public class AbstractParseException extends Exception {

    private static final long serialVersionUID = -89696724511328256L;

}
