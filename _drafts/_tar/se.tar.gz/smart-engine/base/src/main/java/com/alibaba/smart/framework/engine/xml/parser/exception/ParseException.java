package com.alibaba.smart.framework.engine.xml.parser.exception;

/**
 * Created by ettear on 16-4-12.
 */
public class ParseException extends AbstractParseException {

    private static final long serialVersionUID = 6304946747125320343L;

}
