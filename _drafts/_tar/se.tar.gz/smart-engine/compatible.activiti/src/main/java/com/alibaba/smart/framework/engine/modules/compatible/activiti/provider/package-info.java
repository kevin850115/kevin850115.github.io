/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
package com.alibaba.smart.framework.engine.modules.compatible.activiti.provider;