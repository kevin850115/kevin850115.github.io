package com.alibaba.smart.framework.engine.modules.compatible.activiti.assembly.multi.instance;

import com.alibaba.smart.framework.engine.model.assembly.impl.AbstractPerformable;

/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
public class AbortCheckPerformable extends AbstractPerformable {
}
