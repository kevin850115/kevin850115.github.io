package com.alibaba.smart.framework.engine.modules.compatible.activiti.assembly;

/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
public abstract class ActivitiBase {
    public static final String NAME_SPACE="http://activiti.org/bpmn";
}
