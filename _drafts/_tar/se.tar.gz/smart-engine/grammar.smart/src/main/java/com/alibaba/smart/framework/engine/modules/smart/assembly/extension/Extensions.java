package com.alibaba.smart.framework.engine.modules.smart.assembly.extension;

import javax.xml.namespace.QName;

import com.alibaba.smart.framework.engine.modules.smart.assembly.SmartBase;

/**
 * @author ettear
 * Created by ettear on 04/08/2017.
 */
public class Extensions extends com.alibaba.smart.framework.engine.model.assembly.Extensions {
    public final static QName type = new QName(SmartBase.SMART_NS, "extensionElements");

}
