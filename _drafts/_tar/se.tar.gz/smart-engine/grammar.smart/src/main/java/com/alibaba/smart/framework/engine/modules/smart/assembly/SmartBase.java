package com.alibaba.smart.framework.engine.modules.smart.assembly;

/**
 * @author 高海军 帝奇  2016.11.11
 * @author ettear 2016.04.13
 */
public interface SmartBase {

       String SMART_NS = "http://smart.alibaba-inc.com/schema/process";

}
