/**
 * @author ettear
 * Created by ettear on 04/08/2017.
 */
package com.alibaba.smart.framework.engine.modules.smart.provider;