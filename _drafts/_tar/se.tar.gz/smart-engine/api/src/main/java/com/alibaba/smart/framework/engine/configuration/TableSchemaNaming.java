package com.alibaba.smart.framework.engine.configuration;

import lombok.Data;

/**
 * Created by 高海军 帝奇 74394 on 2018 October  16:47.
 */

@Data
public class TableSchemaNaming {

    private  String prefix ="";
    private  String suffix ="";


}