package com.alibaba.smart.framework.engine.model.assembly;

/**
 * @author ettear TODO ??
 * Created by ettear on 02/08/2017.
 */
public interface Invocable extends BaseElement {
}
