package com.alibaba.smart.framework.engine.model.assembly;

/**
 * @author 高海军 帝奇  2016.11.11
 * @author ettear 2016.04.13
 */
public interface Indentity {

    /**
     * 获取元素ID
     *
     * @return 元素ID
     */
    String getId();

    void setId(String id);
}
