package com.alibaba.smart.framework.engine.constant;

/**
 *
 * @author 高海军 帝奇 74394
 * @date 2017 September  12:32
 */
public interface AssigneeTypeConstant {

    String USER = "user";

    String GROUP = "group";


}
