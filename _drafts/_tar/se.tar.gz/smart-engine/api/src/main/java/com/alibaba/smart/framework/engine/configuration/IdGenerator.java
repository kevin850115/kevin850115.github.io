package com.alibaba.smart.framework.engine.configuration;

/**
 * Created by 高海军 帝奇 74394 on 2017 February  23:17.
 */
public interface IdGenerator {

        String getId() ;
}
