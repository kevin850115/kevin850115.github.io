package com.alibaba.smart.framework.engine.constant;

/**
 * Created by 高海军 帝奇 74394 on 2017 September  19:00.
 */
public interface TaskInstanceConstant {

    String PENDING = "pending";

    String COMPLETED = "completed";

    String ABORTED = "aborted";

    String CANCELED = "canceled";

}
