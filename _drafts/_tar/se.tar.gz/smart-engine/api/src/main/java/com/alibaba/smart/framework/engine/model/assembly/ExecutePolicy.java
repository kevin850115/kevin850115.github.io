package com.alibaba.smart.framework.engine.model.assembly;

/**
 * @author ettear
 * Created by ettear on 14/10/2017.
 */
public interface ExecutePolicy {

}
