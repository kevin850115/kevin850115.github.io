package com.alibaba.smart.framework.engine.constant;

/**
 * Created by 高海军 帝奇 74394 on 2018 October  16:49.
 *
 * @author ghj
 * @date 2018/10/22
 */
public   interface  AdHocConstant {

   String DEFAULT_ZERO_VALUE = "0";
}
