package com.alibaba.smart.framework.engine.model.instance;

/**
 * Created by ettear on 16-4-21.
 */
public enum InstanceStatus {


    running, suspended, aborted,completed;


}
