package com.alibaba.smart.framework.engine.model.instance;

import lombok.Data;

/**
 * Created by 高海军 帝奇 74394 on 2017 September  20:38.
 */
@Data
public class TaskAssigneeCandidateInstance {

    private String assigneeId;

    private String assigneeType;
}
