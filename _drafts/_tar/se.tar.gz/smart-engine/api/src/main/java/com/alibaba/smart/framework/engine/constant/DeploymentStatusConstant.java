package com.alibaba.smart.framework.engine.constant;

/**
 * Created by 高海军 帝奇 74394 on 2017 September  17:05.
 */
public interface DeploymentStatusConstant {


    String ACTIVE = "active";

    String INACTIVE = "inactive";

    String DELETED = "deleted";


}
