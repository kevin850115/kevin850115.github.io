package com.alibaba.smart.framework.engine.persister.common.constant;

/**
 * Created by 高海军 帝奇 74394 on 2018 November  11:58.
 */
public interface StorageConstant {

    String NOT_IMPLEMENT_INTENTIONALLY = "not implement intentionally";
}