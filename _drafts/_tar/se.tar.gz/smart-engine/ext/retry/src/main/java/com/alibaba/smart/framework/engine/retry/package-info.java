/**
 * @author zhenhong.tzh
 * @date 2019-04-30
 *
 * 提供重试扩展能力
 */
package com.alibaba.smart.framework.engine.retry;