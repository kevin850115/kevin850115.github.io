package com.alibaba.smart.framework.engine.common.expression.evaluator;

/**
 * @author ettear
 * Created by ettear on 15/10/2017.
 */
//兼容 Activiti
public class TFormalExpressionExpressionEvaluator extends MvelExpressionEvaluator {
}
