package com.alibaba.smart.framework.engine.common.util;

import java.util.Date;

/**
 * Created by 高海军 帝奇 74394 on 2016 November  17:18.
 */
public abstract class DateUtil {

    public static Date getCurrentDate() {
        return new Date();
    }
}
