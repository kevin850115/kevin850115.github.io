package com.alibaba.smart.framework.engine.provider;

import com.alibaba.smart.framework.engine.context.ExecutionContext;

/**
 * Created by 高海军 帝奇 74394 on 2016 November  14:55.
 */
public interface Behavior {

    Object execute(ExecutionContext context);
}
