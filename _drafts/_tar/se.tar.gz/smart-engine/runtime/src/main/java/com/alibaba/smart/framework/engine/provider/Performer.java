package com.alibaba.smart.framework.engine.provider;

import com.alibaba.smart.framework.engine.context.ExecutionContext;

/**
 * @author ettear
 * Created by ettear on 02/08/2017.
 */
public interface Performer {
    /**
     * 执行一个方法
     * @param context 上下文
     * @return 结果
     */
    Object perform(ExecutionContext context);
}
