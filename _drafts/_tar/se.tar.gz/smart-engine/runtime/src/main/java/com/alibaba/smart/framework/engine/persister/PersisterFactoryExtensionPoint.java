package com.alibaba.smart.framework.engine.persister;

/**
 * Created by 高海军 帝奇 74394 on 2016 December  15:16.
 */
public interface PersisterFactoryExtensionPoint {

    public <T> T getExtensionPoint(Class<T> modelType);

}
