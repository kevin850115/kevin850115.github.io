#!/bin/sh
echo mvn -U clean package -Dtest -DfailIfNoTests=false -e
mvn -U clean package -Dtest -DfailIfNoTests=false -e
