package com.taobao.ateye.changelog.dbsync;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import com.alibaba.fastjson.JSON;
import com.alibaba.middleware.jingwei.client.custom.DeleteEvent;
import com.alibaba.middleware.jingwei.client.custom.EventMessage;
import com.alibaba.middleware.jingwei.client.custom.InsertEvent;
import com.alibaba.middleware.jingwei.client.custom.UpdateEvent;
import com.alibaba.middleware.jingwei.common.dbsync.DbSyncMessage;
import com.alibaba.middleware.jingwei.common.dbsync.Message;
import com.alibaba.middleware.jingwei.common.dbsync.MessageContext;
import com.alibaba.middleware.jingwei.common.exception.ApplierException;
import com.alibaba.middleware.jingwei.core.applier.CustomApplier;
import com.esotericsoftware.minlog.Log;
import com.taobao.ateye.changelog.AddAppChangeLogResult;
import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.changelog.AppChangeLogService;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.hsf.app.spring.util.HSFSpringConsumerBean;
import com.taobao.hsf.standalone.HSFEasyStarter;
import com.taobao.tddl.dbsync.dbms.DBMSAction;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * This is a sample for the collection of Configuration in DB of app;  
 *
 * Detail info:
 * http://gitlab.alibaba-inc.com/middleware/jingwei3/wikis/jingwei3-help
 * 
 * 
 */
public class AtEyeConfigApplier extends CustomApplier {

	private static AppChangeLogService appChangeLogService;

	public static String WORK_DIR = System.getProperty("user.dir");

	public static final String PATH_SEPERATOR = File.separator;

	@Override
	public void init() {
		// this.setDebugMode(true);
		initHSFContainer();
		initService();

	}

	// TODO:need to optimize the process and retry flow according to the err
	// msg;
	@Override
	public ApplyResult apply(EventMessage eventMessage,
			MessageContext messageContext) {
		logger.warn(eventMessage.toJsonString());
		
		Map<String, Object> changeMap = new HashMap<String, Object>();
		changeMap.put("action", eventMessage.getAction());
		changeMap.put("rowmap", eventMessage.getRowDataMaps());
		changeMap.put("primaryKeys", eventMessage.getPrimaryKeyNames());
		changeMap.put("options", eventMessage.getOptionMaps());
		
		if(eventMessage instanceof UpdateEvent)
		{
			changeMap.put("modification", ((UpdateEvent) eventMessage).getModifyRowDataMaps());
		}

		try
		{
			AddAppChangeLogResult result = appChangeLogService
					.addOneChangeLogFromDB(eventMessage.getDbName(),
							eventMessage.getTableName(),
							JSON.toJSONString(changeMap));
		
			if(result!=null&&result.isSuccess())
				return ApplyResult.COMMIT;
		
			if(result==null||org.apache.commons.lang.StringUtils.isEmpty(result.getErrorCode()))
			{
				logger.error(
						"fail to consume the message:"
								+ eventMessage.toJsonString()+"; Due to no service result.");
				return ApplyResult.COMMIT;
			}
			
			
			String code = result.getErrorCode();
			
			if(code.equals(AppChangeLogService.ADD_CONFINDB_ERROR_DB))
			{
				logger.error(
						"fail to consume the message:"
								+ eventMessage.toJsonString()+"; Will retry later.");
				return ApplyResult.RETRY_LATER;
			}
			else if(code.equals(AppChangeLogService.ADD_CONFINDB_ERROR_UNKNOW))
			{
				logger.error(
						"fail to consume the message:"
								+ eventMessage.toJsonString()+"; Will retry later.");
				return ApplyResult.RETRY;
			}
			else if(code.equalsIgnoreCase(AppChangeLogService.ADD_CONFINDB_ERROR_NOAPPFOUND))
			{
				logger.error(
						"fail to consume the message:"
								+ eventMessage.toJsonString()+";duplicated message.");
				return ApplyResult.COMMIT;
			}
			else if(code.equals(AppChangeLogService.ADD_CONFINDB_ERROR_BADPARAM)||
					code.equals(AppChangeLogService.ADD_CONFINDB_ERROR_DUPLICATED)||
					code.equals(AppChangeLogService.ADD_CONFINDB_ERROR_MISSPARAM)
					)
			{
				logger.error(
						"fail to consume the message:"
								+ eventMessage.toJsonString()+";bad params or app.");
				return ApplyResult.COMMIT;
			}
			else if(result.isSuccess())
			{
				return ApplyResult.COMMIT;
			}
			
			
			return ApplyResult.RETRY;
		
		}
		catch (Exception e) {
			logger.error(
					"fail to consume the message:"
							+ eventMessage.toJsonString(), e);
			return ApplyResult.RETRY_LATER;
		}

	}

	

	private void initHSFContainer() {

		try {

			String hsfPath = WORK_DIR + PATH_SEPERATOR + "hsf-standalone";
			HSFEasyStarter.start(hsfPath, "2_2_140825");
		} catch (Exception e) {
			logger.error("Fail to start hsf easy starter", e);
		}
	}

	private void initService() {
		HSFSpringConsumerBean consumerBean = new HSFSpringConsumerBean();
		consumerBean
				.setInterfaceName("com.taobao.ateye.changelog.AppChangeLogService");
		consumerBean.setVersion("1.0.0");
		try {
			consumerBean.init();
			appChangeLogService = (AppChangeLogService) consumerBean
					.getObject();
		} catch (Exception e) {
			logger.error("Fail to init the AppChangeLogService", e);
		}
	}
}
