package com.taobao.ateye.changelog.dbsync.test;

import com.alibaba.middleware.jingwei.worker.TaskLoaderDebug;
import com.taobao.ateye.changelog.dbsync.AtEyeConfigApplier;

/**
 * Created by hanxuan.mh on 15/3/13.
 */
public class AtConfigApplierTest {

    /**
     * 运行之前先要确保：
     * 1. 在精卫控制台上创建好任务
     * 2. drc增量通道已经就绪
     * 3. 为任务挂载了集群，下面第一个参数，填写挂载的集群名
     * 4. 点击启动，会把精卫任务的相关配置同步到zk，之后点击停止
     *    这样做的目的是：不让精卫的leader挑选worker机器运行这个任务，而是自己在本地调试
     * 5. 编写好自己的CustomApplier类
     * 6. 你可以运行任务了
     * @param args
     */
    public static void main(String[] args) {
        
    	//AtEyeConfigApplier atApplier = new AtEyeConfigApplier();
    	new TaskLoaderDebug("jingwei", "D_T_RC_1631", null, new AtEyeConfigApplier());
    }
}
