package com.taobao.ateye.dal.impl;

import com.taobao.ateye.dal.AlarmLogRelationDAO;
import com.taobao.ateye.dataobject.AlarmLogRelationDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/11/15.
 */
public class IBatisAlarmLogRelationDAO extends BaseDAO implements AlarmLogRelationDAO {
    @Override
    public Long saveAlarmLogRelation(AlarmLogRelationDO alarmLogRelationDO) throws DAOException {
        return (Long) insert("AlarmLogRelationDAO.saveAlarmLogRelation",alarmLogRelationDO);
    }
}
