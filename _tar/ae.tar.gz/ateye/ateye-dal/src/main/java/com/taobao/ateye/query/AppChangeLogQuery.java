package com.taobao.ateye.query;

import java.util.Date;
import java.util.List;

public class AppChangeLogQuery extends QueryBaseForMysql{

	private static final long serialVersionUID = 1258309221808829400L;
	private String bu;
	private String productName;
	private String appName;
	private Date startTime;
	private Date endTime;
	private List<Integer> changeTypes;
	private Integer env;
	private Integer offset;
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public List<Integer> getChangeTypes() {
		return changeTypes;
	}
	public void setChangeTypes(List<Integer> changeTypes) {
		this.changeTypes = changeTypes;
	}
	public Integer getEnv() {
		return env;
	}
	public void setEnv(Integer env) {
		this.env = env;
	}
	public Integer getOffset() {
		return offset;
	}
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "AppChangeLogQuery [bu=" + bu + ", productName=" + productName
				+ ", appName=" + appName + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", changeTypes=" + changeTypes
				+ ", env=" + env + ", offset=" + offset + "]";
	}

}
