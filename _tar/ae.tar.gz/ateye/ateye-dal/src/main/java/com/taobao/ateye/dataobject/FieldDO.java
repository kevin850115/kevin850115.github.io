package com.taobao.ateye.dataobject;

import java.util.Date;

public class FieldDO extends BaseDO {
	private static final long serialVersionUID = 3904697305789585867L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * �������ؼ���id
	 */
	private Long setId;
	/**
	 * Ӧ����
	 */
	private String appName;
	/**
	 * BeanName
	 */
	private String beanName;
	/**
	 * ������
	 */
	private String fieldName;
	/**
	 * ��������
	 */
	private String fieldDesc;
	/**
	 * ��������
	 */
	private String type;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSetId() {
		return setId;
	}

	public void setSetId(Long setId) {
		this.setId = setId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getBeanName() {
		return beanName;
	}

	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldDesc() {
		return fieldDesc;
	}

	public void setFieldDesc(String fieldDesc) {
		this.fieldDesc = fieldDesc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		else if (!(obj instanceof FieldDO))
			return false;
		else {
			FieldDO other = (FieldDO) obj;
			return this.appName.equals(other.appName)
					&& this.beanName.equals(other.beanName)
					&& this.fieldName.equals(other.fieldName)
					&& this.type.equals(other.type);
		}
	}
	
	@Override
	public int hashCode() {
		int result = this.appName.hashCode();
		result = 37 * result + this.beanName.hashCode();
		result = 37 * result + this.fieldName.hashCode();
		result = 37 * result + this.type.hashCode();
		return result;
	}
}
