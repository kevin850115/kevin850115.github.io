package com.taobao.ateye.dataobject;

import java.util.Date;

public class ChangeFreeApproveDO extends BaseDO {
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ִ���˹���
     */
    private String executorEmpId;

    /**
     * Ӧ��
     */
    private String app;

    /**
     * ����/����
     */
    private String type;

    /**
     * beanname
     */
    private String beanName;

    /**
     * �������򿪹�����
     */
    private String invokeName;

    /**
     * ǩ��,�����򿪹�
     */
    private String sign;

    /**
     * cf���ص�״̬
     */
    private String checkStatus;

    /**
     * cf�Ǳߵ�Ωһֵ
     */
    private String sourceOrderId;

    /**
     * ��Ч�Ŀ�ʼʱ��
     */
    private Date validStartTime;

    /**
     * ��Ч�Ľ���ʱ��
     */
    private Date validEndTime;


    private String approveUrl;

    /**
     * ����
     */
    private String env;

    public String getInvokeName() {
        return invokeName;
    }

    public void setInvokeName(String invokeName) {
        this.invokeName = invokeName;
    }

    public String getApproveUrl() {
        return approveUrl;
    }

    public void setApproveUrl(String approveUrl) {
        this.approveUrl = approveUrl;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getExecutorEmpId() {
        return executorEmpId;
    }

    public void setExecutorEmpId(String executorEmpId) {
        this.executorEmpId = executorEmpId;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getSourceOrderId() {
        return sourceOrderId;
    }

    public void setSourceOrderId(String sourceOrderId) {
        this.sourceOrderId = sourceOrderId;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
