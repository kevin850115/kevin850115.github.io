package com.taobao.ateye.dataobject;

import java.util.Date;

public class FieldTemplateValueDO extends BaseDO 
{
	private static final long serialVersionUID = 505562165020279618L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ģ��id
	 */
	private Long templateId;
	/**
	 * ����id
	 */
	private Long fieldId;
	/**
	 * ����ֵ
	 */
	private String fieldValue;
	/**
	 * ֵ�����͡�0-��ͨ��1-��ֵnull��2-���ַ���
	 */
	private int valueType;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}
	public Long getFieldId() {
		return fieldId;
	}
	public void setFieldId(Long fieldId) {
		this.fieldId = fieldId;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	/**
	 * @return the valueType
	 */
	public int getValueType() {
		return valueType;
	}
	/**
	 * @param valueType the valueType to set
	 */
	public void setValueType(int valueType) {
		this.valueType = valueType;
	}
}
