package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.FlowSceneDO;
import com.taobao.ateye.exception.DAOException;

/*
 * ����
 */
public interface FlowSceneDAO {
	
	void insert(FlowSceneDO sceneDO) throws DAOException;

	void deleteBySceneId(long id, Date day,String env) throws DAOException;

	List<FlowSceneDO> getBySceneId(long id, String env, Date date) throws DAOException;

	List<FlowSceneDO> getAll(String env, Date day) throws DAOException;


}
