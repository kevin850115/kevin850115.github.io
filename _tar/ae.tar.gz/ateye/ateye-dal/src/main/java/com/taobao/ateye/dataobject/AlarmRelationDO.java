package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class AlarmRelationDO extends BaseDO {
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ���б���id
     */
    private long alarmId;

    /**
     * ������Դ���� AlarmRelationEnu
     */
    private String type;

    /**
     * Ψһ����
     */
    private String uniqueServiceName;

    /**
     * ����
     */
    private String env;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * ����value
     */
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public long getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(long alarmId) {
        this.alarmId = alarmId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUniqueServiceName() {
        return uniqueServiceName;
    }

    public void setUniqueServiceName(String uniqueServiceName) {
        this.uniqueServiceName = uniqueServiceName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
