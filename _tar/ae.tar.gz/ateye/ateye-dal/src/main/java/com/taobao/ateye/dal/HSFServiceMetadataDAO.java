package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HSFServiceMetadataDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/4/11.
 */
public interface HSFServiceMetadataDAO {
    Long insert(HSFServiceMetadataDO hsfServiceMetadataDO) throws DAOException;
    void batchinsert(List<HSFServiceMetadataDO> hsfServiceMetadatas) throws DAOException;
    List<HSFServiceMetadataDO> selectByNodeGroup(String nodeGroup, String env) throws DAOException;
    HSFServiceMetadataDO selectByUniqueKey(String appName,String nodeGroup,String uniqueServiceName,int isProvider,String env) throws DAOException;
    void deleteById(long id) throws DAOException;
    void deleteByNodeGroup(String nodeGroup, String env) throws DAOException;
    Long existRecordByGmtCreate(String nodeGroup, String env,Date gmtCreate) throws DAOException;
}
