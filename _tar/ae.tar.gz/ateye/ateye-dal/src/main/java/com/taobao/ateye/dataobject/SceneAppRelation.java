package com.taobao.ateye.dataobject;

import org.apache.commons.codec.digest.DigestUtils;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/5.
 */
public class SceneAppRelation extends BaseDO{
    /**
     */
    private Long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    private Long entryPointId;

    /**
     * �������id
     */
    private Long providerAppId;

    /**
     * ����������ڵķ�������
     */
    private String providerAppNodeGroup;

    /**
     * ��������
     */
    private Long consumerAppId;

    /**
     * ��������
     */
    private String consumerAppNodeGroup;

    private Date timeWindow;

    /**
     * ����  EnvironmentType
     */
    private String env;

    /**
     * Ӧ�õĵ���ջ
     */
    private String appStack;

    /**
     * ���������md5
     */
    private String ukMd5;

    public String buildMd5(){
        StringBuilder ukString = new StringBuilder();
        ukString.append(entryPointId)
                .append(timeWindow)
                .append(providerAppNodeGroup)
                .append(consumerAppNodeGroup)
                .append(env)
                .append(appStack);
        return DigestUtils.md5Hex(ukString.toString());
    }

    public String getAppStack() {
        return appStack;
    }

    public void setAppStack(String appStack) {
        this.appStack = appStack;
    }

    public String getUkMd5() {
        return ukMd5;
    }

    public void setUkMd5(String ukMd5) {
        this.ukMd5 = ukMd5;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getProviderAppId() {
        return providerAppId;
    }

    public void setProviderAppId(Long providerAppId) {
        this.providerAppId = providerAppId;
    }

    public String getProviderAppNodeGroup() {
        return providerAppNodeGroup;
    }

    public void setProviderAppNodeGroup(String providerAppNodeGroup) {
        this.providerAppNodeGroup = providerAppNodeGroup;
    }

    public Long getConsumerAppId() {
        return consumerAppId;
    }

    public void setConsumerAppId(Long consumerAppId) {
        this.consumerAppId = consumerAppId;
    }

    public String getConsumerAppNodeGroup() {
        return consumerAppNodeGroup;
    }

    public void setConsumerAppNodeGroup(String consumerAppNodeGroup) {
        this.consumerAppNodeGroup = consumerAppNodeGroup;
    }

    public Date getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(Date timeWindow) {
        this.timeWindow = timeWindow;
    }

    public Long getEntryPointId() {
        return entryPointId;
    }

    public void setEntryPointId(Long entryPointId) {
        this.entryPointId = entryPointId;
    }
}
