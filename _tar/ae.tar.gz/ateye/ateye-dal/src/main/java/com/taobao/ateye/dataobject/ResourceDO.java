package com.taobao.ateye.dataobject;

import java.util.List;

/**
 * spring security�ж���Ȩ�޷�����Դ(��,url)����Դ�������ݶ���
 * @author gumo
 *
 */
public class ResourceDO extends BaseDO {

	private static final long serialVersionUID = -2102474787000124383L;
	/**
	 * ID
	 */
	private Long id;
	/**
	 * ����
	 */
	private String name;
	/**
	 * 
	 */
	private int sort;
	/**
	 * ����
	 */
	private int type;
	/**
	 * url�ķ���·��
	 */
	private String path;
	/**
	 * �����Ľ�ɫ�ڽ�ɫ���е�ID
	 */
	private Long roleId;
	/**
	 * 
	 */
	private List<RoleDO> roleList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSort() {
		return sort;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public List<RoleDO> getRoleList() {
		return roleList;
	}

	public void setRoleList(List<RoleDO> roleList) {
		this.roleList = roleList;
	}
	
}
