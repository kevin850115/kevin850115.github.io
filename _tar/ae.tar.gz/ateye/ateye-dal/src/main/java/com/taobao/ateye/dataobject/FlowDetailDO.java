package com.taobao.ateye.dataobject;

/**
 * Description:���������������
 * @author �س�
 * Date 2019-05-22
 */
public class FlowDetailDO extends BaseFlowDO{
	
	/**
	 * Ӧ��
	 */
	private String appName;

	/**
	 * Ӧ�÷���
	 */
	private String appNodeGroup;

	/**
	 * �������ID
	 */
	private long sceneId;

	/**
	 * ����Ψһ����
	 */
	private String uniqueServiceName;

	/**
	 * sentinelΨһ����
	 */
	private String sentinelResourceName;

	/**
	 * ����Ψһ����
	 */
	private String uniqueMethodName;

	/**
	 * ���ò��,��1��ʼ
	 */
	private int callLevel;
	
	/*
	 * ʶ���Ƿ��ǵ�һ�������ķ��񣬱�������汾
	 */
	public boolean isAValidService() {
		return uniqueServiceName.contains(":");
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppNodeGroup() {
		return appNodeGroup;
	}

	public void setAppNodeGroup(String appNodeGroup) {
		this.appNodeGroup = appNodeGroup;
	}

	public long getSceneId() {
		return sceneId;
	}

	public void setSceneId(long sceneId) {
		this.sceneId = sceneId;
	}

	public String getUniqueServiceName() {
		return uniqueServiceName;
	}

	public void setUniqueServiceName(String uniqueServiceName) {
		this.uniqueServiceName = uniqueServiceName;
	}

	public String getSentinelResourceName() {
		return sentinelResourceName;
	}

	public void setSentinelResourceName(String sentinelResourceName) {
		this.sentinelResourceName = sentinelResourceName;
	}

	public String getUniqueMethodName() {
		return uniqueMethodName;
	}

	public void setUniqueMethodName(String uniqueMethodName) {
		this.uniqueMethodName = uniqueMethodName;
	}

	public int getCallLevel() {
		return callLevel;
	}

	public void setCallLevel(int callLevel) {
		this.callLevel = callLevel;
	}
}