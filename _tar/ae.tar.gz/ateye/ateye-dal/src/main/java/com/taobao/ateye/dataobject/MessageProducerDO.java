package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:��Ϣ��������(meta/notify)
 * @author ˼��
 * Date 2019-05-05
 */
public class MessageProducerDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * 0-metaq 1-notify
     */
    private Integer type;

    /**
     * topic
     */
    private String topic;

    /**
     * ��
     */
    private String producerGroup;

    /**
     * 0-���� 1-ɾ��
     */
    private Integer status;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getProducerGroup() {
        return producerGroup;
    }

    public void setProducerGroup(String producerGroup) {
        this.producerGroup = producerGroup;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}