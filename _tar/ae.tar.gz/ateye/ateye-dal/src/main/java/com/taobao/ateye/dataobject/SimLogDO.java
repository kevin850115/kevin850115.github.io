package com.taobao.ateye.dataobject;

import java.util.Date;

public class SimLogDO extends BaseDO {


	private static final long serialVersionUID = 1L;
	/**
	 * ����
	 */
	private long id;

	/**
	 * ����ʱ��
	 */
	private Date gmtCreate;

	/**
	 * �޸�ʱ��
	 */
	private Date gmtModified;

	/**
	 * ����ģ������ID
	 */
	private long simId;

	/**
	 * ��־
	 */
	private String log;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	public long getSimId() {
		return simId;
	}

	public void setSimId(long simId) {
		this.simId = simId;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

}
