package com.taobao.ateye.dataobject;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;

import com.taobao.ateye.base.EnvironmentType;

public class MachineDO extends BaseDO {

	public MachineDO(JSONObject jsonObject, AppDO appDO)
	{
		this.appId = appDO.getId();
		this.port = 7001;
		//���storm��Ⱥ�Ļ������˿ںŻ���Ops���ص�json�����и���
		String portStr = jsonObject.optString("port");
		if(StringUtils.isNotBlank(portStr)) {
			try {
				Integer _port = Integer.parseInt(portStr);
				if(_port > 0) {
					this.port = _port;
				}
			} catch(Exception ignore) {}
		}
		this.machineName = jsonObject.optString("nodename");
		this.ip = jsonObject.optString("dns_ip");
		this.setEnv(EnvironmentType.PRODUCTION);
		this.desc = "";
	}
	
	public MachineDO(){}
	/**
	 * 
	 */
	private static final long serialVersionUID = 5360252892144274821L;
	/**
	 * ID, ����
	 */
	private Long id;
	/**
	 * appId Ӧ��ID
	 */
	private Long appId;
	/**
	 * �����Ķ˿�
	 */
	private Integer port;
	/**
	 * ����������
	 */
	private String machineName;
	/*
	 * ������������(armory)
	 */
	private String nodeGroup;
	/**
	 * ������IP
	 */
	private String ip;
	
	/**
	 * ������������Ϣ
	 */
	private String desc;

	private String useType;
	
	/**
	 * ��������������Daily��Ԥ�������ϣ�
	 */
	private int envInt;

	/**
	 * �Ƿ�beta���� 0-�� 1-��
	 */
	private int beta;
	
	public int getEnvInt() {
		return envInt;
	}
	public void setEnvInt(int envInt) {
		this.envInt = envInt;
	}
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAppId() {
		return appId;
	}
	public void setAppId(Long appId) {
		this.appId = appId;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}

	public void setEnv(EnvironmentType env) {
		this.envInt = env.ordinal();
	}

	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public String getMachineName() {
		return machineName;
	}
	public String getDcName() {
		if ( machineName != null && machineName.contains(".") ){
			int pos = machineName.lastIndexOf(".");
			if ( pos != -1 ){
				return machineName.substring(pos+1);
			}
		}
		return "--";
	}
	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getNodeGroup() {
		return nodeGroup;
	}

	public void setNodeGroup(String nodeGroup) {
		this.nodeGroup = nodeGroup;
	}

	public String getUseType() {
		return useType;
	}

	public void setUseType(String useType) {
		this.useType = useType;
	}

	public int getBeta() {
		return beta;
	}

	public void setBeta(int beta) {
		this.beta = beta;
	}
}
