package com.taobao.ateye.dal;

import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.UserAuditDO;
import com.taobao.ateye.exception.DAOException;

/**
 * �û�������Ϊ���
 * @author jianbo.hc 2012-11-15
 *
 */
public interface UserAuditDAO {
	/**
	 * �����û������־��Ϣ
	 * @param userAuditDO
	 * @return
	 * @throws DAOException
	 */
	 public Long insertUserAuditLog(UserAuditDO userAuditDO) throws DAOException;
	 
	 /**��ѯ�����־��Ϣ
	  * * @param userAuditDO
	 /** * @return
	 /** * @throws DAOException
	  */
	 public List<UserAuditDO> getUserAuditLog(UserAuditDO userAuditDO)throws DAOException;
	 
	 
	 /***
	  * GroupBy�û�nickͳ����־��Ϣ* @param start
	 /** * @param end
	 /** * @return
	 /** * @throws DAOException
	  */
	 public List<UserAuditDO> getAuditLogGroupByNick(Map<String,Object> param)throws DAOException;
	 /**
	  * GroupBy bean-fieldͳ����־��Ϣ* @param param
	 /** * @return
	 /** * @throws DAOException
	  */
	 public List<UserAuditDO> getAuditLogGroupByBean(Map<String,Object> param)throws DAOException;
	 
	

}
