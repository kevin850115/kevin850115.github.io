package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.OperateLogDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.query.OperateLogQuery;

/**
 * ���ݷ��ʶ���ӿ�
 * 
 * @since 2011-06-21
 * @author �س�
 */
public interface OperateLogDAO {

    public Integer insertOperateLog(OperateLogDO operateDO) throws DAOException;

    public List<OperateLogDO> getOperateLogByQuery(OperateLogQuery queryDO) throws DAOException;
    
    public Integer getOperateLogCountByQuery(OperateLogQuery queryDO) throws DAOException;

}