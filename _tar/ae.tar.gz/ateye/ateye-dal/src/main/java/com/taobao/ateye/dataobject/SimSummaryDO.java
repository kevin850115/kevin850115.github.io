package com.taobao.ateye.dataobject;

import java.util.Date;

public class SimSummaryDO extends BaseDO {

	public static Integer TYPE_SERVICE_MARK=0;
	public static Integer TYPE_APP_MARK=1;
	public static String TYPE_SERVICE="service";
	public static String TYPE_APP="app";
	public static Integer RESULT_UNKOWN=0;
	public static Integer RESULT_STRONG=1;
	public static Integer RESULT_WEAK=2;
	public static Integer RESULT_IGNORE=3;
	private static final long serialVersionUID = 1L;
	/**
	 * ����
	 */
	private long id;
	private Long fatherId;
	private Long simId;

	/**
	 * ����ʱ��
	 */
	private Date gmtCreate;

	/**
	 * �޸�ʱ��
	 */
	private Date gmtModified;

	/**
	 * ����ORӦ��
	 */
	private int type;

	/**
	 * Ӧ��
	 */
	private String app;

	/**
	 * ����
	 */
	private String simService;
	private String simApp;

	/**
	 * �������ʶ��
	 */
	private int dependResult;

	/**
	 * ����
	 */
	private String detail;

	/**
	 * setter for column ����
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * getter for column ����
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * setter for column ����ʱ��
	 */
	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	/**
	 * getter for column ����ʱ��
	 */
	public Date getGmtCreate() {
		return this.gmtCreate;
	}

	/**
	 * setter for column �޸�ʱ��
	 */
	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	/**
	 * getter for column �޸�ʱ��
	 */
	public Date getGmtModified() {
		return this.gmtModified;
	}

	/**
	 * setter for column ����ORӦ��
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * getter for column ����ORӦ��
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * setter for column Ӧ��
	 */
	public void setApp(String app) {
		this.app = app;
	}

	/**
	 * getter for column Ӧ��
	 */
	public String getApp() {
		return this.app;
	}

	/**
	 * setter for column �������ʶ��
	 */
	public void setDependResult(int dependResult) {
		this.dependResult = dependResult;
	}

	/**
	 * getter for column �������ʶ��
	 */
	public int getDependResult() {
		return this.dependResult;
	}

	/**
	 * setter for column ����
	 */
	public void setDetail(String detail) {
		this.detail = detail;
	}

	/**
	 * getter for column ����
	 */
	public String getDetail() {
		return this.detail;
	}

	public Long getFatherId() {
		return fatherId;
	}

	public void setFatherId(Long fatherId) {
		this.fatherId = fatherId;
	}

	public Long getSimId() {
		return simId;
	}

	public void setSimId(Long simId) {
		this.simId = simId;
	}

	public String getSimApp() {
		return simApp;
	}

	public void setSimApp(String simApp) {
		this.simApp = simApp;
	}

	public String getSimService() {
		return simService;
	}

	public void setSimService(String simService) {
		this.simService = simService;
	}
}
