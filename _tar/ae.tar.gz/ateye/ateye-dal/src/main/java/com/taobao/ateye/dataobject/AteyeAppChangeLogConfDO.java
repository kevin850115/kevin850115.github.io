package com.taobao.ateye.dataobject;

import java.io.Serializable;
import java.util.Date;

/**
 * ���ݶ���
 * @since 2016-07-27
 */
public class AteyeAppChangeLogConfDO implements Serializable {

    private static final long serialVersionUID = 146960451506590272L;

    /**
     * column ateye_app_change_log_conf.id  ����
     */
    private Long id;

    /**
     * column ateye_app_change_log_conf.gmt_create  ����ʱ��
     */
    private Date gmtCreate;

    /**
     * column ateye_app_change_log_conf.gmt_modified  �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * column ateye_app_change_log_conf.app_name  Ӧ������
     */
    private String appName;

    /**
     * column ateye_app_change_log_conf.change_type  �������
     */
    private Integer changeType;

    /**
     * column ateye_app_change_log_conf.key1  key 1
     */
    private String key1;

    /**
     * column ateye_app_change_log_conf.key2  key 2
     */
    private String key2;

    /**
     * column ateye_app_change_log_conf.value1  value 1
     */
    private String value1;

    /**
     * column ateye_app_change_log_conf.value2  value 2
     */
    private String value2;

    /**
     * column ateye_app_change_log_conf.operator  ������
     */
    private String operator;

    /**
     * column ateye_app_change_log_conf.description  ����
     */
    private String description;

    public AteyeAppChangeLogConfDO() {
        super();
    }

    public AteyeAppChangeLogConfDO(Long id, Date gmtCreate, Date gmtModified, String appName, Integer changeType, String key1, String key2, String value1, String value2, String operator, String description) {
        this.id = id;
        this.gmtCreate = gmtCreate;
        this.gmtModified = gmtModified;
        this.appName = appName;
        this.changeType = changeType;
        this.key1 = key1;
        this.key2 = key2;
        this.value1 = value1;
        this.value2 = value2;
        this.operator = operator;
        this.description = description;
    }

    /**
     * getter for Column ateye_app_change_log_conf.id
     */
    public Long getId() {
        return id;
    }

    /**
     * setter for Column ateye_app_change_log_conf.id
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * getter for Column ateye_app_change_log_conf.gmt_create
     */
    public Date getGmtCreate() {
        return gmtCreate;
    }

    /**
     * setter for Column ateye_app_change_log_conf.gmt_create
     * @param gmtCreate
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for Column ateye_app_change_log_conf.gmt_modified
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * setter for Column ateye_app_change_log_conf.gmt_modified
     * @param gmtModified
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for Column ateye_app_change_log_conf.app_name
     */
    public String getAppName() {
        return appName;
    }

    /**
     * setter for Column ateye_app_change_log_conf.app_name
     * @param appName
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * getter for Column ateye_app_change_log_conf.change_type
     */
    public Integer getChangeType() {
        return changeType;
    }

    /**
     * setter for Column ateye_app_change_log_conf.change_type
     * @param changeType
     */
    public void setChangeType(Integer changeType) {
        this.changeType = changeType;
    }

    /**
     * getter for Column ateye_app_change_log_conf.key1
     */
    public String getKey1() {
        return key1;
    }

    /**
     * setter for Column ateye_app_change_log_conf.key1
     * @param key1
     */
    public void setKey1(String key1) {
        this.key1 = key1;
    }

    /**
     * getter for Column ateye_app_change_log_conf.key2
     */
    public String getKey2() {
        return key2;
    }

    /**
     * setter for Column ateye_app_change_log_conf.key2
     * @param key2
     */
    public void setKey2(String key2) {
        this.key2 = key2;
    }

    /**
     * getter for Column ateye_app_change_log_conf.value1
     */
    public String getValue1() {
        return value1;
    }

    /**
     * setter for Column ateye_app_change_log_conf.value1
     * @param value1
     */
    public void setValue1(String value1) {
        this.value1 = value1;
    }

    /**
     * getter for Column ateye_app_change_log_conf.value2
     */
    public String getValue2() {
        return value2;
    }

    /**
     * setter for Column ateye_app_change_log_conf.value2
     * @param value2
     */
    public void setValue2(String value2) {
        this.value2 = value2;
    }

    /**
     * getter for Column ateye_app_change_log_conf.operator
     */
    public String getOperator() {
        return operator;
    }

    /**
     * setter for Column ateye_app_change_log_conf.operator
     * @param operator
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * getter for Column ateye_app_change_log_conf.description
     */
    public String getDescription() {
        return description;
    }

    /**
     * setter for Column ateye_app_change_log_conf.description
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

}