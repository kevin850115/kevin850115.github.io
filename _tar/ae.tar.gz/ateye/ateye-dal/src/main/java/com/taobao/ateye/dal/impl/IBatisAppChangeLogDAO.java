package com.taobao.ateye.dal.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AppChangeLogDAO;
import com.taobao.ateye.dataobject.AppChangeLogDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.query.AppChangeLogQuery;

public class IBatisAppChangeLogDAO extends BaseDAO implements AppChangeLogDAO {

	public Long insert(AppChangeLogDO log) throws DAOException {
		Long id = (Long)insert("ateye_app_change_log.insert",log);
		log.setId(id);
		return id;
	}

	@Override
 	public AppChangeLogDO queryByOperationId(String operationId) throws DAOException {
		Map<String,String> params = Maps.newHashMap();
		params.put("operationId",operationId);
		return (AppChangeLogDO) queryForObject("ateye_app_change_log.queryByOperationId",params);
	}

	@Override
	public void updateServers(AppChangeLogDO log) throws DAOException {
		update("ateye_app_change_log.updateServers",log);
	}

	@Override
	public int deleteChangeLog(Date day) throws DAOException {
		return update("ateye_app_change_log.deleteByDate",day);
	}

	@Override
	public List<AppChangeLogDO> query(AppChangeLogQuery query)
			throws DAOException {
		return queryForList("ateye_app_change_log.query", query);
	}

	@Override
	public AppChangeLogDO getById(Long id) throws DAOException {
		Map<String,Long> params = Maps.newHashMap();
		params.put("id",id);
		return (AppChangeLogDO) queryForObject("ateye_app_change_log.getById",params);
	}

	@Override
	public int deleteOldLogChangeLog(Date day) throws DAOException {
		return update("ateye_app_change_log.deleteOldLogByDate",day);

	}
}
