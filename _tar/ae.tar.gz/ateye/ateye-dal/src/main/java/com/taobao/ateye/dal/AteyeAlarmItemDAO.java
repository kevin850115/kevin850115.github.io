package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmItemDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmItemDAO {
    List<AteyeAlarmItemDO> selectAll() throws DAOException;
    Long insert(AteyeAlarmItemDO ateyeAlarmItemDO) throws DAOException;

    AteyeAlarmItemDO selectByUkMd5(String ukMd5) throws DAOException;

    void deleteOldRule() throws DAOException;

    AteyeAlarmItemDO selectById(long id) throws DAOException;

    List<AteyeAlarmItemDO> selectByApp(String app) throws DAOException;
}
