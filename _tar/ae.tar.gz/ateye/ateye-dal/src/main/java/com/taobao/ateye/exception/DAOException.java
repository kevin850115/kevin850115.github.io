package com.taobao.ateye.exception;

public class DAOException extends Exception {

	private static final long serialVersionUID = 9035264616203452202L;
	
	public DAOException() {
		super();
	}
	
	public DAOException(String message) {
		super(message);
	}
	
	public DAOException(Throwable cause) {
		super(cause);
	}
	
	public DAOException(String message, Throwable cause) {
		super(message, cause);
	}

}
