package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HsfConsumerDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface HsfConsumerDAO {
    Long insert(HsfConsumerDO hsfConsumerDO) throws DAOException;
    HsfConsumerDO getByUk(String uniqueServiceName,String appNodeGroup,String env) throws DAOException;

}
