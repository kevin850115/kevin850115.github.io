package com.taobao.ateye.dataobject;

/**
 * Description:���������������
 * @author �س�
 * Date 2019-05-22
 */
public class FlowMethodDO extends BaseFlowDO{
	/**
	 * Ӧ��
	 */
	private String appName;

	/**
	 * Ӧ�÷���
	 */
	private String appNodeGroup;

	/**
	 * ����Ψһ����
	 */
	private String uniqueServiceName;

	/**
	 * sentinelΨһ����
	 */
	private String sentinelResourceName;

	/**
	 * ����Ψһ����
	 */
	private String uniqueMethodName;


	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppNodeGroup() {
		return appNodeGroup;
	}

	public void setAppNodeGroup(String appNodeGroup) {
		this.appNodeGroup = appNodeGroup;
	}

	public String getUniqueServiceName() {
		return uniqueServiceName;
	}

	public void setUniqueServiceName(String uniqueServiceName) {
		this.uniqueServiceName = uniqueServiceName;
	}

	public String getSentinelResourceName() {
		return sentinelResourceName;
	}

	public void setSentinelResourceName(String sentinelResourceName) {
		this.sentinelResourceName = sentinelResourceName;
	}

	public String getUniqueMethodName() {
		return uniqueMethodName;
	}

	public void setUniqueMethodName(String uniqueMethodName) {
		this.uniqueMethodName = uniqueMethodName;
	}


}