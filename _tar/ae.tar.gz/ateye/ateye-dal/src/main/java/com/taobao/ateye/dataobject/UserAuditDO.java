package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * �û����DO����
 * @author jianbo.hc 2012-11-16
 *
 */
public class UserAuditDO extends BaseDO {
	private static final long serialVersionUID = -337826119181143856L;
	public static final int SWITCH=0;
	public static final int INVOKER=1;
	public static final int SCHEDULE=2;
	public static final int LOGLEVEL=3;
	public static final int SQLMAPB=4;//sqlmap����

	/**
	 * ����id
	 */
	private Long id;
	/**
	 * �û���
	 */
	private String userNick;
	/**
	 * Ӧ����
	 */
	private String appName;

	/**
	 * nodeGroup
	 */
	private String nodeGroup;
	/**
	 * Ӧ��IP
	 */
	private String ip;
	/**
	 * Ӧ�ò������ͣ�0-���أ�1-�������ã�2-ʱ�����
	 */
	private Integer opType;
	/**
	 * ������bean
	 */
	private String opBean;
	/**
	 * �����ľ��巽�����Ա������cron��
	 */
	private String opField;
	/**
	 * ������ֵ
	 */
	private String opValue;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	/**
	 * �����־��ͳ�Ƽ���
	 */
	private long count;

	public String getNodeGroup() {
		return nodeGroup;
	}

	public void setNodeGroup(String nodeGroup) {
		this.nodeGroup = nodeGroup;
	}

	public UserAuditDO() {
		super(); 
	}
	public UserAuditDO(String userNick, String appName, String ip, Integer opType, String opBean, String opField,
			String opValue) {
		super();
		this.userNick = userNick;
		this.appName = appName;
		this.ip = ip;
		this.opType = opType;
		this.opBean = opBean;
		this.opField = opField;
		this.opValue = opValue;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getOpType() {
		return opType;
	}
	public void setOpType(Integer opType) {
		this.opType = opType;
	}
	public String getOpBean() {
		return opBean;
	}
	public void setOpBean(String opBean) {
		this.opBean = opBean;
	}
	public String getOpField() {
		return opField;
	}
	public void setOpField(String opField) {
		this.opField = opField;
	}
	public String getOpValue() {
		return opValue;
	}
	public void setOpValue(String opValue) {
		this.opValue = opValue;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	
	
	
	
	

}
