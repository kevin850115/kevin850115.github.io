package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/10/26.
 */
public class SlowSqlDO extends BaseDO {
    /**
     */
    private Integer id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * ��������
     */
    private Date happenDate;

    /**
     * ��Ⱥ
     */
    private String clusterName;

    /**
     * template_checksum
     */
    private String templateChecksum;

    /**
     * ��sql
     */
    private String sqlTemplate;

    /**
     * ����
     */
    private Integer slowCount;

    /**
     * ƽ��RT����λ����
     */
    private Double avgRt;

    /**
     * ƽ����������
     */
    private Long avgRowsSent;

    /**
     * ƽ����������
     */
    private Long avgRowsAffected;

    /**
     * ƽ��ɨ������
     */
    private Long avgRowsExamined;

    /**
     * �Ż�url
     */
    private String optimizeUrl;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ��id
     */
    private Long appId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Date getHappenDate() {
        return happenDate;
    }

    public void setHappenDate(Date happenDate) {
        this.happenDate = happenDate;
    }

    public String getClusterName() {
        return clusterName;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    public String getTemplateChecksum() {
        return templateChecksum;
    }

    public void setTemplateChecksum(String templateChecksum) {
        this.templateChecksum = templateChecksum;
    }

    public String getSqlTemplate() {
        return sqlTemplate;
    }

    public void setSqlTemplate(String sqlTemplate) {
        this.sqlTemplate = sqlTemplate;
    }

    public Integer getSlowCount() {
        return slowCount;
    }

    public void setSlowCount(Integer slowCount) {
        this.slowCount = slowCount;
    }

    public Double getAvgRt() {
        return avgRt;
    }

    public void setAvgRt(Double avgRt) {
        this.avgRt = avgRt;
    }

    public Long getAvgRowsSent() {
        return avgRowsSent;
    }

    public void setAvgRowsSent(Long avgRowsSent) {
        this.avgRowsSent = avgRowsSent;
    }

    public Long getAvgRowsAffected() {
        return avgRowsAffected;
    }

    public void setAvgRowsAffected(Long avgRowsAffected) {
        this.avgRowsAffected = avgRowsAffected;
    }

    public Long getAvgRowsExamined() {
        return avgRowsExamined;
    }

    public void setAvgRowsExamined(Long avgRowsExamined) {
        this.avgRowsExamined = avgRowsExamined;
    }

    public String getOptimizeUrl() {
        return optimizeUrl;
    }

    public void setOptimizeUrl(String optimizeUrl) {
        this.optimizeUrl = optimizeUrl;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }
}
