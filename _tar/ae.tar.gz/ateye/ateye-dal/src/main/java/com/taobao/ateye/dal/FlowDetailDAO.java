package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.FlowDetailDO;
import com.taobao.ateye.exception.DAOException;

/*
 * ����
 */
public interface FlowDetailDAO {
	
	void insert(FlowDetailDO detailDO) throws DAOException;

	void deleteBySceneId(long id, Date day,String env) throws DAOException;

	void deleteHsfByApp(String app, Date day,String env) throws DAOException;

	List<FlowDetailDO> getFlowDetailsOfApp(String app, Date day,String env)throws DAOException;

	List<FlowDetailDO> getFlowDetailsOfScene(Long sceneId, Date day,String env)throws DAOException;

	List<FlowDetailDO> getDetail(String app, String ng, String interf, String method, Date day, String env)throws DAOException;
	

}
