package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.SwitchBaseLineDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/4/4.
 */
public interface SwitchBaseLineDAO {
    Long insert(SwitchBaseLineDO switchBaseLineDO) throws DAOException;
    void deleteByAppId(long appId,String env) throws DAOException;
    SwitchBaseLineDO selectByAppId(long appId,String env) throws DAOException;
}
