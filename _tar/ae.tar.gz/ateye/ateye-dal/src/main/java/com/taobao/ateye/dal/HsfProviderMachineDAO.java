package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HsfProviderMachineDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface HsfProviderMachineDAO {
    Long insert(HsfProviderMachineDO hsfProviderMachineDO) throws DAOException;
    void delete(String uniqueServiceName,String appNodeGroup,String env) throws DAOException;
    void deleteById(Long id) throws DAOException;
    List<HsfProviderMachineDO> getByService(String uniqueServiceName, String env) throws DAOException;

}
