package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2019/6/20.
 */
public class NoParamSqlDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ����
     */
    private String method;

    /**
     * �����ļ�
     */
    private String file;

    /**
     * sql
     */
    private String sqlNoParam;

    /**
     * ����
     */
    private String appNodeGroup;

    /**
     * Ӧ��
     */
    private String appName;

    /**
     * ����
     */
    private String env;

    /**
     * ����ʱ�䴰��
     */
    private Date timeWindow;

    private String type;

    private Integer hasLimit;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getHasLimit() {
        return hasLimit;
    }

    public void setHasLimit(Integer hasLimit) {
        this.hasLimit = hasLimit;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getSqlNoParam() {
        return sqlNoParam;
    }

    public void setSqlNoParam(String sqlNoParam) {
        this.sqlNoParam = sqlNoParam;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Date getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(Date timeWindow) {
        this.timeWindow = timeWindow;
    }
}
