package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.ChangeFreeAppRelationDO;
import com.taobao.ateye.dataobject.ChangeFreeDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2018/10/9.
 */
public interface ChangeFreeAppRelationDAO {
    Long insertChangeFreeAppRelation(ChangeFreeAppRelationDO changeFreeAppRelationDO) throws DAOException;
    List<ChangeFreeDO> getChangeFreeAppRelationByCondition(Date startTime, Date endTime, Long appId) throws DAOException;
}

