package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:ateye������hsf�ķ�����Ϣ
 * @author ˼��
 * Date 2019-05-15
 */
public class HsfMethodDO extends BaseDO {
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ��������
     */
    private String name;

    /**
     * �����json
     */
    private String params;

    /**
     * ��������
     */
    private String returnType;

    /**
     * �Ƿ���future����
     */
    private Integer future;

    /**
     * �Ƿ���callback
     */
    private Integer callback;

    /**
     * ��ʱʱ��
     */
    private Integer timeout;


    /**
     * ��������
     */
    private Long interfaceId;

    /**
     * eagleeye��Ψһ��ʾ
     */
    private String eagleeyeUniqueName;

    /**
     * sentinel��Ψһ��ʾ
     */
    private String sentinelResourceName;

    /**
     * 0-hsf��meta 1-������־
     */
    private Integer source;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public Integer getFuture() {
        return future;
    }

    public void setFuture(Integer future) {
        this.future = future;
    }

    public Integer getCallback() {
        return callback;
    }

    public void setCallback(Integer callback) {
        this.callback = callback;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getEagleeyeUniqueName() {
        return eagleeyeUniqueName;
    }

    public void setEagleeyeUniqueName(String eagleeyeUniqueName) {
        this.eagleeyeUniqueName = eagleeyeUniqueName;
    }

    public String getSentinelResourceName() {
        return sentinelResourceName;
    }

    public void setSentinelResourceName(String sentinelResourceName) {
        this.sentinelResourceName = sentinelResourceName;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }
}
