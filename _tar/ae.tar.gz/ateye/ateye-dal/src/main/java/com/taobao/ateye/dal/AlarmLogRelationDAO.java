package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AlarmLogRelationDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/11/15.
 */
public interface AlarmLogRelationDAO {
    Long saveAlarmLogRelation(AlarmLogRelationDO alarmLogRelationDO) throws DAOException;
}
