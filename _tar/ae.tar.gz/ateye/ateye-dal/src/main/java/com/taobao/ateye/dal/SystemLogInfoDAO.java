package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.SystemLogInfoDO;
import com.taobao.ateye.exception.DAOException;

public interface SystemLogInfoDAO
{
	/**
	 * ����Ӧ����+����IP+��־·����ѯϵͳ��־�ռ���Ϣ
	 * @param appName
	 * @param ip
	 * @param path
	 * @return
	 * @throws DAOException
	 */
	SystemLogInfoDO getSystemLogInfoDO(String appName, String ip, String path) throws DAOException;
	
	/**
	 * ����һ��SystemLogInfoDO
	 * @param systemLogInfoDO
	 * @return
	 * @throws DAOException
	 */
	int updateSystemLogInfoDO(SystemLogInfoDO systemLogInfoDO) throws DAOException;
	
	/**
	 * ����һ��SystemLogInfoDO
	 * @param systemLogInfoDO
	 * @return
	 * @throws DAOException
	 */
	Long insertSystemLogInfoDO(SystemLogInfoDO systemLogInfoDO) throws DAOException;
}
