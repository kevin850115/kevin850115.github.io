package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SceneServiceProvider;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneServiceProviderDAO {

    public SceneServiceProvider getServiceProviderByCondition(String providerName, String providerType,String appNodeGroup,String env) throws DAOException;

    public List<SceneServiceProvider> getServiceProvider(String providerName, String providerType,String env) throws DAOException;

    public Long insertServiceProvider(SceneServiceProvider provider) throws DAOException;

    SceneServiceProvider getProviderById(Long providerId) throws DAOException;
    void updateAppInfo(long id,long appId,String appNodeGroup) throws DAOException;

    void deleteByProviderId(long id) throws DAOException;

    List<SceneServiceProvider> selectByAppId(Long appId,String env) throws DAOException;
}
