/*
 * @(#)MataDataDO.java 2012-12-14
 *
 * Copyright (c) 2010, Taobao and/or its affiliates. All rights reserved.
 * TAOBAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.taobao.ateye.dataobject;

import java.util.Date;


/**
 * ��־ͨ�û�������Ԫ���ݶ���
 * @author guangu.lj
 * @verion 0.1.0
 *
 */
public class MetaDataDO extends BaseDO{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6552619967692485556L;
	/**
	 * idֵ
	 */
	private Long id;
	/**
	 * Ԫ��������
	 */
	private String name;
	/**
	 * Ԫ��������.0-��ͨ;1-ͳ������
	 */
	private int type;
	/**
	 * ����������������������վcolumn������+�ָ�
	 */
	private String keyColumn;
	/**
	 * ��������������������ʽ column1,column1+column2
	 */
	private String indexColumns;
	/**
	 * ʱ��column
	 */
	private String timeColumn;
	/**
	 * �����ۺϼ�����������ʽ column1,column1+column2
	 */
	private String mergeColumns;
	/**
	 * ��ͳ�Ƶ���������ʽ column1,column2 (��֧��+����column)
	 */
	private String statColumns;
	/**
	 * ͳ������.1-�֣�2-ʱ��3-��
	 */
	private int statType;
	
	private String operator;
	
	private int status;
	
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return the keyColumn
	 */
	public String getKeyColumn() {
		return keyColumn;
	}
	/**
	 * @param keyColumn the keyColumn to set
	 */
	public void setKeyColumn(String keyColumn) {
		this.keyColumn = keyColumn;
	}
	/**
	 * @return the indexColumns
	 */
	public String getIndexColumns() {
		return indexColumns;
	}
	/**
	 * @param indexColumns the indexColumns to set
	 */
	public void setIndexColumns(String indexColumns) {
		this.indexColumns = indexColumns;
	}
	/**
	 * @return the timeColumn
	 */
	public String getTimeColumn() {
		return timeColumn;
	}
	/**
	 * @param timeColumn the timeColumn to set
	 */
	public void setTimeColumn(String timeColumn) {
		this.timeColumn = timeColumn;
	}
	/**
	 * @return the mergeColumns
	 */
	public String getMergeColumns() {
		return mergeColumns;
	}
	/**
	 * @param mergeColumns the mergeColumns to set
	 */
	public void setMergeColumns(String mergeColumns) {
		this.mergeColumns = mergeColumns;
	}
	/**
	 * @return the statColumns
	 */
	public String getStatColumns() {
		return statColumns;
	}
	/**
	 * @param statColumns the statColumns to set
	 */
	public void setStatColumns(String statColumns) {
		this.statColumns = statColumns;
	}
	/**
	 * @return the statType
	 */
	public int getStatType() {
		return statType;
	}
	/**
	 * @param statType the statType to set
	 */
	public void setStatType(int statType) {
		this.statType = statType;
	}
	/**
	 * @return the createdTime
	 */
	public Date getCreatedTime() {
		return createdTime;
	}
	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	/**
	 * @return the modifiedTime
	 */
	public Date getModifiedTime() {
		return modifiedTime;
	}
	/**
	 * @param modifiedTime the modifiedTime to set
	 */
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * @param operator the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
}