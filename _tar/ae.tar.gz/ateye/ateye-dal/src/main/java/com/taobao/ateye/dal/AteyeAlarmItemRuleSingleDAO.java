package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmItemRuleSingleDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmItemRuleSingleDAO {
    List<AteyeAlarmItemRuleSingleDO> selectAll() throws DAOException;

    Long insert(AteyeAlarmItemRuleSingleDO ruleDO) throws DAOException;

    void updateStatus(Long id,int isDelete) throws DAOException;

    void deleteOldRule() throws DAOException;

    List<AteyeAlarmItemRuleSingleDO> selectByConfId(long id) throws DAOException;

    List<AteyeAlarmItemRuleSingleDO> selectByItemIds(List<Long> itemIds) throws DAOException;

    void deleteByConfId(long confId) throws DAOException;
}
