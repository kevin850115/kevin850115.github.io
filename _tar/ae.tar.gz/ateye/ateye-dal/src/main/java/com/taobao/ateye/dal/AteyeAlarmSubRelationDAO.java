package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmSubRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmSubRelationDAO {
    List<AteyeAlarmSubRelationDO> selectAll() throws DAOException;

    Long insert(AteyeAlarmSubRelationDO ruleDO) throws DAOException;

    void updateStatus(Long id, int isDelete) throws DAOException;

    void deleteOldRule() throws DAOException;

    AteyeAlarmSubRelationDO getByUK(Long subId, Long alarmConfId, Integer appScopeType, String appScopeValue, int isDelete, String env) throws DAOException;

    List<AteyeAlarmSubRelationDO> getValidByConfId(Long confId, String env) throws DAOException;

    void deleteRule(long subId, Long confId, String env) throws DAOException;

    List<AteyeAlarmSubRelationDO> selectAppScope(String env) throws DAOException;

    List<AteyeAlarmSubRelationDO> selectAppScopeBySubId(long subId,String env) throws DAOException;

    Integer countAppScopeBySubId(long subId,String env) throws DAOException;

    List<AteyeAlarmSubRelationDO> getByRuleType(String ruleType) throws DAOException;

    void deleteRuleByConfId(long id) throws DAOException;

    List<AteyeAlarmSubRelationDO> getAllBySubId(long subId, String env) throws DAOException;
}
