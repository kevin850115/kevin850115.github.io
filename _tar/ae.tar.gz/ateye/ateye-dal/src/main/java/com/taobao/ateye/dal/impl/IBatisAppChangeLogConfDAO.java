package com.taobao.ateye.dal.impl;


import com.taobao.ateye.dal.AppChangeLogConfDAO;
import com.taobao.ateye.dataobject.AteyeAppChangeLogConfDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * ���ݷ��ʶ���ʵ����
 * @since 2016-07-27
 */
public class IBatisAppChangeLogConfDAO extends BaseDAO implements AppChangeLogConfDAO {

    /**
     * ��������
     * @param ateyeAppChangeLogConfDO
     * @return �������ݵ�����
     */
    public Long insertAteyeAppChangeLogConfDO(AteyeAppChangeLogConfDO ateyeAppChangeLogConfDO) throws DAOException {
        Object id = insert("AteyeAppChangeLogConf.insert", ateyeAppChangeLogConfDO);
        return (Long) id;
    }

    /**
     * ͳ�Ƽ�¼��
     * @param ateyeAppChangeLogConfDO
     * @return ����ļ�¼��
     */
    public Integer countAteyeAppChangeLogConfDOByQuery(AteyeAppChangeLogConfDO ateyeAppChangeLogConfDO) throws DAOException {
        Integer count = (Integer) queryForObject("AteyeAppChangeLogConf.countByDOExample", ateyeAppChangeLogConfDO);
        return count;
    }

    /**
     * ���¼�¼
     * @param ateyeAppChangeLogConfDO
     * @return ��Ӱ�������
     */
    public Integer updateAteyeAppChangeLogConfDO(AteyeAppChangeLogConfDO ateyeAppChangeLogConfDO) throws DAOException {
        int result = update("AteyeAppChangeLogConf.update", ateyeAppChangeLogConfDO);
        return result;
    }

    /**
     * ��ȡ�����б�
     * @param ateyeAppChangeLogConfDO
     * @return �����б�
     */
    @SuppressWarnings("unchecked")
    public List<AteyeAppChangeLogConfDO> findListByQuery(AteyeAppChangeLogConfDO ateyeAppChangeLogConfDO) throws DAOException {
        List<AteyeAppChangeLogConfDO> list = queryForList("AteyeAppChangeLogConf.findListByDO", ateyeAppChangeLogConfDO);
        return list;
    }

    /**
     * ����������ȡateyeAppChangeLogConfDO
     * @param id
     * @return ateyeAppChangeLogConfDO
     */
    public AteyeAppChangeLogConfDO findAteyeAppChangeLogConfDOByPrimaryKey(Long id) throws DAOException {
        AteyeAppChangeLogConfDO ateyeAppChangeLogConfDO = (AteyeAppChangeLogConfDO) queryForObject("AteyeAppChangeLogConf.findByPrimaryKey", id);
        return ateyeAppChangeLogConfDO;
    }

    /**
     * ɾ����¼
     * @param id
     * @return ��Ӱ�������
     */
    public Integer deleteAteyeAppChangeLogConfDOByPrimaryKey(Long id) throws DAOException {
        Integer rows = (Integer) delete("AteyeAppChangeLogConf.deleteByPrimaryKey", id);
        return rows;
    }

}