package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:ateye��������Ϣ���ѷ�
 * @author ˼��
 * Date 2019-05-05
 */
public class MessageConsumerDO extends BaseDO{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int TYPE_META=0;
	public static int TYPE_NOTIFY=1;

	/**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * Ӧ��
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * topic
     */
    private String topic;

    /**
     * ���ѷ���
     */
    private String consumerGroup;
    /*
     * ��Ϣ����
     */
    private String messageType;

    /**
     * 0-���� 1-ɾ��
     */
    private Integer type;

    /**
     * 0-���� 1-ɾ��
     */
    private Integer status;

    /**
     * ����
     */
    private String env;

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column Ӧ��
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * getter for column Ӧ��
     */
    public String getAppName() {
        return this.appName;
    }

    /**
     * setter for column Ӧ�÷���
     */
    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    /**
     * getter for column Ӧ�÷���
     */
    public String getAppNodeGroup() {
        return this.appNodeGroup;
    }

    /**
     * setter for column topic
     */
    public void setTopic(String topic) {
        this.topic = topic;
    }

    /**
     * getter for column topic
     */
    public String getTopic() {
        return this.topic;
    }

    /**
     * setter for column ���ѷ���
     */
    public void setConsumerGroup(String consumerGroup) {
        this.consumerGroup = consumerGroup;
    }

    /**
     * getter for column ���ѷ���
     */
    public String getConsumerGroup() {
        return this.consumerGroup;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
}