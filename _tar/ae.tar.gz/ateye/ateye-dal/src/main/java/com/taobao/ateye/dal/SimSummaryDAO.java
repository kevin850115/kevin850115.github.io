package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SimSummaryDO;
import com.taobao.ateye.exception.DAOException;

public interface SimSummaryDAO {
	
	Long addSummary(SimSummaryDO simSummaryDO) throws DAOException;

	List<SimSummaryDO> getSimSummarysById(Long simId) throws DAOException;

}
