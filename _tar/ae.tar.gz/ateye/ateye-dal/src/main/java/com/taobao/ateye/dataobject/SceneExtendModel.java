package com.taobao.ateye.dataobject;

import java.util.ArrayList;
import java.util.List;

/*
 * Ӧ����չ�ֶ�
 */
public class SceneExtendModel {

    private List<String> tags = new ArrayList<String>();//Ӧ�ñ�ǩ
    private boolean ignoreDetect = false;//����Safeƽ̨�Ķ��׼��

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

	public boolean isIgnoreDetect() {
		return ignoreDetect;
	}

	public void setIgnoreDetect(boolean ignoreDetect) {
		this.ignoreDetect = ignoreDetect;
	}


}
