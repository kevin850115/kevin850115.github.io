package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.GocEmgAlarmDetailDO;
import com.taobao.ateye.exception.DAOException;

public interface GocEmgDAO {
	
	List<GocEmgAlarmDetailDO> getAll() throws DAOException;
	
    List<GocEmgAlarmDetailDO> getByAlarmId(String alarmId) throws DAOException;

    Integer countByAlarmId(String alarmId) throws DAOException;
}
