package com.taobao.ateye.dataobject;

import java.util.Date;

public class FieldMethodTemplateDO extends BaseDO
{
	private static final long serialVersionUID = 430613501767477516L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ģ������
	 */
	private String templateName;
	/**
	 * ģ�����ͣ�����ģ��\����ģ�壩
	 */
	private int templateType;
	/**
	 * ����\��������id
	 */
	private Long setId;
	/**
	 * ����\�����������ƣ������ֶΣ�
	 */
	private String setName;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public Long getSetId() {
		return setId;
	}
	public void setSetId(Long setId) {
		this.setId = setId;
	}
	public String getSetName() {
		return setName;
	}
	public void setSetName(String setName) {
		this.setName = setName;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public int getTemplateType() {
		return templateType;
	}
	public void setTemplateType(int templateType) {
		this.templateType = templateType;
	}
}