package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/5.
 */
public class SceneServiceProvider extends BaseDO{
    /**
     */
    private long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * �����������
     */
    private String providerType;

    /**
     * �����������
     */
    private String providerName;

    /**
     * ����������ڵ�appName
     */
    private Long appId;

    /**
     * ����������ڵķ�������
     */
    private String appNodeGroup;

    private Date timeWindow;

    /**
     * ����  EnvironmentType
     */
    private String env;

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getProviderType() {
        return providerType;
    }

    public void setProviderType(String providerType) {
        this.providerType = providerType;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Date getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(Date timeWindow) {
        this.timeWindow = timeWindow;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }
}
