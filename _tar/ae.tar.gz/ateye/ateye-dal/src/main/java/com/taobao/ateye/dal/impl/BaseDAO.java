package com.taobao.ateye.dal.impl;

import java.util.List;

import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.monitor.dao.TripSqlMapBase;
import com.taobao.common.dao.persistence.DBRoute;


/**
* <p>
* ����dao�Ļ��� ��װsqlmapclienttemplate ת�� DataAccessException �� DAOException
* ��֤�����쳣���׳� DAOException ������־ logger��������
* </p>
*
* @author kongwang
* @version $Id: BaseDAO.java,v 0.1 Dec 18, 2006 2:46:11 PM hu.weih Exp $
* 
* @modified miaohai 2011-04-03 ���������������������ʵ��...
* 
* @author gumo ʹ����ET��Ŀ�е�BaseDAO��ɾ����һЩ�����õķ���
* 
*/
public class BaseDAO extends TripSqlMapBase{
	static final int BATCH_SIZE = 200;
	
    public DBRoute dbRoute = new DBRoute("ateye");

	public Object queryForObject(final String statementName,
			final Object parameterObject) throws DAOException {
		try {
			return super.executeQueryForObject(statementName, parameterObject, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

	
	@SuppressWarnings("unchecked")
	public List queryForList(final String statementName) throws DAOException {
		
		try {
			return super.executeQueryForList(statementName, null, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

	@SuppressWarnings("unchecked")
	public List queryForList(final String statementName,
			final Object parameterObject) throws DAOException {
		try {
			return super.executeQueryForList(statementName, parameterObject, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

	public Object insert(final String statementName,
			final Object parameterObject) throws DAOException {
		try {
			return super.executeInsert(statementName, parameterObject, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

	public int update(final String statementName, final Object parameterObject)
			throws DAOException {
		try {
			return super.executeUpdate(statementName, parameterObject, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

	public int delete(final String statementName, final Object parameterObject)
			throws DAOException {
		try {
			return super.executeUpdate(statementName, parameterObject, dbRoute);
		} catch (com.taobao.common.dao.persistence.exception.DAOException e1) {
			throw new DAOException(e1);
		}
	}

}
