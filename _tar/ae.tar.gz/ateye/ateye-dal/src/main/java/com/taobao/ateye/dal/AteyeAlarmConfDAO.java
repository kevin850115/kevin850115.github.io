package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmConfDAO {
    List<AteyeAlarmConfDO> selectAll(String env) throws DAOException;

    Long insert(AteyeAlarmConfDO ruleDO) throws DAOException;

    void updateStatus(Long id, int status) throws DAOException;

    void deleteOldRule() throws DAOException;

    List<AteyeAlarmConfDO> selectByIds(List<Long> confIds, String env) throws DAOException;

    AteyeAlarmConfDO selectById(Long id) throws DAOException;

    void updateReopenDate(String confId, Date date) throws DAOException;

    List<AteyeAlarmConfDO> selectAppScope() throws DAOException;

    AteyeAlarmConfDO selectByUUID(String uuid) throws DAOException;

    void deleteById(long id) throws DAOException;
}
