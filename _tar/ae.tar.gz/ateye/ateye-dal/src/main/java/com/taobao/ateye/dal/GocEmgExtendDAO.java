package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.GocEmgExtendDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2019/5/7.
 */
public interface GocEmgExtendDAO {
    List<GocEmgExtendDO> getAll() throws DAOException;
    
    List<GocEmgExtendDO> getByAlarmId(String id) throws DAOException;

    List<GocEmgExtendDO> getByAlarmIdAndType(String id,String type) throws DAOException;

	void insert(GocEmgExtendDO aDO) throws DAOException;

	void deleteByIdAndType(String alarmId, String type) throws DAOException;
	void deleteByIdAndTypeAndValue(String alarmId, String type,String value) throws DAOException;
}
