package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2019/4/11.
 */
public class HSFServiceMetadataDO extends BaseDO {
    /**
     */
    private long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * Ψһ�����ʾ
     */
    private String uniqueServiceName;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * ����
     */
    private String nodeGroup;

    /**
     * 0-�� 1-��
     */
    private int isProvider;

    /**
     * �ӿ�����
     */
    private String interfaceName;

    /**
     * version
     */
    private String version;

    /**
     * ��
     */
    private String hsfGroup;

    /**
     * ��������
     */
    private String generic;

    /**
     * ��ʱʱ��
     */
    private int timeout;

    /**
     * �����߳���
     */
    private int corePoolSize;

    /**
     * ����߳���
     */
    private int maxPoolSize;

    /**
     * ����json��Ϣ
     */
    private String methodInfos;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getUniqueServiceName() {
        return uniqueServiceName;
    }

    public void setUniqueServiceName(String uniqueServiceName) {
        this.uniqueServiceName = uniqueServiceName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getNodeGroup() {
        return nodeGroup;
    }

    public void setNodeGroup(String nodeGroup) {
        this.nodeGroup = nodeGroup;
    }

    public int getIsProvider() {
        return isProvider;
    }

    public void setIsProvider(int isProvider) {
        this.isProvider = isProvider;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getHsfGroup() {
        return hsfGroup;
    }

    public void setHsfGroup(String hsfGroup) {
        this.hsfGroup = hsfGroup;
    }

    public String getGeneric() {
        return generic;
    }

    public void setGeneric(String generic) {
        this.generic = generic;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getCorePoolSize() {
        return corePoolSize;
    }

    public void setCorePoolSize(int corePoolSize) {
        this.corePoolSize = corePoolSize;
    }

    public int getMaxPoolSize() {
        return maxPoolSize;
    }

    public void setMaxPoolSize(int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

    public String getMethodInfos() {
        return methodInfos;
    }

    public void setMethodInfos(String methodInfos) {
        this.methodInfos = methodInfos;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
