package com.taobao.ateye.query;

public class OperateLogQuery extends QueryBaseForMysql{
    /**
     * 
     */
    private static final long serialVersionUID = 6553144284804918750L;
    String operater;
    String cl;
    String method;
    String args;
    String msg;
    String level;
    String serverId;
    public String getOperater() {
        return operater;
    }
    public void setOperater(String operater) {
        this.operater = operater;
    }
    public String getCl() {
        return cl;
    }
    public void setCl(String cl) {
        this.cl = cl;
    }
    public String getMethod() {
        return method;
    }
    public void setMethod(String method) {
        this.method = method;
    }
    public String getArgs() {
        return args;
    }
    public void setArgs(String args) {
        this.args = args;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public String getLevel() {
        return level;
    }
    public void setLevel(String level) {
        this.level = level;
    }
    public String getServerId() {
        return serverId;
    }
    public void setServerId(String serverId) {
        this.serverId = serverId;
    }
}
