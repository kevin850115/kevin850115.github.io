package com.taobao.ateye.dataobject;

public class UserProfileDO {
	public static final String ON_WORK="work";
	public static final String OFF_WORK="off";
	private String nick;
	private String email="--";
	private String phone="";
	private String status=ON_WORK;
	public String getNick() {
		return nick;
	}
	public String getWorkStatusDesc(){
		if ( status.equals(ON_WORK) ){
			return "��ְ";
		}else if ( status.equals(OFF_WORK) ){
			return "��ְ";
		}
		return "";
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
