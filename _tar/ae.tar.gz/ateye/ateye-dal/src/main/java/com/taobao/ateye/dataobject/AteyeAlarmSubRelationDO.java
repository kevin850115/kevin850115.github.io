package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:���Ĺ�ϵ
 * @author ˼��
 * Date 2018-12-06
 */
public class AteyeAlarmSubRelationDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ������id
     */
    private Long subId;

    /**
     * ��������id
     */
    private Long alarmConfId;

    /**
     * Ȧ��Ӧ�õ�����,ҵ����,ĳ����,ownerӦ��,appps
     */
    private Integer appScopeType;

    /**
     * Ȧ��Ӧ�õ�ֵ
     */
    private String appScopeValue;

    /**
     * ҵ������
     */
    private String ruleType;

    /**
     * 0-��Ч 1-ɾ��
     */
    private int isDelete;

    /**
     * ����
     */
    private String env;

    /**
     * 0-�����ӵ�,1-������ͬ��hbase���ϵĹ���
     */
    private int source;

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column ������id
     */
    public void setSubId(long subId) {
        this.subId = subId;
    }

    /**
     * getter for column ������id
     */
    public long getSubId() {
        return this.subId;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

    public void setSubId(Long subId) {
        this.subId = subId;
    }

    public Long getAlarmConfId() {
        return alarmConfId;
    }

    public void setAlarmConfId(Long alarmConfId) {
        this.alarmConfId = alarmConfId;
    }

    public Integer getAppScopeType() {
        return appScopeType;
    }

    public void setAppScopeType(Integer appScopeType) {
        this.appScopeType = appScopeType;
    }

    public String getAppScopeValue() {
        return appScopeValue;
    }

    public void setAppScopeValue(String appScopeValue) {
        this.appScopeValue = appScopeValue;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }
}