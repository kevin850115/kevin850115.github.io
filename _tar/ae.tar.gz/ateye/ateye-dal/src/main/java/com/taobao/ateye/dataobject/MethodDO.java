package com.taobao.ateye.dataobject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MethodDO extends BaseDO
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5550897470568765357L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ��������id
	 */
	private Long setId;
	/**
	 * Ӧ����
	 */
	private String appName;
	/**
	 * BeanName
	 */
	private String beanName;
	/**
	 * ����ǩ��
	 */
	private String methodSign;
	/**
	 * ��������
	 */
	private String methodDesc;
	/**
	 * ��������
	 */
	private int paramCount;
	/**
	 * ������������
	 */
	private String paramDesc;
	/**
	 * ������������
	 */
	private String paramType;
	/**
	 * setId,appName,beanName,methodSign��ϼ����MD5ֵ
	 */
	private String md5;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSetId() {
		return setId;
	}
	public void setSetId(Long setId) {
		this.setId = setId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getBeanName() {
		return beanName;
	}
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	public String getMethodSign() {
		return methodSign;
	}
	public void setMethodSign(String methodSign) {
		this.methodSign = methodSign;
	}
	public String getMethodDesc() {
		return methodDesc;
	}
	public void setMethodDesc(String methodDesc) {
		this.methodDesc = methodDesc;
	}
	public int getParamCount() {
		return paramCount;
	}
	public void setParamCount(int paramCount) {
		this.paramCount = paramCount;
	}
	public String getParamDesc() {
		return paramDesc;
	}
	public void setParamDesc(String paramDesc) {
		this.paramDesc = paramDesc;
	}
	public String getParamType() {
		return paramType;
	}
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	public String getMd5() {
		return md5;
	}
	public void setMd5(String md5) {
		this.md5 = md5;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public List<Map<String,String>> getParamValueRowForVelocity(MethodTemplateValueDO methodTemplateValue)
	{
		if(paramCount>0){
			List<Map<String,String>> rtnValue = new ArrayList<Map<String,String>>();
			String[] paramTypeArray = getParamTypeArray();
			String[] paramDescArray = getParamDescArray();
			String[] paramValueArray = methodTemplateValue.getParamValueArray();
			String[] nullValueIndexArray = methodTemplateValue.getNullValueIndexArray();
			for(int i=0; i<paramCount; i++){
				Map<String,String> one = new HashMap<String,String>();
				one.put("oneParamType", paramTypeArray[i]);
				one.put("oneParamDesc", paramDescArray[i]);
				one.put("oneParamValue", (paramValueArray != null && i<paramValueArray.length)?paramValueArray[i]:"");
				one.put("valueType", "0");//��null����ֵ
				if(nullValueIndexArray != null && nullValueIndexArray.length>0){
					for(String nullIndex : nullValueIndexArray){
						if(nullIndex.equalsIgnoreCase(String.valueOf(i+1))){
							one.put("valueType", "1");//null
							break;
						}
					}
				}				
				rtnValue.add(one);
			}
			return rtnValue;
		}
		return null;
	}
	public List<Map<String,String>> getParamValueRowForVelocity()
	{
		if(paramCount>0){
			List<Map<String,String>> rtnValue = new ArrayList<Map<String,String>>();
			String[] paramTypeArray = getParamTypeArray();
			String[] paramDescArray = getParamDescArray();
			for(int i=0; i<paramCount; i++){
				Map<String,String> one = new HashMap<String,String>();
				one.put("oneParamType", paramTypeArray[i]);
				one.put("oneParamDesc", paramDescArray[i]);
				one.put("oneParamValue", "");
				rtnValue.add(one);
			}
			return rtnValue;
		}
		return null;
	}
	private String[] getParamDescArray()
	{
		if(paramCount>0){
			String[] rtnValue = new String[paramCount];
			int i=0;
			if(paramDesc != null){
				String[] splitArray = paramDesc.split("&");
				if(splitArray != null){
					for(; i<splitArray.length&&i<paramCount; i++){
						rtnValue[i] = splitArray[i];
					}
				}
			}
			for(; i<paramCount; i++){
				rtnValue[i] = "���޲�������";
			}
			return rtnValue;
		}
		return null;
	}
	private String[] getParamTypeArray()
	{
		if(paramCount>0){
			String[] rtnValue = new String[paramCount];
			int i=0;
			if(paramType != null){
				String[] splitArray = paramType.split(",");
				if(splitArray != null){
					for(; i<splitArray.length&&i<paramCount; i++){
						rtnValue[i] = splitArray[i];
					}
				}
			}
			for(; i<paramCount; i++){
				rtnValue[i] = "���޲���������Ϣ";
			}
			return rtnValue;
		}
		return null;
	}
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		else if (!(obj instanceof MethodDO))
			return false;
		else {
			MethodDO other = (MethodDO) obj;
			return this.appName.equals(other.appName)
					&& this.beanName.equals(other.beanName)
					&& this.methodSign.equals(other.methodSign);
		}
	}
	
	@Override
	public int hashCode() {
		int result = this.appName.hashCode();
		result = 37 * result + this.beanName.hashCode();
		result = 37 * result + this.methodSign.hashCode();
		return result;
	}
    public void calculateMD5Value()
    {
    	if(md5 == null || md5.length() != 32){
    		byte[] bytes = null;
        	if(setId>0 && appName != null && beanName != null && methodSign != null ){
        		try{
            		MessageDigest digest = MessageDigest.getInstance("MD5");
            		digest.update((setId+""+appName+beanName+methodSign).getBytes("UTF-8"));
            		bytes = digest.digest();
            	}catch(Exception e){
            		bytes = generate16LengthByteArray();
            	}
    		}
    		else{
    			bytes = generate16LengthByteArray();
    		}
        	StringBuilder sb = new StringBuilder();
    		for(byte b : bytes){
    			sb.append(toHexValue(b));
    		}
    		md5 = sb.toString();
    	}
    }
    private static String toHexValue(byte b)
    {
    	int low = b&0xf;
    	int high = (b>>>4)&0xf;
    	return hexConst[high]+""+hexConst[low];
    }
    private byte[] generate16LengthByteArray(){
    	byte[] array = new byte[16];
    	for(int i=0; i<16; i++){
    		array[i] = (byte)rand.nextInt(16);
    	}
    	return array;
    }
    private static String[] hexConst = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
    private static Random rand = new Random(17);
}
