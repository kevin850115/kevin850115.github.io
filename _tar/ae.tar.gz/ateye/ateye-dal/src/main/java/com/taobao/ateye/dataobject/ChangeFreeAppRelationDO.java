package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/10/9.
 */
public class ChangeFreeAppRelationDO extends BaseDO {
    /**
     */
    private Long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * Ӧ��id
     */
    private long appId;

    /**
     * changeFreeId
     */
    private long changeFreeId;

    /**
     * �ƻ���ʼʱ��
     */
    private Date startTime;

    /**
     * �ƻ�����ʱ�� end_time
     */
    private Date endTime;

    /**
     * ����
     */
    private String env;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public long getAppId() {
        return appId;
    }

    public void setAppId(long appId) {
        this.appId = appId;
    }

    public long getChangeFreeId() {
        return changeFreeId;
    }

    public void setChangeFreeId(long changeFreeId) {
        this.changeFreeId = changeFreeId;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
}
