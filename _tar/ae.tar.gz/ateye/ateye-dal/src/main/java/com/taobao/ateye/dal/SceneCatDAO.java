package com.taobao.ateye.dal;

import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.SceneCatDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneCatDAO {

    Long insert(SceneCatDO CatDO) throws DAOException;
    
    List<SceneCatDO> getAll() throws DAOException;
    
    Map<Long,SceneCatDO> getAllMap() throws DAOException;

	int updateCatName(String id, String catName) throws DAOException;

}
