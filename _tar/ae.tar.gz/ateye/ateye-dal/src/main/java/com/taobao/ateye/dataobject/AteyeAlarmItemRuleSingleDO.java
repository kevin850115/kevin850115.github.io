package com.taobao.ateye.dataobject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Description:���������
 * @author ˼��
 * Date 2018-12-06
 */
public class AteyeAlarmItemRuleSingleDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ������id
     */
    private long alarmItemId;

    /**
     * ��������id
     */
    private long alarmConfId;

    /**
     * ��ֵ
     */
    private BigDecimal threshold;

    /**
     * 0-��, 1-ʱ, 2-��
     */
    private int timeType;

    /**
     * �Ƚ�>,=,<
     */
    private int compareType;

    /**
     * ��������
     */
    private BigDecimal continuousTime;

    /**
     * ��������,sum,avg,each one
     */
    private Integer ruleOprType;

    /**
     * ����
     */
    private String env;

    /**
     * ͬ��֮ǰ����,0 ��ʾ��
     */
    private Integer relativeDay;

    /**
     * ͬ��֮ǰ�ı���
     */
    private BigDecimal relativeDayTimes;

    /**
     * 0-�����ӵ�,1-������ͬ��hbase���ϵĹ���
     */
    private int source;

    public Integer getIntContinuousTime(){
        if(continuousTime != null){
            return continuousTime.intValue();
        }
        return 0;
    }


    public BigDecimal getRelativeDayTimes() {
        return relativeDayTimes;
    }

    public void setRelativeDayTimes(BigDecimal relativeDayTimes) {
        this.relativeDayTimes = relativeDayTimes;
    }

    public int getTimeType() {
        return timeType;
    }

    public void setTimeType(int timeType) {
        this.timeType = timeType;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public Integer getRelativeDay() {
        return relativeDay;
    }

    public void setRelativeDay(Integer relativeDay) {
        this.relativeDay = relativeDay;
    }

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    public long getAlarmItemId() {
        return alarmItemId;
    }

    public void setAlarmItemId(long alarmItemId) {
        this.alarmItemId = alarmItemId;
    }

    public long getAlarmConfId() {
        return alarmConfId;
    }

    public void setAlarmConfId(long alarmConfId) {
        this.alarmConfId = alarmConfId;
    }

    /**
     * setter for column ��ֵ
     */
    public void setThreshold(BigDecimal threshold) {
        this.threshold = threshold;
    }

    /**
     * getter for column ��ֵ
     */
    public BigDecimal getThreshold() {
        return this.threshold;
    }

    public Float getLowerValueThresholdOfPercent() {
        if(getThreshold()!=null){
            return getThreshold().floatValue()/100;
        }else{
            return 0f;
        }

    }

    public int getCompareType() {
        return compareType;
    }

    public void setCompareType(int compareType) {
        this.compareType = compareType;
    }

    public Integer getRuleOprType() {
        return ruleOprType;
    }

    public void setRuleOprType(Integer ruleOprType) {
        this.ruleOprType = ruleOprType;
    }

    public BigDecimal getContinuousTime() {
        return continuousTime;
    }

    public void setContinuousTime(BigDecimal continuousTime) {
        this.continuousTime = continuousTime;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

}