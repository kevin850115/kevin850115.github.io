package com.taobao.ateye.dataobject;

public class ReportSubscribDO extends BaseDO {

	/**
	 * �������Ĺ�ϵDO
	 */
	private static final long serialVersionUID = -2131369544004995210L;
	private Integer id;
	private String email;
	private String userNick;
	private Integer status;
	private Integer reportId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getReportId() {
		return reportId;
	}
	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	

}
