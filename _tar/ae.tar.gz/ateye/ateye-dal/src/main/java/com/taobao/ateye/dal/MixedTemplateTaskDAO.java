package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.MixedTemplateTaskDO;
import com.taobao.ateye.exception.DAOException;

public interface MixedTemplateTaskDAO 
{
	/**
	 * ��ѯȫ������
	 * @return
	 * @throws DAOException
	 */
	public List<MixedTemplateTaskDO> getAllTemplateTaskAsList() throws DAOException;
	
	/**
	 * ����id��ѯָ��������
	 * @param mixedTemplateTaskId
	 * @return
	 * @throws DAOException
	 */
	public MixedTemplateTaskDO getMixedTemplateTaskById(Long mixedTemplateTaskId) throws DAOException;
	
	/**
	 * ����һ������
	 * @param mixedTemplateTask
	 * @return
	 * @throws DAOException
	 */
	public Long insertMixedTemplateTask(MixedTemplateTaskDO mixedTemplateTask) throws DAOException;
	
	/**
	 * ɾ��ָ���Ŀ�������
	 * @param mixedTemplateTaskId
	 * @return
	 * @throws DAOException
	 */
	public int deleteMixedTemplateTaskById(Long mixedTemplateTaskId) throws DAOException;
	
	/**
	 * ����һ�����������ִ��ʱ��
	 * @param newMixedTemplateTask
	 * @return
	 * @throws DAOException
	 */
	public int updateMixedTemplateTask(MixedTemplateTaskDO newMixedTemplateTask) throws DAOException;
	
	/**
	 * ��֤TaskNameΨһ
	 * @param taskName
	 * @return
	 * @throws DAOException
	 */
	public boolean validTemplateTaskName(String taskName) throws DAOException;
}
