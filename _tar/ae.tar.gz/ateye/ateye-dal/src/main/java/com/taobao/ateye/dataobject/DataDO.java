package com.taobao.ateye.dataobject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
/***
 * ����������ֵDO
 * @author jianbo.hc
 *
 */
public class DataDO extends BaseDO {

	private static final long serialVersionUID = 4877698035764880524L;
    private long id;
    private Integer dataId;
    private String name;
    private String summary;
    private Integer catId;//���id
    private Date statTime;//ͳ��ʱ��
    private Date statTimeMin;//��ʼʱ��
    private Date statTimeMax;//����ʱ��
    private String dataValue;//������ֵ
    private String yesToValue;//��������
    private String lasWekValue;//��������
    private String subName;//Group By�������ݱ�־����ָ����
    
    
	public String getYesToValue() {
		return yesToValue;
	}
	public void setYesToValue(String yesToValue) {
		this.yesToValue = yesToValue;
	}
	public String getLasWekValue() {
		return lasWekValue;
	}
	public void setLasWekValue(String lasWekValue) {
		this.lasWekValue = lasWekValue;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Integer getDataId() {
		return dataId;
	}
	public void setDataId(Integer dataId) {
		this.dataId = dataId;
	}
	public Date getStatTime() {
		return statTime;
	}
	public void setStatTime(Date statTime) {
		this.statTime = statTime;
	}
	
	public Date getStatTimeMin() {
		return statTimeMin;
	}
	public void setStatTimeMin(Date statTimeMin) {
		this.statTimeMin = statTimeMin;
	}
	public Date getStatTimeMax() {
		return statTimeMax;
	}
	public void setStatTimeMax(Date statTimeMax) {
		this.statTimeMax = statTimeMax;
	}
	public String getDataValue() {
		return dataValue;
	}
	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public Integer getCatId() {
		return catId;
	}
	public void setCatId(Integer catId) {
		this.catId = catId;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}

	/*
	 * ��ȡurlEndode���dataNameֵ������"+"ת��Ӱ��
	 */
	public String getEncodeName(){
		try {
			return URLEncoder.encode(name, "utf8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
    
}
