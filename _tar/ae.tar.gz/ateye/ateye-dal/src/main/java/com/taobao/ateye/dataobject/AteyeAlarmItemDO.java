package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:������
 * @author ˼��
 * Date 2018-12-06
 */
public class AteyeAlarmItemDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * Ӧ������
     */
    private String app;

    /**
     * ������k1
     */
    private String k1;
    /**
     * ������k2
     */
    private String k2;
    /**
     * ������k3
     */
    private String k3;
    /**
     * ������k4
     */
    private String k4;
    /**
     * ������k5
     */
    private String k5;
    /**
     * ������k6
     */
    private String k6;

    /**
     * ������KVʱ���ڶ���ֵ��ValueType:v1,v2,v1v2,v2v1
     */
    private String type2;

    /**
     * ������KVʱ���ڶ���ֵ��Ӧ����
     */
    private String app2;

    /**
     * ҵ������,KV EXCEPTION��
     */
    private String ruleType;

    /**
     * ҵ������,Ʃ��biz_hsf_exception,biz_hsf_timeout,biz_exception_type_incr,tracker_hbase_cache,KV��
     */
    private String ruleTypeDetail;

    /**
     * ����
     */
    private String env;

    /**
     * ����KV��,��ʾv1,v2,v1v2,v2v1
     */
    private String type;

    /**
     * Ψһֵ app k1 k2 k3 k4 k5 k6 env
     */
    private String ukMd5;

    /**
     * 0-�����ӵ�,1-������ͬ��hbase���ϵĹ���
     */
    private int source;

    public String getRuleTypeDetail() {
        return ruleTypeDetail;
    }

    public void setRuleTypeDetail(String ruleTypeDetail) {
        this.ruleTypeDetail = ruleTypeDetail;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public String getUkMd5() {
        return ukMd5;
    }

    public void setUkMd5(String ukMd5) {
        this.ukMd5 = ukMd5;
    }

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column Ӧ������
     */
    public void setApp(String app) {
        this.app = app;
    }

    /**
     * getter for column Ӧ������
     */
    public String getApp() {
        return this.app;
    }

    public String getK1() {
        return k1;
    }

    public void setK1(String k1) {
        this.k1 = k1;
    }

    public String getK2() {
        return k2;
    }

    public void setK2(String k2) {
        this.k2 = k2;
    }

    public String getK3() {
        return k3;
    }

    public void setK3(String k3) {
        this.k3 = k3;
    }

    public String getK4() {
        return k4;
    }

    public void setK4(String k4) {
        this.k4 = k4;
    }

    public String getK5() {
        return k5;
    }

    public void setK5(String k5) {
        this.k5 = k5;
    }

    public String getK6() {
        return k6;
    }

    public void setK6(String k6) {
        this.k6 = k6;
    }

    /**
     * setter for column ����KV��,��ʾv1,v2,v1v2,v2v1
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * getter for column ����KV��,��ʾv1,v2,v1v2,v2v1
     */
    public String getType() {
        return this.type;
    }

    /**
     * setter for column ҵ������,Ʃ��biz_hsf_exception,biz_hsf_timeout,biz_exception_type_incr,tracker_hbase_cache,KV��
     */
    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    /**
     * getter for column ҵ������,Ʃ��biz_hsf_exception,biz_hsf_timeout,biz_exception_type_incr,tracker_hbase_cache,KV��
     */
    public String getRuleType() {
        return this.ruleType;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

    public String getType2() {
        return type2;
    }

    public void setType2(String type2) {
        this.type2 = type2;
    }

    public String getApp2() {
        return app2;
    }

    public void setApp2(String app2) {
        this.app2 = app2;
    }
}