package com.taobao.ateye.dataobject;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Ӧ�÷�����������
 * 
 * @author saite.wd
 * @version $Id: AppServiceDescDO.java, v 0.1 2016��2��16�� ����2:25:20 saite Exp $
 */
public class AppServiceDescDO extends BaseDO {

    private static final long serialVersionUID = -1745144819533648403L;
    
    public static final Map<Integer, String> CATEGORIES = new HashMap<Integer, String>();
    
    static {
        CATEGORIES.put(7, "ƽ̨����");
        CATEGORIES.put(8, "���ݷ���");
        CATEGORIES.put(9, "���߷���");
        CATEGORIES.put(10, "�ͻ���");
        CATEGORIES.put(11, "�����������");
        CATEGORIES.put(12, "ҵ�����");
        CATEGORIES.put(13, "�̼ҷ���");
        CATEGORIES.put(14, "֧�ŷ���");
        CATEGORIES.put(15, "��̨����");
        CATEGORIES.put(16, "�������ݷ���");
        CATEGORIES.put(17, "��������");
    }
    
    /**
     * ����
     */
    private Long id;
    
    /**
     * Ӧ������
     */
    private String app;
    
    /**
     * ��������
     */
    private String service;
    
    /**
     * ��������
     */
    private String method;
    
    /**
     * ����
     */
    private String description;
    
    /**
     * ����
     */
    private Integer category;
    
    /**
     * ����ʱ��
     */
    private Date gmtCreate;
    
    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((app == null) ? 0 : app.hashCode());
        result = prime * result + ((category == null) ? 0 : category.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((gmtCreate == null) ? 0 : gmtCreate.hashCode());
        result = prime * result + ((gmtModified == null) ? 0 : gmtModified.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((method == null) ? 0 : method.hashCode());
        result = prime * result + ((service == null) ? 0 : service.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AppServiceDescDO other = (AppServiceDescDO) obj;
        if (app == null) {
            if (other.app != null)
                return false;
        } else if (!app.equals(other.app))
            return false;
        if (category == null) {
            if (other.category != null)
                return false;
        } else if (!category.equals(other.category))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (gmtCreate == null) {
            if (other.gmtCreate != null)
                return false;
        } else if (!gmtCreate.equals(other.gmtCreate))
            return false;
        if (gmtModified == null) {
            if (other.gmtModified != null)
                return false;
        } else if (!gmtModified.equals(other.gmtModified))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (method == null) {
            if (other.method != null)
                return false;
        } else if (!method.equals(other.method))
            return false;
        if (service == null) {
            if (other.service != null)
                return false;
        } else if (!service.equals(other.service))
            return false;
        return true;
    }
    
}
