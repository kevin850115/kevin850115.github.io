package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.NoParamSqlDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/6/20.
 */
public interface NoParamSqlDAO {
    Long insert(NoParamSqlDO noParamSqlDO) throws DAOException;
    List<NoParamSqlDO> select(String appName, String appNodeGroup, Date timeWindow, String env) throws DAOException;
    Integer exist(String appNodeGroup, String method,Date timeWindow, String env) throws DAOException;
}
