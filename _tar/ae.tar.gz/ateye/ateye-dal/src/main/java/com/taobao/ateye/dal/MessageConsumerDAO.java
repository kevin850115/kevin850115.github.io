package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.MessageConsumerDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface MessageConsumerDAO {
    Long insert(MessageConsumerDO messageConsumerDO) throws DAOException;

	void deleteAll() throws DAOException;
}
