package com.taobao.ateye.dataobject;

import java.util.Date;

public class CollectionInfoDO  extends BaseDO
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollectionInfoDO(){}
	
	/**
	 * ����ID
	 */
	private Long id;
	
	/**
	 * Ӧ����
	 */
	private String appName;
	
	/**
	 * ����IP
	 */
	private String ip;
	
	/**
	 * ��־�ļ�����·��
	 */
	private String path;
	
	/**
	 * �ռ����ĵ�һ����־��LogTime
	 */
	private String firstTime;
	
	/**
	 * �ռ��������һ����־��LogTime
	 */
	private String lastTime;
	
	/**
	 * �ռ����ĵ�һ����־�ı���Sample
	 */
	private String firstLine;
	
	/**
	 * �ռ��������һ����־�ı���Sample
	 */
	private String lastLine;
	
	/**
	 * �ռ�������־������
	 */
	private int total;
	
	/**
	 * ����ʱ��
	 */
	private Date createdTime;

	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getFirstTime() {
		return firstTime;
	}

	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public String getFirstLine() {
		return firstLine;
	}

	public void setFirstLine(String firstLine) {
		this.firstLine = firstLine;
	}

	public String getLastLine() {
		return lastLine;
	}

	public void setLastLine(String lastLine) {
		this.lastLine = lastLine;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
}
