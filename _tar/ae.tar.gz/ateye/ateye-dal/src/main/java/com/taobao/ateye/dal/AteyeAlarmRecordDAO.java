package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmRecordDAO {
    List<AteyeAlarmRecordDO> selectByAlarmTime(Date startTime, Date endTime) throws DAOException;

    Long insert(AteyeAlarmRecordDO ruleDO) throws DAOException;

    void deleteByAlarmTime(Date startTime, Date endTime) throws DAOException;

    Integer countByStartTime(String uuid,String extendUUID,Date start) throws DAOException;

    Integer countRealAlarmByStartTime(String uuid,String extendUUID,Date start) throws DAOException;
    Integer countRetrainAlarmByStartTime(String uuid,String extendUUID,Date start) throws DAOException;

    AteyeAlarmRecordDO selectRecentlyRealByStartTime(String uuid, String extendUUID,Date start) throws DAOException;

    List<AteyeAlarmRecordDO> getTodayByConfIds(Date date, List<Long> alarmConfIds, String env)throws DAOException;

    List<AteyeAlarmRecordDO> select(List<Long> confIds, Date startDate, String uuid, String extendUUID, String appName, Long subId, String env) throws DAOException;

    Integer countRealBySubIdStartTime(long subId, Date date) throws DAOException;

    Integer countRealByConfIdStartTime(long confId, Date startTime) throws DAOException ;

    AteyeAlarmRecordDO selectById(long id) throws DAOException;

    void updateAlarmText(Long id, String alarmText) throws DAOException;

    void updateAlarmType(Long recordId, String alarmType) throws DAOException;
}
