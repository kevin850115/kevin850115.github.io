package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HsfInterfaceDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface HsfInterfaceDAO {
    Long insert(HsfInterfaceDO hsfInterfaceDO) throws DAOException;
    HsfInterfaceDO getByUk(String uniqueServiceName,String appNodeGroup,String type,String env) throws DAOException;
    void deleteById(Long id) throws DAOException;
    List<String> getAllProviderService(String env) throws DAOException;

    List<String> getAllConsumerService(String env) throws DAOException;

    List<HsfInterfaceDO> getAllConsumer(String env) throws DAOException;

    List<HsfInterfaceDO> getAll() throws DAOException;

    HsfInterfaceDO getById(Long id) throws DAOException;

    /*
     * ������Ĳ�ѯ
     */
    List<HsfInterfaceDO> getByInterface(String interfaceName,String appNodeGroup,String type,String env) throws DAOException;
    /*
     * ��������Ĳ�ѯ
     */
    List<HsfInterfaceDO> getByInterface(String interfaceName,String type,String env) throws DAOException;

    List<HsfInterfaceDO> getByService(String uniqueServiceName,String type,String env) throws DAOException;
}
