package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/17.
 * ҵ������Ϣ
 */
public class BizLineDO extends BaseDO{
    /**
     */
    private long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * ҵ��������
     */
    private String name;

    /**
     * ҵ���߸�����
     */
    private String owner;
    /*
     * ����ҵ����
     */
    private String detail;

    /**
     * ������
      */
    private String operator;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}
}
