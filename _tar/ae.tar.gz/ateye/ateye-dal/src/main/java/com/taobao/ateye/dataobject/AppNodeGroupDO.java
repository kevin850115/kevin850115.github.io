package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:Ӧ�÷���
 * @author ˼��
 * Date 2019-05-05
 */
public class AppNodeGroupDO extends BaseDO{

    /**
     * ���� ��ֹ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * Ӧ��id
     */
    private long appId;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * ����
     */
    private String env;

    /**
     * setter for column ���� ��ֹ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ���� ��ֹ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column Ӧ��id
     */
    public void setAppId(long appId) {
        this.appId = appId;
    }

    /**
     * getter for column Ӧ��id
     */
    public long getAppId() {
        return this.appId;
    }

    /**
     * setter for column Ӧ�÷���
     */
    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    /**
     * getter for column Ӧ�÷���
     */
    public String getAppNodeGroup() {
        return this.appNodeGroup;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}