package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SimSampleDO;
import com.taobao.ateye.exception.DAOException;

public interface SimSampleDAO {

	Long addSample(SimSampleDO sample) throws DAOException;
	
	List<SimSampleDO> querySamples(Long simId) throws DAOException;

}
