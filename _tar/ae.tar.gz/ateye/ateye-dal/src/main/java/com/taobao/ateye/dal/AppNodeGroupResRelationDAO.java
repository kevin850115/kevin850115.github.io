package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AppNodeGroupResRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AppNodeGroupResRelationDAO {
    Long insert(AppNodeGroupResRelationDO appNodeGroupResRelationDO) throws DAOException;
    AppNodeGroupResRelationDO getByUk(String appNodeGroup,String type, String uniqueServiceName,Date timeWindow,String env) throws DAOException;
}
