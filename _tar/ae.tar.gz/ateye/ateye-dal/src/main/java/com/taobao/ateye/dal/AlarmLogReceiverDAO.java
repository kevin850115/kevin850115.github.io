package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AlarmLogReceiverDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/11/15.
 */
public interface AlarmLogReceiverDAO {
    Long saveAlarmLogReceiver(AlarmLogReceiverDO alarmLogReceiverDO) throws DAOException;

    AlarmLogReceiverDO getByName(String name) throws DAOException;
}
