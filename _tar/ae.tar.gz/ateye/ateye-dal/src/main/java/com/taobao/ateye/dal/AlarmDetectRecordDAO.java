package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AlarmDetectRecordDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/1/11.
 */
public interface AlarmDetectRecordDAO {

    Long insert(AlarmDetectRecordDO detectRecordDO) throws DAOException;

    List<AlarmDetectRecordDO> selectByStartTime(Date startTime) throws DAOException;

    Integer countByStartTime(String uuid,String extendUUID,Date startTime) throws DAOException;

    List<Long> selectBeforeIdsByStartTime(Date startTime,int size) throws DAOException;

    void deleteByIds(List<Long> ids) throws DAOException;
}
