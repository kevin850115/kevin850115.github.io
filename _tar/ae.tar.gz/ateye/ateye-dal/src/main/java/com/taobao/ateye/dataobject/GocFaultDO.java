package com.taobao.ateye.dataobject;

import java.util.Date;

public class GocFaultDO extends BaseDO {

	private static final long serialVersionUID = 1L;
	/**
	 * ����
	 */
	private Long id;

	/**
	 * ����ʱ��
	 */
	private Date gmtCreate;

	/**
	 * �޸�ʱ��
	 */
	private Date gmtModified;

	/**
	 * ����ʱ��
	 */
	private Date happenTime;

	/**
	 * ����ʱ��
	 */
	private Date catchTime;

	/**
	 * ��Ӧʱ��
	 */
	private Date responseTime;

	/**
	 * ʵ�ʽ��ʱ��
	 */
	private Date resolveTime;

	/**
	 * ����id
	 */
	private Long hitchId;

	/**
	 * ���ϱ���
	 */
	private String hitchName;

	/**
	 * ��������Ӧ��
	 */
	private String hitchApp;

	/**
	 * ���ϵȼ�
	 */
	private Integer hitchLevel;

	/**
	 * 0 Ԥ�� 1=p1, 2 =p2, 3=p3, 4=p4, 5=��������
	 */
	private String hitchLevelCn;

	/**
	 * ������Դ
	 */
	private Integer hitchOrigin;

	/**
	 * ������Դ 1=��ط���,2=�û��ϱ�
	 */
	private String hitchOriginCn;

	/**
	 * ��������
	 */
	private Integer hitchType;

	/**
	 * �������� 1=ҵ�����, 3=��ȫ©��
	 */
	private String hitchTypeCn;

	/**
	 * ����״̬
	 */
	private Integer hitchStatus;

	/**
	 * 1 �����,3 ϵͳ���޸� ,4 ������ 5 ��ȡ��
	 */
	private String hitchStatusName;

	/**
	 * ���ϱ���״̬id
	 */
	private Long hitchReportedDone;

	/**
	 * ���ϱ���״̬����pm ע:0=δ��д,1=���ύ,2=�����,3=���˻�,4=�����,5=�ѷ���,6=��ȡ��
	 */
	private String hitchReportedDoneCn;

	/**
	 * �������
	 */
	private Integer hitchCategory;

	/**
	 * ������������
	 */
	private String hitchCategoryCn;

	/**
	 * �Ƿ�������
	 */
	private Boolean ischangetrigger;

	/**
	 * ������id
	 */
	private String hitchSheepBlamed;

	/**
	 * ����������
	 */
	private String hitchSheepBlamedCn;

	/**
	 * ������id
	 */
	private String hitchHandler;

	/**
	 * ����������
	 */
	private String hitchHandlerCn;

	/**
	 * ����վ��id ע�⣺��id ����14905���� id = 14941ʱ�ǲ���վ�������
	 */
	private Long hitchSite;

	/**
	 * ����վ������
	 */
	private String hitchSiteCn;

	/**
	 * �����Ŷ�ID
	 */
	private Long hitchTeamBlamedId;

	/**
	 * �����Ŷ�����
	 */
	private String hitchTeamBlamedCn;

	/**
	 * ��Ӱ���Ʒ�� ��ע: �ö��ŷָ��ģ���dwd����в��
	 */
	private String hitchProductLine;

	/**
	 * ��Ʒ�����ƣ���hitch_product_line����node��ȡ
	 */
	private String hitchProductLineCn;

	/**
	 * ����ԭ��
	 */
	private String hitchCause;

	/**
	 * ���ϱ���״̬���ʱ��
	 */
	private String faultreviewedtime;

	/**
	 * pm�ϲ���pm�еĹ���id
	 */
	private String serialNumber;

	/**
	 * ����d����id
	 */
	private Long hitchDLevel;

	/**
	 * ����d����cn ��ע: -2=null ,1=d1,2=d2,3=d3,4=d4
	 */
	private String hitchDLevelCn;

	/**
	 * ����չʾ��id
	 */
	private String hitchIdPresentation;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Date getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	public Date getHappenTime() {
		return happenTime;
	}

	public void setHappenTime(Date happenTime) {
		this.happenTime = happenTime;
	}

	public Date getCatchTime() {
		return catchTime;
	}

	public void setCatchTime(Date catchTime) {
		this.catchTime = catchTime;
	}

	public Date getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	public Date getResolveTime() {
		return resolveTime;
	}

	public void setResolveTime(Date resolveTime) {
		this.resolveTime = resolveTime;
	}

	public Long getHitchId() {
		return hitchId;
	}

	public void setHitchId(Long hitchId) {
		this.hitchId = hitchId;
	}

	public String getHitchName() {
		return hitchName;
	}

	public void setHitchName(String hitchName) {
		this.hitchName = hitchName;
	}

	public String getHitchApp() {
		return hitchApp;
	}

	public void setHitchApp(String hitchApp) {
		this.hitchApp = hitchApp;
	}

	public Integer getHitchLevel() {
		return hitchLevel;
	}

	public void setHitchLevel(Integer hitchLevel) {
		this.hitchLevel = hitchLevel;
	}

	public String getHitchLevelCn() {
		return hitchLevelCn;
	}

	public void setHitchLevelCn(String hitchLevelCn) {
		this.hitchLevelCn = hitchLevelCn;
	}

	public Integer getHitchOrigin() {
		return hitchOrigin;
	}

	public void setHitchOrigin(Integer hitchOrigin) {
		this.hitchOrigin = hitchOrigin;
	}

	public String getHitchOriginCn() {
		return hitchOriginCn;
	}

	public void setHitchOriginCn(String hitchOriginCn) {
		this.hitchOriginCn = hitchOriginCn;
	}

	public Integer getHitchType() {
		return hitchType;
	}

	public void setHitchType(Integer hitchType) {
		this.hitchType = hitchType;
	}

	public String getHitchTypeCn() {
		return hitchTypeCn;
	}

	public void setHitchTypeCn(String hitchTypeCn) {
		this.hitchTypeCn = hitchTypeCn;
	}

	public Integer getHitchStatus() {
		return hitchStatus;
	}

	public void setHitchStatus(Integer hitchStatus) {
		this.hitchStatus = hitchStatus;
	}

	public String getHitchStatusName() {
		return hitchStatusName;
	}

	public void setHitchStatusName(String hitchStatusName) {
		this.hitchStatusName = hitchStatusName;
	}

	public Long getHitchReportedDone() {
		return hitchReportedDone;
	}

	public void setHitchReportedDone(Long hitchReportedDone) {
		this.hitchReportedDone = hitchReportedDone;
	}

	public String getHitchReportedDoneCn() {
		return hitchReportedDoneCn;
	}

	public void setHitchReportedDoneCn(String hitchReportedDoneCn) {
		this.hitchReportedDoneCn = hitchReportedDoneCn;
	}

	public Integer getHitchCategory() {
		return hitchCategory;
	}

	public void setHitchCategory(Integer hitchCategory) {
		this.hitchCategory = hitchCategory;
	}

	public String getHitchCategoryCn() {
		return hitchCategoryCn;
	}

	public void setHitchCategoryCn(String hitchCategoryCn) {
		this.hitchCategoryCn = hitchCategoryCn;
	}

	public Boolean getIschangetrigger() {
		return ischangetrigger;
	}

	public void setIschangetrigger(Boolean ischangetrigger) {
		this.ischangetrigger = ischangetrigger;
	}

	public String getHitchSheepBlamed() {
		return hitchSheepBlamed;
	}

	public void setHitchSheepBlamed(String hitchSheepBlamed) {
		this.hitchSheepBlamed = hitchSheepBlamed;
	}

	public String getHitchSheepBlamedCn() {
		return hitchSheepBlamedCn;
	}

	public void setHitchSheepBlamedCn(String hitchSheepBlamedCn) {
		this.hitchSheepBlamedCn = hitchSheepBlamedCn;
	}

	public String getHitchHandler() {
		return hitchHandler;
	}

	public void setHitchHandler(String hitchHandler) {
		this.hitchHandler = hitchHandler;
	}

	public String getHitchHandlerCn() {
		return hitchHandlerCn;
	}

	public void setHitchHandlerCn(String hitchHandlerCn) {
		this.hitchHandlerCn = hitchHandlerCn;
	}

	public Long getHitchSite() {
		return hitchSite;
	}

	public void setHitchSite(Long hitchSite) {
		this.hitchSite = hitchSite;
	}

	public String getHitchSiteCn() {
		return hitchSiteCn;
	}

	public void setHitchSiteCn(String hitchSiteCn) {
		this.hitchSiteCn = hitchSiteCn;
	}

	public Long getHitchTeamBlamedId() {
		return hitchTeamBlamedId;
	}

	public void setHitchTeamBlamedId(Long hitchTeamBlamedId) {
		this.hitchTeamBlamedId = hitchTeamBlamedId;
	}

	public String getHitchTeamBlamedCn() {
		return hitchTeamBlamedCn;
	}

	public void setHitchTeamBlamedCn(String hitchTeamBlamedCn) {
		this.hitchTeamBlamedCn = hitchTeamBlamedCn;
	}

	public String getHitchProductLine() {
		return hitchProductLine;
	}

	public void setHitchProductLine(String hitchProductLine) {
		this.hitchProductLine = hitchProductLine;
	}

	public String getHitchProductLineCn() {
		return hitchProductLineCn;
	}

	public void setHitchProductLineCn(String hitchProductLineCn) {
		this.hitchProductLineCn = hitchProductLineCn;
	}

	public String getHitchCause() {
		return hitchCause;
	}

	public void setHitchCause(String hitchCause) {
		this.hitchCause = hitchCause;
	}

	public String getFaultreviewedtime() {
		return faultreviewedtime;
	}

	public void setFaultreviewedtime(String faultreviewedtime) {
		this.faultreviewedtime = faultreviewedtime;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Long getHitchDLevel() {
		return hitchDLevel;
	}

	public void setHitchDLevel(Long hitchDLevel) {
		this.hitchDLevel = hitchDLevel;
	}

	public String getHitchDLevelCn() {
		return hitchDLevelCn;
	}

	public void setHitchDLevelCn(String hitchDLevelCn) {
		this.hitchDLevelCn = hitchDLevelCn;
	}

	public String getHitchIdPresentation() {
		return hitchIdPresentation;
	}

	public void setHitchIdPresentation(String hitchIdPresentation) {
		this.hitchIdPresentation = hitchIdPresentation;
	}

}
