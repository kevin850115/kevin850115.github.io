package com.taobao.ateye.dal.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Maps;
import com.taobao.ateye.annotation.AteyeInvoker;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.exception.DAOException;

public class IBatisAppDAO extends BaseDAO implements AppDAO {
	
	private static AppDO virtualDbApp = new AppDO();
	static{
		virtualDbApp.setAdministrators("�س�");
		virtualDbApp.setAppName("_DB_");
		virtualDbApp.setId(-1999l);
	}
	private static AppDO virtualMsgApp = new AppDO();
	static{
		virtualMsgApp.setAdministrators("�س�");
		virtualMsgApp.setAppName("_MSG_");
		virtualMsgApp.setId(-1998l);
	}
	private static AppDO virtualTairApp = new AppDO();
	static{
		virtualTairApp.setAdministrators("�س�");
		virtualTairApp.setAppName("_TAIR_");
		virtualTairApp.setId(-1997l);
	}
	private static AppDO virtualErrorApp = new AppDO();
	static{
		virtualErrorApp.setAdministrators("�س�");
		virtualErrorApp.setAppName("_ERROR_");
		virtualErrorApp.setId(-1996l);
	}
	private static AppDO virtualErrorDetailApp = new AppDO();
	static{
		virtualErrorDetailApp.setAdministrators("�س�");
		virtualErrorDetailApp.setAppName("_ERROR_DETAIL_");
		virtualErrorDetailApp.setId(-1995l);
	}
	private static AppDO virtualRealTimeApp = new AppDO();
	static{
		virtualRealTimeApp.setAdministrators("�س�");
		virtualRealTimeApp.setAppName("_REALTIME_");
		virtualRealTimeApp.setId(-1994l);
	}
	@SuppressWarnings("unchecked")
	@Override
	public AppDO getAppById(Long appId) throws DAOException {
		List<AppDO> appList = queryForList("AteyeAppDAO.getAppById", appId);
        if (appList != null && !appList.isEmpty()) {
            return appList.get(0);
        }
        return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public AppDO getAppByName(String name) throws DAOException {
		List<AppDO> appList = queryForList("AteyeAppDAO.getAppByName", name);
        if (appList != null && !appList.isEmpty()) {
            return appList.get(0);
        }
        if ( name.equals("_DB_") ){
        	return virtualDbApp;
        }
        if ( name.equals("_MSG_") ){
        	return virtualMsgApp;
        }
        if ( name.equals("_TAIR_") ){
        	return virtualTairApp;
        }
        if ( name.equals("_ERROR_") ){
        	return virtualErrorApp;
        }
        if ( name.equals("_ERROR_DETAIL_") ){
        	return virtualErrorDetailApp;
        }
        if ( name.equals("_REALTIME_") ){
        	return virtualRealTimeApp;
        }
        //�س�2017.03.01.����Ӧ�ü���
        if ( name.startsWith("_VIRTUAL_")){
        	AppDO va  = new AppDO();
        	va.setAdministrators("�س�");
        	va.setAppName(name);
        	va.setId(-1990l);
        	return va;
        }
        //�ײ��������Ӧ��������
        String[] parts = name.split(":");
        if ( parts.length == 2 ){
        	return getAppByName(parts[0]);
        }
        return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AppDO> getAllAppAsList() throws DAOException {
		return queryForList("AteyeAppDAO.getAllAppList", null);
	}

	@Override
	public Long saveApp(AppDO appDO) throws DAOException {
		return (Long)insert("AteyeAppDAO.insertApp", appDO);
	}
	@Override
	public int deleteAppByName(String name) throws DAOException {
		return update("AteyeAppDAO.deleteAppByName",name);
	}

	@Override
	public int deleteObsoleteStormApp(Long appId, Date gmtModified) throws DAOException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("id", appId);
		params.put("gmtModified", gmtModified);
		return update("AteyeAppDAO.deleteObsoleteStormApp", params);
	}

	@Override
	public int updateAppAdminInfo(Long appId, String administrators)
			throws DAOException {
		HashMap<String,String> m = new HashMap<String,String>();
        m.put("administrators",administrators);
        m.put("id", appId+"");
		return update("AteyeAppDAO.updateAppAdminInfo", m);
	}

	@Override
	public int updateAppDingdingTokens(Long appId, String tokens) throws DAOException {
		HashMap<String,String> m = new HashMap<String,String>();
		m.put("tokens",tokens);
		m.put("id", appId+"");
		return update("AteyeAppDAO.updateDingDingToken", m);
	}

	@Override
	@AteyeInvoker(description="����ҵ���߸���dingdingTokenֵ")
	public int updateAppDingdingTokensByBiz(int bizType, String tokens) throws DAOException {
		HashMap<String,String> m = new HashMap<String,String>();
		m.put("tokens",tokens);
		m.put("biz", bizType+"");
		return update("AteyeAppDAO.updateDingDingTokenByBiz", m);
	}

	@Override
	public int updateAppContextRoot(Long appId, String contextRoot)
			throws DAOException {
		HashMap<String, String> m = new HashMap<String, String>();
        m.put("contextRoot",contextRoot);
        m.put("id", appId + "");
		return update("AteyeAppDAO.updateAppContextRoot", m);
	}

	@Override
	public Map<String, AppDO> getAllAppAsMap() throws DAOException {
		List<AppDO> allAppAsList = this.getAllAppAsList();
		Map<String,AppDO> ret = new HashMap<String,AppDO>();
		for ( AppDO app:allAppAsList ){
			ret.put(app.getAppName(), app);
		}
		return ret;
	}

	@Override
	public Map<Long, AppDO> getAllAppAsMapById() throws DAOException {
		List<AppDO> allAppAsList = this.getAllAppAsList();
		Map<Long,AppDO> ret = new HashMap<Long,AppDO>();
		for ( AppDO app:allAppAsList ){
			ret.put(app.getId(), app);
		}
		return ret;
	}

	@Override
	public List<AppDO> queryAppByBizType(Integer bizType, Integer subBizType) throws DAOException {
		HashMap<String,Integer> m = new HashMap<String,Integer>();
        m.put("bizType",bizType);
        m.put("subBizType", subBizType);
		return queryForList("AteyeAppDAO.queryAppByBizType", m);
	}
	public List<AppDO> queryAppByBizType(Integer bizType) throws DAOException {
		return this.queryAppByBizType(bizType,null);
	}

	@Override
	public int updateAppAlias(Long appId, String alias) throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("id", appId );
        m.put("appAlias", alias);
		return update("AteyeAppDAO.updateAlias", m);
	}

	@Override
	public int updateAppBizType(Long appId, int bizType) throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("id", appId );
        m.put("bizType", bizType);
		return update("AteyeAppDAO.updateBizType", m);
	}

	@Override
	public int updateAppSubBizType(Long appId, int subBizType)
			throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("id", appId );
        m.put("subBizType", subBizType);
		return update("AteyeAppDAO.updateSubBizType", m);
	}

    @Override
    public int updateAppTag(Long appId, String tag) throws DAOException {
        HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("id", appId );
        m.put("appTag", tag);
        return update("AteyeAppDAO.updateTag", m);
    }

	@Override
	public int updateAoneAppInfo(Long appId, String bu, String productName,
			String description) throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("id", appId );
        m.put("bu", bu);
        m.put("productName", productName);
        m.put("description", description);
        return update("AteyeAppDAO.updateAoneInfo", m);
	}

	@Override
	public List<AppDO> queryAppByProduct(String productName) throws DAOException {
		HashMap<String,String> m = new HashMap<String,String>();
        m.put("productName",productName);
		return queryForList("AteyeAppDAO.queryAppByProductName", m);
	}

	@Override
	public void updateAoneCreateTimeByName(String appName, Date aoneCreateTime) throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
		m.put("appName", appName );
		m.put("aoneCreateTime", aoneCreateTime);
		update("AteyeAppDAO.updateAoneCreateTimeByName", m);
	}

	@Override
	public List<AppDO> queryAppByBizType(String biz) throws DAOException {
		if ( StringUtils.isNumeric(biz) ){
			Integer nBiz = Integer.valueOf(biz);
			return this.queryAppByBizType(nBiz);
		}else{
			return this.queryAppByProduct(biz);
		}
	}
	public static void main(String[] args) {
		System.out.println(Integer.valueOf("dafds"));
	}

	@Override
	public int changeAppBizType(int from, int to) throws DAOException {
		HashMap<String, Object> m = new HashMap<String, Object>();
        m.put("fromType", from);
        m.put("toType", to);
		return update("AteyeAppDAO.changeBizType", m);
	}
	
}
