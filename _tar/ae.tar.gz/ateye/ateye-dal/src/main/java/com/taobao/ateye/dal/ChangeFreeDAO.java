package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.ChangeFreeDO;
import com.taobao.ateye.dataobject.ChangeFreeStatDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/10/9.
 */
public interface ChangeFreeDAO {
    Long insertChangeFree(ChangeFreeDO changeFreeDO) throws DAOException;
    List<ChangeFreeDO> getChangeFreeByCondition(Date startTime, Date endTime,String empId) throws DAOException;
    List<ChangeFreeDO> getChangeFrees(Date startTime, Date endTime) throws DAOException;
    ChangeFreeDO getLatestPubOfApp(String app) throws DAOException;
    List<ChangeFreeStatDO> getRecentChangeFrees(Date startTime) throws DAOException;
    List<Long> selectIdsByCondition(Date date, Date date1, String empId,int pageSize) throws DAOException;

    /**
     * ����changefree��status״̬
     * @param changeFreeId
     * @param taskStatus
     * @return
     * @throws DAOException
     */
    void updateChangeFreeTaskStatus(Long changeFreeId, Integer taskStatus) throws DAOException;

    /**
     * ��ѯ��û��ִ�б�����ı����¼
     * @param taskStatus
     * @param maxSecond
     * @return
     * @throws DAOException
     */
    List<ChangeFreeDO> getTaskChangeFrees(Integer taskStatus , Integer maxSecond) throws DAOException;

    /**
     * ����id������ѯchangefree��¼
     * @param id
     * @return
     * @throws DAOException
     */
    ChangeFreeDO getChangeFreeById(Integer id) throws DAOException;

    void deleteByIds(List<Long> ids) throws DAOException;
}

