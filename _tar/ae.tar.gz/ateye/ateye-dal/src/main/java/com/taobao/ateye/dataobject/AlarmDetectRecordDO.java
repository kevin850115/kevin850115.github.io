package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2019/1/11.
 */
public class AlarmDetectRecordDO extends BaseDO {
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * uuid
     */
    private String uuid;


    /**
     * uuid����չ�ֶ�,���ڷ�Χ����,�����������ӱ�����ʱ����Ҫ����Χ������ƽ,����һ����չuuid,���ڲ�ѯ�Ƿ��Ѿ�������
     */
    private String extendUUID;

    /**
     * ����
     */
    private String env;

    /**
     * ip
     */
    private String ip;

    /**
     * ����
     */
    private String description;

    /**
     * ��ʱ ms
     */
    private int cost;

    private String dependOnExtendUUID;

    public String getDependOnExtendUUID() {
        return dependOnExtendUUID;
    }

    public void setDependOnExtendUUID(String dependOnExtendUUID) {
        this.dependOnExtendUUID = dependOnExtendUUID;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getExtendUUID() {
        return extendUUID;
    }

    public void setExtendUUID(String extendUUID) {
        this.extendUUID = extendUUID;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
