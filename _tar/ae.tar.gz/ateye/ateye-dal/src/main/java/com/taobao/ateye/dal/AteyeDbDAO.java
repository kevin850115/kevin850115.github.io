package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeDbDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AteyeDbDAO {
    Long insert(AteyeDbDO ateyeDbDO) throws DAOException;
    AteyeDbDO getByUk(String name,String env) throws DAOException;
}
