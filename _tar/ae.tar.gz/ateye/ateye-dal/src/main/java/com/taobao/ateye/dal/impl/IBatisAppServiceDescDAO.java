package com.taobao.ateye.dal.impl;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dal.AppServiceDescDAO;
import com.taobao.ateye.dataobject.AppServiceDescDO;
import com.taobao.ateye.exception.DAOException;

public class IBatisAppServiceDescDAO extends BaseDAO implements AppServiceDescDAO {

    @SuppressWarnings("unchecked")
    @Override
    public List<AppServiceDescDO> queryByApp(String app) throws DAOException {
        return queryForList("AppServiceDescDAO.queryByApp", app);
    }

    @Override
    public int saveOrUpdate(AppServiceDescDO object) throws DAOException {
        AppServiceDescDO old = (AppServiceDescDO) this.queryForObject("AppServiceDescDAO.queryByUniqueKey", object);
        if (old == null) {
            this.insert("AppServiceDescDAO.insert", object);
            return 1;
        } else {
            object.setId(old.getId());
            object.setGmtModified(new Date());
            return this.update("AppServiceDescDAO.update", object);
        }
    }

    @Override
    public AppServiceDescDO queryByUniqueKey(String app, String service, String method)
                                                                                       throws DAOException {
        AppServiceDescDO query = new AppServiceDescDO();
        query.setApp(app);
        query.setService(service);
        query.setMethod(method);
        return (AppServiceDescDO) this.queryForObject("AppServiceDescDAO.queryByUniqueKey", query);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<AppServiceDescDO> queryByService(String app, String service) throws DAOException {
        AppServiceDescDO query = new AppServiceDescDO();
        query.setApp(app);
        query.setService(service);
        return this.queryForList("AppServiceDescDAO.queryByService", query);
    }

}
