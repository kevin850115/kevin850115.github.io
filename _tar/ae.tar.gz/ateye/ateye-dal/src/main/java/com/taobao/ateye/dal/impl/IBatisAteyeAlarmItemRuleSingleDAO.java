package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AteyeAlarmItemRuleSingleDAO;
import com.taobao.ateye.dataobject.AteyeAlarmItemRuleSingleDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2018/12/6.
 */
public class IBatisAteyeAlarmItemRuleSingleDAO extends BaseDAO implements AteyeAlarmItemRuleSingleDAO {
    @Override
    public List<AteyeAlarmItemRuleSingleDO> selectAll() throws DAOException {
        return queryForList("AteyeAlarmItemRuleSingleDAO.selectAll");
    }

    @Override
    public Long insert(AteyeAlarmItemRuleSingleDO ruleDO) throws DAOException {
        return (Long) insert("AteyeAlarmItemRuleSingleDAO.insert",ruleDO);
    }

    @Override
    public void updateStatus(Long id, int isDelete) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("status",isDelete);
        update("AteyeAlarmItemRuleSingleDAO.updateStatus",map);
    }

    @Override
    public void deleteOldRule() throws DAOException {
        delete("AteyeAlarmItemRuleSingleDAO.deleteOldRule",null);
    }

    @Override
    public List<AteyeAlarmItemRuleSingleDO> selectByConfId(long confId) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("confId",confId);
        return queryForList("AteyeAlarmItemRuleSingleDAO.selectByConfId",map);
    }

    @Override
    public List<AteyeAlarmItemRuleSingleDO> selectByItemIds(List<Long> itemIds) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("itemIds",itemIds);
        return queryForList("AteyeAlarmItemRuleSingleDAO.selectByItemIds",map);
    }

    @Override
    public void deleteByConfId(long confId) throws DAOException {
        delete("AteyeAlarmItemRuleSingleDAO.deleteByConfId",confId);
    }
}
