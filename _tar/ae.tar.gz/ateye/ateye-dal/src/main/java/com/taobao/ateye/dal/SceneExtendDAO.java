package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SceneExtendDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/17.
 */
public interface SceneExtendDAO {

    /**
     * ���볡����չ��Ϣ
     *
     * @param sceneExtendDO
     * @return
     */
    Long insertSceneExtend(SceneExtendDO sceneExtendDO) throws DAOException;

    /**
     * ɾ��������չ��Ϣ
     *
     * @param sceneId
     * @param name
     * @param tag
     */
    void deleteSceneExtend(Long sceneId, String name, String tag) throws DAOException;

    List<SceneExtendDO> getAllSceneExtends() throws DAOException;
    
    List<SceneExtendDO> getExtendById(Long id) throws DAOException;
    
    void deleteSceneExtend(Long sceneId, String name) throws DAOException;

}
