package com.taobao.ateye.dataobject;

import java.util.Date;

public class UserAndAppDO extends BaseDO {

	/**
	 *
	 */
	private static final long serialVersionUID = -2936476534648223906L;
	/**
	 * ID, ����
	 */
	private Long id;
	/**
	 * �û�ID
	 */
	private Long userId;
	/**
	 * Ӧ��ID
	 */
	private Long appId;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAppId() {
		return appId;
	}
	public void setAppId(Long appId) {
		this.appId = appId;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

}
