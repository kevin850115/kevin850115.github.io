package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.GocFaultDO;
import com.taobao.ateye.exception.DAOException;

public interface GocFaultDAO {
	
	List<GocFaultDO> getAll(Date startDate) throws DAOException;

}
