package com.taobao.ateye.dataobject;

import java.util.Date;

public class FieldMethodSetDO extends BaseDO 
{
	private static final long serialVersionUID = 8642809643479535324L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ����\������������
	 */
	private String setName;
	/**
	 * ����\������������
	 */
	private String setDesc;
	/**
	 * �������ͣ����ؼ���|�������ϣ�
	 */
	private int setType;
	/**
	 * ������
	 */
	private String creator;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSetName() {
		return setName;
	}
	public void setSetName(String setName) {
		this.setName = setName;
	}
	public String getSetDesc() {
		return setDesc;
	}
	public void setSetDesc(String setDesc) {
		this.setDesc = setDesc;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public int getSetType() {
		return setType;
	}
	public void setSetType(int setType) {
		this.setType = setType;
	}
}
