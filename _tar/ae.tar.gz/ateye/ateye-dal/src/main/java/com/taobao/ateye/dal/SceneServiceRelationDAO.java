package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.taobao.ateye.dataobject.SceneServiceRelation;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneServiceRelationDAO {

    SceneServiceRelation getServiceRelationByMd5(String ukMd5
                                                       ) throws DAOException;
    List<SceneServiceRelation> selectInvalidProviderId(int pageSize, long minId, Date timeWindow,String env) throws DAOException;
    List<SceneServiceRelation> queryRelationsByEntryPoint(long entryPointId,Date date,String env) throws DAOException;
    List<SceneServiceRelation> queryRelationsByConsumer(String consumer,Date date,String env) throws DAOException;

    void updateProviderInfo(String providerName,
                       String providerType, Date timeWinow,
                       String providerAppNodeGroup,
                       long providerId,String env) throws DAOException;

    Long insertServiceRelation(SceneServiceRelation relation) throws DAOException;

    List<SceneServiceRelation> selectByPage(long minId, int pageSize, Date date,String env) throws DAOException;

    void deleteByProviderId(long id) throws DAOException;
    
    List<String> getDBNamesByApp(Set<String> apps,Date date,String env) throws DAOException;
    List<String> getTairNamesByApp(Set<String> apps,Date date,String env) throws DAOException;

    SceneServiceRelation existEntryPoint(long entryPoint) throws DAOException;

    List<SceneServiceRelation> selectExpired(Date time, int pageSize,String env) throws DAOException;

    void deleteByIds(List<Long> ids) throws DAOException;


    List<SceneServiceRelation>  getServiceRelationByProApp(String appName, Date timeWindow, int pageSize, String env) throws DAOException;
}
