package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AppNodeGroupDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AppNodeGroupDAO {
    Long insert(AppNodeGroupDO appNodeGroupDO) throws DAOException;
    AppNodeGroupDO getByUk(Long appId,String appNodeGroup,String env) throws DAOException;

    List<AppNodeGroupDO> getAllByAppName(String appNameOrNodeGroup, String env) throws DAOException;
}
