package com.taobao.ateye.dataobject;

public class SystemLogDO {

}
