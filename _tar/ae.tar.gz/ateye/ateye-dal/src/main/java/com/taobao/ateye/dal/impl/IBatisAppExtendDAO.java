package com.taobao.ateye.dal.impl;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AppExtendDAO;
import com.taobao.ateye.dataobject.AppExtendDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/17.
 */
public class IBatisAppExtendDAO extends BaseDAO implements AppExtendDAO {
    @Override
    public List<AppExtendDO> getAppExtendByType(String type) throws DAOException {
        Map<String,Object> map  = Maps.newHashMap();
        map.put("type",type);

        return (List<AppExtendDO>) queryForList("AppExtendDAO.getAppExtendByType",map);
    }

    @Override
    public Long insertAppExtend(AppExtendDO appExtendDO) throws DAOException {
        return (Long) insert("AppExtendDAO.insert",appExtendDO);
    }

    @Override
    public void deleteAppExtendByType(String type) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("type",type);
        delete("AppExtendDAO.deleteAppExtendByType",map);
    }

	@Override
	public List<AppExtendDO> getAppExtends(Long appId) throws DAOException {
		Map<String,Object> map  = Maps.newHashMap();
        map.put("appId",appId);

        return (List<AppExtendDO>) queryForList("AppExtendDAO.getAppExtends",map);
	}

	@Override
	public List<AppExtendDO> getAllAppExtends() throws DAOException {
		Map<String,Object> map  = Maps.newHashMap();
        return (List<AppExtendDO>) queryForList("AppExtendDAO.getAllAppExtends",map);
	}

	@Override
	public void deleteAppExtendByType(Long appId, String type)
			throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("appId",appId);
        map.put("type",type);
        delete("AppExtendDAO.deleteAppExtendByIdAndType",map);
		
	}

	@Override
	public void deleteAppExtend(Long appId, String type, String value)
			throws DAOException {
		Map<String,Object> map = Maps.newHashMap();
        map.put("appId",appId);
        map.put("type",type);
        map.put("value",value);
        delete("AppExtendDAO.deleteAppExtendByIdAndTypeAndValue",map);
		
	}

	@Override
	public AppExtendDO getAppExtendByType(Long appId, String type)
			throws DAOException {
		Map<String,Object> map  = Maps.newHashMap();
        map.put("appId",appId);
        map.put("type",type);

        return (AppExtendDO) queryForObject("AppExtendDAO.getAppExtendByAppIdAndType",map);
	}

	@Override
	public void updateAppExtend(Long appId, String type, String value)
			throws DAOException {
		Map<String,Object> map  = Maps.newHashMap();
        map.put("appId",appId);
        map.put("type",type);
        map.put("value",value);

        update("AppExtendDAO.updateAppExtend",map);		
	}
}
