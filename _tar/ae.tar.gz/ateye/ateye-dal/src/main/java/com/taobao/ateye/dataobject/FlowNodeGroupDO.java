package com.taobao.ateye.dataobject;

/**
 * Description:���������������
 * @author �س�
 * Date 2019-05-22
 */
public class FlowNodeGroupDO extends BaseFlowDO{
	/**
	 * Ӧ��
	 */
	private String appName;

	/**
	 * Ӧ�÷���
	 */
	private String appNodeGroup;



	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppNodeGroup() {
		return appNodeGroup;
	}

	public void setAppNodeGroup(String appNodeGroup) {
		this.appNodeGroup = appNodeGroup;
	}


}