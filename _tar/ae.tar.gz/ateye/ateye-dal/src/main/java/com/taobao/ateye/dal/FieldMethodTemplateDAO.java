package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.FieldMethodTemplateDO;
import com.taobao.ateye.exception.DAOException;

public interface FieldMethodTemplateDAO 
{
	/**
	 * ��ѯȫ������\����ģ��
	 * @return
	 * @throws DAOException
	 */
	public List<FieldMethodTemplateDO> getAllFieldMethodTemplates() throws DAOException;
	
	/**
	 * ���ݼ���id�б���ȡģ���б�
	 * @return
	 * @throws DAOException
	 */
	public List<FieldMethodTemplateDO> getTemplatesBySetIds(List<Long> ids) throws DAOException;
	
	/**
	 * ����һ��ģ���¼
	 * @param templateDO
	 * @return
	 * @throws DAOException
	 */
	public Long insertFieldMethodTemplate(FieldMethodTemplateDO template) throws DAOException;
	
	/**
	 * ����ģ��id��ѯģ����Ϣ
	 * @param templateDOId
	 * @return
	 * @throws DAOException
	 */
	public FieldMethodTemplateDO getFieldMethodTemplateById(Long templateId) throws DAOException;
	
	/**
	 * ɾ��һ��ģ��
	 * @param templateId
	 * @return
	 * @throws DAOException
	 */
	public int deleteFieldMethodTemplateById(Long templateId) throws DAOException;
	
	/**
	 * ����ģ������
	 * @param newTemplateName
	 * @throws DAOException
	 */
	public void updateTemplateName(Long templateId, String newTemplateName) throws DAOException;
	
	/**
	 * ��֤ģ������Ψһ
	 * @param newTemplateName
	 * @throws DAOException
	 */
	public boolean validTemplateName(String newTemplateName) throws DAOException;
}
