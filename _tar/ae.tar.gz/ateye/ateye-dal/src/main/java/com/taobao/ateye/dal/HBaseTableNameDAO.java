package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HBaseTableNameDO;
import com.taobao.ateye.exception.DAOException;

public interface HBaseTableNameDAO {
	/**
	 * ����һ��HBaseTableNameDO
	 * @param hBaseTableNameDO
	 * @throws DAOException
	 */
	long saveHBaseTableNameDO(HBaseTableNameDO hBaseTableNameDO) throws DAOException;
	
	/**
	 * ����HBase�����������DO
	 * @param tableName
	 * @return
	 * @throws DAOException
	 */
	HBaseTableNameDO getHBaseTableNameDOByTableName(String tableName) throws DAOException;
	
	/**
	 * ����id��ѯ
	 * @param id
	 * @return
	 * @throws DAOException
	 */
	HBaseTableNameDO getHBaseTableNameDOById(Long id) throws DAOException;
	
	/**
	 * ����HBase����ɾ�����DO
	 * @param tableName
	 * @return
	 * @throws DAOException
	 */
	int deleteHBaseTableNameDOByTableName(String tableName) throws DAOException;
	
	/**
	 * ����idɾ��
	 * @param id
	 * @return
	 * @throws DAOException
	 */
	int deleteHBaseTableNameDOById(Long id) throws DAOException;
}
