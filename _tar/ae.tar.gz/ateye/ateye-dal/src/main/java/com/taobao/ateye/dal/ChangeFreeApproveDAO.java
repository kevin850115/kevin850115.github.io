package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.ChangeFreeApproveDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/6/17.
 */
public interface ChangeFreeApproveDAO {
    void updateStatus(String sourceOrderId,String checkStatus) throws DAOException;

    List<ChangeFreeApproveDO> getApproveByCondition(String sign,
                                                    String env,
                                                    Date approveTime) throws DAOException;
    Long insertApprove(ChangeFreeApproveDO changeFreeApproveDO) throws DAOException;

    void updateApproveUrl(String sourceOrderId, String approveUrl) throws DAOException;
}
