package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmDetectRecordDAO;
import com.taobao.ateye.dataobject.AlarmDetectRecordDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2019/1/11.
 */
public class IBatisAlarmDetectRecordDAO  extends BaseDAO implements AlarmDetectRecordDAO  {
    @Override
    public Long insert(AlarmDetectRecordDO detectRecordDO) throws DAOException {
        return (Long) insert("AlarmDetectRecordDAO.insert",detectRecordDO);
    }

    @Override
    public List<AlarmDetectRecordDO> selectByStartTime(Date startTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("startTime",startTime);
        return queryForList("AlarmDetectRecordDAO.selectByStartTime",map);
    }

    @Override
    public Integer countByStartTime(String uuid,String extendUUID,Date startTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("startTime",startTime);
        map.put("uuid",uuid);
        map.put("extendUUID",extendUUID);
        return (Integer) queryForObject("AlarmDetectRecordDAO.countByStartTime",map);
    }

    @Override
    public List<Long> selectBeforeIdsByStartTime(Date startTime, int size) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("startTime",startTime);
        map.put("size",size);
        return queryForList("AlarmDetectRecordDAO.selectBeforeIdsByStartTime",map);
    }

    @Override
    public void deleteByIds(List<Long> ids) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("ids",ids);
        delete("AlarmDetectRecordDAO.deleteByIds",map);
    }
}
