package com.taobao.ateye.dataobject;

/**
 * @author yunqing.wxl
 * 
 */
public class UserStaticsDO extends BaseDO {

    /**
     * 
     */
    private static final long serialVersionUID = 3452269351712475598L;

    private Long id;
    private String statDate;
    private String bizType;
    private String userLevel;
    private int totalUserCount;
    private int potentialUserCount;
    private int newUserCount;
    private int activeUserCount;
    private int inactiveUserCount;
    private String gmtCreate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String userLevel) {
        this.userLevel = userLevel;
    }

    public int getTotalUserCount() {
        return totalUserCount;
    }

    public void setTotalUserCount(int totalUserCount) {
        this.totalUserCount = totalUserCount;
    }

    public int getPotentialUserCount() {
        return potentialUserCount;
    }

    public void setPotentialUserCount(int potentialUserCount) {
        this.potentialUserCount = potentialUserCount;
    }

    public int getNewUserCount() {
        return newUserCount;
    }

    public void setNewUserCount(int newUserCount) {
        this.newUserCount = newUserCount;
    }

    public int getActiveUserCount() {
        return activeUserCount;
    }

    public void setActiveUserCount(int activeUserCount) {
        this.activeUserCount = activeUserCount;
    }

    public int getInactiveUserCount() {
        return inactiveUserCount;
    }

    public void setInactiveUserCount(int inactiveUserCount) {
        this.inactiveUserCount = inactiveUserCount;
    }

    public String getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(String gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

}
