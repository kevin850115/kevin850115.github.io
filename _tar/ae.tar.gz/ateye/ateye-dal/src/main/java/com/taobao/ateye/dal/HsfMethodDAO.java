package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HsfMethodDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2019/5/15.
 */
public interface HsfMethodDAO {
    Long insert(HsfMethodDO hsfMethodDO) throws DAOException;
    HsfMethodDO getByUk(String eagleeyeUniqueName,Long interfaceId,String env) throws DAOException;
    void deleteById(Long id) throws DAOException;
    void deleteByInterfaceId(Long interfaceId) throws DAOException;

    List<HsfMethodDO> getBySentinelResourceName(String sentinelResourceName, String env) throws DAOException;

    List<HsfMethodDO> getByMethod(String method, String env) throws DAOException;
    List<HsfMethodDO> getAllTimeoutMethod(String env)throws DAOException;
}
