package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:ateye������db
 * @author ˼��
 * Date 2019-05-05
 */
public class AteyeDbDO extends BaseDO {

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * Ӧ������
     */
    private String name;

    /**
     * ����
     */
    private String description;

    /**
     * ����
     */
    private String env;

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column Ӧ������
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for column Ӧ������
     */
    public String getName() {
        return this.name;
    }

    /**
     * setter for column ����
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * getter for column ����
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }
}