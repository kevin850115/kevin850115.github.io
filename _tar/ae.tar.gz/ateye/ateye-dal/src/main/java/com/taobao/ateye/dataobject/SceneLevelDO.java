package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/5.
 */
public class SceneLevelDO extends BaseDO{
    /**
     */
    private long id;
    private String levelName;
    private String levelDesc;
    private String env;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLevelName() {
		return levelName;
	}
	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}
	public String getLevelDesc() {
		return levelDesc;
	}
	public void setLevelDesc(String levelDesc) {
		this.levelDesc = levelDesc;
	}
	public String getEnv() {
		return env;
	}
	public void setEnv(String env) {
		this.env = env;
	}
	public Date getGmtCreate() {
		return gmtCreate;
	}
	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}
	public Date getGmtModified() {
		return gmtModified;
	}
	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

}
