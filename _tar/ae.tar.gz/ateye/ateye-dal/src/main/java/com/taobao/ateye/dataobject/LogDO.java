package com.taobao.ateye.dataobject;

import java.util.HashMap;
import java.util.Map;

/**
 * solr��schema��������ݽṹ��Ӧ��DO����
 * @author gumo
 *
 */
public class LogDO extends BaseDO {

	private static final long serialVersionUID = -2988232290263457800L;
	/**
	 * ID,�û�ȡ����־���ݵ�MD5ֵ��ID
	 */
	private String id;
	/**
	 * ��־����Ӧ�õ�����
	 */
	private String app;
	/**
	 * ��־���ݵ����
	 */
	private String categories;
	private String ip;

	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	/*
	 * key
	 */
	private Map<String,String> keys=new HashMap<String,String>();
	/**
	 * ��־����
	 */
	private String msg;
	/**
	 * ��־����
	 */
	private String level;
	/**
	 * ʱ���
	 */
	private Long timestamp;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getApp() {
		return app;
	}
	public void setApp(String app) {
		this.app = app;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
    public Map<String, String> getKeys() {
        return keys;
    }
    public void setKeys(Map<String, String> keys) {
        this.keys = keys;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public void setLevel(String level) {
        this.level = level;
    }
    public String getLevel() {
        return level;
    }

}
