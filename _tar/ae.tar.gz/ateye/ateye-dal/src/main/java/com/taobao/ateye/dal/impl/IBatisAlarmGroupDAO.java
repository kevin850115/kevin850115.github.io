package com.taobao.ateye.dal.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmGroupDAO;
import com.taobao.ateye.dataobject.AteyeAlarmGroupDO;
import com.taobao.ateye.exception.DAOException;

public class IBatisAlarmGroupDAO extends BaseDAO implements AlarmGroupDAO{

	@Override
	public Long insert(AteyeAlarmGroupDO alarmDO) throws DAOException {
        return (Long) insert("AteyeAlarmGroupDAO.insert",alarmDO);

	}

	@Override
	public List<AteyeAlarmGroupDO> getAll() throws DAOException {
		HashMap<String,Object> m = new HashMap<String,Object>();
		return queryForList("AteyeAlarmGroupDAO.getAll",m);
	}

	@Override
	public int updateToken(String id, String token) throws DAOException {
		Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("token",token);
        return update("AteyeAlarmGroupDAO.updateToken",map);
	}

	@Override
	public int updateBiz(String id, int biz) throws DAOException {
		Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("biz",biz);
        return update("AteyeAlarmGroupDAO.updateBiz",map);
	}

	@Override
	public List<AteyeAlarmGroupDO> getByBiz(int biz) throws DAOException {
		HashMap<String,Object> m = new HashMap<String,Object>();
		m.put("biz", biz);
		return queryForList("AteyeAlarmGroupDAO.getByBiz",m);
	}

	@Override
	public AteyeAlarmGroupDO getAlarmGroupByName(String name)
			throws DAOException {
		HashMap<String,Object> m = new HashMap<String,Object>();
		m.put("name", name);
		return (AteyeAlarmGroupDO) queryForObject("AteyeAlarmGroupDAO.getByName",m);
	}

	@Override
	public int removeAll() throws DAOException {
		return delete("AteyeAlarmGroupDAO.removeAll", null);
	}

	@Override
	public int remove(Long id) throws DAOException {
		HashMap<String,Object> m = new HashMap<String,Object>();
		m.put("id", id);
		return delete("AteyeAlarmGroupDAO.removeById", m);
	}
}
