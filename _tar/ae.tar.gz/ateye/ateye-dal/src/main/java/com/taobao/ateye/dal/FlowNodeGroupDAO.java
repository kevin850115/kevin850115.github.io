package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.FlowNodeGroupDO;
import com.taobao.ateye.exception.DAOException;

/*
 * ����
 */
public interface FlowNodeGroupDAO {
	
	void insert(FlowNodeGroupDO nodeGroupDO) throws DAOException;

	void delete(String app, Date day, String env) throws DAOException;

	List<FlowNodeGroupDO> getAll(Date day, String env) throws DAOException;

	

}
