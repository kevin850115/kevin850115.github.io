package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AteyeAlarmConfDAO;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by sunqiang on 2018/12/6.
 */
public class IBatisAteyeAlarmConfDAO extends BaseDAO implements AteyeAlarmConfDAO {
    @Override
    public List<AteyeAlarmConfDO> selectAll(String env) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("env",env);
        return queryForList("AteyeAlarmConfDAO.selectAll",map);
    }

    @Override
    public List<AteyeAlarmConfDO> selectByIds(List<Long> confIds, String env) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("env",env);
        map.put("ids",confIds);
        return queryForList("AteyeAlarmConfDAO.selectByIds",map);
    }

    @Override
    public AteyeAlarmConfDO selectById(Long id) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        return (AteyeAlarmConfDO) queryForObject("AteyeAlarmConfDAO.selectById",map);
    }

    @Override
    public void updateReopenDate(String id, Date date) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("reopenDate",date);
        update("AteyeAlarmConfDAO.updateReopenDate",map);
    }

    @Override
    public List<AteyeAlarmConfDO> selectAppScope() throws DAOException {
        return queryForList("AteyeAlarmConfDAO.selectAppScope");
    }

    @Override
    public AteyeAlarmConfDO selectByUUID(String uuid) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        return (AteyeAlarmConfDO) queryForObject("AteyeAlarmConfDAO.selectByUUID",map);
    }

    @Override
    public void deleteById(long id) throws DAOException {
        delete("AteyeAlarmConfDAO.deleteById",id);
    }

    @Override
    public Long insert(AteyeAlarmConfDO ruleDO) throws DAOException {
        return (Long) insert("AteyeAlarmConfDAO.insert",ruleDO);
    }

    @Override
    public void updateStatus(Long id, int status) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("status",status);
        update("AteyeAlarmConfDAO.updateStatus",map);
    }

    @Override
    public void deleteOldRule() throws DAOException {
        delete("AteyeAlarmConfDAO.deleteOldRule",null);
    }
}
