package com.taobao.ateye.dal.impl;

import java.util.List;

import com.taobao.ateye.dal.AlarmRuleDAO;
import com.taobao.ateye.dataobject.AlarmRuleDO;
import com.taobao.ateye.exception.DAOException;

public class IBatisAlarmRuleDAO extends BaseDAO implements AlarmRuleDAO {

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#getAllAlarmRules()
	 */
	@Override
	public List<AlarmRuleDO> getAllAlarmRules() throws DAOException {
		return queryForList("AlarmRuleDAO.getAllAlarmRules");
	}

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#getAlarmRuleDOById(java.lang.Long)
	 */
	@Override
	public AlarmRuleDO getAlarmRuleDOById(Long alarmRuleId) throws DAOException {
		List<AlarmRuleDO> alarmRules = queryForList("AlarmRuleDAO.getAlarmRuleDOById", alarmRuleId);
		if (alarmRules != null && !alarmRules.isEmpty()) {
				return alarmRules.get(0);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#insertAlarmRuleDO(com.taobao.ateye.dataobject.AlarmRuleDO)
	 */
	@Override
	public Long insertAlarmRuleDO(AlarmRuleDO alarmRuleDO) throws DAOException {
		return (Long)insert("AlarmRuleDAO.saveAlarmRuleDO", alarmRuleDO);
	}

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#updateAlarmRuleDO(com.taobao.ateye.dataobject.AlarmRuleDO)
	 */
	@Override
	public int updateAlarmRuleDO(AlarmRuleDO alarmRuleDO) throws DAOException {
		return update("AlarmRuleDAO.updateAlarmRuleDO", alarmRuleDO);
	}

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#deleteAlarmRuleDOById(java.lang.Long)
	 */
	@Override
	public int deleteAlarmRuleDOById(Long alarmRuleId) throws DAOException {
		return update("AlarmRuleDAO.deleteAlarmRuleDOById", alarmRuleId);
	}

	/* (non-Javadoc)
	 * @see com.taobao.ateye.dal.AlarmRuleDAO#deleteAlarmRulesBylogId(java.lang.Long)
	 */
	@Override
	public int deleteAlarmRulesBylogId(Long logFilePathId) throws DAOException {
		return update("AlarmRuleDAO.deleteAlarmRulesByLogId", logFilePathId);
	}

}
