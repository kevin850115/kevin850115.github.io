package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.HsfServiceRealtionDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface HsfServiceRealtionDAO {
    Long insert(HsfServiceRealtionDO hsfServiceRealtionDO) throws DAOException;
    HsfServiceRealtionDO getByUk(String appNodeGroup,String sUniqueServiceName,String cUniqueServiceName,String env) throws DAOException;
}
