package com.taobao.ateye.dataobject;

import java.util.Date;
import java.util.List;

/**
 * spring security�ж����û������ݱ������ݶ���
 * @author gumo
 *
 */
public class UserDO extends BaseDO {

	private static final long serialVersionUID = -1702555629858356006L;
	/**
	 * ID, ����
	 */
	private Long id;
	/**
	 * nick
	 */
	private String nick;
	/**
	 * ְλ
	 */
	private String title;
	/**
	 * ���û��Ƿ񱻶���
	 */
	private Boolean enable;
	/**
	 * 
	 */
	private int sort;
	/**
	 * ��һ�ε�½ʱ��
	 */
	private Date lastLoginTime;
	/**
	 * ��һ�ε�½��IP
	 */
	private String lastLoginIp;
	/**
	 * ��ɫ���й�����ID
	 */
	private Long roleId;

	/**
	 * ����
	 */
	private String realName;

	/**
	 * �绰
	 */
	private String phone;

	/**
	 * Ա������
	 */
	private Long empId;

	/**
	 * Ա������
	 */
	private String emailAddr;

	/**
	 * leader����
	 */
	private Long supervisorEmpId;

	/**
	 * leader�������ǻ���
	 */
	private String supervisorRealName;
	//��������
	private String depDesc;

	/**
	 * ��ɫ�б�
	 */
	private List<RoleDO> roleList;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Boolean isEnable() {
		return enable;
	}
	public void setEnable(Boolean enable) {
		this.enable = enable;
	}
	public int getSort() {
		return sort;
	}
	public void setSort(int sort) {
		this.sort = sort;
	}
	public Date getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	public String getLastLoginIp() {
		return lastLoginIp;
	}
	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public List<RoleDO> getRoleList() {
		return roleList;
	}
	public void setRoleList(List<RoleDO> roleList) {
		this.roleList = roleList;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getSupervisorRealName() {
		return supervisorRealName;
	}

	public void setSupervisorRealName(String supervisorRealName) {
		this.supervisorRealName = supervisorRealName;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public Long getSupervisorEmpId() {
		return supervisorEmpId;
	}

	public void setSupervisorEmpId(Long supervisorEmpId) {
		this.supervisorEmpId = supervisorEmpId;
	}
	public String getDepDesc() {
		return depDesc;
	}
	public void setDepDesc(String depDesc) {
		this.depDesc = depDesc;
	}
}

