package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.SceneAppRelation;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneAppRelationDAO {
    SceneAppRelation getSceneAppRelationByMd5(String ukMd5) throws DAOException;

    Long insertAppRelation(SceneAppRelation appRelation) throws DAOException;
    
    List<SceneAppRelation> queryRelationsByEntryPoint(long entryPointId,Date date,String env) throws DAOException;

    List<SceneAppRelation> queryRelations(String consumerAppNodeGroup,Date date,String env) throws DAOException;

    List<SceneAppRelation> selectExpired(Date expiredTime, int pageSize, String env) throws DAOException;
    void deleteByIds(List<Long> ids) throws DAOException;
	List<Long> getEntryIdsByApp(Set<String> apps,Date date,String env) throws DAOException;

}
