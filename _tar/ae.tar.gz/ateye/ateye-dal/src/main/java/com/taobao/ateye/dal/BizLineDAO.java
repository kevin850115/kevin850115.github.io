package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2018/9/17.
 */
public interface BizLineDAO {
    /**
     * ������е�ҵ������Ϣ
     * @return
     */
    List<BizLineDO> getAllBizLineList() throws DAOException;
    Map<Long,BizLineDO> getAllBizLineMap() throws DAOException;
    Map<String,BizLineDO> getAllBizLineMapByName() throws DAOException;

    /**
     * ����ҵ����
     * @param bizLineDO
     * @return
     */
    Long insertBizLine(BizLineDO bizLineDO) throws DAOException;

    /**
     * ɾ��ҵ����
     * @param id
     */
    void deleteBizLine(Long id) throws DAOException;
	int updateBizOwner(String bizId, String bizOwner)throws DAOException;
	int updateBizName(String bizId, String bizName)throws DAOException;
	int updateBizDetail(String bizId, String bizDetail)throws DAOException;

}
