package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AppNodeGroupDAO;
import com.taobao.ateye.dataobject.AppNodeGroupDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class IBatisAppNodeGroupDAO extends BaseDAO implements AppNodeGroupDAO {
    @Override
    public Long insert(AppNodeGroupDO appNodeGroupDO) throws DAOException {
        return (Long) insert("AppNodeGroupDAO.insert",appNodeGroupDO);
    }

    @Override
    public AppNodeGroupDO getByUk(Long appId, String appNodeGroup, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("appId",appId);
        param.put("appNodeGroup",appNodeGroup);
        param.put("env",env);
        return (AppNodeGroupDO) queryForObject("AppNodeGroupDAO.getByUk",param);
    }

    @Override
    public List<AppNodeGroupDO> getAllByAppName(String appName, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("appName",appName);
        param.put("env",env);

        return queryForList("AppNodeGroupDAO.getAllByAppName",param);
    }
}
