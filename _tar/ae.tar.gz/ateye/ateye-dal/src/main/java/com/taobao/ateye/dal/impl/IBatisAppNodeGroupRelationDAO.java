package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AppNodeGroupRelationDAO;
import com.taobao.ateye.dataobject.AppNodeGroupRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class IBatisAppNodeGroupRelationDAO extends BaseDAO implements AppNodeGroupRelationDAO {
    @Override
    public Long insert(AppNodeGroupRelationDO appNodeGroupRelationDO) throws DAOException {
        return (Long) insert("AppNodeGroupRelationDAO.insert",appNodeGroupRelationDO);
    }

    @Override
    public AppNodeGroupRelationDO getByUk(String sAppNodeGroup, String cAppNodeGroup, Date timeWindow, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("sAppNodeGroup",sAppNodeGroup);
        param.put("cAppNodeGroup",cAppNodeGroup);
        param.put("timeWindow",timeWindow);
        param.put("env",env);

        return (AppNodeGroupRelationDO) queryForObject("AppNodeGroupRelationDAO.getByUk",param);
    }

    @Override
    public List<AppNodeGroupRelationDO> getRelationByNodeGroup(String sAppNodeGroup, String cAppNodeGroup, Date timeWindow, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("sAppNodeGroup",sAppNodeGroup);
        param.put("cAppNodeGroup",cAppNodeGroup);
        param.put("timeWindow",timeWindow);
        param.put("env",env);
        return queryForList("AppNodeGroupRelationDAO.getRelationByNodeGroup",param);
    }

    @Override
    public List<AppNodeGroupRelationDO> getRelationByAppName(String sAppName, String cAppName, Date timeWindow, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("sAppName",sAppName);
        param.put("cAppName",cAppName);
        param.put("timeWindow",timeWindow);
        param.put("env",env);
        return queryForList("AppNodeGroupRelationDAO.getRelationByAppName",param);
    }
}
