package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AppNodeGroupRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AppNodeGroupRelationDAO {
    Long insert(AppNodeGroupRelationDO appNodeGroupRelationDO) throws DAOException;
    AppNodeGroupRelationDO getByUk(String sAppNodeGroup, String cAppNodeGroup, Date timeWindow, String env) throws DAOException;

    List<AppNodeGroupRelationDO> getRelationByNodeGroup(String sAppNodeGroup, String cAppNodeGroup, Date timeWindow, String env) throws DAOException ;

    List<AppNodeGroupRelationDO> getRelationByAppName(String sAppName, String cAppName, Date timeWindow, String env) throws DAOException ;
}
