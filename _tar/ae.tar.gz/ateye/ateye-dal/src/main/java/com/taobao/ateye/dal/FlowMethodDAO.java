package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.FlowMethodDO;
import com.taobao.ateye.exception.DAOException;

/*
 * ����
 */
public interface FlowMethodDAO {
	
	void insert(FlowMethodDO methodDO) throws DAOException;

	void delete(String app, Date day, String env)throws DAOException;

	List<FlowMethodDO> getAll(String app,String ng,Date day,String env) throws DAOException;
	

}
