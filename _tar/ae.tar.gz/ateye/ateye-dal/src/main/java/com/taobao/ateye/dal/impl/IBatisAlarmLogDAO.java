package com.taobao.ateye.dal.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmLogDAO;
import com.taobao.ateye.dataobject.AlarmLogDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/11/15.
 */
public class IBatisAlarmLogDAO extends BaseDAO implements AlarmLogDAO {
    @Override
    public Long saveAlarmLog(AlarmLogDO alarmLogDO) throws DAOException {
        return (Long) insert("AlarmLogDAO.saveAlarmLog",alarmLogDO);
    }

	@Override
	public List<AlarmLogDO> queryLogList(Date start, Date end)
			throws DAOException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("startTime", start);
		params.put("endTime", end);
		return queryForList("AlarmLogDAO.queryLogList", params);		
	}

	@Override
	public List<AlarmLogDO> querySimpleLogList(Date start, Date end)
			throws DAOException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("startTime", start);
		params.put("endTime", end);
		return queryForList("AlarmLogDAO.querySimpleLogList", params);		
	}

	@Override
	public List<AlarmLogDO> queryMonitorByRuleName(String appName, String ruleName, Date startTime) throws DAOException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("startTime", startTime);
		params.put("ruleName", ruleName);
		params.put("appName", appName);
		return queryForList("AlarmLogDAO.queryMonitorByRuleName", params);
	}

	@Override
	public List<Long> selectBeforeIdsByStartTime(Date startTime, int size) throws DAOException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("startTime", startTime);
		params.put("size", size);
		return queryForList("AlarmLogDAO.selectBeforeIdsByStartTime", params);
	}

	@Override
	public void deleteByIds(List<Long> ids) throws DAOException {
		Map<String,Object> map = Maps.newHashMap();
		map.put("ids",ids);
		delete("AlarmLogDAO.deleteByIds",map);
	}
}
