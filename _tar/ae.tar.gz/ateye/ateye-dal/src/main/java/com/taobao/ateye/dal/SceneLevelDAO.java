package com.taobao.ateye.dal;

import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.SceneLevelDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneLevelDAO {

    Long insert(SceneLevelDO levelDO) throws DAOException;
    
    List<SceneLevelDO> getAll() throws DAOException;
    
    Map<Long,SceneLevelDO> getAllMap() throws DAOException;

	int updateLevelName(String levelId, String levelName) throws DAOException;

	int updateLevelDesc(String levelId, String levelDesc) throws DAOException;

}
