package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AteyeAlarmRecordDAO;
import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2018/12/6.
 */
public class IBatisAteyeAlarmRecordDAO extends BaseDAO implements AteyeAlarmRecordDAO {
    @Override
    public List<AteyeAlarmRecordDO> selectByAlarmTime(Date startTime, Date endTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("startTime",startTime);
        map.put("endTime",endTime);
        return queryForList("AteyeAlarmRecordDAO.selectByAlarmTime",map);
    }

    @Override
    public Long insert(AteyeAlarmRecordDO ruleDO) throws DAOException {
        return (Long) insert("AteyeAlarmRecordDAO.insert",ruleDO);
    }

    @Override
    public void deleteByAlarmTime(Date startTime, Date endTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("startTime",startTime);
        map.put("endTime",endTime);
        delete("AteyeAlarmRecordDAO.deleteByAlarmTime",map);
    }

    @Override
    public Integer countByStartTime(String uuid, String extendUUID,Date start) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        map.put("startTime",start);
        map.put("extendUUID",extendUUID);

        return (Integer) queryForObject("AteyeAlarmRecordDAO.countByStartTime",map);
    }

    @Override
    public AteyeAlarmRecordDO selectRecentlyRealByStartTime(String uuid, String extendUUID,Date start) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        map.put("startTime",start);
        map.put("extendUUID",extendUUID);

        return (AteyeAlarmRecordDO) queryForObject("AteyeAlarmRecordDAO.selectRecentlyRealByStartTime",map);
    }



    @Override
    public Integer countRealAlarmByStartTime(String uuid, String extendUUID, Date start) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        map.put("startTime",start);
        map.put("extendUUID",extendUUID);

        return (Integer) queryForObject("AteyeAlarmRecordDAO.countRealAlarmByStartTime",map);
    }

    @Override
    public Integer countRetrainAlarmByStartTime(String uuid, String extendUUID, Date start) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        map.put("startTime",start);
        map.put("extendUUID",extendUUID);

        return (Integer) queryForObject("AteyeAlarmRecordDAO.countRetrainAlarmByStartTime",map);
    }

    @Override
    public List<AteyeAlarmRecordDO> getTodayByConfIds(Date date, List<Long> alarmConfIds, String env) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("alarmConfIds",alarmConfIds);
        map.put("env",env);
        map.put("startTime",date);
        return queryForList("AteyeAlarmRecordDAO.getTodayByConfIds",map);
    }
    @Override
    public List<AteyeAlarmRecordDO> select(List<Long> confIds, Date startDate, String uuid, String extendUUID, String appName, Long subId, String env) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("confIds",confIds);
        map.put("startDate",startDate);
        map.put("uuid",uuid);
        map.put("env",env);
        map.put("extendUUID",extendUUID);
        map.put("appName",appName);
        map.put("subId",subId);
        return queryForList("AteyeAlarmRecordDAO.select",map);
    }

    @Override
    public Integer countRealBySubIdStartTime(long subId, Date startTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("subId",subId);
        map.put("startTime",startTime);
        return (Integer) queryForObject("AteyeAlarmRecordDAO.countRealBySubIdStartTime",map);
    }

    @Override
    public Integer countRealByConfIdStartTime(long confId, Date startTime) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("confId",confId);
        map.put("startTime",startTime);
        return (Integer) queryForObject("AteyeAlarmRecordDAO.countRealByConfIdStartTime",map);
    }

    @Override
    public AteyeAlarmRecordDO selectById(long id) throws DAOException {
        return (AteyeAlarmRecordDO) queryForObject("AteyeAlarmRecordDAO.selectById",id);
    }

    @Override
    public void updateAlarmText(Long id, String alarmText) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("alarmText",alarmText);
        update("AteyeAlarmRecordDAO.updateAlarmText",map);
    }

    @Override
    public void updateAlarmType(Long id, String alarmType) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("alarmType",alarmType);
        update("AteyeAlarmRecordDAO.updateAlarmType",map);
    }
}
