package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:�����ϵ��
 * @author ˼��
 * Date 2019-05-05
 */
public class AppNodeGroupRelationDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ��ԴappName
     */
    private String sAppName;

    /**
     * ��Դ����
     */
    private String sAppNodeGroup;

    /**
     * Ŀ��appName
     */
    private String cAppName;

    /**
     * Ŀ�ķ���
     */
    private String cAppNodeGroup;

    /**
     * ʱ�䴰�� ��
     */
    private Date timeWindow;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getsAppName() {
        return sAppName;
    }

    public void setsAppName(String sAppName) {
        this.sAppName = sAppName;
    }

    public String getsAppNodeGroup() {
        return sAppNodeGroup;
    }

    public void setsAppNodeGroup(String sAppNodeGroup) {
        this.sAppNodeGroup = sAppNodeGroup;
    }

    public String getcAppName() {
        return cAppName;
    }

    public void setcAppName(String cAppName) {
        this.cAppName = cAppName;
    }

    public String getcAppNodeGroup() {
        return cAppNodeGroup;
    }

    public void setcAppNodeGroup(String cAppNodeGroup) {
        this.cAppNodeGroup = cAppNodeGroup;
    }

    public Date getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(Date timeWindow) {
        this.timeWindow = timeWindow;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
