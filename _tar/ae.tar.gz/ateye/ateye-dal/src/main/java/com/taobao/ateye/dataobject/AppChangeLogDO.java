package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:Ӧ�����ϱ����¼��
 * @author ���
 * Date 2015-07-21
 */
public class AppChangeLogDO extends BaseDO{
	/**
	 * ����
	 */
	private Long id;

	/**
	 * ����ʱ��
	 */
	private Date gmtCreate;

	/**
	 * �޸�ʱ��
	 */
	private Date gmtModified;

	/**
	 * ҵ������
	 */
	@Deprecated
	private Integer bizType;

	/**
	 * ��ҵ������
	 */
	@Deprecated
	private Integer subBizType;
	private String bu;
	private String productName;
	private String subProductName;

	/**
	 * �������
	 */
	private Integer changeType;

	/**
	 * �������
	 */
	private String changeTypeCode;

	/**
	 * ���Ӧ��
	 */
	private String appName;

	/**
	 * �������
	 */
	private String servers;

	/**
	 * ���key
	 */
	private String changeKey;

	/**
	 * ���ǰֵ
	 */
	private String oldValue;

	/**
	 * �����ֵ
	 */
	private String newValue;

	/**
	 * ���ʱ��
	 */
	private Date gmtChangeTime;

	/**
	 * �������ժҪ
	 */
	private String summary;

	/**
	 * ����˵��
	 */
	private String comment;

	/**
	 * ������
	 */
	private String operator;

	/**
	 * ����ID
	 */
	private String operationId;

	/**
	 * ������Դ
	 */
	private String changeFrom;

	/**
	 * ֪ͨ״̬��0����֪ͨ��1��֪ͨ��2��֪ͨ��
	 */
	private Integer notifyStatus;

	/**
	 * ֪ͨ��Ա,�ָ�
	 */
	private String notifyWho;

	/**
	 * ֪ͨʱ��
	 */
	private Date gmtNotifyTime;

	/**
	 * ֪ͨ��ʽ��ww,sms,mail
	 */
	private String notifyBy;

	/**
	 * �������μ�EnvironmentType.code
	 */
	private Integer env;

	/**
	 * setter for column ����
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * getter for column ����
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * setter for column ����ʱ��
	 */
	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	/**
	 * getter for column ����ʱ��
	 */
	public Date getGmtCreate() {
		return this.gmtCreate;
	}

	/**
	 * setter for column �޸�ʱ��
	 */
	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	/**
	 * getter for column �޸�ʱ��
	 */
	public Date getGmtModified() {
		return this.gmtModified;
	}

	/**
	 * setter for column ҵ������
	 */
	public void setBizType(Integer bizType) {
		this.bizType = bizType;
	}

	/**
	 * getter for column ҵ������
	 */
	public Integer getBizType() {
		return this.bizType;
	}

	/**
	 * setter for column ��ҵ������
	 */
	public void setSubBizType(Integer subBizType) {
		this.subBizType = subBizType;
	}

	/**
	 * getter for column ��ҵ������
	 */
	public Integer getSubBizType() {
		return this.subBizType;
	}

	/**
	 * setter for column �������
	 */
	public void setChangeType(Integer changeType) {
		this.changeType = changeType;
	}

	/**
	 * getter for column �������
	 */
	public Integer getChangeType() {
		return this.changeType;
	}

	/**
	 * setter for column �������
	 */
	public void setChangeTypeCode(String changeTypeCode) {
		this.changeTypeCode = changeTypeCode;
	}

	/**
	 * getter for column �������
	 */
	public String getChangeTypeCode() {
		return this.changeTypeCode;
	}

	/**
	 * setter for column ���Ӧ��
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * getter for column ���Ӧ��
	 */
	public String getAppName() {
		return this.appName;
	}

	/**
	 * setter for column �������
	 */
	public void setServers(String servers) {
		this.servers = servers;
	}

	/**
	 * getter for column �������
	 */
	public String getServers() {
		return this.servers;
	}

	/**
	 * setter for column ���key
	 */
	public void setChangeKey(String changeKey) {
		this.changeKey = changeKey;
	}

	/**
	 * getter for column ���key
	 */
	public String getChangeKey() {
		return this.changeKey;
	}

	/**
	 * setter for column ���ǰֵ
	 */
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	/**
	 * getter for column ���ǰֵ
	 */
	public String getOldValue() {
		return this.oldValue;
	}

	/**
	 * setter for column �����ֵ
	 */
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	/**
	 * getter for column �����ֵ
	 */
	public String getNewValue() {
		return this.newValue;
	}

	/**
	 * setter for column ���ʱ��
	 */
	public void setGmtChangeTime(Date gmtChangeTime) {
		this.gmtChangeTime = gmtChangeTime;
	}

	/**
	 * getter for column ���ʱ��
	 */
	public Date getGmtChangeTime() {
		return this.gmtChangeTime;
	}

	/**
	 * setter for column �������ժҪ
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * getter for column �������ժҪ
	 */
	public String getSummary() {
		return this.summary;
	}

	/**
	 * setter for column ����˵��
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * getter for column ����˵��
	 */
	public String getComment() {
		return this.comment;
	}

	/**
	 * setter for column ������
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * getter for column ������
	 */
	public String getOperator() {
		return this.operator;
	}

	/**
	 * setter for column ������Դ
	 */
	public void setChangeFrom(String changeFrom) {
		this.changeFrom = changeFrom;
	}

	/**
	 * getter for column ������Դ
	 */
	public String getChangeFrom() {
		return this.changeFrom;
	}

	/**
	 * setter for column ֪ͨ״̬��0����֪ͨ��1��֪ͨ��2��֪ͨ��
	 */
	public void setNotifyStatus(Integer notifyStatus) {
		this.notifyStatus = notifyStatus;
	}

	/**
	 * getter for column ֪ͨ״̬��0����֪ͨ��1��֪ͨ��2��֪ͨ��
	 */
	public Integer getNotifyStatus() {
		return this.notifyStatus;
	}

	/**
	 * setter for column ֪ͨ��Ա,�ָ�
	 */
	public void setNotifyWho(String notifyWho) {
		this.notifyWho = notifyWho;
	}

	/**
	 * getter for column ֪ͨ��Ա,�ָ�
	 */
	public String getNotifyWho() {
		return this.notifyWho;
	}

	/**
	 * setter for column ֪ͨʱ��
	 */
	public void setGmtNotifyTime(Date gmtNotifyTime) {
		this.gmtNotifyTime = gmtNotifyTime;
	}

	/**
	 * getter for column ֪ͨʱ��
	 */
	public Date getGmtNotifyTime() {
		return this.gmtNotifyTime;
	}

	/**
	 * setter for column ֪ͨ��ʽ��ww,sms,mail
	 */
	public void setNotifyBy(String notifyBy) {
		this.notifyBy = notifyBy;
	}

	/**
	 * getter for column ֪ͨ��ʽ��ww,sms,mail
	 */
	public String getNotifyBy() {
		return this.notifyBy;
	}

	public Integer getEnv() {
		return env;
	}

	public void setEnv(Integer env) {
		this.env = env;
	}

	public String getOperationId() {
		return operationId;
	}

	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSubProductName() {
		return subProductName;
	}

	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	public String getUniqString() {
		return "AppChangeLogDO [bizType=" + bizType
				+ ", subBizType=" + subBizType + ", bu=" + bu
				+ ", productName=" + productName + ", subProductName="
				+ subProductName + ", changeType=" + changeType
				+ ", changeTypeCode=" + changeTypeCode + ", appName=" + appName
				+ ", changeKey=" + changeKey + ", oldValue=" + oldValue
				+ ", newValue=" + newValue + ", summary=" + summary
				+ ", operator=" + operator + ", changeFrom=" + changeFrom
				+ ", notifyStatus=" + notifyStatus + ", notifyWho=" + notifyWho
				+ ", notifyBy=" + notifyBy
				+ ", env=" + env + "]";
	}
}
