package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeTairDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AteyeTairDAO {
    Long insert(AteyeTairDO ateyeTairDO) throws DAOException;
    AteyeTairDO getByUk(String namespace,String configid,String username,String env) throws DAOException;

}
