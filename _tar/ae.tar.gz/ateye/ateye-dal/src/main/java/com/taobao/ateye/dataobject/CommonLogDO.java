package com.taobao.ateye.dataobject;

import org.apache.solr.client.solrj.beans.Field;

/**
 * solr��schema��������ݽṹ��Ӧ��DO����
 * @author gumo
 *
 */
public class CommonLogDO extends BaseDO {

	private static final long serialVersionUID = -2988232290263457800L;
	/**
	 * ID,�û�ȡ����־���ݵ�MD5ֵ��ID
	 */
	@Field
	private String id;
	/**
	 * ��־����Ӧ�õ�����
	 */
	@Field
	private String app;
	/**
	 * ��־���ݵ����
	 */
	@Field("cat")
	private String categories;
	/**
	 * �ؼ���1
	 */
	@Field
	private String key1;
	/**
	 * �ؼ���2
	 */
	@Field
	private String key2;
	/**
	 * �ؼ���3
	 */
	@Field
	private String key3;
	/**
	 * �ؼ���4
	 */
	@Field
	private String key4;
	/**
	 * ��־����
	 */
	@Field
	private String log;
	/**
	 * ��¼��־�Ļ���IP
	 */
	@Field
	private String ip;
	/**
	 * ��־�ļ���
	 */
	@Field
	private String file;
	/**
	 * ʱ���
	 */
	@Field
	private Long timestamp;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getApp() {
		return app;
	}
	public void setApp(String app) {
		this.app = app;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getKey1() {
		return key1;
	}
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	public String getKey2() {
		return key2;
	}
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	public String getKey3() {
		return key3;
	}
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	public String getKey4() {
		return key4;
	}
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getLog() {
		return log;
	}
	public void setLog(String log) {
		this.log = log;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

}
