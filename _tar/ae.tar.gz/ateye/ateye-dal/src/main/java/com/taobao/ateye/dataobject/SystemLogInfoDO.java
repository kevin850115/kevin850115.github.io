package com.taobao.ateye.dataobject;

import java.util.Date;

public class SystemLogInfoDO  extends BaseDO
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SystemLogInfoDO(){}
	
	/**
	 * ����ID
	 */
	private Long id;
	
	/**
	 * Ӧ����
	 */
	private String appName;
	
	/**
	 * ����IP
	 */
	private String ip;
	
	/**
	 * ��־�ļ�����·��
	 */
	private String path;
	
	/**
	 * ����ռ�����ϵͳ��־ʱ���
	 */
	private String latestTime;
	
	/**
	 * ����ռ���ϵͳ��־count������ģ���ջ���кţ�
	 */
	private int latestCount;
	
	
	/**
	 * ����ʱ��
	 */
	private Date createdTime;

	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getLatestTime() {
		return latestTime;
	}

	public void setLatestTime(String latestTime) {
		this.latestTime = latestTime;
	}

	public int getLatestCount() {
		return latestCount;
	}

	public void setLatestCount(int latestCount) {
		this.latestCount = latestCount;
	}
	
	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
}
