package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.MethodTemplateValueDO;
import com.taobao.ateye.exception.DAOException;

public interface MethodTemplateValueDAO 
{
	/**
	 * ���ݷ���ģ��id�ͷ���id��ѯ����ģ��ֵ
	 * @param templatedId
	 * @param methodId
	 * @return
	 * @throws DAOException
	 */
	public MethodTemplateValueDO getMethodTemplateValueByTemplateIdAndMethodId(Long templateId, Long methodId) throws DAOException;
	
	/**
	 * ����id��ѯģ��ֵ
	 * @param templateId
	 * @param fieldId
	 * @return
	 * @throws DAOException
	 */
	public MethodTemplateValueDO getMethodTemplateValueById(Long methodTemplateValueId) throws DAOException;
	
	/**
	 * ����һ������ģ��ֵ
	 * @param methodTemplateValue
	 * @return
	 * @throws DAOException
	 */
	public Long insertMethodTemplateValue(MethodTemplateValueDO methodTemplateValue) throws DAOException;
	
	/**
	 * ����һ������ģ��ֵ
	 * @param methodTemplateValueId
	 * @param methodParamValue
	 * @param emptyStringIndex
	 * @param nullValueIndex
	 * @return
	 * @throws DAOException
	 */
	public int updateMethodTemplateValue(Long methodTemplateValueId, String methodParamValue, 
			String emptyStringIndex, String nullValueIndex) throws DAOException;
	
	/**
	 * ɾ��ĳһ����ģ���µ�ȫ��ģ��ֵ
	 * @param methodTemplateValueId
	 * @return
	 * @throws DAOException
	 */
	public int deleteMethodTemplateValueByTemplateId(Long methodTemplateValueId) throws DAOException;
}
