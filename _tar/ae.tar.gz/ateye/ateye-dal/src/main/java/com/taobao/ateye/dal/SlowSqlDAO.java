package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.SlowSqlDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2018/10/26.
 */
public interface SlowSqlDAO {
    void insertSlowSql(SlowSqlDO slowSqlDO) throws DAOException;
    void batchInsertSlowSql(List<SlowSqlDO> list) throws DAOException;

    void deleteByHappenDate(Date date) throws DAOException;

    void deleteExpiredSlowSql(Date expiredDate) throws DAOException;
    
    List<SlowSqlDO> queryAll(Date date) throws DAOException;

    Integer existByHappenDate(Date happenDate) throws DAOException;
}
