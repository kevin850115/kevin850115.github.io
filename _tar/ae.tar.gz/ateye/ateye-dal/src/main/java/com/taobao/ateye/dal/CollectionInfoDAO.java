package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.CollectionInfoDO;
import com.taobao.ateye.exception.DAOException;

public interface CollectionInfoDAO 
{
	/**
	 * ����Ӧ����+����IP+��־·����ѯ�ռ���Ϣ
	 * @param appName
	 * @param ip
	 * @param path
	 * @return
	 * @throws DAOException
	 */
	CollectionInfoDO getCollectionInfoDO(String appName, String ip, String path) throws DAOException;
	
	/**
	 * ����һ��CollectionInfoDO
	 * @param collectionInfoDO
	 * @return
	 * @throws DAOException
	 */
	int updateCollectionInfoDO(CollectionInfoDO collectionInfoDO) throws DAOException;
	
	/**
	 * ����һ��CollectionInfoDO
	 * @param collectionInfoDO
	 * @return
	 * @throws DAOException
	 */
	Long insertCollectionInfoDO(CollectionInfoDO collectionInfoDO) throws DAOException;
	
	/**
	 * ɾ��ĳһApp��ĳһ������ĳһpath��־�ռ���Ϣ
	 * @param appName
	 * @param ip
	 * @param path
	 * @return
	 * @throws DAOException
	 */
	int deleteCollectionInfoDO(String appName, String ip, String path) throws DAOException;
}