package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AteyeAlarmItemDAO;
import com.taobao.ateye.dataobject.AteyeAlarmItemDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2018/12/6.
 */
public class IBatisAteyeAlarmItemDAO extends BaseDAO implements AteyeAlarmItemDAO {
    @Override
    public List<AteyeAlarmItemDO> selectAll() throws DAOException {
        return queryForList("AteyeAlarmItemDAO.selectAll");
    }

    @Override
    public Long insert(AteyeAlarmItemDO ateyeAlarmItemDO) throws DAOException {
        return (Long) insert("AteyeAlarmItemDAO.insert",ateyeAlarmItemDO);
    }

    @Override
    public AteyeAlarmItemDO selectByUkMd5(String ukMd5) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("ukMd5",ukMd5);
        return (AteyeAlarmItemDO) queryForObject("AteyeAlarmItemDAO.selectByUkMd5",map);
    }

    @Override
    public void deleteOldRule() throws DAOException {
        delete("AteyeAlarmItemDAO.deleteOldRule",null);
    }

    @Override
    public AteyeAlarmItemDO selectById(long id) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        return (AteyeAlarmItemDO) queryForObject("AteyeAlarmItemDAO.selectById",map);
    }

    public List<AteyeAlarmItemDO> selectByApp(String app) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("app",app);
        return queryForList("AteyeAlarmItemDAO.selectByApp",map);
    }
}
