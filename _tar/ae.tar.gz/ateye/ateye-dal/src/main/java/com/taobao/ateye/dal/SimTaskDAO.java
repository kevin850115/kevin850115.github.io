package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SimTaskDO;
import com.taobao.ateye.exception.DAOException;

public interface SimTaskDAO {

	Long addTask(SimTaskDO simTaskDO) throws DAOException;
	List<SimTaskDO> queryTaskList(Long simId) throws DAOException;

}
