package com.taobao.ateye.dal;

import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.UserStaticsDO;
import com.taobao.ateye.exception.DAOException;

/**
 * @author yunqing.wxl
 * 
 */
public interface UserStaticsDAO {

    /**
     * @param userStaticsDO
     * @return
     * @throws DAOException
     */
    List<UserStaticsDO> selectByStatDate(UserStaticsDO userStaticsDO) throws DAOException;

    /**
     * @param parammeter
     * @return
     * @throws DAOException
     */
    List<UserStaticsDO> selectCountByStatDate(Map<String, String> parammeter) throws DAOException;
}
