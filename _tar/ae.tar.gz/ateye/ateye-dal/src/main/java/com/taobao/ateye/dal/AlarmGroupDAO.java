package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.AteyeAlarmGroupDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface AlarmGroupDAO {

    Long insert(AteyeAlarmGroupDO alarmDO) throws DAOException;
    
    List<AteyeAlarmGroupDO> getAll() throws DAOException;
    List<AteyeAlarmGroupDO> getByBiz(int biz) throws DAOException;
    AteyeAlarmGroupDO getAlarmGroupByName(String name) throws DAOException;

	int updateToken(String id, String token) throws DAOException;
	int updateBiz(String id, int biz) throws DAOException;
	int removeAll() throws DAOException;
	int remove(Long id) throws DAOException;

}
