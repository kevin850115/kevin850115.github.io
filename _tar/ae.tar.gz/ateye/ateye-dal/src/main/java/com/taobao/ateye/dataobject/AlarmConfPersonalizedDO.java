package com.taobao.ateye.dataobject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Description:�ۺϱ���
 * @author ˼��
 * Date 2018-12-06
 */
public class AlarmConfPersonalizedDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * 0-��Ч,1-��ͣ 2-�߼�ɾ��
     */
    private int sourceStatus;

    /**
     * �����м���ͣһ��ʱ��
     */
    private Date sourceReopenDate;

    /**
     * ����
     */
    private String env;


    /**
     * Ψһ��ʾ
     */
    private String sourceUUID;

    /**
     * Ψһ��ʾ
     */
    private Long sourceConfId;

    /**
     * Ψһ��ʾ
     */
    private String sourceExtendUUID;

    /**
     * ����ʱ��ο�ʼʱ��
     */
    private Integer sourceHourStart;

    /**
     * ����ʱ��ν���ʱ��
     */
    private Integer sourceHourEnd;

    /**
     * �رչ��� 0-�� 1-��
     */

    private int isDelete;

    /**
     * ��չ��Ϣ
     */
    private String extendInfo;

    /**
     * ����ȫ���쳣,�쳣����,�����쳣���Ͷ��Ÿ���
     */
    private String exTypes;

    private BigDecimal threshold;

    /**
     * Ӧ��
     */
    private String app;

    /**
     * ������ʷid
     */
    private Long recordId;

    private Long subId;

    /**
     * ������
     */
    private String operator;


    /**
     * ԭ��������
     */
    private String detail;

    /**
     * ��ע
     */
    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Long getSubId() {
        return subId;
    }

    public void setSubId(Long subId) {
        this.subId = subId;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public Long getRecordId() {
        return recordId;
    }

    public void setRecordId(Long recordId) {
        this.recordId = recordId;
    }

    public BigDecimal getThreshold() {
        return threshold;
    }

    public void setThreshold(BigDecimal threshold) {
        this.threshold = threshold;
    }

    public int getSourceStatus() {
        return sourceStatus;
    }

    public void setSourceStatus(int sourceStatus) {
        this.sourceStatus = sourceStatus;
    }

    public Date getSourceReopenDate() {
        return sourceReopenDate;
    }

    public void setSourceReopenDate(Date sourceReopenDate) {
        this.sourceReopenDate = sourceReopenDate;
    }

    public String getSourceUUID() {
        return sourceUUID;
    }

    public void setSourceUUID(String sourceUUID) {
        this.sourceUUID = sourceUUID;
    }

    public String getSourceExtendUUID() {
        return sourceExtendUUID;
    }

    public void setSourceExtendUUID(String sourceExtendUUID) {
        this.sourceExtendUUID = sourceExtendUUID;
    }

    public Integer getSourceHourStart() {
        return sourceHourStart;
    }

    public void setSourceHourStart(Integer sourceHourStart) {
        this.sourceHourStart = sourceHourStart;
    }

    public Integer getSourceHourEnd() {
        return sourceHourEnd;
    }

    public void setSourceHourEnd(Integer sourceHourEnd) {
        this.sourceHourEnd = sourceHourEnd;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    public String getExTypes() {
        return exTypes;
    }

    public void setExTypes(String exTypes) {
        this.exTypes = exTypes;
    }

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

    public Long getSourceConfId() {
        return sourceConfId;
    }

    public void setSourceConfId(Long sourceConfId) {
        this.sourceConfId = sourceConfId;
    }
}