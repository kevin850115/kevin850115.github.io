package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SceneEntryPoint;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneEntryPointDAO {
    SceneEntryPoint getEntryPointById(long entryPointId) throws DAOException;

    SceneEntryPoint getEntryPointByNameAndType(String name,String type,String env,String clientAppName) throws DAOException;
    List<SceneEntryPoint> getEntryPointByName(String name,String env) throws DAOException;



    void updateSceneId(String name,String type,long sceneId,String env) throws DAOException;

    Long insertEntryPoint(SceneEntryPoint entryPoint) throws DAOException;
    
    List<SceneEntryPoint> getEntryPoints(String env,int limit) throws DAOException;

    List<SceneEntryPoint> getEntryPointsByIds(String env,List<Long> sceneIds) throws DAOException;
    List<SceneEntryPoint> getEntryPointsByType(String env,String type,int limit) throws DAOException;

	int updateDesc(Long entryId, String desc)throws DAOException;
	int updateLevel(Long entryId, Long levelId)throws DAOException;
	int updateCat(Long entryId, Long catId)throws DAOException;

    void deleteById(long id) throws DAOException;

    List<SceneEntryPoint> getEntryPointByApp(String app, String env) throws DAOException;
}
