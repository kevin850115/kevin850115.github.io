package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmConfPersonalizedDAO;
import com.taobao.ateye.dataobject.AlarmConfPersonalizedDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by sunqiang on 2019/1/28.
 */
public class IBatisAlarmConfPersonalizedDAO extends BaseDAO implements AlarmConfPersonalizedDAO {

    @Override
    public List<AlarmConfPersonalizedDO> selectAll(String env) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("env",env);
        return queryForList("AlarmConfPersonalizedDAO.selectAll",map);
    }

    @Override
    public AlarmConfPersonalizedDO selectById(Long id) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        return (AlarmConfPersonalizedDO) queryForObject("AlarmConfPersonalizedDAO.selectById",map);
    }

    @Override
    public void updateReopenDate(String id, Date date) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("reopenDate",date);
        update("AlarmConfPersonalizedDAO.updateReopenDate",map);
    }

    @Override
    public List<AlarmConfPersonalizedDO> selectByUUID(String uuid) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("uuid",uuid);
        return queryForList("AlarmConfPersonalizedDAO.selectByUUID",map);
    }

    @Override
    public List<AlarmConfPersonalizedDO> selectByExtendUUID(String extendUUID) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("extendUUID",extendUUID);
        return queryForList("AlarmConfPersonalizedDAO.selectByExtendUUID",map);
    }

    @Override
    public List<AlarmConfPersonalizedDO> selectByConfId(Long confId) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("confId",confId);
        return queryForList("AlarmConfPersonalizedDAO.selectByConfId",map);
    }

    @Override
    public void deleteById(long id) throws DAOException {
        update("AlarmConfPersonalizedDAO.deleteById",id);
    }

    @Override
    public void update(AlarmConfPersonalizedDO personalizedDO) throws DAOException {
        update("AlarmConfPersonalizedDAO.update",personalizedDO);
    }

    @Override
    public Long insert(AlarmConfPersonalizedDO ruleDO) throws DAOException {
        return (Long) insert("AlarmConfPersonalizedDAO.insert",ruleDO);
    }

    @Override
    public void updateStatus(Long id, int status) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("id",id);
        map.put("status",status);
        update("AlarmConfPersonalizedDAO.updateStatus",map);
    }
}
