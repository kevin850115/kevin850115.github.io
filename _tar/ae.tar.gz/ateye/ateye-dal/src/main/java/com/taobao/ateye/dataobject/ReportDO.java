package com.taobao.ateye.dataobject;

import java.util.List;

/****
 * ҵ�񱨱�DO
 * @author jianbo.hc
 *
 */
public class ReportDO extends BaseDO{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2213531381832882848L;
	private Integer id;
	private String name;
	private String summary;
	private String appName;
	private Integer status;
	private List<CategoryDO> cateList;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public List<CategoryDO> getCateList() {
		return cateList;
	}
	public void setCateList(List<CategoryDO> cateList) {
		this.cateList = cateList;
	}
	
	
	

}
