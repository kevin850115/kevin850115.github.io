package com.taobao.ateye.dataobject;

import java.util.Date;

public class MixedTemplateTaskDO extends BaseDO
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5777169912819240639L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ��������
	 */
	private String taskName;
	/**
	 * ����ģ��id
	 */
	private Long fieldTemplateId;
	/**
	 * ����ģ�����ƣ������ֶΣ�
	 */
	private String fieldTemplateName="";
	/**
	 * ����ģ��id
	 */
	private Long methodTemplateId;
	/**
	 * ����ģ�����ƣ������ֶΣ�
	 */
	private String methodTemplateName="";
	/**
	 * �������ͣ�Oneshot��cron��
	 */
	private int taskType;
	/**
	 * ִ��ʱ���cron����ʽ
	 */
	private String cronTime;
	/**
	 * �����������
	 */
	private String owner;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public Long getFieldTemplateId() {
		return fieldTemplateId;
	}
	public void setFieldTemplateId(Long fieldTemplateId) {
		this.fieldTemplateId = fieldTemplateId;
	}
	public String getFieldTemplateName() {
		return fieldTemplateName;
	}
	public void setFieldTemplateName(String fieldTemplateName) {
		this.fieldTemplateName = fieldTemplateName;
	}
	public Long getMethodTemplateId() {
		return methodTemplateId;
	}
	public void setMethodTemplateId(Long methodTemplateId) {
		this.methodTemplateId = methodTemplateId;
	}
	public String getMethodTemplateName() {
		return methodTemplateName;
	}
	public void setMethodTemplateName(String methodTemplateName) {
		this.methodTemplateName = methodTemplateName;
	}
	public int getTaskType() {
		return taskType;
	}
	public void setTaskType(int taskType) {
		this.taskType = taskType;
	}
	public String getCronTime() {
		return cronTime;
	}
	public void setCronTime(String cronTime) {
		this.cronTime = cronTime;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
}
