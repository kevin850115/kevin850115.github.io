package com.taobao.ateye.dataobject;

import java.util.Date;

public class UrlDO extends BaseDO 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8404948469476459472L;

	/**
	 * ID, ����
	 */
	private Long id;
	
	/**
	 * ��������
	 */
	private String urlName;
	
	/**
	 * ��������
	 */
	private String urlDesc;
	
	/**
	 * ������
	 */
	private String creator;
	
	/**
	 * �������ݣ�Url��ַ��
	 */
	private String urlContent;
	
	/**
	 * ����ģʽ������\˽�У�
	 */
	private int urlType;
	
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUrlName() {
		return urlName;
	}
	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}
	public String getUrlDesc() {
		return urlDesc;
	}
	public void setUrlDesc(String urlDesc) {
		this.urlDesc = urlDesc;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getUrlContent() {
		return urlContent;
	}
	public void setUrlContent(String urlContent) {
		this.urlContent = urlContent;
	}
	public int getUrlType() {
		return urlType;
	}
	public void setUrlType(int urlType) {
		this.urlType = urlType;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UrlName:"+urlName+"\n");
		sb.append("UrlDesc:"+urlDesc+"\n");
		sb.append("UrlContent:"+urlContent+"\n");
		sb.append("Creator:"+creator+"\n");
		if(urlType==0)
		{
			sb.append("UrlType:˽������\n");
		}
		else
		{
			sb.append("UrlType:��������\n");
		}
		sb.append("\n");
		return sb.toString();
	}
}
