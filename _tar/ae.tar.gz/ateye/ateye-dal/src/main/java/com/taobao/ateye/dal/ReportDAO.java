package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.CategoryDO;
import com.taobao.ateye.dataobject.DataDO;
import com.taobao.ateye.dataobject.ReportDO;
import com.taobao.ateye.dataobject.ReportSubscribDO;
import com.taobao.ateye.exception.DAOException;

/**
 * ���ݱ���DAO��
 * @author jianbo.hc
 *
 */
public interface ReportDAO {
	/**
	 * ��ȡ����report ����
	 * @return
	 */
	public List<ReportDO> getAllReportsDef()throws DAOException;
	
	public ReportDO getReportDefById(int reportId)throws DAOException;
	/**
	 * ���ݱ���id��ȡ�����
	 * @param reportId
	 * @return
	 */
	public List<CategoryDO> getCatDefByReportId(int reportId)throws DAOException;
	/**
	 * �������id��ȡָ�궨��
	 * @param catId
	 * @return
	 */
	public List<DataDO> getDataDefByCatId(int catId)throws DAOException;
	/**
	 * ���ݲ�����ȡ����ָ��ֵ
	 * @param paramMap
	 * @return
	 */
	public List<DataDO> getDataDOByParam(Map paramMap)throws DAOException;
	
	public Integer saveReportDef(ReportDO reportDO)throws DAOException;

	public Integer saveCatDef(CategoryDO catDO)throws DAOException;
	
	public DataDO getDataDefByName(String name,int catId)throws DAOException;
	
	public Integer saveDataDef(DataDO dataDO)throws DAOException;
	
	public Integer updateReportDef(ReportDO reportDO)throws DAOException;
	
    public Integer updateCatDef(CategoryDO catDO)throws DAOException;
	
	public Integer updateDataDef(DataDO dataDO)throws DAOException;
	/**
	 * ���ݶ���ʹ��
	 * @param dataDO
	 * @return
	 * @throws DAOException
	 */
	public Integer updateData(DataDO dataDO)throws DAOException;
	/**
	 * ���ݱ���id��ȡ���ĵ��ʼ��б�
	 * @return
	 * @throws DAOException
	 */
	public List<String> getEmailsByReportId(int id)throws DAOException;
	/**
	 * ��ȡĳһ�û����ĵı���id���û�Ϊnull���ȡ���б���
	 * @return
	 * @throws DAOException
	 */
	public List<ReportSubscribDO> getSubcribReportId(String nick)throws DAOException;
	/**
	 * �²��붩�Ĺ�ϵ
	 * @param name
	 * @param id
	 * @return
	 * @throws DAOException
	 */
	public Integer saveEmailSubcrib(String name,int id,String nick)throws DAOException;
	/**
	 * ����id���¶��ĵ�״̬
	 * @param id
	 * @param status
	 * @return
	 * @throws DAOException
	 */
	public Integer updateEmailSubcrib(int id,int status,String userNick)throws DAOException;
	
	
	public Integer deleteCatDefById(int catId) throws DAOException;
	
	public Integer deleteDataDefById(int dataId) throws DAOException;
	
	public Integer deleteDataByDataKeyTime(String dataKey, Date day) throws DAOException;

	/**
	 * @param data
	 * @return
	 */
	public Integer saveData(Map<String, Object> data) throws DAOException;
	
	public CategoryDO getCategoryDOById(int catId)throws DAOException;

}
