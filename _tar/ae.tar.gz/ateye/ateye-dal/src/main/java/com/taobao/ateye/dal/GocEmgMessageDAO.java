package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.GocEmgMessageDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/5/8.
 */
public interface GocEmgMessageDAO {
    List<GocEmgMessageDO> getByCondition(String adKey, String alarmId,Integer statusCode, Date startTime, Date endTime) throws DAOException;
    Long insert(GocEmgMessageDO gocEmgMessageDO) throws DAOException;

    GocEmgMessageDO getByUk(String adKey, String statusCode) throws DAOException;

    List<GocEmgMessageDO> getByDate(Date statDate, Date endDate) throws DAOException;
}
