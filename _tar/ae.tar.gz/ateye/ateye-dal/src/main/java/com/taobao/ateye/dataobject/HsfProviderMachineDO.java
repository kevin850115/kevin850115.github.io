package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:�ṩhsf����Ļ���
 * @author ˼��
 * Date 2019-05-05
 */
public class HsfProviderMachineDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ����
     */
    private String uniqueServiceName;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * ip
     */
    private String ip;

    /**
     * �˿�
     */
    private int port;

    /**
     * ����
     */
    private String env;

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column ����
     */
    public void setUniqueServiceName(String uniqueServiceName) {
        this.uniqueServiceName = uniqueServiceName;
    }

    /**
     * getter for column ����
     */
    public String getUniqueServiceName() {
        return this.uniqueServiceName;
    }

    /**
     * setter for column Ӧ������
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * getter for column Ӧ������
     */
    public String getAppName() {
        return this.appName;
    }

    /**
     * setter for column Ӧ�÷���
     */
    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    /**
     * getter for column Ӧ�÷���
     */
    public String getAppNodeGroup() {
        return this.appNodeGroup;
    }

    /**
     * setter for column ip
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
     * getter for column ip
     */
    public String getIp() {
        return this.ip;
    }

    /**
     * setter for column �˿�
     */
    public void setPort(int port) {
        this.port = port;
    }

    /**
     * getter for column �˿�
     */
    public int getPort() {
        return this.port;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }
}