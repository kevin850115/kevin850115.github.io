package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmLogReceiverDAO;
import com.taobao.ateye.dataobject.AlarmLogReceiverDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Map;

/**
 * Created by sunqiang on 2018/11/15.
 */
public class IBatisAlarmLogReceiverDAO extends BaseDAO implements AlarmLogReceiverDAO {
    @Override
    public Long saveAlarmLogReceiver(AlarmLogReceiverDO alarmLogReceiverDO) throws DAOException {
        return (Long) insert("AlarmLogReceiverDAO.saveAlarmLogReceiver",alarmLogReceiverDO);
    }

    @Override
    public AlarmLogReceiverDO getByName(String name) throws DAOException {
        Map<String,Object> map = Maps.newHashMap();
        map.put("name",name);

        return (AlarmLogReceiverDO) queryForObject("AlarmLogReceiverDAO.getByName",map);
    }
}
