package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.FlowInterfaceDO;
import com.taobao.ateye.exception.DAOException;

/*
 * ����
 */
public interface FlowInterfaceDAO {
	
	void insert(FlowInterfaceDO interfaceDO) throws DAOException;

	void delete(String app, Date day, String env)throws DAOException;

	List<FlowInterfaceDO> getAll(String app,String ng,Date day, String env) throws DAOException;
	

}
