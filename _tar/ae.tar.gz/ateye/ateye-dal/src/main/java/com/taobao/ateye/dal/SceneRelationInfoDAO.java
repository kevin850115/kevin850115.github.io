package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.AteyeSceneRelationInfoDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/9/5.
 */
public interface SceneRelationInfoDAO {

	long insert(AteyeSceneRelationInfoDO infoDO) throws DAOException;
	
	List<AteyeSceneRelationInfoDO> getBySceneId(Long sceneId) throws DAOException;


	int updateDepType(Long sceneId,String nodeGroup, String uniqMethodInfo, String nick,String depType)throws DAOException;
	
	int updateDepDesc(Long sceneId,String nodeGroup, String uniqMethodInfo, String nick,String depDesc)throws DAOException;

	AteyeSceneRelationInfoDO getRelation(Long sceneId,String nodeGroup, String uniqMethodInfo)throws DAOException;
   
}
