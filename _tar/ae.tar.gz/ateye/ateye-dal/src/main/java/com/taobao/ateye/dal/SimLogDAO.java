package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.SimLogDO;
import com.taobao.ateye.exception.DAOException;

public interface SimLogDAO {

	Long addLog(SimLogDO simDO) throws DAOException;
	List<SimLogDO> queryList(Long simId) throws DAOException;

}
