package com.taobao.ateye.dataobject;

import java.util.Date;

public class LogFilePathDO extends BaseDO
{
	private static final long serialVersionUID = -1841866590899531257L;
	
	//accessLog��id����
	public static final int ACCESS_LOG_TYPE_ID = 8;

	public LogFilePathDO(){}
	/**
	 * ID, ����
	 */
	private Long id;
	/**
	 * appId Ӧ��ID
	 */
	private Long appId;
	
	/**
	 * ��Ӧ��meta_data����idֵ
	 */
	private Long dataId;
	
	/**
	 * filePath ��־�ļ���·��
	 */
	private String filePath;
	
	/**
	 * type ��־���ͣ����ڱ�ʾ��������
	 */
	private int type;
	
	/**
	 * �ű��ֶ�
	 */
	private String script;
	
	/**
	 * �ű�������
	 */
	private int scriptType;
	
	/**
	 * ����־��������
	 */
	private String operator;
	
	/**
	 * ����������־�ռ������Tracker����IP��ַ
	 */
	private String owner;

	/**
	 * Ԥ����������������־�ռ������Tracker����IP��ַ
	 */
	private String preOwner;



	/**
	 * ����ʱ��
	 */
	private Date createdTime;

	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;

	public String getPreOwner() {
		return preOwner;
	}

	public void setPreOwner(String preOwner) {
		this.preOwner = preOwner;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAppId() {
		return appId;
	}

	public void setAppId(Long appId) {
		this.appId = appId;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	/**
	 * @return the script
	 */
	public String getScript() {
		return script;
	}

	/**
	 * @param script the script to set
	 */
	public void setScript(String script) {
		this.script = script;
	}

	/**
	 * @return the scriptType
	 */
	public int getScriptType() {
		return scriptType;
	}

	/**
	 * @param scriptType the scriptType to set
	 */
	public void setScriptType(int scriptType) {
		this.scriptType = scriptType;
	}

	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * @param operator the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * @return the data_id
	 */
	public Long getDataId() {
		return dataId;
	}

	/**
	 * @param data_id the data_id to set
	 */
	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}

	
}
