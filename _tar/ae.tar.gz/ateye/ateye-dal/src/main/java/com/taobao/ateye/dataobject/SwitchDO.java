package com.taobao.ateye.dataobject;

import java.io.Serializable;
import java.util.Date;

/**
 * ���ݶ���
 * @since 2011-06-21
 * @author �س�
 */
public class SwitchDO implements Serializable {

    private static final long serialVersionUID = 130865514316250096L;
    public static final int STATUS_OK=0;
    public static final int STATUS_DELETE=1;

    /**
     * column at_eye_switch.id
     */
    private Integer id;
    
    private boolean hasPersistence;
    
    private String persistenceDesc;

    private String bean;
    /**
     * column at_eye_switch.key
     */
    private String key;

    /**
     * column at_eye_switch.desc
     */
    private String desc;

    /**
     * column at_eye_switch.class
     */
    private String cl;

    /**
     * column at_eye_switch.field
     */
    private String field;

    /**
     * column at_eye_switch.server_role
     */
    private String app;
    private Integer status;

    /**
     * column at_eye_switch.gmt_create
     */
    private Date gmtCreate;

    /**
     * column at_eye_switch.gmt_modified
     */
    private Date gmtModified;

    public SwitchDO() {
        super();
    }
/*
     * getter for Column at_eye_switch.id
     */
    public Integer getId() {
        return id;
    }

    /**
     * setter for Column at_eye_switch.id
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * getter for Column at_eye_switch.key
     */
    public String getKey() {
        return key;
    }

    /**
     * setter for Column at_eye_switch.key
     * @param key
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * getter for Column at_eye_switch.desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * setter for Column at_eye_switch.desc
     * @param desc
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

  

    /**
     * getter for Column at_eye_switch.field
     */
    public String getField() {
        return field;
    }

    /**
     * setter for Column at_eye_switch.field
     * @param field
     */
    public void setField(String field) {
        this.field = field;
    }

    /**
     * getter for Column at_eye_switch.gmt_create
     */
    public Date getGmtCreate() {
        return gmtCreate;
    }

    /**
     * setter for Column at_eye_switch.gmt_create
     * @param gmtCreate
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for Column at_eye_switch.gmt_modified
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * setter for Column at_eye_switch.gmt_modified
     * @param gmtModified
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
    public String getCl() {
        return cl;
    }
    public void setCl(String cl) {
        this.cl = cl;
    }
    public void setApp(String app) {
        this.app = app;
    }
    public String getApp() {
        return app;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getStatus() {
        return status;
    }
    public void setBean(String bean) {
        this.bean = bean;
    }
    public String getBean() {
        return bean;
    }
    public void setHasPersistence(boolean hasPersistence) {
        this.hasPersistence = hasPersistence;
    }
    public boolean isHasPersistence() {
        return hasPersistence;
    }
    public void setPersistenceDesc(String persistenceDesc) {
        this.persistenceDesc = persistenceDesc;
    }
    public String getPersistenceDesc() {
        return persistenceDesc;
    }


}