package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/10/31.
 */
public class RealTimeTrackerLogDO extends BaseDO {
    /**
     * ����id
     */
    private Long id;
    /**
     * ����ʱ��
     */
    private Date gmtCreate;
    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * �û���Ϣ,�û�id����nick
     */
    private String userInfo;


    /**
     * �������ץȡ �������targetName
     */
    private String targetName;

    /**
     * ��ʼʱ��
     */
    private Date startTime;

    /**
     * ����ʱ��
     */
    private Date endTime;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * ����
     */
    private String env;
    /*
     * ������
     */
    private String operator;

    /**
     * �Ƿ������ץȡ
     */
    private int random;

    public int getRandom() {
        return random;
    }

    public void setRandom(int random) {
        this.random = random;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }
}
