package com.taobao.ateye.dataobject;



public class ChangeFreeStatDO extends BaseDO {
	private static final long serialVersionUID = -3248972264746167336L;
	private String productName;
	private Long total;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
  
}
