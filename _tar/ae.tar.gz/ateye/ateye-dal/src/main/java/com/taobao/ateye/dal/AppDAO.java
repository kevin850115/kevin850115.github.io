package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.exception.DAOException;

public interface AppDAO {
    
	/**
	 * ����ID��ѯӦ��
	 * @param appId Ӧ��ID
	 * @return �û�����
	 * @throws DAOException
	 */
    AppDO getAppById(Long appId) throws DAOException;
	
	/**
	 * ����name��ѯӦ��
	 * @param name
	 * @return
	 * @throws DAOException
	 */
    AppDO getAppByName(String appName) throws DAOException;
		
	/**
	 * ��ѯ����Ӧ��
	 * @return
	 * @throws DAOException
	 */
	List<AppDO> getAllAppAsList() throws DAOException;
	
	Map<String,AppDO> getAllAppAsMap() throws DAOException;
	
	Map<Long,AppDO> getAllAppAsMapById() throws DAOException;
	
	/**
	 * ����ҵ���ߺ���ҵ���߲�ѯӦ��
	 */
	List<AppDO> queryAppByBizType(Integer bizType, Integer subBizType) throws DAOException;

	/**
	 * ����Ӧ��
	 * @param appDO AppDO����
	 * @return Id
	 * @throws DAOException
	 */
	Long saveApp(AppDO appDO) throws DAOException;
	
	
	/**
	 * ����nameɾ��Ӧ��
	 * @param appName
	 * @return
	 * @throws DAOException
	 */
	int deleteAppByName(String appName) throws DAOException;

	/**
	 * ɾ�����ڵ�StormӦ�ã�ɾ��gmt_modified<gmtModified�ļ�¼��
	 * @param appId
	 * @param gmtModified
	 * @return
	 * @throws DAOException
	 */
	int deleteObsoleteStormApp(Long appId, Date gmtModified) throws DAOException;
	
	/**
	 * ����App�Ĺ���Ա��Ϣ
	 * @param appId
	 * @param administrators
	 * @return
	 * @throws DAOException
	 */
	int updateAppAdminInfo(Long appId, String administrators) throws DAOException;
	int updateAoneAppInfo(Long appId,String bu,String productName,String description) throws DAOException;


	/**
	 * ����App�ı��֪ͨ����ȺToken
	 */
	int updateAppDingdingTokens(Long appId, String tokens) throws DAOException;
	int updateAppDingdingTokensByBiz(int bizType, String tokens) throws DAOException;
	
	/**
	 * ����App��Context Root ��Ϣ
	 * @param appId
	 * @param contextRoot
	 * @return
	 * @throws DAOException
	 */
	int updateAppContextRoot(Long appId, String contextRoot) throws DAOException;

	/*
	 * ����ҵ������
	 */
	int updateAppBizType(Long appId, int bizType) throws DAOException;
	int changeAppBizType(int from,int to) throws DAOException;
	int updateAppSubBizType(Long appId, int subBizType) throws DAOException;
	int updateAppAlias(Long appId, String alias) throws DAOException;
	int updateAppTag(Long appId, String tag) throws DAOException;

	/*
	 * DAO��������
	 */
	List<AppDO> queryAppByBizType(String biz) throws DAOException;
	List<AppDO> queryAppByProduct(String biz) throws DAOException;

	void updateAoneCreateTimeByName(String appName,Date aoneCreateTime) throws DAOException;
}
