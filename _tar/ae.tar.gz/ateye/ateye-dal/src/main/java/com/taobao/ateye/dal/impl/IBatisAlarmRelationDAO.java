package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AlarmRelationDAO;
import com.taobao.ateye.dataobject.AlarmRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class IBatisAlarmRelationDAO extends BaseDAO implements AlarmRelationDAO {
    @Override
    public Long insert(AlarmRelationDO alarmRelationDO) throws DAOException {
        return (Long) insert("AlarmRelationDAO.insert",alarmRelationDO);
    }

    @Override
    public List<AlarmRelationDO> get(String type,String appName, String appNodeGroup,Date startDate,Date endDate) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("type",type);
        param.put("appNodeGroup",appNodeGroup);
        param.put("appName",appName);
        param.put("startDate",startDate);
        param.put("endDate",endDate);
        return queryForList("AlarmRelationDAO.get",param);
    }
}
