package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/10/8.
 *
 * ʵ����
 * {"change_summary":"Ӧ��link����production����",
 "change_key":"","change_result":"�����","change_type_id":"","name_excutor":"������[�Ⱥ�]","change_type_name":"PUBLISH",
 "product_name_list":"link","end_time":"2018-10-08 18:02:16","change_content":"",
 "url":"http://changefree.alibaba-inc.com:80/pages/order_detail_auto/index.html?orderId=55578611","is_emergency":0,
 "type_order":2,"start_time":"2018-10-08 18:02:16",
 "excutor":"132146","source_system_name":"normandy","id":55578611,"source_system_id":7}

 ��Ϣֻ���˴����ģ�û�з����µ�
 �ӿ����� http://rap.alibaba-inc.com/workspace/myWorkspace.do?projectId=414#1885
 */
public class ChangeFreeDO extends BaseDO {
    /**
     */
    private Long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * �������  change_summary
     */
    private String changeSummary;

    /**
     * change_key
     */
    private String changeKey;

    /**
     * change_result ������ ����� ����ɹ�
     */
    private String changeResult;

    /**
     *change_type_id
     */
    private String changeTypeId;

    /**
     * name_excutor ����������
     */
    private String nameExcutor;

    /**
     * ����˹���
     */
    private String empId;

    /**
     * change_type_name PUBLISH PUBLISH_PREPUB
     * ��ͬ ��Դ �Լ�����
     */
    private String changeTypeName;

    /**
     * �ƻ���ʼʱ��
     */
    private Date startTime;

    /**
     * �ƻ�����ʱ�� end_time
     */
    private Date endTime;

    /**
     * change_content
     */
    private String changeContent;

    /**
     * changefree�ı�������ַ
     */
    private String url;

    /**
     * is_emergency 1��������0���ǽ���
     */
    private int isEmergency;

    /**
     * type_order TODO ѡ�{0:"�ݸ�",1:"������",2:"����ɣ�����ͨ����",3:"����ɣ�����������",4:"��ȡ��",5:"����ɣ��ɹ���",6:"����ɣ�ʧ�ܣ�",7:"�����ύ��������ͨ����"}
     */
    private int typeOrder;

    /**
     * ��Դϵͳ source_system_name
     */
    private String sourceSystemName;

    /**
     * id
     */
    private long changefreeId;

    /**
     * ��Դϵͳid
     */
    private long sourceSystemId;

    /**
     * �����ֶ�
     */
    private String env;

    /**
     * ����Ӧ��
     */
    private String productNameList;

    /**
     * ��Ϣ����ʱ��
     */
    private Date msgCreateTime;

    private Integer taskStatus;

    public Date getMsgCreateTime() {
        return msgCreateTime;
    }

    public void setMsgCreateTime(Date msgCreateTime) {
        this.msgCreateTime = msgCreateTime;
    }

    public String getProductNameList() {
        return productNameList;
    }

    public void setProductNameList(String productNameList) {
        this.productNameList = productNameList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getChangeSummary() {
        return changeSummary;
    }

    public void setChangeSummary(String changeSummary) {
        this.changeSummary = changeSummary;
    }

    public String getChangeKey() {
        return changeKey;
    }

    public void setChangeKey(String changeKey) {
        this.changeKey = changeKey;
    }

    public String getChangeResult() {
        return changeResult;
    }

    public void setChangeResult(String changeResult) {
        this.changeResult = changeResult;
    }

    public String getChangeTypeId() {
        return changeTypeId;
    }

    public void setChangeTypeId(String changeTypeId) {
        this.changeTypeId = changeTypeId;
    }

    public String getNameExcutor() {
        return nameExcutor;
    }

    public void setNameExcutor(String nameExcutor) {
        this.nameExcutor = nameExcutor;
    }

    public String getChangeTypeName() {
        return changeTypeName;
    }

    public void setChangeTypeName(String changeTypeName) {
        this.changeTypeName = changeTypeName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getChangeContent() {
        return changeContent;
    }

    public void setChangeContent(String changeContent) {
        this.changeContent = changeContent;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getIsEmergency() {
        return isEmergency;
    }

    public void setIsEmergency(int isEmergency) {
        this.isEmergency = isEmergency;
    }

    public int getTypeOrder() {
        return typeOrder;
    }

    public void setTypeOrder(int typeOrder) {
        this.typeOrder = typeOrder;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public long getChangefreeId() {
        return changefreeId;
    }

    public void setChangefreeId(long changefreeId) {
        this.changefreeId = changefreeId;
    }

    public long getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(long sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

    public String getEmpId() {
        return empId;
    }

    public Long getEmpIdL() {
    	try{
			return Long.valueOf(empId);
    	}catch(Throwable t){
    		return 0l;
    	}
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public Integer getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(Integer taskStatus) {
        this.taskStatus = taskStatus;
    }
}
