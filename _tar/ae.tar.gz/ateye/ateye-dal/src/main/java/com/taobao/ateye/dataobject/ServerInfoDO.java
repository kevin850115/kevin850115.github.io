package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * mysql�е�et_server_info����Ӧ��DO����
 * 
 * @author gumo
 * 
 */
public class ServerInfoDO extends BaseDO {
    static public final int STATUS_OK = 0;
    static public final int STATUS_DELETE = 1;
    static public final int STATUS_STOP = 2;
    private static final long serialVersionUID = -190160423431591454L;
    /**
	 */
    private Integer id;
    /*
     * Ӧ��
     */
    private String app;
    /**
     * ���������ƣ���Ӧ��������е�host_name
     */
    private String name;
    /**
     * ������IP
     */
    private String ip;
    /**
     * �˿�
     */
    private String port;
    /**
     * ������������ж�Ӧ������host_id����
     */
    private String hubId;
    /**
     * �������Ľ�ɫ��
     */
    private String role;
    /**
     * ��������������Ϣ��
     */
    private String desc;
    /**
     * ��ע��
     */
    private String memo;
    private Integer status;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public void setHubId(String hubId) {
        this.hubId = hubId;
    }

    public String getHubId() {
        return hubId;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getPort() {
        return port;
    }

}
