package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AppExtendDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2018/9/17.
 */
public interface AppExtendDAO {
    /**
     * �������Ͳ�ѯӦ����չ��Ϣ
     * @param type
     * @return
     */
    List<AppExtendDO> getAppExtendByType(String type) throws DAOException;
    List<AppExtendDO> getAppExtends(Long appId) throws DAOException;
    AppExtendDO getAppExtendByType(Long appId,String type) throws DAOException;
    List<AppExtendDO> getAllAppExtends() throws DAOException;

    /**
     * ����app��չ��Ϣ
     * @param appExtendDAO
     * @return
     */
    Long insertAppExtend(AppExtendDO appExtendDO) throws DAOException;


    /**
     * ����typeɾ��app��չ��Ϣ
     * @param type
     */
    void deleteAppExtendByType(String type) throws DAOException;
    void deleteAppExtendByType(Long appId,String type) throws DAOException;
    void deleteAppExtend(Long appId,String type,String value) throws DAOException;
	void updateAppExtend(Long appId, String name, String level) throws DAOException;
}
