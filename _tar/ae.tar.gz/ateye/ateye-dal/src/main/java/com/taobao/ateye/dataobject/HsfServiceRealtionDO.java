package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class HsfServiceRealtionDO extends BaseDO{
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ��Դ��������
     */
    private String sUniqueServiceName;

    /**
     * ��Դ��������
     */
    private String sType;

    /**
     * ���η�������
     */
    private String cUniqueServiceName;

    /**
     * ���η�������
     */
    private String cType;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * ��Դ�������ڵ�Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getsUniqueServiceName() {
        return sUniqueServiceName;
    }

    public void setsUniqueServiceName(String sUniqueServiceName) {
        this.sUniqueServiceName = sUniqueServiceName;
    }

    public String getsType() {
        return sType;
    }

    public void setsType(String sType) {
        this.sType = sType;
    }

    public String getcUniqueServiceName() {
        return cUniqueServiceName;
    }

    public void setcUniqueServiceName(String cUniqueServiceName) {
        this.cUniqueServiceName = cUniqueServiceName;
    }

    public String getcType() {
        return cType;
    }

    public void setcType(String cType) {
        this.cType = cType;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
