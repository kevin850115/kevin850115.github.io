package com.taobao.ateye.dataobject;

import java.util.Date;

public class PermissionApplyDO extends BaseDO {
	public static int STATUS_REJECT=2;
	public static int STATUS_APPROVE=1;
	public static int STATUS_INIT=0;
	/**
	 * 
	 */
	private static final long serialVersionUID = 7430858398202316122L;
	/**
	 * ID, ����
	 */
	private int id;
	/**
	 * �û��ǳ�
	 */
	private String nick;
	/**
	 * �û�ְλ
	 */
	private String title;
	/**
	 * ����Ľ�ɫ�б�
	 */
	private String roleIds;
	/**
	 * �����Ӧ���б�
	 */
	private String appNames;
	/**
	 * ��������
	 */
	private String reason;
	/**
	 * ״̬��0:δ����;1:ͨ��;2:�ܾ�
	 */
	private int status;

	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the nick
	 */
	public String getNick() {
		return nick;
	}
	/**
	 * @param nick the nick to set
	 */
	public void setNick(String nick) {
		this.nick = nick;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the roleIds
	 */
	public String getRoleIds() {
		return roleIds;
	}
	/**
	 * @param roleIds the roleIds to set
	 */
	public void setRoleIds(String roleIds) {
		this.roleIds = roleIds;
	}
	/**
	 * @return the appNames
	 */
	public String getAppNames() {
		return appNames;
	}
	/**
	 * @param appNames the appNames to set
	 */
	public void setAppNames(String appNames) {
		this.appNames = appNames;
	}
	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}
	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * @return the createdTime
	 */
	public Date getCreatedTime() {
		return createdTime;
	}
	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	/**
	 * @return the modifiedTime
	 */
	public Date getModifiedTime() {
		return modifiedTime;
	}
	/**
	 * @param modifiedTime the modifiedTime to set
	 */
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	
}
