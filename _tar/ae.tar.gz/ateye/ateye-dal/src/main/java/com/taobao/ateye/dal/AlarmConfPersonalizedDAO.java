package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AlarmConfPersonalizedDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;

/**
 * Created by sunqiang on 2019/1/28.
 */
public interface AlarmConfPersonalizedDAO {

    List<AlarmConfPersonalizedDO> selectAll(String env) throws DAOException;

    Long insert(AlarmConfPersonalizedDO ruleDO) throws DAOException;

    void updateStatus(Long id, int status) throws DAOException;

    AlarmConfPersonalizedDO selectById(Long id) throws DAOException;

    void updateReopenDate(String confId, Date date) throws DAOException;

    List<AlarmConfPersonalizedDO> selectByUUID(String uuid) throws DAOException;

    List<AlarmConfPersonalizedDO> selectByExtendUUID(String uuid) throws DAOException;

    List<AlarmConfPersonalizedDO> selectByConfId(Long confId) throws DAOException;

    void deleteById(long id) throws DAOException;

    void update(AlarmConfPersonalizedDO personalizedDO) throws DAOException;
}
