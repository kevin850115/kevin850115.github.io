package com.taobao.ateye.dataobject;

import org.apache.commons.codec.digest.DigestUtils;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/5.
 */
public class SceneServiceRelation extends BaseDO{
    /**
     */
    private long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * �������id
     */
    private Long entryPointId;

    /**
     * �������id
     */
    private Long providerId;

    /**
     * �����������
     */
    private String providerType;

    /**
     * �����������
     */
    private String providerName;

    /**
     * ����������ڵ�appName
     */
    private String providerAppName;

    /**
     * ����������ڵķ�������
     */
    private String providerAppNodeGroup;

    /**
     * ��������
     */
    private String consumerType;

    /**
     * ��������
     */
    private String consumerName;

    private Date timeWindow;

    /**
     * ����  EnvironmentType
     */
    private String env;

    /**
     * ����ĵ���ջ
     */
    private String serviceStack;

    /**
     * ���������md5
     */
    private String ukMd5;

    public String buildMd5(){
        StringBuilder ukString = new StringBuilder();
        ukString.append(entryPointId)
                .append(consumerName)
                .append(consumerType)
                .append(timeWindow)
                .append(providerName)
                .append(providerType)
                .append(providerAppNodeGroup)
                .append(env)
                .append(serviceStack);
        return DigestUtils.md5Hex(ukString.toString());
    }

    public String getServiceStack() {
        return serviceStack;
    }

    public void setServiceStack(String serviceStack) {
        this.serviceStack = serviceStack;
    }

    public String getUkMd5() {
        return ukMd5;
    }

    public void setUkMd5(String ukMd5) {
        this.ukMd5 = ukMd5;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getEntryPointId() {
        return entryPointId;
    }

    public void setEntryPointId(Long entryPointId) {
        this.entryPointId = entryPointId;
    }

    public Long getProviderId() {
        return providerId;
    }

    public void setProviderId(Long providerId) {
        this.providerId = providerId;
    }

    public String getProviderType() {
        return providerType;
    }

    public void setProviderType(String providerType) {
        this.providerType = providerType;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderAppName() {
        return providerAppName;
    }

    public void setProviderAppName(String providerAppName) {
        this.providerAppName = providerAppName;
    }

    public String getProviderAppNodeGroup() {
        return providerAppNodeGroup;
    }

    public void setProviderAppNodeGroup(String providerAppNodeGroup) {
        this.providerAppNodeGroup = providerAppNodeGroup;
    }

    public String getConsumerType() {
        return consumerType;
    }

    public void setConsumerType(String consumerType) {
        this.consumerType = consumerType;
    }

    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String consumerName) {
        this.consumerName = consumerName;
    }

    public Date getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(Date timeWindow) {
        this.timeWindow = timeWindow;
    }
}
