package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.SimDO;
import com.taobao.ateye.exception.DAOException;

public interface SimDAO {

	Long addSim(SimDO simDO) throws DAOException;
	List<SimDO> queryListByDate(Date startTime, Date endTime) throws DAOException;
	List<SimDO> queryListByDate(Long sceneId, Date startTime, Date endTime) throws DAOException;
	SimDO getSimById(Long simId ) throws DAOException;
	void updateModified(int finishStep,long id) throws DAOException;

}
