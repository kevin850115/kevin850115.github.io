package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:ateye������hsf�����ѷ�
 * @author ˼��
 * Date 2019-05-05
 */
public class HsfConsumerDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * �����Ψһ��ʾ
     */
    private String uniqueServiceName;

    /**
     * �ӿ�
     */
    private String interfaceName;

    /**
     * �汾
     */
    private String version;

    /**
     * Ӧ������
     */
    private String appName;

    /**
     * Ӧ�÷���
     */
    private String appNodeGroup;

    /**
     * ��ʱ����
     */
    private Integer timeout;

    /**
     * 0-hsf��meta 1-������־
     */
    private Integer source;

    /**
     * �ýӿڷ�����Ԫ��Ϣ
     */
    private String methodInfos;

    /**
     * ����
     */
    private String env;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getUniqueServiceName() {
        return uniqueServiceName;
    }

    public void setUniqueServiceName(String uniqueServiceName) {
        this.uniqueServiceName = uniqueServiceName;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppNodeGroup() {
        return appNodeGroup;
    }

    public void setAppNodeGroup(String appNodeGroup) {
        this.appNodeGroup = appNodeGroup;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getMethodInfos() {
        return methodInfos;
    }

    public void setMethodInfos(String methodInfos) {
        this.methodInfos = methodInfos;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}