package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.AlarmLogDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/11/15.
 */
public interface AlarmLogDAO {
    Long saveAlarmLog(AlarmLogDO alarmLogDO) throws DAOException;

	List<AlarmLogDO> queryLogList(Date start, Date end) throws DAOException;
	/*
	 * ֻȡ�����ֶ�
	 */
	List<AlarmLogDO> querySimpleLogList(Date start, Date end) throws DAOException;

	List<AlarmLogDO> queryMonitorByRuleName(String appName, String ruleName, Date startTime) throws DAOException;

	List<Long> selectBeforeIdsByStartTime(Date startTime,int size) throws DAOException;

	void deleteByIds(List<Long> ids) throws DAOException;
}
