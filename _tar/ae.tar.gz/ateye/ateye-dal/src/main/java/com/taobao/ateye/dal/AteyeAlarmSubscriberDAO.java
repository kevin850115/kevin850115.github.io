package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;
import com.taobao.ateye.exception.DAOException;

import java.util.List;

/**
 * Created by sunqiang on 2018/12/6.
 */
public interface AteyeAlarmSubscriberDAO {
    List<AteyeAlarmSubscriberDO> selectAll() throws DAOException;

    Long insert(AteyeAlarmSubscriberDO ruleDO) throws DAOException;

    void updateStatus(Long id, int isDelete) throws DAOException;

    AteyeAlarmSubscriberDO getByUk(String name, String env, int isDelete) throws DAOException;

    AteyeAlarmSubscriberDO getById(Long subId) throws DAOException;

    int updateValue(Long id, String value) throws DAOException;
    
    int updateBiz(Long id, Long biz) throws DAOException;

    List<AteyeAlarmSubscriberDO> select(Integer biz, String name, Integer type) throws DAOException;

    List<AteyeAlarmSubscriberDO> selectByIds(List<Long> subIds) throws DAOException;

    AteyeAlarmSubscriberDO selectById(Long subId) throws DAOException;

    void updateName(long id,String newName) throws DAOException;
}
