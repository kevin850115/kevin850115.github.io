package com.taobao.ateye.dataobject;

import java.util.Date;

public class BaseFlowDO {
	public static String FLOW_SYNC_Y="sync";
	public static String FLOW_SYNC_N="async";
	public static String FLOW_TYPE_TOTALHSF="TotalHsf";
	/**
	 * ����
	 */
	private long id;

	/**
	 * ����ʱ��
	 */
	private Date gmtCreate;

	/**
	 * �޸�ʱ��
	 */
	private Date gmtModified;

	/**
	 * ����
	 */
	private String env;

	private String timeWindow;

	/**
	 * ��������
	 */
	private String flowType;

	/**
	 * ͬ��/�첽
	 */
	private String flowSync;

	/**
	 * ����ֵ
	 */
	private long flow;
	
	private long flowWeight;//����Ȩ��

	/**
	 * setter for column ����
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * getter for column ����
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * setter for column ����ʱ��
	 */
	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	/**
	 * getter for column ����ʱ��
	 */
	public Date getGmtCreate() {
		return this.gmtCreate;
	}

	/**
	 * setter for column �޸�ʱ��
	 */
	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	/**
	 * getter for column �޸�ʱ��
	 */
	public Date getGmtModified() {
		return this.gmtModified;
	}

	/**
	 * setter for column ����
	 */
	public void setEnv(String env) {
		this.env = env;
	}

	/**
	 * getter for column ����
	 */
	public String getEnv() {
		return this.env;
	}

	

	/**
	 * setter for column ��������
	 */
	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}

	/**
	 * getter for column ��������
	 */
	public String getFlowType() {
		return this.flowType;
	}

	/**
	 * setter for column ͬ��/�첽
	 */
	public void setFlowSync(String flowSync) {
		this.flowSync = flowSync;
	}

	/**
	 * getter for column ͬ��/�첽
	 */
	public String getFlowSync() {
		return this.flowSync;
	}

	/**
	 * setter for column ����ֵ
	 */
	public void setFlow(long flow) {
		this.flow = flow;
	}

	/**
	 * getter for column ����ֵ
	 */
	public long getFlow() {
		return this.flow;
	}

	public String getTimeWindow() {
		return timeWindow;
	}

	public void setTimeWindow(String timeWindow) {
		this.timeWindow = timeWindow;
	}

	public long getFlowWeight() {
		return flowWeight;
	}

	public void setFlowWeight(long flowWeight) {
		this.flowWeight = flowWeight;
	}

}
