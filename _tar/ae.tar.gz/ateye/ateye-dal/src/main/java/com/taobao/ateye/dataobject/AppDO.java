package com.taobao.ateye.dataobject;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.taobao.ateye.changelog.AppChangeLogConstants;

public class AppDO extends BaseDO {
    
    public static final String TAG_NAME_APP_TYPE = "type";
    public static final String TAG_NAME_PUBLISH_STATUS = "publishStatus";
    public static final String TAG_NAME_DELETE_STATUS = "deleteStatus";
    public static final String TAG_NAME_ONLINE_TIME = "onlineTime";
    public static final String TAG_NAME_APP_IMPORTANCE = "importance";
    public static final String TAG_NAME_AONE_APP_ID = "aoneAppId";
    
    public static final int APP_STATUS_WILL_ONLINE = 0;
    public static final int APP_STATUS_STABLE = 1;
    public static final int APP_STATUS_WILL_OFFLINE = 2;
    public static final int APP_STATUS_DELETED = 3;
    public static final int APP_STATUS_NEW_ONLINE = 4;
    
    public static final long NEW_ONLINE_CONTINUE_TIME = 30 * 24 * 60 * 60 * 1000L;
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1255459063308371990L;
	/**
	 * ID, ����
	 */
	private Long id;
	/**
	 * Ӧ�õ�����
	 */
	private String appName;
	
	/**
	 * Ӧ��������
	 */
	private String appAlias;
	
	/**
	 * Ӧ�ù���Ա�������Ӣ�Ķ��š�,���ֿ�
	 */
	private String administrators;
	/**
	 * Ӧ��Context Root
	 */
	private String contextRoot;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	
	private Integer bizType=-1;
	private Integer subBizType;
	/**
	 * 2017.11.20.��ҵ���ߴ�aoneͬ��
	 */
	@Deprecated
	private String productName;
	private String bu;
	private String desc;
	/**
	 * Ӧ�ñ�ǩjson
	 */
	private String appTag;

	private String dingDingTokens;

	/**
	 * aone�Ĵ���ʱ��
	 */
	private Date aoneCreateTime;
	public void setAppTag(String appTag) {
	    this.appTag = appTag;
	}
	
	public String getAppTag() {
	    return appTag;
	}
	
	public int getAppStatus() {
        String deleteStatus = this.getDeleteStatus();
        String publishStatus = this.getPublishStatus();
        if (AppChangeLogConstants.DELETE_STATUS_DELETED.equals(deleteStatus)) {
            return APP_STATUS_DELETED;
        }
        if (AppChangeLogConstants.DELETE_STATUS_WILLDELETE.equals(deleteStatus)) {
            return APP_STATUS_WILL_OFFLINE;
        }
        if (AppChangeLogConstants.DELETE_STATUS_UNDELETED.equals(deleteStatus)
                && AppChangeLogConstants.PUBLISH_STATUS_OFFLINE.equals(publishStatus)) {
            return APP_STATUS_WILL_ONLINE;
        }
        Date onlineTime = this.getOnlineTime();
        if (onlineTime != null) {
            Date now = new Date();
            long diff = now.getTime() - onlineTime.getTime();
            if (diff <= NEW_ONLINE_CONTINUE_TIME) {
                return APP_STATUS_NEW_ONLINE;
            }
        }
        return APP_STATUS_STABLE;
    }
	
	public void setTagValue(String tagName, String value) {
	    JSONObject json = null;
	    if (StringUtils.isEmpty(appTag)) {
	        json = new JSONObject();
	    } else {
	        json = JSONObject.parseObject(appTag);
	    }
	    json.put(tagName, value);
	    this.appTag = json.toJSONString();
	}
	
	public String getTagValue(String tagName) {
	    if (StringUtils.isEmpty(appTag)) {
            return null;
        } else {
            JSONObject json = JSONObject.parseObject(appTag);
            return json.getString(tagName);
        }
	}
	
	public void setAoneAppId(int value) {
	    setTagValue(TAG_NAME_AONE_APP_ID, String.valueOf(value));
	}
	
	public int getAoneAppId() {
	    String value = getTagValue(TAG_NAME_AONE_APP_ID);
        if (value != null) {
            return Integer.parseInt(value);
        } else {
            return -1;
        }
	}
	
	public void setImportance(int value) {
	    setTagValue(TAG_NAME_APP_IMPORTANCE, String.valueOf(value));
	}
	
	public int getImportance() {
	    String value = getTagValue(TAG_NAME_APP_IMPORTANCE);
	    if (value != null) {
	        return Integer.parseInt(value);
	    } else {
	        return -1;
	    }
	}
	
	public void setOnlineTime(Date value) {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    setTagValue(TAG_NAME_ONLINE_TIME, sdf.format(value));
	}
	
	public Date getOnlineTime() {
	    try {
    	    String value = getTagValue(TAG_NAME_ONLINE_TIME);
    	    if (value == null) {
    	        return null;
    	    }
    	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    	    return sdf.parse(value);
	    } catch (Exception e) {
	        return null;
	    }
	}
	
	public void setAppType(String value) {
	    setTagValue(TAG_NAME_APP_TYPE, value);
	}
	
	public void setPublishStatus(String value) {
        setTagValue(TAG_NAME_PUBLISH_STATUS, value);
    }
	
	public void setDeleteStatus(String value) {
        setTagValue(TAG_NAME_DELETE_STATUS, value);
    }
	
	public String getAppType() {
	    return getTagValue(TAG_NAME_APP_TYPE);
	}
	
	public String getPublishStatus() {
	    return getTagValue(TAG_NAME_PUBLISH_STATUS);
    }
	
	public String getDeleteStatus() {
	    return getTagValue(TAG_NAME_DELETE_STATUS);
    }
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAdministrators() {
		return administrators;
	}
	public void setAdministrators(String administrators) {
		this.administrators = administrators;
	}
	public String getContextRoot() {
		if(StringUtils.isNotBlank(contextRoot)) {
			return contextRoot;
		} else {
			return "";
		}
	}
	public void setContextRoot(String contextRoot) {
		this.contextRoot = contextRoot;
	}
	/**
	 * @return the bizType
	 */
	public Integer getBizType() {
		return bizType;
	}
	/**
	 * @param bizType the bizType to set
	 */
	public void setBizType(Integer bizType) {
		this.bizType = bizType;
	}
	/**
	 * @return the subBizType
	 */
	public Integer getSubBizType() {
		return subBizType;
	}
	/**
	 * @param subBizType the subBizType to set
	 */
	public void setSubBizType(Integer subBizType) {
		this.subBizType = subBizType;
	}
	
	public String getAppAlias() {
		return appAlias;
	}
	public void setAppAlias(String appAlias) {
		this.appAlias = appAlias;
	}

	public String getDingDingTokens() {
		return dingDingTokens;
	}

	public void setDingDingTokens(String dingDingTokens) {
		this.dingDingTokens = dingDingTokens;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Date getAoneCreateTime() {
		return aoneCreateTime;
	}

	public void setAoneCreateTime(Date aoneCreateTime) {
		this.aoneCreateTime = aoneCreateTime;
	}
}
