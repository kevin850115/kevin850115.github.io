package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.AppChangeLogDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.query.AppChangeLogQuery;

public interface AppChangeLogDAO {
	
	public List<AppChangeLogDO> query(AppChangeLogQuery query) throws DAOException;

	public Long insert(AppChangeLogDO log) throws DAOException;

	public AppChangeLogDO queryByOperationId(String operationId) throws DAOException;
	
	public AppChangeLogDO getById(Long id) throws DAOException;

	public void updateServers(AppChangeLogDO map) throws DAOException;
	
	int deleteChangeLog(Date day) throws DAOException;
	
	int deleteOldLogChangeLog(Date day) throws DAOException;
}
