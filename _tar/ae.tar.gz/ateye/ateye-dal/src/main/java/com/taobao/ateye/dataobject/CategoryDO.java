package com.taobao.ateye.dataobject;

import java.util.List;
/****
 * �������DO
 * @author jianbo.hc
 *
 */
public class CategoryDO extends BaseDO{

	private static final long serialVersionUID = 7693889706521504374L;
	public static final int HBaseDataType=3;
	public static final int KeyValueType=2;
	public static final int GroupByType=1;
	public static final int DefaultType=0;
	private Integer id;
	private String name;
	private String summary;
	private Integer  reportId;
	private List<DataDO> dataList;
	private Integer type;
	private int dataSize;//����Group By����ʱ�洢�������dataDO�ĸ���
	//HBaseͳ�����ݣ���־app
	private String app;
	//HBaseͳ�����ݣ���־Ԫ���ݶ���
	private Long metadataId;
	//HBaseͳ�����ݣ���־�ۺ�ָ��
	private String mergeColumn;
	//HBaseͳ�����ݣ���־ͳ��ָ��
	private String statColumn;
	/*
	 * HBaseͳ�����ݣ���ָ��Ĵ�����ʽ
	 * 0-��ͣ�1-��ƽ��
	 */
	private Integer dataType;
	
	public int getDataSize() {
		return dataSize;
	}
	public void setDataSize(int dataSize) {
		this.dataSize = dataSize;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public Integer getReportId() {
		return reportId;
	}
	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	public List<DataDO> getDataList() {
		return dataList;
	}
	public void setDataList(List<DataDO> dataList) {
		this.dataList = dataList;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	/**
	 * @return the app
	 */
	public String getApp() {
		return app;
	}
	/**
	 * @param app the app to set
	 */
	public void setApp(String app) {
		this.app = app;
	}
	/**
	 * @return the metadataId
	 */
	public Long getMetadataId() {
		return metadataId;
	}
	/**
	 * @param metadataId the metadataId to set
	 */
	public void setMetadataId(Long metadataId) {
		this.metadataId = metadataId;
	}
	/**
	 * @return the mergeColumn
	 */
	public String getMergeColumn() {
		return mergeColumn;
	}
	/**
	 * @param mergeColumn the mergeColumn to set
	 */
	public void setMergeColumn(String mergeColumn) {
		this.mergeColumn = mergeColumn;
	}
	/**
	 * @return the statColumn
	 */
	public String getStatColumn() {
		return statColumn;
	}
	/**
	 * @param statColumn the statColumn to set
	 */
	public void setStatColumn(String statColumn) {
		this.statColumn = statColumn;
	}
	/**
	 * @return the dataType
	 */
	public Integer getDataType() {
		return dataType;
	}
	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(Integer dataType) {
		this.dataType = dataType;
	}


}
