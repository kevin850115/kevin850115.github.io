package com.taobao.ateye.dataobject;

import java.util.List;

/**
 * spring security�еĽ�ɫ����Ӧ�����ݶ���
 * @author gumo
 *
 */
public class RoleDO extends BaseDO {

	private static final long serialVersionUID = -7572664802150618772L;
	
	/**
	 * �ÿ͵Ľ�ɫ����
	 */
	 public static String ROLE_GUEST_NAME = "ROLE_GUEST";
	 
	/**
	 * ID
	 */
	private Long id;
	/**
	 * ����
	 */
	private String name;
	/**
	 * ��ɫȨ�޵�����
	 */
	private String description;
	/**
	 * 
	 */
	private int sort;
	/**
	 * ��ɫ��Ӧ��Ȩ����Դ�б�
	 */
	private List<ResourceDO> resourceList;
	/**
	 * 
	 */
	private List<UserDO> userList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getSort() {
		return sort;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public List<ResourceDO> getResourceList() {
		return resourceList;
	}

	public void setResourceList(List<ResourceDO> resourceList) {
		this.resourceList = resourceList;
	}

	public List<UserDO> getUserList() {
		return userList;
	}

	public void setUserList(List<UserDO> userList) {
		this.userList = userList;
	}
	
}
