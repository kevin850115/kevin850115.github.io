package com.taobao.ateye.dataobject;

import java.util.Date;

public class MethodTemplateValueDO extends BaseDO 
{
	private static final long serialVersionUID = 9220105624630890971L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * ģ��id
	 */
	private Long templateId;
	/**
	 * ����id
	 */
	private Long methodId;
	/**
	 * ��������ֵ,���ŷָ�
	 */
	private String methodParamValue = "";
	/**
	 * Java���ַ�������indexֵ�����ŷָ�
	 */
	private String emptyStringIndex = "-1";
	/**
	 * null����indexֵ�����ŷָ�
	 */
	private String nullValueIndex = "-1";
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}
	public Long getMethodId() {
		return methodId;
	}
	public void setMethodId(Long methodId) {
		this.methodId = methodId;
	}
	public String getMethodParamValue() {
		return methodParamValue;
	}
	public void setMethodParamValue(String methodParamValue) {
		this.methodParamValue = methodParamValue;
	}
	public String getEmptyStringIndex() {
		return emptyStringIndex;
	}
	public void setEmptyStringIndex(String emptyStringIndex) {
		this.emptyStringIndex = emptyStringIndex;
	}
	public String getNullValueIndex() {
		return nullValueIndex;
	}
	public void setNullValueIndex(String nullValueIndex) {
		this.nullValueIndex = nullValueIndex;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public String[] getParamValueArray(){
		if(methodParamValue!=null){
			return methodParamValue.split(",");
		}
		return null;
	}
	public String[] getNullValueIndexArray(){
		if(nullValueIndex!=null){
			return nullValueIndex.split(",");
		}
		return null;
	}
}
