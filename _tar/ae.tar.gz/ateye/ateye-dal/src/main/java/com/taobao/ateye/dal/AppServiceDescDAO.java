package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.AppServiceDescDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Ӧ�÷�������DAO
 * 
 * @author saite.wd
 * @version $Id: AppServiceDescDAO.java, v 0.1 2016��2��16�� ����3:49:07 saite Exp $
 */
public interface AppServiceDescDAO {
    
    List<AppServiceDescDO> queryByApp(String app) throws DAOException;
    
    List<AppServiceDescDO> queryByService(String app, String service) throws DAOException;
    
    AppServiceDescDO queryByUniqueKey(String app, String service, String method) throws DAOException;
    
    int saveOrUpdate(AppServiceDescDO object) throws DAOException;
    
}
