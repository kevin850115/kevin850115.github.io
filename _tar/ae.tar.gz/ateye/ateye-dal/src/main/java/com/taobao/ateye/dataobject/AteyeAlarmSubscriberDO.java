package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:����������
 * @author ˼��
 * Date 2018-12-06
 */
public class AteyeAlarmSubscriberDO extends BaseDO{

    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ҵ����
     */
    private Integer biz = -1;

    /**
     * ������
     */
    private String operator;

    /**
     * ����,����,�绰
     */
    private Integer type;

    /**
     * ������token
     */
    private String value;

    /**
     * 0-��Ч 1-ɾ��
     */
    private int isDelete;

    /**
     * ����
     */
    private String env;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBiz() {
        return biz;
    }

    public void setBiz(Integer biz) {
        this.biz = biz;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * setter for column ����
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * getter for column ����
     */
    public long getId() {
        return this.id;
    }

    /**
     * setter for column ����ʱ��
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * getter for column ����ʱ��
     */
    public Date getGmtCreate() {
        return this.gmtCreate;
    }

    /**
     * setter for column �޸�ʱ��
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * getter for column �޸�ʱ��
     */
    public Date getGmtModified() {
        return this.gmtModified;
    }

    /**
     * setter for column ������token
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * getter for column ������token
     */
    public String getValue() {
        return this.value;
    }

    /**
     * setter for column ����
     */
    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * getter for column ����
     */
    public String getEnv() {
        return this.env;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }
}