package com.taobao.ateye.dal;

import java.util.List;

import com.taobao.ateye.dataobject.ProfileDO;
import com.taobao.ateye.exception.DAOException;

public interface ProfileDAO {
	/**
	 * �洢һ��ProfileDO��¼
	 * @param profile
	 * @return
	 * @throws DAOException
	 */
	public Long saveProfileDO(ProfileDO profile) throws DAOException;
	
	/**
	 * ��ѯĳһ���ȫ��ProfileDO��¼
	 * @param day
	 * @return
	 * @throws DAOException
	 */
	public List<ProfileDO> getAllProfileOfOneDay(String day) throws DAOException;
	
	/**
	 * ��ѯĳһӦ�õ�ȫ��ProfileDO��¼
	 * @param appName
	 * @return
	 * @throws DAOException
	 */
	public List<ProfileDO> getAllProfileOfAnApp(String appName) throws DAOException;
}
