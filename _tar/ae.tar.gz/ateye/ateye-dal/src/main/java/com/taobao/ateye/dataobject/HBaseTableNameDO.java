package com.taobao.ateye.dataobject;

import java.util.Date;

public class HBaseTableNameDO extends BaseDO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3437044338243698603L;
	/**
	 * ���ݿ�id
	 */
	private Long id;
	/**
	 * HBase����������TrackerOpLog201304
	 */
	private String tableName;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
}
