package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Description:goc��Ӧ������������Ϣ
 * @author ˼��
 * Date 2019-05-06
 */
public class GocEmgAlarmDetailDO {

    /**
     * ����
     */
    private Long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * nodeid
     */
    private Long nodeId;

    /**
     * ����·��=name-name-name
     */
    private String namepath;

    /**
     * �쳣����
     */
    private String description;

    /**
     * �����ֶ�
     */
    private String node;

    /**
     * ����ref����,apm�İ�ǰʹ��ʱ���md5�㷨���ɣ��Ժ�ʹ��uuid����Ϊref������
     */
    private String ref;

    /**
     * �Զ���ȼ�����
     */
    private String faultlevel;

    /**
     * ��Ӧ����
     */
    private String responseLevel;

    /**
     * 0:ȫ�Զ� 1 ���Զ� 2 �ֶ�
     */
    private Integer responseMode;

    /**
     * ���϶��������
     */
    private String idxFaultLevels;

    /**
     * ������
     */
    private String idxConfigInfos;

    /**
     * �����߹���
     */
    private Integer idxOnlineRule;

    /**
     * �вݸ����
     */
    private Integer idxDraftRule;

    /**
     * ����ģ��id
     */
    private Long idxTemplateId;

    /**
     * ���϶�������
     */
    private Long idxFaultRuleType;

    /**
     * Ӧ���������� :1:Ӧ������;2:����Ԥ��
     */
    private Integer type;

    /**
     * ������id�����ϵͳ���ݲ�Ψһ
     */
    private String alarmId;

    /**
     * ����������
     */
    private String alarmName;

    /**
     * ����Ψһ��ʶ����ϵͳ�ڲ�Ψһ
     */
    private String monitorUid;

    /**
     * ����Դurl
     */
    private String url;

    /**
     * �ص�url
     */
    private String callback;
    public String getNamepathAbbr() {
    	if ( namepath == null ) {
    		return "";
    	}
    	return namepath.replace("����/����/", "");
    }
    /*
     * ���URL
     */
    public String getMonitorUrl() {
    	if ( url == null ) {
			return "";
    	}
    	if ( url.contains("sunfire.alibaba-inc.com")
    		|| url.contains("x.alibaba-inc.com")	) {
    		return url.replace("update", "preview");
    	}
    	return url;
    }
    /*
     * ����޸�URl
     */
    public String getEditUrl() {
    	if ( url == null ) {
			return "";
    	}
    	if ( url.contains("sunfire.alibaba-inc.com")
    		|| url.contains("x.alibaba-inc.com")	) {
    		return url.replace("preview", "update");
    	}
    	return url;
    }

    /**
     * ��Դϵͳ
     */
    private String system;

    /**
     * �����˹���
     */
    private String operatorEmpId;

    /**
     * �������ǳ�
     */
    private String operatorName;

    /**
     * ���״̬
     */
    private String status;

    /**
     * �Ƿ�ĥ���� 0-��1-��
     */
    private Integer isRunningIn;

    /**
     * �Ƿ��϶�����0-��1-��
     */
    private Integer isAccess;

    /**
     * ��˽������
     */
    private String result;

    /**
     * ��˲���ʱ��
     */
    private Date auditTime;

    /**
     * �����owner
     */
    private String owner;

    /**
     * ����ʱ���
     */
    private Date createTime;

    /**
     * scene_id
     */
    private Long sceneId;

    /**
     * datasource_name
     */
    private String datasourceName;

    /**
     * uuid
     */
    private String uuid;

    /**
     * �Ƿ���Ҫ����
     */
    private String baseline;

    /**
     * �Ƿ񱨾�
     */
    private String alert;

    /**
     * �Ƿ���Ҫ�쳣���
     */
    private String detection;

    /**
     * �Ƿ���Ч 1:��:0��
     */
    private Integer isValid;

    /**
     * alarm_nameʵ������(���ڻ��߼����alarm_name��׼ʱ)
     */
    private String alarmNameReal;

    /**
     * ��ע
     */
    private String note;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getNodeId() {
        return nodeId;
    }

    public void setNodeId(Long nodeId) {
        this.nodeId = nodeId;
    }

    public String getNamepath() {
        return namepath;
    }

    public void setNamepath(String namepath) {
        this.namepath = namepath;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getFaultlevel() {
        return faultlevel;
    }

    public void setFaultlevel(String faultlevel) {
        this.faultlevel = faultlevel;
    }

    public String getResponseLevel() {
        return responseLevel;
    }

    public void setResponseLevel(String responseLevel) {
        this.responseLevel = responseLevel;
    }

    public Integer getResponseMode() {
        return responseMode;
    }

    public void setResponseMode(Integer responseMode) {
        this.responseMode = responseMode;
    }

    public String getIdxFaultLevels() {
        return idxFaultLevels;
    }

    public void setIdxFaultLevels(String idxFaultLevels) {
        this.idxFaultLevels = idxFaultLevels;
    }

    public String getIdxConfigInfos() {
        return idxConfigInfos;
    }

    public void setIdxConfigInfos(String idxConfigInfos) {
        this.idxConfigInfos = idxConfigInfos;
    }

    public Integer getIdxOnlineRule() {
        return idxOnlineRule;
    }

    public void setIdxOnlineRule(Integer idxOnlineRule) {
        this.idxOnlineRule = idxOnlineRule;
    }

    public Integer getIdxDraftRule() {
        return idxDraftRule;
    }

    public void setIdxDraftRule(Integer idxDraftRule) {
        this.idxDraftRule = idxDraftRule;
    }

    public Long getIdxTemplateId() {
        return idxTemplateId;
    }

    public void setIdxTemplateId(Long idxTemplateId) {
        this.idxTemplateId = idxTemplateId;
    }

    public Long getIdxFaultRuleType() {
        return idxFaultRuleType;
    }

    public void setIdxFaultRuleType(Long idxFaultRuleType) {
        this.idxFaultRuleType = idxFaultRuleType;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(String alarmId) {
        this.alarmId = alarmId;
    }

    public String getAlarmName() {
        return alarmName;
    }

    public void setAlarmName(String alarmName) {
        this.alarmName = alarmName;
    }

    public String getMonitorUid() {
        return monitorUid;
    }

    public void setMonitorUid(String monitorUid) {
        this.monitorUid = monitorUid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCallback() {
        return callback;
    }

    public void setCallback(String callback) {
        this.callback = callback;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getOperatorEmpId() {
        return operatorEmpId;
    }

    public void setOperatorEmpId(String operatorEmpId) {
        this.operatorEmpId = operatorEmpId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getIsRunningIn() {
        return isRunningIn;
    }

    public void setIsRunningIn(Integer isRunningIn) {
        this.isRunningIn = isRunningIn;
    }

    public Integer getIsAccess() {
        return isAccess;
    }

    public void setIsAccess(Integer isAccess) {
        this.isAccess = isAccess;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getSceneId() {
        return sceneId;
    }

    public void setSceneId(Long sceneId) {
        this.sceneId = sceneId;
    }

    public String getDatasourceName() {
        return datasourceName;
    }

    public void setDatasourceName(String datasourceName) {
        this.datasourceName = datasourceName;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getBaseline() {
        return baseline;
    }

    public void setBaseline(String baseline) {
        this.baseline = baseline;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public String getDetection() {
        return detection;
    }

    public void setDetection(String detection) {
        this.detection = detection;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public String getAlarmNameReal() {
        return alarmNameReal;
    }

    public void setAlarmNameReal(String alarmNameReal) {
        this.alarmNameReal = alarmNameReal;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}