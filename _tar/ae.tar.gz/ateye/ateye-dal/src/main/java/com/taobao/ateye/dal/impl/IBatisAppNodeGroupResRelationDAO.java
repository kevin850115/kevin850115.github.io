package com.taobao.ateye.dal.impl;

import com.google.common.collect.Maps;
import com.taobao.ateye.dal.AppNodeGroupResRelationDAO;
import com.taobao.ateye.dataobject.AppNodeGroupResRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.Map;

/**
 * Created by sunqiang on 2019/5/14.
 */
public class IBatisAppNodeGroupResRelationDAO extends BaseDAO implements AppNodeGroupResRelationDAO {
    @Override
    public Long insert(AppNodeGroupResRelationDO appNodeGroupResRelationDO) throws DAOException {
        return (Long) insert("AppNodeGroupResRelationDAO.insert",appNodeGroupResRelationDO);
    }

    @Override
    public AppNodeGroupResRelationDO getByUk(
            String appNodeGroup, String type,
            String uniqueServiceName, Date timeWindow, String env) throws DAOException {
        Map<String,Object> param = Maps.newHashMap();
        param.put("appNodeGroup",appNodeGroup);
        param.put("type",type);
        param.put("uniqueServiceName",uniqueServiceName);
        param.put("timeWindow",timeWindow);
        param.put("env",env);
        return (AppNodeGroupResRelationDO) queryForObject("AppNodeGroupResRelationDAO.getByUk",param);
    }
}
