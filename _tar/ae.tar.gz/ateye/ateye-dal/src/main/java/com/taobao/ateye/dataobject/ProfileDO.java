package com.taobao.ateye.dataobject;

import java.util.Date;

public class ProfileDO extends BaseDO{
	/**
	 * 
	 */
	private static final long serialVersionUID = -57872348578741457L;
	/**
	 * ����id
	 */
	private Long id;
	/**
	 * Ӧ������
	 */
	private String appName;
	/**
	 * �����������
	 */
	private int machineNum;
	/**
	 * ���õĿ�������
	 */
	private int switchNum;
	/**
	 * ���õķ�������
	 */
	private int methodNum;
	/**
	 * ���õ�Scheduler����
	 */
	private int schedulerNum;
	/**
	 * ���õ�Trigger����
	 */
	private int triggerNum;
	/**
	 * ����ʱ��
	 */
	private Date createdTime;
	/**
	 * �޸�ʱ��
	 */
	private Date modifiedTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public int getMachineNum() {
		return machineNum;
	}
	public void setMachineNum(int machineNum) {
		this.machineNum = machineNum;
	}
	public int getSwitchNum() {
		return switchNum;
	}
	public void setSwitchNum(int switchNum) {
		this.switchNum = switchNum;
	}
	public int getMethodNum() {
		return methodNum;
	}
	public void setMethodNum(int methodNum) {
		this.methodNum = methodNum;
	}
	public int getSchedulerNum() {
		return schedulerNum;
	}
	public void setSchedulerNum(int schedulerNum) {
		this.schedulerNum = schedulerNum;
	}
	public int getTriggerNum() {
		return triggerNum;
	}
	public void setTriggerNum(int triggerNum) {
		this.triggerNum = triggerNum;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
}
