package com.taobao.ateye.dal;

import com.taobao.ateye.dataobject.AlarmRelationDO;
import com.taobao.ateye.exception.DAOException;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Created by sunqiang on 2019/5/14.
 */
public interface AlarmRelationDAO {
    Long insert(AlarmRelationDO alarmRelationDO) throws DAOException;
    List<AlarmRelationDO> get(String type, String appName,String appNodeGroup, Date startDate, Date endDate) throws DAOException;
}
