package com.taobao.ateye.dataobject;

import java.util.Date;

/**
 * Created by sunqiang on 2018/9/5.
 */
public class SceneEntryPoint extends BaseDO{
    /**
     */
    private long id;
    /**
     * ��¼����ʱ�䡣
     */
    private Date gmtCreate;
    /**
     * ��¼������޸�ʱ�䡣
     */
    private Date gmtModified;

    /**
     * ����id
     */
    private Long sceneId;
    private Long catId;//����ID
    private Long levelId;

    /**
     * �������
     */
    private String type;

    /**
     * �������
     */
    private String name;

    /**
     * ����
     */
    private String description;

    /**
     * ����  EnvironmentType
     */
    private String env;

    private String appName;
	private Double scoreInSort=0.0;//�����ķ���

    /**
     * �������
     */
    private String typeDesc;

    /**
     * ���øó�����ڵĿͻ���Ӧ��,��Ҫ��������hsf_s
     */
    private String clientAppName;

    /**
     * ������չ��Ϣ
     */
    private  SceneExtendModel sceneExtendModel;

    public String getClientAppName() {
        return clientAppName;
    }

    public void setClientAppName(String clientAppName) {
        this.clientAppName = clientAppName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getSceneId() {
        return sceneId;
    }

    public void setSceneId(Long sceneId) {
        this.sceneId = sceneId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

	public Long getCatId() {
		return catId;
	}

	public void setCatId(Long catId) {
		this.catId = catId;
	}

	public Long getLevelId() {
		return levelId;
	}

	public void setLevelId(Long levelId) {
		this.levelId = levelId;
	}

	public Double getScoreInSort() {
		return scoreInSort;
	}

	public void setScoreInSort(Double scoreInSort) {
		this.scoreInSort = scoreInSort;
	}

    public String getTypeDesc() {
        return typeDesc;
    }

    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }



    public SceneExtendModel getSceneExtendModel() {
        return sceneExtendModel;
    }

    public void setSceneExtendModel(SceneExtendModel sceneExtendModel) {
        this.sceneExtendModel = sceneExtendModel;
    }
}
