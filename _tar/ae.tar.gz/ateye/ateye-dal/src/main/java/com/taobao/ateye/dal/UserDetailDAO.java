package com.taobao.ateye.dal;

import java.util.Map;

import com.taobao.ateye.dataobject.UserProfileDO;
import com.taobao.ateye.exception.DAOException;

public interface UserDetailDAO {

	void updateEmail(String nick,String email) throws DAOException;
	void updatePhone(String nick,String phone) throws DAOException;
	
	UserProfileDO getByNick(String nick)throws DAOException;
	
	Map<String,UserProfileDO> getAllMap() throws DAOException;
	
	Map<String,UserProfileDO> getPhoneMap() throws DAOException;

	void updateStatus(String nick, String st) throws DAOException;
}
