package com.taobao.ateye.dal;

import java.util.Date;
import java.util.List;

import com.taobao.ateye.dataobject.RealTimeTrackerLogDO;
import com.taobao.ateye.exception.DAOException;

/**
 * Created by sunqiang on 2018/10/31.
 */
public interface RealTimeTrackerLogDAO {
    void insertRealTimeTrackerLog(RealTimeTrackerLogDO realTimeTrackerLog) throws DAOException;
    List<RealTimeTrackerLogDO> queryValidRealTimeTrackerLog(String appName,String env) throws DAOException;
    List<RealTimeTrackerLogDO> queryAllByDate(Date startTime,Date endTime, String env) throws DAOException;

    List<RealTimeTrackerLogDO> queryValidRandomRealTimeTrackerLog(String appName,String env) throws DAOException;
}
