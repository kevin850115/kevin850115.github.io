package com.taobao.ateye.controller.scene;

import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.relation.model.RNodeExtInfo;
import com.taobao.ateye.scene.index.data.SceneSugData;
import com.taobao.ateye.scene.index.search.SceneKWManager;
import com.taobao.ateye.util.DescUtils;
@Controller
@RequestMapping("/scene")
public class SceneSugController extends AbstractController{
	
	@Autowired
	private SceneKWManager kvManager;

	@RequestMapping("sug.htm")
	public String biz(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
        List<Map<String,String>> ret = new ArrayList<Map<String,String>>();
		String key = request.getParameter("key");
		if ( !StringUtils.isBlank(key) ){
			key = URLDecoder.decode(key,"UTF-8");
		}
		try{
			List<SceneSugData> datas = kvManager.search(key, 20);
			for (SceneSugData data:datas ){
				ret.add(buildMap(data));
			}
		}catch(Throwable t){
		}
		PrintWriter out = response.getWriter();
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(json);
		return null;
	}
	private Map<String,String> buildMap(SceneSugData data){
        Map<String,String> ret = new HashMap<String,String>();
        ret.put("id", String.valueOf(data.getId()));
        ret.put("data",buildData(data));
        ret.put("description",buildDesc(data));
        return ret;
	}
	private String buildDesc(SceneSugData data){
		String description = data.getDescription();
		if ( StringUtils.isNotBlank(description) ){
			return description;
		}
		return "[��]";
	}
	private String buildData(SceneSugData data) {
		StringBuilder sb = new StringBuilder();
		sb.append("<font class='green fb'>").append(data.getType()).append("</font>:");
		sb.append(DescUtils.descEntryPoint5(data.getName()));
		RNodeExtInfo extInfo = data.getExtInfo();
		if ( extInfo != null ){
			long flow = extInfo.getFlow();
			sb.append(" | �������:<font class='green fb'>").append(DescUtils.descTimes(flow)).append("��</font>");
		}
		sb.append("<font class='red fb fr'>");
		if ( StringUtils.isNoneBlank(data.getLevelName())){
			sb.append("[").append(data.getLevelName()).append("]");
		}
		if ( StringUtils.isNoneBlank(data.getBizName())){
			sb.append("[").append(data.getBizName()).append("]");
		}
		sb.append("[").append(data.getAppName()).append("]");
		sb.append("</font>");
		return sb.toString();
	}

	
}
