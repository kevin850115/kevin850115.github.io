package com.taobao.ateye.excep;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.taobao.ateye.monitor.TripMonitor;

@Service
public class AteyeExceptionHandler implements HandlerExceptionResolver{
	
	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public ModelAndView resolveException(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex) {
		Map<String, Object> model = new HashMap<String, Object>();  
        model.put("error", ex.getMessage());  
        model.put("excep", ex.getClass().getName());
        model.put("stacks", ex.getStackTrace());
        model.put("ex", ex);
        TripMonitor.qps("ҳ���쳣",request.getRequestURI(),ex.getClass().getSimpleName()).record();
        log.error("ҳ���쳣,uri:"+request.getRequestURL()+",param:"+JSON.toJSONString(request.getParameterMap()),ex);
		return new ModelAndView("screen/err", model);  
	}

}
