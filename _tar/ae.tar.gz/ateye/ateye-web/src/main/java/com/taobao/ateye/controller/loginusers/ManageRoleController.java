package com.taobao.ateye.controller.loginusers;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.taobao.ateye.authority.TempRole;
import com.taobao.ateye.common.User4Test;
import com.taobao.ateye.dataobject.ResourceDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.operate.OperateLogger;
import com.taobao.ateye.service.ResourceService;
import com.taobao.ateye.service.RoleService;
import com.taobao.ateye.service.UserService;

@Controller
@RequestMapping("/manage/role")
public class ManageRoleController {
    @Autowired
    OperateLogger operateLogger;
    @Autowired
    private RoleService ateyeRoleService;
    @Autowired
    private ResourceService ateyeResourceService;
    @Autowired
    private UserService ateyeUserService;
    @Autowired
    private TempRole tempRole;

    private void init(Map<String, Object> result) {
        List<ResourceDO> allResources = ateyeResourceService.getAllResourceList();
        List<UserDO> allUsers = ateyeUserService.getAllUserList();
        result.put("allResources", allResources);
        result.put("allUsers", allUsers);
    }

    @RequestMapping("addRole.htm")
    public final String addRole(ModelMap model) {
        this.init(model);
        return "manage/role/addRole";
    }

    @RequestMapping("saveRole.htm")
    public final String saveRole(final RoleDO roleDO,
            @RequestParam(value = "userId", required = false) final String[] userId, @RequestParam(
                    value = "resourceId", required = false) final String[] resourceId, final ModelMap result) throws DAOException {
        boolean flag = ateyeRoleService.insertRole(roleDO, userId, resourceId);

        if (!flag) {
            result.put("error", " �����ɫʧ��");
            operateLogger.logError("�����ɫʧ��", -1, roleDO.getName());
        } else {
            result.put("info", "�����ɫ�ɹ�");
            operateLogger.logInfo("�����ɫ�ɹ�", -1, roleDO.getName());
        }
        return queryRole(null, result);
    }

    @RequestMapping("queryRole.htm")
    public final String queryRole(@RequestParam(value = "name", required = false) final String name,
            final ModelMap result) {
        List<RoleDO> roleList = null;
        if (StringUtil.isBlank(name)) {
            roleList = ateyeRoleService.getAllRoleList();
        } else {
            RoleDO role = new RoleDO();
            role.setName(name);
            roleList = ateyeRoleService.findRole(role);
        }
        result.put("allRoles", roleList);
        return "manage/role/queryRole";
    }

    @RequestMapping("editRole.htm")
    public final String editRole(@RequestParam("id") final Long roleId, final ModelMap result) {
        this.init(result);
        RoleDO role = ateyeRoleService.getRoleById(roleId);
        role.setUserList(ateyeUserService.getRoleUserList(roleId));
        role.setResourceList(ateyeResourceService.getResourcesByRoleId(roleId));
        result.put("role", role);
        return "manage/role/editRole";
    }

    @RequestMapping("updateRole.htm")
    public final String updateRole(final RoleDO role,
            @RequestParam(value = "userId", required = false) final String[] userId, @RequestParam(
                    value = "resourceId", required = false) final String[] resourceId, final HttpServletRequest request,final ModelMap result) throws DAOException {
        this.init(result);
        boolean flag = ateyeRoleService.updateRole(role, userId, resourceId);

        // ��־����
//        SystemLogUtil.createLog(this.getClass(), ActionName.MANAGE_ROLE_UPDATE, "role id:" + role.getId(), "���½�ɫ��Ϣ");
        if (!flag) {
            result.put("error", "���½�ɫʧ��");
            operateLogger.logError("���½�ɫʧ��", -1, role.getName());
        } else {
            result.put("info", "���½�ɫ�ɹ�");
            operateLogger.logInfo("���½�ɫ�ɹ�", -1, role.getName());
        }
        return queryRole(null, result);
    }

    @RequestMapping("deleteRole.htm")
    public final String deleteRole(@RequestParam("id") final Long roleId, final ModelMap result) throws DAOException {
        boolean flag = ateyeRoleService.deleteRole(roleId);

        if (!flag) {
            result.put("error", "ɾ����ɫʧ��");
            operateLogger.logError("ɾ����ɫʧ��", -1, roleId);
        } else {
            result.put("info", "ɾ����ɫ�ɹ�");
            operateLogger.logInfo("ɾ����ɫ�ɹ�", -1, roleId);
        }
        return queryRole(null, result);
    }
    
    @RequestMapping("changeRole.htm") 
    public String changeRole(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String nick = request.getParameter("nick");
    	if ( StringUtils.isBlank(nick) ){
    		return "manage/role/changeRole";
    	}
    	//����ֻ���е�test�˻���test���ճ������ϻ�������ʵ���ڣ���������Ȩ�ޣ�
    	if ( !nick.equals(User4Test.USER_NAME) ){
    		result.put("error", "�����л���test�˻�");
    		return "manage/role/changeRole";
    	}
    	UserDO user = ateyeUserService.getUserByNick(nick);
    	if ( user == null ){
    		result.put("error", "�û�������");
    		return "manage/role/changeRole";
    	}
    	tempRole.useRole(nick, user);
    	return "redirect:/index2.htm";
    }
    @RequestMapping("resetRole.htm") 
    public String resetRole(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	tempRole.reset();
    	return "redirect:/index2.htm";
    }
}
