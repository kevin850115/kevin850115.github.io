package com.taobao.ateye.controller.arch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.score.health.HealthScoreManager;
import com.taobao.ateye.score.health.TotalScoreResult;
import com.taobao.ateye.sqlmap.StatementManager;
import com.taobao.ateye.annotation.Switch;
import com.taobao.ateye.arch.ArchitectureManager;
import com.taobao.ateye.arch.EagleeyeManager;
import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.HsfRelationDO;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.util.CalendarUtil;

/**
 * �ܹ�ͼҳ���߼�
 * 
 * @author saite.wd
 * @version $Id: ArchitectController.java, v 0.1 2015��12��9�� ����1:31:34 saite Exp $
 */
@Controller
@RequestMapping("/arch")
public class ArchitectureController extends AbstractController {
    
    @Resource
    private AppDAO appDAO;
    
    @Resource
    private HbaseReadService hbaseReadService;
    
    @Resource
    private HealthScoreManager healthScoreManager;
    
    @Resource
    private MonitorLogQueryService monitorLogQueryService;
    
    @Resource
    private StatementManager statementManager;
    
    @Resource
    private EagleeyeManager eagleeyeManager;
    
    @Resource
    private ArchitectureManager architectureManager;

    @Autowired
    private EnvironmentService environmentService;

    @Autowired
    private MachineDAO machineDAO;
    
    @Switch(name = "healthThreshold", description = "�����ȵ���ֵ")
    public static String healthThreshold = "90,80,70,60,0";
    
    @Switch(name = "waitingOfflineAppThreshold", description = "Ҫ����Ӧ�õ�����ֵ")
    public static int waitingOfflineAppThreshold = 1000;
    
    @Switch(name = "refreshInterval", description = "ҳ��ˢ�¼��")
    public static int refreshInterval = 60;

    @Switch(name = "oldAppThreshold", description = "��Ӧ�õ�ʱ����ֵ")
    public static final long oldAppThreshold = 90 * 24 * 60 * 60 * 1000L;

    @Switch(name = "waitingOfflineAppsWhiteList", description = "������Ӧ�ð�����")
    public static String waitingOfflineAppsWhiteList = "";
    
    @RequestMapping("appCorePathList.htm")
    public String appCorePathList(final HttpServletRequest request, ModelMap result) throws Exception {
        result.put("to", "/arch/appCorePath.htm");
        result.put("level2","���ĵ�����·");
        if ( initBizMapOwned(result) == null ){
            return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    }
    
    @RequestMapping("appRealtimePathList.htm")
    public String appRealtimePathList(final HttpServletRequest request, ModelMap result) throws Exception {
        result.put("to", "/arch/appRealtimePath.htm");
        result.put("level2","ʵʱ������·");
        if ( initBizMapOwned(result) == null ){
            return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    }
    
    private void fillAppInfoMap(Map<String, String> appInfoMap, List<AppDO> apps, String appName) {
        String[] appInfos = null;
        for (AppDO app : apps) {
            if (app.getAppName().equals(appName)) {
                appInfos = new String[] {appName, app.getAppAlias(), AppChangeLogConstants.bizTypes.get(app.getBizType())};
                break;
            }
        }
        if (appInfos != null) {
            appInfoMap.put(appName, appInfos[0] + ":" + appInfos[1] + ":" + appInfos[2]);
        } else {
            if (appName.contains("@")) {
                String[] splits = appName.split("@");
                if (splits[0].equals("db")) {
                    appInfoMap.put(appName, appName + ":" + splits[0] + ":���ݿ�");
                } else {
                    appInfoMap.put(appName, appName + ":" + splits[0] + ":�м��");
                }
            } else {
                appInfoMap.put(appName, appName + ":�Ǻ���Ӧ��:�Ǻ���");
            }
        }
    }
    
    @RequestMapping("appRealtimePath.htm")
    public String appRealtimePath(final HttpServletRequest request, ModelMap result) throws Exception {
        String appName = request.getParameter("app");
        if (StringUtils.isBlank(appName)) {
            return StringUtils.EMPTY;
        }
        int nl = ServletRequestUtils.getIntParameter(request, "nl", -1);
        int pl = ServletRequestUtils.getIntParameter(request, "pl", -1);
        String[] edgeTypes = request.getParameterValues("edgeType");
        List<Integer> selectedEdgeTypes = new ArrayList<Integer>();
        if (edgeTypes != null) {
            for (int i = 0; i < edgeTypes.length; i++) {
                selectedEdgeTypes.add(Integer.parseInt(edgeTypes[i]));
            }
        }
        if (CollectionUtils.isEmpty(selectedEdgeTypes)) {
            //Ĭ��ȡ�����̶ȵ�ǰ3
            selectedEdgeTypes.add(0);
            selectedEdgeTypes.add(1);
            selectedEdgeTypes.add(2);
        }
        Collections.sort(selectedEdgeTypes);
        
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<AppDO> apps = appDAO.getAllAppAsList();
        List<HsfRelationDO> relations = hbaseReadService.getAllHsfRelationsIgnoreEnv(day);
        List<HsfRelationDO> notAppDownDeps = eagleeyeManager.getNotHsfAppDependencies(appName, day, true);
        List<HsfRelationDO> notAppUpDeps = eagleeyeManager.getNotHsfAppDependencies(appName, day, false);
        relations.addAll(notAppDownDeps);
        relations.addAll(notAppUpDeps);
        List<HsfRelationDO> filteredRelations = new ArrayList<HsfRelationDO>();
        Map<String, String> appInfoMap = new HashMap<String, String>();
        for (HsfRelationDO r: relations) {
            String consumer = r.getAppConsumer();
            String provider = r.getAppProvider();
            long times = r.getTimes();
            if (!inEdgeThreshold(times, selectedEdgeTypes)) {
                continue;
            }
            if (StringUtils.isEmpty(consumer) || StringUtils.isEmpty(provider)) {
                continue;
            }
            if ("null".equals(consumer) || "null".equals(provider)) {
                continue;
            }
            filteredRelations.add(r);
            fillAppInfoMap(appInfoMap, apps, consumer);
            fillAppInfoMap(appInfoMap, apps, provider);
        }
        fillAppInfoMap(appInfoMap, apps, appName);
        String gtxt = architectureManager.generateRealtimePathGraph(appName, appInfoMap, filteredRelations, nl, pl);
        result.put("appName", appName);
        result.put("nl", nl);
        result.put("pl", pl);
        result.put("gtxt", gtxt);
        result.put("edgeTypes", ArchitectureManager.edgeTypeConfigMap);
        result.put("colorConfig", ArchitectureManager.bizTypeColorConfigMap);
        result.put("selectedEdgeTypes", selectedEdgeTypes);
        Date now = new Date();
        result.put("refreshTime", CalendarUtil.formatDate(now, "yyyy-MM-dd HH:mm:ss"));
        result.put("refreshInterval", refreshInterval);
        return "screen/arch/appRealtimePath";
    }
    
    @RequestMapping("appCorePath.htm")
    public String appCorePath(final HttpServletRequest request, ModelMap result) throws Exception {
        String appName = request.getParameter("app");
        if (StringUtils.isBlank(appName)) {
            return StringUtils.EMPTY;
        }
        int nl = ServletRequestUtils.getIntParameter(request, "nl", -1);
        int pl = ServletRequestUtils.getIntParameter(request, "pl", -1);
        String[] edgeTypes = request.getParameterValues("edgeType");
        List<Integer> selectedEdgeTypes = new ArrayList<Integer>();
        if (edgeTypes != null) {
            for (int i = 0; i < edgeTypes.length; i++) {
                selectedEdgeTypes.add(Integer.parseInt(edgeTypes[i]));
            }
        }
        if (CollectionUtils.isEmpty(selectedEdgeTypes)) {
            //Ĭ��ȡ�����̶ȵ�ǰ3
            selectedEdgeTypes.add(0);
            selectedEdgeTypes.add(1);
        }
        Collections.sort(selectedEdgeTypes);
        
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<AppDO> apps = appDAO.getAllAppAsList();
        List<HsfRelationDO> relations = hbaseReadService.getAllHsfRelationsIgnoreEnv(day);
        List<HsfRelationDO> notAppDownDeps = eagleeyeManager.getNotHsfAppDependencies(appName, day, true);
        List<HsfRelationDO> notAppUpDeps = eagleeyeManager.getNotHsfAppDependencies(appName, day, false);
        relations.addAll(notAppDownDeps);
        relations.addAll(notAppUpDeps);
        List<HsfRelationDO> filteredRelations = new ArrayList<HsfRelationDO>();
        Map<String, String> appInfoMap = new HashMap<String, String>();
        for (HsfRelationDO r: relations) {
            String consumer = r.getAppConsumer();
            String provider = r.getAppProvider();
            long times = r.getTimes();
            if (!inEdgeThreshold(times, selectedEdgeTypes)) {
                continue;
            }
            if (StringUtils.isEmpty(consumer) || StringUtils.isEmpty(provider)) {
                continue;
            }
            if ("null".equals(consumer) || "null".equals(provider)) {
                continue;
            }
            filteredRelations.add(r);
            fillAppInfoMap(appInfoMap, apps, consumer);
            fillAppInfoMap(appInfoMap, apps, provider);
        }
        fillAppInfoMap(appInfoMap, apps, appName);
        String gtxt = architectureManager.generateCorePathGraph(appName, appInfoMap, filteredRelations, nl, pl, false);
        result.put("appName", appName);
        result.put("nl", nl);
        result.put("pl", pl);
        result.put("gtxt", gtxt);
        result.put("edgeTypes", ArchitectureManager.edgeTypeConfigMap);
        result.put("colorConfig", ArchitectureManager.bizTypeColorConfigMap);
        result.put("selectedEdgeTypes", selectedEdgeTypes);
        return "screen/arch/appCorePath";
    }
    
    private double getAppScore(String appName) {
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        double score = 0;
        int count = 0;
        for (int i = 0; i < 7; i++) {
            Date dt = DateUtils.addDays(day, -i);
            TotalScoreResult scoreResult = healthScoreManager.getScoreOfApp(appName, dt);
            if (scoreResult != null) {
                score += scoreResult.getTotalScore();
                count++;
            }
        }
        if (count == 0) {
            return 100;
        } else {
            return score / count;
        }
    }
    
    @RequestMapping("archByAppHealth.htm")
    public String archByAppHealth(final HttpServletRequest request, ModelMap result) throws Exception {
        String biz = request.getParameter("biz");
        if (StringUtils.isBlank(biz)) {
            return "";
        }
        int bizType = Integer.parseInt(biz);
        String bizName = AppChangeLogConstants.bizTypes.get(bizType);
        String[] ass = request.getParameterValues("appHealth");
        List<Integer> selectedAppHealths = new ArrayList<Integer>();
        if (ass != null) {
            for (int i = 0; i < ass.length; i++) {
                selectedAppHealths.add(Integer.parseInt(ass[i]));
            }
        }
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        if (CollectionUtils.isEmpty(selectedAppHealths)) {
            selectedAppHealths.addAll(AppChangeLogConstants.appHealths.keySet());
        }
        List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
        Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
        String[] thresholds = healthThreshold.split(",");
        for (AppDO appInfo : appInfos) {
            int status = appInfo.getAppStatus();
            if (status == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            int subBizType = appInfo.getSubBizType();
            String domain = subBizTypes.get(subBizType);
            String appName = appInfo.getAppName();
            String appDesc = appInfo.getAppAlias();
            List<String> infos = appInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                appInfoMap.put(domain, infos);
            }
            int scoreType = -1;
            boolean flag = false;
            for (int selectedAppHealth : selectedAppHealths) {
                double score = getAppScore(appName);
                int from = selectedAppHealth - 1;
                int end = selectedAppHealth;
                if (from < 0) {
                    int down = Integer.parseInt(thresholds[end]);
                    if (score >= down) {
                        flag = true;
                        scoreType = selectedAppHealth;
                        break;
                    }
                } else {
                    int up = Integer.parseInt(thresholds[from]);
                    int down = Integer.parseInt(thresholds[end]);
                    if (score < up && score >= down) {
                        flag = true;
                        scoreType = selectedAppHealth;
                        break;
                    }
                }
            }
            if (!flag) {
                continue;
            }
            infos.add(appName + ":" + appDesc + ":" + scoreType);
        }    
        String gtxt = architectureManager.generateAppHealthGraph(appInfoMap);
        result.put("biz", biz);
        result.put("bizName", bizName);
        result.put("gtxt", gtxt);
        result.put("appHealths", AppChangeLogConstants.appHealths);
        result.put("selectedAppHealths", selectedAppHealths);
        result.put("colorConfig", ArchitectureManager.appHealthColorConfigMap);
        return "screen/arch/archByAppHealth";
    }
    
    private boolean inEdgeThreshold(long times, List<Integer> selectedEdgeTypes) {
        String[] edgeThresholds = ArchitectureManager.edgeThreshold.split(",");
        for (int i = 0; i < selectedEdgeTypes.size(); i++) {
            int edgeType = selectedEdgeTypes.get(i);
            int up = edgeType - 1;
            int down = edgeType;
            if (up < 0) {
                int threshold = Integer.parseInt(edgeThresholds[down]);
                if (times > threshold) {
                    return true;
                }
            } else {
                int upThreshold = Integer.parseInt(edgeThresholds[up]);
                int downThreshold = Integer.parseInt(edgeThresholds[down]);
                if (times <= upThreshold && times > downThreshold) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @RequestMapping("archByPhysical.htm")
    public String archByPhysical(final HttpServletRequest request, ModelMap result) throws Exception {
        String biz = request.getParameter("biz");
        if (StringUtils.isBlank(biz)) {
            return "";
        }
        int bizType = Integer.parseInt(biz);
        String bizName = AppChangeLogConstants.bizTypes.get(bizType);
        
        String[] edgeTypes = request.getParameterValues("edgeType");
        List<Integer> selectedEdgeTypes = new ArrayList<Integer>();
        if (edgeTypes != null) {
            for (int i = 0; i < edgeTypes.length; i++) {
                selectedEdgeTypes.add(Integer.parseInt(edgeTypes[i]));
            }
        }
        if (CollectionUtils.isEmpty(selectedEdgeTypes)) {
            //Ĭ��ȡ�����̶ȵ�ǰ2
            selectedEdgeTypes.add(0);
            selectedEdgeTypes.add(1);
        }
        Collections.sort(selectedEdgeTypes);
        
        Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
        List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
        Set<String> appNameList = new HashSet<String>();
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        for (AppDO appInfo : appInfos) {
            String appName = appInfo.getAppName();
            appNameList.add(appName);
            if (appInfo.getAppStatus() == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            int subBizType = appInfo.getSubBizType();
            String domain = subBizTypes.get(subBizType);
            String appDesc = appInfo.getAppAlias();
            List<String> infos = appInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                appInfoMap.put(domain, infos);
            }
            infos.add(appName + ":" + appDesc);
        }
        List<AppDO> allAppInfos = appDAO.getAllAppAsList();
        Set<String> allAppNameList = new HashSet<String>();
        for (AppDO appInfo : allAppInfos) {
            allAppNameList.add(appInfo.getAppName());
        }
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<HsfRelationDO> res = hbaseReadService.getAllHsfRelationsIgnoreEnv(day);
        List<HsfRelationDO> relatedList = new ArrayList<HsfRelationDO>();
        Set<String> otherDomainAppNames = new HashSet<String>();
        Map<String, List<String>> otherDomainAppInfoMap = new HashMap<String, List<String>>();
        Set<String> mainSiteApps = new TreeSet<String>();
        for (HsfRelationDO r: res) {
            String consumer = r.getAppConsumer();
            String provider = r.getAppProvider();
            long times = r.getTimes();
            if (!inEdgeThreshold(times, selectedEdgeTypes)) {
                continue;
            }
            if (StringUtils.isEmpty(consumer) || StringUtils.isEmpty(provider)) {
                continue;
            }
            if ("null".equals(consumer) || "null".equals(provider)) {
                continue;
            }
            if (!appNameList.contains(consumer) && !appNameList.contains(provider)) {
                continue;
            }
            relatedList.add(r);
            String appName = null;
            if (appNameList.contains(consumer)) {
                appName = provider;
            } else if (appNameList.contains(provider)) {
                appName = consumer;
            }
            if (appName == null) {
                continue;
            }
            if (appNameList.contains(appName)) {
                continue;
            }
            if (allAppNameList.contains(appName)) {
                otherDomainAppNames.add(appName);
            } else {
                //�����Ǻ���Ӧ��
                mainSiteApps.add(appName + ":" + "Ӧ��");
            }
        }
        List<String> mainSiteAppNames = new ArrayList<String>();
        mainSiteAppNames.addAll(mainSiteApps);
        otherDomainAppInfoMap.put("�Ǻ���", mainSiteAppNames);
        for (AppDO appInfo : allAppInfos) {
            if (appInfo.getAppStatus() == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            if (!otherDomainAppNames.contains(appInfo.getAppName())) {
                continue;
            }
            int bt = appInfo.getBizType();
            String domain = AppChangeLogConstants.bizTypes.get(bt);
            String appName = appInfo.getAppName();
            String appDesc = appInfo.getAppAlias();
            List<String> infos = otherDomainAppInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                otherDomainAppInfoMap.put(domain, infos);
            }
            infos.add(appName + ":" + appDesc);
        }
        //ȡ�м����db����
        List<HsfRelationDO> notAppDeps = new ArrayList<HsfRelationDO>();
        for (AppDO appInfo : appInfos) {
            List<HsfRelationDO> inner1 = eagleeyeManager.getNotHsfAppDependencies(appInfo.getAppName(), day, true);
            List<HsfRelationDO> inner2 = eagleeyeManager.getNotHsfAppDependencies(appInfo.getAppName(), day, false);
            inner1.addAll(inner2);
            for (HsfRelationDO r : inner1) {
                long times = r.getTimes();
                if (!inEdgeThreshold(times, selectedEdgeTypes)) {
                    continue;
                }
                notAppDeps.add(r);
            }
        }
        relatedList.addAll(notAppDeps);
        String gtxt = architectureManager.generatePhysicalGraph(appInfoMap, relatedList, otherDomainAppInfoMap);
        result.put("biz", biz);
        result.put("bizName", bizName);
        result.put("gtxt", gtxt);
        result.put("edgeTypes", ArchitectureManager.edgeTypeConfigMap);
        result.put("selectedEdgeTypes", selectedEdgeTypes);
        return "screen/arch/archByPhysical";
    }

    @RequestMapping("waitingOfflineApps.htm")
    public String waitingOfflineApps(final HttpServletRequest request, ModelMap result, boolean willOffline) throws Exception {
        String[] whiteList = waitingOfflineAppsWhiteList.split(",");
        Set<String> whiteApps = new HashSet<String>();
        for (String whiteApp : whiteList) {
            whiteApps.add(whiteApp);
        }
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<HsfRelationDO> res = hbaseReadService.getAllHsfRelationsIgnoreEnv(day);
        List<AppDO> appInfos = appDAO.getAllAppAsList();
        List<AppDO> apps = new ArrayList<AppDO>();
        int machineTotalCount = 0;
        for (AppDO appInfo : appInfos) {
            if (!isAppWaitingOffline(appInfo, day, res)) {
                continue;
            }
            List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appInfo.getId(), environmentService.getEnvironmentType().ordinal());
            if (CollectionUtils.isEmpty(machines)) {
                appInfo.setTagValue("machineCount", "0");
            } else {
                appInfo.setTagValue("machineCount", String.valueOf(machines.size()));
            }
            apps.add(appInfo);
            machineTotalCount += Integer.parseInt(appInfo.getTagValue("machineCount"));
        }
        Collections.sort(apps, new Comparator<AppDO>() {
            @Override
            public int compare(AppDO left, AppDO right) {
                return left.getBizType() - right.getBizType();
            }
        });
        result.put("bizTypes", AppChangeLogConstants.bizTypes);
        result.put("subBizTypes", AppChangeLogConstants.subBizTypes);
        result.put("appTypes", AppChangeLogConstants.appTypes);
        result.put("colorConfigs", ArchitectureManager.bizTypeColorConfigMap);
        result.put("apps", apps);
        result.put("machineTotalCount", machineTotalCount);
        return "screen/arch/waitingOfflineApps";
    }

    private boolean isAppWaitingOffline(AppDO appInfo, Date day, List<HsfRelationDO> res) throws DAOException {
        String[] whiteList = waitingOfflineAppsWhiteList.split(",");
        Set<String> whiteApps = new HashSet<String>();
        for (String whiteApp : whiteList) {
            whiteApps.add(whiteApp);
        }
        if (whiteApps.contains(appInfo.getAppName())) {
            return false;
        }
        int status = appInfo.getAppStatus();
        if (status == AppDO.APP_STATUS_DELETED) {
            return false;
        }
        int bizType = appInfo.getBizType();
        if (bizType == AppChangeLogConstants.BIZ_TYPE_UNKNOWN) {
            return false;
        }
        String publishStatus = appInfo.getPublishStatus();
        if (AppChangeLogConstants.PUBLISH_STATUS_OFFLINE.equals(publishStatus)) {
            return false;
        }
        Date createTime = appInfo.getCreatedTime();
        Date now = new Date();
        if (now.getTime() - createTime.getTime() < oldAppThreshold) {
            return false;
        }
        String type = appInfo.getAppType();
        if (AppChangeLogConstants.APP_TYPE_STORM.equals(type)
                || AppChangeLogConstants.APP_TYPE_PACKAGE.equals(type)
                || AppChangeLogConstants.APP_TYPE_CLIENT.equals(type)
                || appInfo.getAppName().startsWith("storm~")) {
            return false;
        }
        long sqltimes = 0;
        long[] dbStat = eagleeyeManager.getAppDBStat(appInfo.getAppName(), day);
        if (dbStat != null) {
            sqltimes = dbStat[1];
        }
        appInfo.setTagValue("sqlTimes", String.valueOf(sqltimes));
        long ptimes = 0;
        long ctimes = 0;
        for (HsfRelationDO r : res) {
            String p = r.getAppProvider();
            String c = r.getAppConsumer();
            if (appInfo.getAppName().equals(p)) {
                ptimes += r.getTimes();
            }
            if (appInfo.getAppName().equals(c)) {
                ctimes += r.getTimes();
            }
        }
        appInfo.setTagValue("hsfProviderTimes", String.valueOf(ptimes));
        appInfo.setTagValue("hsfConsumerTimes", String.valueOf(ctimes));
        long httpCalledTimes = 0;
        long[] httpStat = eagleeyeManager.getAppURLStat(appInfo.getAppName(), day, false);
        if (httpStat != null) {
            httpCalledTimes = httpStat[1];
        }
        long httpCallTimes = 0;
        httpStat = eagleeyeManager.getAppURLStat(appInfo.getAppName(), day, true);
        if (httpStat != null) {
            httpCallTimes = httpStat[1];
        }
        appInfo.setTagValue("httpCalledTimes", String.valueOf(httpCalledTimes));
        appInfo.setTagValue("httpCallTimes", String.valueOf(httpCallTimes));
        if (ptimes < waitingOfflineAppThreshold && ctimes < waitingOfflineAppThreshold
                && sqltimes < waitingOfflineAppThreshold
                && httpCalledTimes < waitingOfflineAppThreshold && httpCallTimes < waitingOfflineAppThreshold) {
            appInfo.setTagValue("easyToOffline", "true");
        } else {
            appInfo.setTagValue("easyToOffline", "false");
        }
        if (status == AppDO.APP_STATUS_WILL_OFFLINE || appInfo.getTagValue("easyToOffline").equals("true")) {
            return true;
        }
        return false;
    }
    
    @RequestMapping("waitingOnlineApps.htm")
    public String waitOnlineApps(final HttpServletRequest request, ModelMap result) throws Exception {
        List<AppDO> appInfos = appDAO.getAllAppAsList();
        List<AppDO> apps = new ArrayList<AppDO>();
        for (AppDO appInfo : appInfos) {
            int status = appInfo.getAppStatus();
            if (status == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            if (status == AppDO.APP_STATUS_WILL_ONLINE) {
                apps.add(appInfo);
            }
        }
        Collections.sort(apps, new Comparator<AppDO>() {
            @Override
            public int compare(AppDO left, AppDO right) {
                return left.getBizType() - right.getBizType();
            }
        });
        result.put("bizTypes", AppChangeLogConstants.bizTypes);
        result.put("subBizTypes", AppChangeLogConstants.subBizTypes);
        result.put("appTypes", AppChangeLogConstants.appTypes);
        result.put("colorConfigs", ArchitectureManager.bizTypeColorConfigMap);
        result.put("apps", apps);
        return "screen/arch/waitingOnlineApps";
    }
    
    @RequestMapping("archByBiz.htm")
    public String archByBiz(final HttpServletRequest request, ModelMap result) throws Exception {
        String biz = request.getParameter("biz");
        if (StringUtils.isBlank(biz)) {
            return "";
        }
        int bizType = Integer.parseInt(biz);
        String bizName = AppChangeLogConstants.bizTypes.get(bizType);
        Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
        List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        for (AppDO appInfo : appInfos) {
            if (appInfo.getAppStatus() == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            int subBizType = appInfo.getSubBizType();
            String domain = subBizTypes.get(subBizType);
            String appName = appInfo.getAppName();
            String appDesc = appInfo.getAppAlias();
            List<String> infos = appInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                appInfoMap.put(domain, infos);
            }
            infos.add(appName + ":" + appDesc);
        }
        String gtxt = architectureManager.generateGraphByBiz(appInfoMap);
        result.put("biz", biz);
        result.put("bizName", bizName);
        result.put("gtxt", gtxt);
        return "screen/arch/archByBiz";
    }
    
    @RequestMapping("archByAppImportance.htm")
    public String archByAppImportance(final HttpServletRequest request, ModelMap result) throws Exception {
        String biz = request.getParameter("biz");
        if (StringUtils.isBlank(biz)) {
            return "";
        }
        int bizType = Integer.parseInt(biz);
        String bizName = AppChangeLogConstants.bizTypes.get(bizType);
        String[] ass = request.getParameterValues("appImportance");
        List<Integer> selectedAppImportances = new ArrayList<Integer>();
        if (ass != null) {
            for (int i = 0; i < ass.length; i++) {
                selectedAppImportances.add(Integer.parseInt(ass[i]));
            }
        }
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        if (CollectionUtils.isEmpty(selectedAppImportances)) {
            selectedAppImportances.addAll(AppChangeLogConstants.appImportances.keySet());
        }
        List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
        Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
        for (AppDO appInfo : appInfos) {
            int status = appInfo.getAppStatus();
            if (status == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            int subBizType = appInfo.getSubBizType();
            String domain = subBizTypes.get(subBizType);
            String appName = appInfo.getAppName();
            String appDesc = appInfo.getAppAlias();
            List<String> infos = appInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                appInfoMap.put(domain, infos);
            }
            boolean flag = false;
            for (int selectedAppImportance : selectedAppImportances) {
                if (selectedAppImportance == appInfo.getImportance()) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                continue;
            }
            infos.add(appName + ":" + appDesc + ":" + appInfo.getImportance());
        }    
        String gtxt = architectureManager.generateAppImportanceGraph(appInfoMap);
        result.put("biz", biz);
        result.put("bizName", bizName);
        result.put("gtxt", gtxt);
        result.put("appImportances", AppChangeLogConstants.appImportances);
        result.put("selectedAppImportances", selectedAppImportances);
        result.put("colorConfig", ArchitectureManager.appImportanceColorConfigMap);
        return "screen/arch/archByAppImportance";
    }
    
    @RequestMapping("archByAppStatus.htm")
    public String archByAppStatus(final HttpServletRequest request, ModelMap result) throws Exception {
        String biz = request.getParameter("biz");
        if (StringUtils.isBlank(biz)) {
            return "";
        }
        int bizType = Integer.parseInt(biz);
        String bizName = AppChangeLogConstants.bizTypes.get(bizType);
        String[] ass = request.getParameterValues("appStatus");
        List<Integer> selectedAppStatuses = new ArrayList<Integer>();
        if (ass != null) {
            for (int i = 0; i < ass.length; i++) {
                selectedAppStatuses.add(Integer.parseInt(ass[i]));
            }
        }
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        if (CollectionUtils.isEmpty(selectedAppStatuses)) {
            selectedAppStatuses.addAll(ArchitectureManager.appStatusConfigMap.keySet());
        }
        List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
        Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<HsfRelationDO> res = hbaseReadService.getAllHsfRelationsIgnoreEnv(day);
        for (AppDO appInfo : appInfos) {
            if (isAppWaitingOffline(appInfo, day, res)) {
                appInfo.setDeleteStatus(String.valueOf(AppChangeLogConstants.DELETE_STATUS_WILLDELETE));
            }
            int status = appInfo.getAppStatus();
            if (status == AppDO.APP_STATUS_DELETED) {
                continue;
            }
            int subBizType = appInfo.getSubBizType();
            String domain = subBizTypes.get(subBizType);
            String appName = appInfo.getAppName();
            String appDesc = appInfo.getAppAlias();
            List<String> infos = appInfoMap.get(domain);
            if (infos == null) {
                infos = new ArrayList<String>();
                appInfoMap.put(domain, infos);
            }
            boolean flag = false;
            for (Integer selectedAppStatus : selectedAppStatuses) {
                if (selectedAppStatus == status) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                continue;
            }
            infos.add(appName + ":" + appDesc + ":" + status);
        }    
        String gtxt = architectureManager.generateAppStatusGraph(appInfoMap);
        result.put("biz", biz);
        result.put("bizName", bizName);
        result.put("gtxt", gtxt);
        result.put("appStatuses", ArchitectureManager.appStatusConfigMap);
        result.put("selectedAppStatuses", selectedAppStatuses);
        result.put("colorConfig", ArchitectureManager.appStatusColorConfigMap);
        return "screen/arch/archByAppStatus";
    }
    
    @RequestMapping("archByTotal.htm")
    public String archByTotal(final HttpServletRequest request, ModelMap result) throws Exception {
        String[] bts = request.getParameterValues("bizType");
        List<Integer> selectedBizTypes = new ArrayList<Integer>();
        if (bts != null) {
            for (int i = 0; i < bts.length; i++) {
                selectedBizTypes.add(Integer.parseInt(bts[i]));
            }
        }
        Map<String, List<String>> appInfoMap = new HashMap<String, List<String>>();
        if (CollectionUtils.isEmpty(selectedBizTypes)) {
            selectedBizTypes.addAll(AppChangeLogConstants.bizTypes.keySet());
        }
        Iterator<Integer> bizTypeIter = selectedBizTypes.iterator();
        while (bizTypeIter.hasNext()) {
            int bizType = bizTypeIter.next();
            Map<Integer, String> subBizTypes = AppChangeLogConstants.subBizTypes.get(bizType);
            List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
            for (AppDO appInfo : appInfos) {
                if (appInfo.getAppStatus() == AppDO.APP_STATUS_DELETED) {
                    continue;
                }
                int subBizType = appInfo.getSubBizType();
                String domain = subBizTypes.get(subBizType);
                String appName = appInfo.getAppName();
                String appDesc = appInfo.getAppAlias();
                List<String> infos = appInfoMap.get(domain);
                if (infos == null) {
                    infos = new ArrayList<String>();
                    appInfoMap.put(domain, infos);
                }
                infos.add(appName + ":" + appDesc + ":" + bizType);
            }
        }
        String gtxt = architectureManager.generateTotalGraph(appInfoMap);
        result.put("gtxt", gtxt);
        result.put("bizTypes", AppChangeLogConstants.bizTypes);
        result.put("selectedBizTypes", selectedBizTypes);
        result.put("colorConfig", ArchitectureManager.bizTypeColorConfigMap);
        return "screen/arch/archByTotal";
    }
    
    @RequestMapping("archByBizs.htm")
    public String archByBizs(final HttpServletRequest request, ModelMap result) throws Exception {
        result.put("bizTypes", AppChangeLogConstants.bizTypes);
        result.put("type", Integer.parseInt(request.getParameter("type")));
        Iterator<Integer> bizTypeIter = AppChangeLogConstants.bizTypes.keySet().iterator();
        Map<Integer, Integer> countMap = new HashMap<Integer, Integer>();
        Map<Integer, Integer> machineMap = new HashMap<Integer, Integer>();
        while (bizTypeIter.hasNext()) {
            int bizType = bizTypeIter.next();
            List<AppDO> appInfos = appDAO.queryAppByBizType(bizType,null);
            countMap.put(bizType, appInfos.size());
            int machineCount = 0;
            for (AppDO appInfo : appInfos) {
                List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appInfo.getId(), environmentService.getEnvironmentType().ordinal());
                if (!CollectionUtils.isEmpty(machines)) {
                    machineCount += machines.size();
                }
            }
            machineMap.put(bizType, machineCount);
        }
        result.put("countMap", countMap);
        result.put("machineMap", machineMap);
        return "screen/arch/archByBizs";
    }
    
}
