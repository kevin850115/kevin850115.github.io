package com.taobao.ateye.controller.cf;

import com.alibaba.goc.changefree.model.CallResult;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.ChangeFreeApproveDAO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.reflect.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by sunqiang on 2019/6/17.
 */
@Controller
@RequestMapping("changefree")
public class ChangeFreeController extends AbstractController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private ChangeFreeApproveDAO approveDAO;
    @RequestMapping("/notifyUrl.htm")
    @ResponseBody
    public CallResult<Object> notifyUrl(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
        String sourceOrderId = request.getParameter("source_order_id");
        String checkStatus = request.getParameter("check_status_enum");
        String approveUrl = request.getParameter("apply_order_url");
        try{
            approveDAO.updateStatus(sourceOrderId,checkStatus);
            if(StringUtils.isNotEmpty(approveUrl)){
                approveDAO.updateApproveUrl(sourceOrderId,approveUrl);
            }

        }catch (Exception e){
            logger.error("�������ݿ��쳣,sourceOrderId="+sourceOrderId+",checkStatus="+checkStatus+",approveUrl="+approveUrl,e);
        }

        return CallResult.<Object>success();
    }
}
