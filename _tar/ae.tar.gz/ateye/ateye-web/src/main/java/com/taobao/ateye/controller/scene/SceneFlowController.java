package com.taobao.ateye.controller.scene;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.app.model.AppModelListDO;
import com.taobao.ateye.cache.SceneEntryPointCache;
import com.taobao.ateye.config.app.extend.AppExtendModel;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.flow.manager.FlowConstant;
import com.taobao.ateye.flow.manager.FlowViewManager;
import com.taobao.ateye.flow.model.FlowDetailModelDO;
import com.taobao.ateye.flow.model.FlowMethodModelDO;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.security.util.SecurityUtil;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/scene")
public class SceneFlowController extends AbstractController{
	private static final String FLOW_NODEGROUP_LIST = "screen/scene/flowNgList";
	private static final String FLOW_METHOD_LIST = "screen/scene/flowMethodList";
	private static final String FLOW_DETAIL_LIST = "screen/scene/flowDetailList";
	private static final String FLOW_ENTRY_LIST = "screen/scene/flowEntryList";

	@Autowired
	private FlowViewManager flowViewManager;
	@Autowired
	private SceneEntryPointCache sepCache;

	@RequestMapping("flowDetail.htm")
	public String flowDetail(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String ng = request.getParameter("ng");
		String interf = request.getParameter("interf");
		String method = request.getParameter("method");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(ng) || StringUtils.isBlank(interf) || StringUtils.isBlank(method)) {
			return "";
		}
		List<FlowDetailModelDO> details = flowViewManager.buildDetailModel(app, ng,interf,method);
		result.put("levels", getSceneLevelOrdered());	
		result.put("details", details);
		result.put("app", app);
		result.put("ng", ng);
		result.put("interf", interf);
		result.put("method", method);
		result.put("sepCacheMap", sepCache.getEntrys());
		AppExtendModel appExtendDO = appExtendManager.getAppExtendDO(app);
		result.put("extendDO", appExtendDO);	
		return FLOW_DETAIL_LIST;
	}
	@RequestMapping("flowMethodList.htm")
	public String flowMethodList(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String ng = request.getParameter("ng");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(ng) ) {
			return "";
		}
		Map<String, List<FlowMethodModelDO>> methods = flowViewManager.buildMethodModel(app, ng);
		List<FlowMethodModelDO> inters = flowViewManager.buildInterfaceModel(app, ng);
		result.put("levels", getSceneLevelOrdered());	
		result.put("methods", methods);
		result.put("inters", inters);
		result.put("app", app);
		result.put("ng", ng);
		
		AppExtendModel appExtendDO = appExtendManager.getAppExtendDO(app);
		result.put("extendDO", appExtendDO);
		
		return FLOW_METHOD_LIST;
	}
	@RequestMapping("flowSceneList.htm")
	public String flowSceneList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltTag = request.getParameter("fltTag");
		if ( StringUtils.isNotBlank(fltTag) ){
			flts.put("tag", fltTag);
			result.put("fltTag",fltTag);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltCat= request.getParameter("fltCat");
		if ( StringUtils.isNotBlank(fltCat) ){
			flts.put("cat", fltCat);
			result.put("fltCat",fltCat);
		}
		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltType= request.getParameter("fltType");
		if ( StringUtils.isNotBlank(fltType) ){
			flts.put("typeDesc", fltType);
			result.put("fltType",fltType);
		}
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		SceneEntryModel model = sceneEntryManager.getEntryList4Flow(flts);
		Map<String, List<Pair<String, Integer>>> fltMap = model.getFltMap();
		result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
		result.put("typeFlt", fltMap.get("typeDesc"));
		result.put("appFlt", fltMap.get("app"));
        result.put("tagFlt", fltMap.get("tag"));
        result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("bizMap",getBizMap());
		result.put("catFlt", formatToLong(fltMap.get("cat")));
		result.put("levelFlt", formatToLong(fltMap.get("level")));
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("entrys",model.getRetList());
		result.put("model",model);
		result.put("allCats",sceneCatDAO.getAllMap());
		result.put("allLevels", sceneLevelDAO.getAllMap());
		result.put("fullShow", "true");

		return FLOW_ENTRY_LIST;
	}
	@RequestMapping("flowNgList.htm")
	public String flowNgList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltTag = request.getParameter("fltTag");
		if ( StringUtils.isNotBlank(fltTag) ){
			flts.put("tag", fltTag);
			result.put("fltTag",fltTag);
		}
		String fltOps = request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltVersion = request.getParameter("fltVersion");
		if ( StringUtils.isNotBlank(fltVersion) ){
			flts.put("version", fltVersion);
			result.put("fltVersion",fltVersion);
		}
		String fltLevel = request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltGrade = request.getParameter("fltGrade");
		if ( StringUtils.isNotBlank(fltGrade) ){
			flts.put("grade", fltGrade);
			result.put("fltGrade",fltGrade);
		}
		String fltJava = request.getParameter("fltJava");
		if ( StringUtils.isNotBlank(fltJava) ){
			flts.put("java", fltJava);
			result.put("fltJava",fltJava);
		}
		String fltSafe = request.getParameter("fltSafe");
		if ( StringUtils.isNotBlank(fltSafe) ){
			flts.put("safe", fltSafe);
			result.put("fltSafe",fltSafe);
		}
		String fltSpe = request.getParameter("fltSpe");
		if ( StringUtils.isNotBlank(fltSpe) ){
			flts.put("spe", fltSpe);
			result.put("fltSpe",fltSpe);
		}
		String fltNgType= request.getParameter("fltNgType");
		if ( StringUtils.isNotBlank(fltNgType) ){
			flts.put("ngType", fltNgType);
			result.put("fltNgType",fltNgType);
		}
		AppModelListDO appList = appModelManager.queryAppList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = appList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("opsFlt", formatToLong(fltMap.get("ops")));
		result.put("versionFlt", fltMap.get("version"));
		result.put("tagFlt", fltMap.get("tag"));
		result.put("levelFlt", fltMap.get("level"));
		result.put("gradeFlt", fltMap.get("grade"));
		result.put("javaFlt", fltMap.get("java"));
		result.put("safeFlt", fltMap.get("safe"));
		result.put("speFlt", fltMap.get("spe"));
		result.put("ngTypeFlt", fltMap.get("ngType"));
		result.put("bizMap",getBizMap());
		result.put("appList",appList);
		result.put("serversCnt", appList.getServerCount());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("apps",appList.getRetListOrderByFlow());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		result.put("levels", getSceneLevelOrdered());
		result.put("typeLst", FlowConstant.NodeGroupTypes);
		
		return FLOW_NODEGROUP_LIST;
    }
	@RequestMapping("updateNgTypeAjax.htm")
	public String updateNgTypeAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String ng = request.getParameter("ng");
		String ngType = request.getParameter("ngType");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(ng) && StringUtils.isNotBlank(ngType) ){
			int update = appExtendManager.updateAppNodeGroupType(Long.valueOf(appId), ng, ngType);
			ret.put("success", update>0?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	/*
	 * ҳ�水���˳��չʾ
	 */
	private List<String> getSceneLevelOrdered() throws DAOException{
		//HardCode
		return Arrays.asList(
				"���-S��", 
				"���-A��", 
				"���-B��", 
				"���-C��", 
				"����-A��", 
				"����-B��",
				"����"
				);
		
	}
}
