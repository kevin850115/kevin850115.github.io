package com.taobao.ateye.controller.alarm.data;

/**
 * Created by sunqiang on 2018/12/21.
 */
public class AlarmRecord {
}
