package com.taobao.ateye.controller.loginusers;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.alarm.rule.RuleManager;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.UserAndAppDAO;
import com.taobao.ateye.dal.UserDAO;
import com.taobao.ateye.dal.UserDetailDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserAndAppDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.dataobject.UserProfileDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.operate.OperateLogger;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.RoleService;
import com.taobao.ateye.service.UserService;
import com.taobao.ateye.user.UserNameConverter;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/manage/user")
public class ManageUserController {
    @Autowired
    OperateLogger operateLogger;
    @Autowired
    private UserService ateyeUserService;
    @Autowired
    private RoleService ateyeRoleService;
    @Autowired
    private OpsServic opsServic;
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserAndAppDAO userAndAppDAO;
    @Autowired
    private AppDAO appDAO;
    @Autowired
    private UserDetailDAO userDetailDAO;
    @Autowired
    private AclSyncUtil aclSyncUtil;
    @Autowired
    private RuleManager ruleManager;
	@Autowired
	private UserDAO ateyeUserDAO;


    private void init(Map<String, Object> result) throws DAOException {
        List<RoleDO> list = ateyeRoleService.getAllRoleList();
        List<AppDO> apps=opsServic.getAllApps();
        result.put("apps",apps);
        result.put("allRoles", list);
    }

    @RequestMapping("addUser.htm")
    public final String addUser(final ModelMap result) throws DAOException {
        this.init(result);
        return "manage/user/addUser";
    }

    @RequestMapping("saveUser.htm")
    public final String saveUser(final UserDO user, @RequestParam(value = "roleId", required = false) String[] roleIds,
                                 @RequestParam(value = "roleapp", required = false) String[] apps,
                                 final ModelMap result) throws DAOException, UnsupportedEncodingException {
        boolean flag = ateyeUserService.insertUser(user, roleIds);


        if (!flag) {
            result.put("error", " �����û�ʧ��");
            operateLogger.logError("�����û�ʧ��", -1, user.getNick());
        } else {

            List<String> roleNames = new ArrayList<String>();

            for(String id:roleIds) {
                roleNames.add(roleService.getRoleById(Long.parseLong(id)).getName());
            }
            try {
                aclSyncUtil.grantUserAclRolePermission(user.getNick(), roleNames);
            } catch (Exception e) {
                result.put("error-acl", "ͬ��aclʧ��");
                operateLogger.logError("ͬ��aclʧ��", -1, user.getNick());
            }

            if(apps!=null&&apps.length>0){
                UserDO userDO = this.ateyeUserService.getUserByNick(user.getNick());
                // ��ȡ�û��Ľ�ɫ�б�
                List<RoleDO> roles = roleService.getUserRoleList(userDO.getId());
                // �ж��û��Ƿ����adminȨ��
                boolean isAdmin = false;
                for (RoleDO role : roles) {
                    String admin = "ROLE_ADMIN";
                    if (admin.equals(role.getName())) {
                        isAdmin = true;
                        break;
                    }
                }
                if(!isAdmin)
                {
                    opsServic.deleteUseAndAppInfoByUserId(userDO.getId());
                    for (String appName : apps)
                    {
                        opsServic.insertUserAndAppInfo(appName, userDO.getId());
                    }
                }
            }
            result.put("info", "�����û��ɹ�");
            operateLogger.logInfo("�����û��ɹ�", -1, user.getNick());
        }
        return queryUser(null, result);
    }

    @RequestMapping("queryUser.htm")
    public final String queryUser(final UserDO user, final ModelMap result) throws DAOException, UnsupportedEncodingException {
        this.init(result);
        List<UserDO> userList = null;
        if (user == null || (StringUtil.isBlank(user.getNick()) && (user.getRoleId() == null))) {
            userList = ateyeUserService.getAllUserList();
        } else {
            userList = ateyeUserService.findUser(user);
        }
        for (UserDO u : userList) {
            List<RoleDO> userRoleList = ateyeRoleService.getUserRoleList(u.getId());
            u.setRoleList(userRoleList);
        }
        /*�û���Ȩ�޵�Ӧ����*/
        result.put("userNames",UserNameConverter.convert(userList));
        result.put("allUsers", userList);
        List<AppDO> allApps = appDAO.getAllAppAsList();
        List<UserAndAppDO> userApps = userAndAppDAO.getAll();

        Map<Long,Integer> countMap = new HashMap<Long,Integer>();
        for ( UserAndAppDO ua:userApps ){
            Long userId = ua.getUserId();
            Integer count = countMap.get(userId);
            if ( count == null){
                countMap.put(userId, 1);
            }else{
                countMap.put(userId, count+1);
            }
        }
        Map<String, UserProfileDO> userMap = userDetailDAO.getAllMap();
        result.put("userAppMap",countMap);
        result.put("allApps", allApps);
        result.put("userMap", userMap);

        result.put("todayLogins",statLoginRecently(1, userList));
        result.put("weekLogins",statLoginRecently(7, userList));
        result.put("monthLogins",statLoginRecently(30, userList));

        return "manage/user/queryUser";
    }

    private Integer statLoginRecently(int day,List<UserDO> users){
        int ret = 0;
        Date dt = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),-(day-1));
        for ( UserDO ud:users ){
            Date lastLoginTime = ud.getLastLoginTime();
            if ( lastLoginTime != null && lastLoginTime.after(dt) ){
                ret ++;
            }
        }
        return ret;
    }

    @RequestMapping("editUser.htm")
    public final String editUser(@RequestParam("id") final Long id, final ModelMap result) throws DAOException {
        this.init(result);
        UserDO user = ateyeUserService.getUserById(id);
        List<RoleDO> userRoleList = ateyeRoleService.getUserRoleList(user.getId());
        user.setRoleList(userRoleList);
        result.put("user", user);
        List<AppDO> useapps = this.opsServic.getAllAppsBelongToAUser(user.getId());
        result.put("userapps", useapps);
        return "manage/user/editUser";
    }

    @RequestMapping("updateUser.htm")
    public final String updateUser(final UserDO user, @RequestParam(value = "roleId", required = false) final String[] roleIds,
                                   @RequestParam(value = "roleapp", required = false) String[] apps,
                                   final HttpServletRequest request,final ModelMap result) throws DAOException, UnsupportedEncodingException {
        boolean flag = ateyeUserService.updateUser(user, roleIds);

        // ��־����
        // SystemLogUtil.createLog(this.getClass(), ActionName.MANAGE_USER_UPDATE, "role id:" + user.getId(),
        // "�����û���Ϣ");
        if (!flag) {
            result.put("error", " �༭�û�ʧ��");
            operateLogger.logError("�༭�û�ʧ��", -1, user.getId(), user.getNick());
        } else {

            UserDO userDO = this.ateyeUserService.getUserByNick(user.getNick());
            // ��ȡ�û��Ľ�ɫ�б�
            List<RoleDO> roles = roleService.getUserRoleList(userDO.getId());
            // �ж��û��Ƿ����adminȨ��
            boolean isAdmin = false;
            for (RoleDO role : roles) {
                String admin = "ROLE_ADMIN";
                if (admin.equals(role.getName())) {
                    isAdmin = true;
                    break;
                }
            }
            if (!isAdmin) {
                opsServic.deleteUseAndAppInfoByUserId(userDO.getId());
                if (apps != null && apps.length > 0) {
                    for (String appName : apps) {
                        opsServic.insertUserAndAppInfo(appName, userDO.getId());
                    }
                }
            }

            result.put("info", "�༭�û��ɹ�");
            operateLogger.logInfo("�༭�û��ɹ�", -1, user.getId(), user.getNick());
        }
        return queryUser(null, result);
    }

    @RequestMapping("deleteUser.htm")
    public final String deleteUser(@RequestParam("id") final Long id, final ModelMap result) throws DAOException, UnsupportedEncodingException {
    	UserDO user = ateyeUserDAO.getUserById(id);
    	if ( user == null ){
    		return "";
    	}
    	String nick = user.getNick();
    	//1.ɾ���û�
        boolean flag = ateyeUserService.deleteUser(id);
        if (!flag) {
            result.put("error", "ɾ���û�ʧ��");
            operateLogger.logError("ɾ���û�ʧ��", -1, id);
        } else {
            result.put("info", "ɾ���û��ɹ�");
            operateLogger.logInfo("ɾ���û��ɹ�", -1, id);
            //2.ɾ���û���Ӧ�ı�������
            UserProfileDO upd = userDetailDAO.getByNick(nick);
            if ( upd != null ){
	            ruleManager.deleteAllRulesOfUser(upd.getNick());
	            operateLogger.logInfo("ɾ���û����б�������", -1, upd.getNick());
	            if ( StringUtils.isNotBlank(upd.getPhone())) {
		            ruleManager.deleteAllRulesOfUser(upd.getPhone());
		            operateLogger.logInfo("ɾ���û����б�������-�绰", -1, upd.getPhone());
	            }
            }
        }
        return queryUser(null, result);
    }
}
