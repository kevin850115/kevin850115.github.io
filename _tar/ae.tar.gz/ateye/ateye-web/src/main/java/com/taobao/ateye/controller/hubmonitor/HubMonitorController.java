package com.taobao.ateye.controller.hubmonitor;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.alarm.config.RuleTypeConstant;
import com.taobao.ateye.alarm.manager.AlarmGroupManager;
import com.taobao.ateye.alarm.manager.AlarmRuleManager;
import com.taobao.ateye.alarm.n.data.AlarmNewRuleVO;
import com.taobao.ateye.alarm.n.manager.AlarmManager;
import com.taobao.ateye.alarm.n.manager.AlarmSwitchManager;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.base.EnvIdType;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.data.obj.HsfVO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.kv.KvDetailManager;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.monitor.HbaseStat;
import com.taobao.ateye.monitor.MonitorItemDO;
import com.taobao.ateye.monitor.TrackerMonitorDO;
import com.taobao.ateye.monitor.compare.MonitorCompareResultDO;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.scene.SceneContants;
import com.taobao.ateye.scene.common.StackInfo;
import com.taobao.ateye.scene.common.StackInfoUtil;
import com.taobao.ateye.scene.data.SceneTrackerLog;
import com.taobao.ateye.scene.util.TrackerLogConvertUtils;
import com.taobao.ateye.sqlmap.OpType;
import com.taobao.ateye.sqlmap.QuerySqlmapManager;
import com.taobao.ateye.sqlmap.SqlMapBlackManager;
import com.taobao.ateye.sqlmap.StatementDO;
import com.taobao.ateye.sqlmap.StatementManager;
import com.taobao.ateye.tracker.TrackerInfoManager;
import com.taobao.ateye.tracker.TrackerTypeConstant;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.ateye.view.AteyeViewManager;
import com.taobao.ateye.view.config.AggrTypeEnum;
import com.taobao.ateye.view.config.BaseDataConfig;
import com.taobao.ateye.view.config.DivDataConfig;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.hbase.AlarmRuleDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.UserFavor;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.AlarmGroupDO;
import com.taobao.tracker.hbase.view.BaseViewDO;
import com.taobao.tracker.hbase.view.LineDefDO;
import com.taobao.tracker.hbase.view.MultiViewDO;
import com.taobao.tracker.hbase.view.SingleViewDO;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;

@Controller
@RequestMapping("/hubmonitor")
public class HubMonitorController extends AbstractController{
	@Autowired
	AteyeConfig ateyeConfig;
	@Autowired
	private AppDAO appDAO;
	@Autowired
	private QuerySqlmapManager querySqlmapManager;
	private static final String MONITOR_LOG = "screen/hubmonitor/monitorLog";
	private static final String SCENE_EXCEPTION_LOG = "screen/hubmonitor/sceneExceptionLog";
	private static final String MONITOR_COMPARE = "screen/hubmonitor/monitorCompare";
	private static final String MONITOR_TREE = "screen/hubmonitor/monitorTree";
	private static final String VIEW_DETAIL = "screen/hubmonitor/viewDetail";
	private static final String VIEW_VIRTUAL_VIEW= "screen/hubmonitor/viewVirtualView";
	private static final String VIEW_MULTI_DETAIL = "screen/hubmonitor/viewMultiDetail";
	private static final String HSF_MONITOR_LOG = "screen/hubmonitor/hsfMonitorLog";
	private static final String SERVICE_MONITOR_LOG = "screen/hubmonitor/serviceMonitorLog";
	private static final String SQLMAP = "screen/hubmonitor/sqlmap";
	private static final String HISTORY_INFO2 = "screen/hubmonitor/historyInfo2";
	private static final String HISTORY_DAY= "screen/hubmonitor/historyDay";
	private static final String HISTORY_INFO3 = "screen/hubmonitor/historyInfo3";
	private static final String SQLMAP_HISTORY = "screen/hubmonitor/sqlmapHistory";
	private static final String SPEED_TRACKER = "screen/hubmonitor/trackerSpeed";
	private static final String MONITOR_TRACKER = "screen/hubmonitor/trackerMonitor";
	private static final String MONITOR_TRACKER_TYPE = "screen/hubmonitor/trackerMonitorByType";
	private static final String MONITOR_TRACKER_APP = "screen/hubmonitor/trackerMonitorByApp";

	@Autowired
	private MonitorLogQueryService monitorLogQueryService;
	@Autowired
	private StatementManager statementManager;
	@Autowired
	private HbaseReadService hbaseReadService;
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private AlarmRuleManager alarmRuleManager;

	@Autowired
	private AlarmSwitchManager alarmSwitchManager;

	@Autowired
	private AlarmManager alarmManager;
	@Autowired
	private TrackerInfoManager trackerInfoManager;
	@Autowired
	private SqlMapBlackManager sqlMapBlackManager;
	@Autowired
	private AlarmGroupManager alarmGroupManager;
	@Autowired
	private KvDetailManager kvDetailManager;

	@RequestMapping("kvAddFavor.htm")
	public String kvAddFavor(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, IOException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String keys = request.getParameter("keys");
		String app = request.getParameter("app");
		String startDate = request.getParameter("startDate");

		if ( StringUtils.isEmpty(app) || StringUtils.isEmpty(keys) ){
			return null;
		}
		hbaseReadService.addFavorItem(user.getNick(), getKVItemType(app), URLEncoder.encode(keys, "utf8"));
		return "redirect:/hubmonitor/monitorLog.htm?app="+app+"&startDate="+startDate;

	}
	@RequestMapping("kvRemoveFavor.htm")
	public String kvRemoveFavor(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, UnsupportedEncodingException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String keys = request.getParameter("keys");
		String app = request.getParameter("app");
		String startDate = request.getParameter("startDate");

		String date = request.getParameter("date");
		if ( StringUtils.isEmpty(app) || StringUtils.isEmpty(keys) ){
			return null;
		}
		UserFavor favor = new UserFavor();
		favor.setDate(date);
		favor.setNick(user.getNick());
		favor.setType(getKVItemType(app));
		hbaseReadService.removeFavorItem(favor);
		return "redirect:/hubmonitor/monitorLog.htm?app="+app+"&startDate="+startDate;

	}
	@RequestMapping("viewMultiDetail.htm")
	public String viewMultiDetail(final HttpServletRequest request,ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		result.put("domain", ateyeConfig.getAteyeDomain());

		String nick = user.getNick();
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		result.put("returnUrl", super.getWholeUrl(request));
		putV("gSize", request, result);
		putV("wholeDay", request, result);

		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotEmpty(uuid) ){
			result.put("uuid", uuid);
		}
		if ( StringUtils.isBlank(uuid) ){
			return null;
		}
		BaseViewDO view = ateyeViewService.getView(uuid);
		if ( view ==null || view.getType() != BaseViewDO.TYPE_MULTI){
			return null;
		}
		boolean isOwn = false;
		if ( view.getOwner().equals(nick) ){
			isOwn = true;
		}
		result.put("owner",view.getOwner());
		result.put("isOwn",isOwn);
		List<BaseViewDO> myList = ateyeViewService.listAllViewOfUser(nick);
		boolean isFollowed = false;
		for ( BaseViewDO bv:myList ){
			if ( bv.getUuid().equals(uuid) ){
				isFollowed = true;
				break;
			}
		}
		result.put("followed", isFollowed);
		result.put("view",view);
		//1.��ȡ�����б�
		Map<SingleViewDO,Integer> viewOrders = new HashMap<SingleViewDO,Integer>();
		List<SingleViewDO> ss = new ArrayList<SingleViewDO>();
		MultiViewDO mv = (MultiViewDO) view;
		List<String> singleViewUUids = mv.getSingleViewUUids();
		int idx = 1;
		for ( String suuid:singleViewUUids ){
			BaseViewDO sview = ateyeViewService.getView(suuid);
			if ( sview == null || sview.getType() != BaseViewDO.TYPE_SINGLE ){
				continue;
			}
			SingleViewDO sv = (SingleViewDO) sview;
			ss.add(sv);
			viewOrders.put(sv, idx*10);
			idx ++;
		}
		result.put("sviews",ss);
		result.put("sviewOrders",viewOrders);
		//2.view����
		return VIEW_MULTI_DETAIL;
	}
	@RequestMapping("viewVirtualView.htm")
	public String viewVirtualView(final HttpServletRequest request,ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		result.put("returnUrl", super.getWholeUrl(request));
		result.put("gSize","big");
		putV("wholeDay", request, result);

		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotEmpty(uuid) ){
			result.put("uuid", uuid);
		}
		if ( StringUtils.isBlank(uuid) ){
			return null;
		}
		String[] split = uuid.split("_");
		if ( split.length < 2 ){
			return null;
		}
		String name = AteyeViewManager.getName(split[0]);
		if ( name == null ){
			return null;
		}
		result.put("name", name);
		return VIEW_VIRTUAL_VIEW;
	}
	@RequestMapping("viewDetail.htm")
	public String viewDetail(final HttpServletRequest request,ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		result.put("domain", ateyeConfig.getAteyeDomain());

		String nick = user.getNick();
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		result.put("returnUrl", super.getWholeUrl(request));

		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotEmpty(uuid) ){
			result.put("uuid", uuid);
		}
		if ( StringUtils.isBlank(uuid) ){
			return null;
		}
		BaseViewDO view = ateyeViewService.getView(uuid);
		if ( view == null || view.getType() != BaseViewDO.TYPE_SINGLE ){
			return null;
		}
		boolean isOwn = false;
		if ( view.getOwner().equals(nick) ){
			isOwn = true;
		}
		result.put("owner",view.getOwner());
		List<BaseViewDO> myList = ateyeViewService.listAllViewOfUser(nick);
		boolean isFollowed = false;
		for ( BaseViewDO bv:myList ){
			if ( bv.getUuid().equals(uuid) ){
				isFollowed = true;
				break;
			}
		}
		result.put("followed", isFollowed);
		/*appΪkey*/
		Map<String,Map<String,Boolean>> nodeInView = new HashMap<String,Map<String,Boolean>>();
		/*<encodeKey,<valueType,"">*/
		Map<String,Map<String,String>> nodes = new HashMap<String,Map<String,String>>();
		SingleViewDO sv = (SingleViewDO)view;
		result.put("view",sv);
		List<LineDefDO> lines = sv.getLines();
		Set<String> apps = new HashSet<String>();
		//step1.�ռ�KV�����ص�����
		for ( LineDefDO ldo:lines ){
			if ( ldo.getType().equals("kv") ){
				apps.add(ldo.getApp());
				Map<String,Boolean> mp = nodeInView.get(ldo.getApp());
				if ( mp == null ){
					mp = new HashMap<String,Boolean>();
					nodeInView.put(ldo.getApp(), mp);
				}
				boolean isRecord=false;
				if (StringUtils.isNotBlank(ldo.getK3()) ){
					KeysDO k = new KeysDO(new String[]{ldo.getK1(),ldo.getK2(),ldo.getK3()});
					mp.put(k.encode(),true);
					if ( !isRecord ){
						recordLine(nodes, ldo, k);
						isRecord = true;
					}
				}
				if (StringUtils.isNotBlank(ldo.getK2()) ){
					KeysDO k = new KeysDO(new String[]{ldo.getK1(),ldo.getK2()});
					mp.put(k.encode(),true);
					if ( !isRecord ){
						recordLine(nodes, ldo, k);
						isRecord = true;
					}
				}
				if (StringUtils.isNotBlank(ldo.getK1()) ){
					KeysDO k = new KeysDO(new String[]{ldo.getK1()});
					mp.put(k.encode(),true);
					if ( !isRecord ){
						recordLine(nodes, ldo, k);
						isRecord = true;
					}
				}
			}
		}
		result.put("nodeInView", nodeInView);//��Ҫչʾ�Ľڵ�
		result.put("nodeOfView",nodes);//view�еľ�������
		result.put("isOwn",isOwn);
		/*appΪkey*/
		//step1.1.��ȡKV����
		Map<String,MonitorLogNode[]> ret = new HashMap<String,MonitorLogNode[]>();
		for ( String app:apps ){
			MonitorLogNode[] monitorLog = _monitorLog(app, request, result,false);
			ret.put(app, monitorLog);
		}
		result.put("appResults",ret);
		//step2.�ռ�HSF�����ص�����
		/*key:app*/
		Map<String,List<HsfVO>> hsfResults = new HashMap<String,List<HsfVO>>();
		for ( LineDefDO ldo:lines ){
			if ( ldo.getType().equals("hsf") ){
				HsfVO vo = new HsfVO();
				vo.setApp(ldo.getApp());
				vo.setNode(new KeysDO(new String[]{ldo.getK1(),ldo.getK2(),ldo.getK3(),ldo.getK4(),ldo.getK5(),ldo.getK6()}));
				vo.setVt(ldo.getValueType());
				List<HsfVO> list = hsfResults.get(ldo.getApp());
				if ( list == null ){
					list = new ArrayList<HsfVO>();
					hsfResults.put(ldo.getApp(), list);
				}
				list.add(vo);
			}
		}
		result.put("hsfResults",hsfResults);
		//step4.�ж������������ͼ
		List<MultiViewDO> mViews = ateyeViewService.listMViewOfSView(uuid);
		result.put("mviews",mViews);
		return VIEW_DETAIL;
	}
	static
	private void recordLine(Map<String, Map<String, String>> nodes,
							LineDefDO ldo, KeysDO k) {
		Map<String, String> mm = nodes.get(k.encode());
		if ( mm == null ){
			mm = new HashMap<String, String>();
			nodes.put(k.encode(),mm);
		}
		mm.put(ldo.getValueType(), "");
	}
	@RequestMapping("monitorTree.htm")
	public String monitorTree(final HttpServletRequest request, ModelMap result) throws Exception {
		String key1 = request.getParameter("key1");
		String key2 = request.getParameter("key2");
		if ( StringUtils.isBlank(key1) ){
			return null;
		}
		key1 = UrlUtil.decodeUtf8(key1);
		if ( StringUtils.isNotBlank(key2) ){
			key2 = UrlUtil.decodeUtf8(key2);
			result.put("key2", key2);
		}
		result.put("key1", key1);
		//1.��ȡ����
		MonitorLogNode[] monitorLogs = _monitorLog(request, result);
		//2.�ҵ���Ӧkey1��key2�Ľڵ�
		MonitorLogNode selected = getSelecteNodeOfKey(key1, key2, monitorLogs);
		//3.
		result.put("node",selected);
		result.put("prefer",request.getParameter("prefer"));

		return MONITOR_TREE;
	}
	@RequestMapping("monitorCompare.htm")
	public String monitorCompare(final HttpServletRequest request, ModelMap result) throws Exception {
		String key1 = request.getParameter("key1");
		String key2 = request.getParameter("key2");
		String appName = SecurityUtil.escapeHtml(request.getParameter("app"));
		result.put("app", appName);
		if ( StringUtils.isBlank(key1) ){
			return null;
		}
		key1 = UrlUtil.decodeUtf8(key1);
		if ( StringUtils.isNotBlank(key2) ){
			key2 = UrlUtil.decodeUtf8(key2);
			result.put("key2", key2);
		}
		result.put("key1", key1);
		//1.��ȡ����
		MonitorLogNode[] monitorLogs = _monitorLog1(appName,request, result);
		//2.�ҵ���Ӧkey1��key2�Ľڵ�
		MonitorLogNode selected = getSelecteNodeOfKey(key1, key2, monitorLogs);
		result.put("node",selected);
		//3.��ȡ���Աȵ�����
		MonitorLogNode[] monitorLogs2 = _monitorLog2(appName,request, result);
		MonitorLogNode selected2 = getSelecteNodeOfKey(key1, key2, monitorLogs2);

		if ( selected == null || selected2 == null ){
			return null;
		}
		//4.��Node���жԱȣ��õ��ȶ����ݽṹ
		List<MonitorCompareResultDO> childRs = compareNode(selected,selected2);
		MonitorCompareResultDO selectedRs = new MonitorCompareResultDO(selected.getSelfKey(),selected, selected2);
		result.put("childRs", childRs);
		result.put("selectedRs", selectedRs);

		return MONITOR_COMPARE;
	}
	private List<MonitorCompareResultDO> compareNode(MonitorLogNode selected, MonitorLogNode selected2) {
		List<MonitorCompareResultDO> ret = new ArrayList<MonitorCompareResultDO>();
		Set<String> keys = new HashSet<String>();
		Map<String,MonitorLogNode> children1 = new HashMap<String,MonitorLogNode>();
		Map<String,MonitorLogNode> children2 = new HashMap<String,MonitorLogNode>();
		for ( MonitorLogNode n:selected.getChildren() ){
			children1.put(n.getSelfKey(), n);
			keys.add(n.getSelfKey());
		}
		for ( MonitorLogNode n:selected2.getChildren() ){
			children2.put(n.getSelfKey(), n);
			keys.add(n.getSelfKey());
		}
		for ( String k:keys ){
			MonitorLogNode n1 = children1.get(k);
			MonitorLogNode n2 = children2.get(k);
			String key = null;
			if ( n1 != null ){
				key = n1.getSelfKey();
			}else if ( n2 != null ){
				key = n2.getSelfKey();
			}
			if ( key == null ){
				continue;
			}
			ret.add(new MonitorCompareResultDO(key,children1.get(k),children2.get(k)));
		}
		return ret;
	}
	private MonitorLogNode getSelecteNodeOfKey(String key1, String key2,
											   MonitorLogNode[] monitorLogs) {
		for ( MonitorLogNode ml:monitorLogs ){
			if ( !key1.equals(ml.getSelfKey())) {
				continue;
			}
			if ( StringUtils.isBlank(key2) ){
				return ml;
			}
			for ( MonitorLogNode ml2:ml.getChildren() ){
				if ( key2.equals(ml2.getSelfKey())){
					return ml2;
				}
			}
		}
		return null;
	}

	@RequestMapping("sceneExceptionLog.htm")
	public String sceneExceptionLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String kw = request.getParameter("kw");
		result.put("kw", kw);
		List<MonitorItemDO> items  = new ArrayList<MonitorItemDO>();
		MonitorLogNode[] monitorLog = _monitorLog(request, result);
		for (MonitorLogNode node:monitorLog ) {
			items.add(new MonitorItemDO(node,"v2"));
			SortedSet<MonitorLogNode> children = node.getChildren();
			for (MonitorLogNode node2:children) {
				items.add(new MonitorItemDO(node2,"v2"));
			}
		}
		List<Pair<StackInfo,MonitorItemDO>> items2 = buildItems2(items);
		result.put("items", items2);
		//����ͼ��չʾ
		Map<String,List<KvGraphMonitorItemDO>> itemsMap = buildKvGraphParams(items);
		List<String> customeParams = kvGraphManager.buildParam(itemsMap,DataBuilder.graphSizeMap.get("xxs"));
		result.put("customParams", customeParams);
		result.put("itemsIdx",buildArrIdx(itemsMap));
		List<String> customeBigParams = kvGraphManager.buildParam(itemsMap,DataBuilder.defaultSize);
		result.put("customeBigParams", customeBigParams);
		return SCENE_EXCEPTION_LOG;
	}
	private List<List<KvGraphMonitorItemDO>> buildArrIdx(Map<String, List<KvGraphMonitorItemDO>> items) {
		List<List<KvGraphMonitorItemDO>> ret = new ArrayList<List<KvGraphMonitorItemDO>>();
		Collection<List<KvGraphMonitorItemDO>> values = items.values();
		for(List<KvGraphMonitorItemDO> it:values ){
			ret.add(it);
		}
		return ret;
	}
	private Map<String, List<KvGraphMonitorItemDO>> buildKvGraphParams(List<MonitorItemDO> items) {
		Map<String, List<KvGraphMonitorItemDO>> ret = new LinkedHashMap<String, List<KvGraphMonitorItemDO>>();
		//1.��������
		Collections.sort(items, new Comparator<MonitorItemDO>() {
			@Override
			public int compare(MonitorItemDO o1, MonitorItemDO o2) {
				return o2.getDValue().compareTo(o1.getDValue());
			}
		});
		//2.�ֶ�
		int perGraph = 3;
		for (int i=0;i<items.size();++i ) {
			MonitorItemDO item = items.get(i);
			if ( item.getNode().getLevel() == 1 ) {//��һ��Ͳ�չʾ��ͼ������
				continue;
			}
			int graphNo = i/perGraph;
			String graphKey = "ͼ"+graphNo;
			List<KvGraphMonitorItemDO> list = ret.get(graphKey);
			if ( list == null ) {
				list = new ArrayList<KvGraphMonitorItemDO>();
				ret.put(graphKey, list);
			}
			list.add(new KvGraphMonitorItemDO(items.get(i)));
		}
		return ret;
	}
	private List<Pair<StackInfo, MonitorItemDO>> buildItems2(List<MonitorItemDO> items) {
		List<Pair<StackInfo,MonitorItemDO>> ret = new ArrayList<Pair<StackInfo,MonitorItemDO>>();
		for (MonitorItemDO item:items ) {
			String st = item.getNode().getSelfKey();
			StackInfo si = StackInfoUtil.parseStackInfo(st);
			ret.add(Pair.of(si,item));
		}
		Collections.sort(ret, new Comparator<Pair<StackInfo,MonitorItemDO>>(){
			@Override
			public int compare(Pair<StackInfo, MonitorItemDO> o1, Pair<StackInfo, MonitorItemDO> o2) {
				return o2.getValue().getDValue().compareTo(o1.getValue().getDValue());
			}
			
		});
		return ret;
	}
	@RequestMapping("monitorLog.htm")
	public String monitorLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String kw = request.getParameter("kw");
		result.put("kw", kw);
		MonitorLogNode[] monitorLog = _monitorLog(request, result);
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		result.put("beta",beta);
		//���ҹ�ע��Keys
		String appName = SecurityUtil.escapeHtml(request.getParameter("app"));
		UserDO user = (UserDO) MyThreadLocal.get();
		List<UserFavor> favorItems = hbaseReadService.getFavorItems(user.getNick(), getKVItemType(appName) );
		if ( favorItems.size() > 0 ){
			Map<String,UserFavor> noDataMap = new HashMap<String,UserFavor>();//�����ݵ�Map
			Map<String,UserFavor> favorMap = new HashMap<String,UserFavor>();
			for ( UserFavor uf:favorItems ){
				favorMap.put(uf.getDesc(), uf);
				noDataMap.put(uf.getDesc(), uf);
			}
			/*encodeKey*/
			Map<String,Boolean> nodeHasFavor = new HashMap<String,Boolean>();
			//���������ɸ���encodedKey��Map
			for ( MonitorLogNode node1:monitorLog ){
				for ( MonitorLogNode node2:node1.getChildren() ){
					for ( MonitorLogNode node3:node2.getChildren() ){
						if ( favorMap.containsKey(node3.getEncodedKey()) ){
							nodeHasFavor.put(node3.getEncodedKey(), true);
							nodeHasFavor.put(node2.getEncodedKey(), true);
							nodeHasFavor.put(node1.getEncodedKey(), true);
							noDataMap.remove(node3.getEncodedKey());
						}
					}
					if ( favorMap.containsKey(node2.getEncodedKey()) ){
						nodeHasFavor.put(node2.getEncodedKey(), true);
						nodeHasFavor.put(node1.getEncodedKey(), true);
						noDataMap.remove(node2.getEncodedKey());
					}
				}
				if ( favorMap.containsKey(node1.getEncodedKey()) ){
					nodeHasFavor.put(node1.getEncodedKey(), true);
					noDataMap.remove(node1.getEncodedKey());
				}
			}
			result.put("favorKeys", favorMap);
			if ( !noDataMap.isEmpty() ){
				Map<String,KeysDO> noDatas = new HashMap<String,KeysDO>();
				for ( String ek:noDataMap.keySet() ){
					noDatas.put(ek, new KeysDO(ek));
				}
				result.put("noFavorDatas", noDatas);
			}
			result.put("hasFavor", nodeHasFavor);
		}
		//���������˱�����Key
		List<AlarmNewRuleVO> ruleVOS = alarmManager.getNewRule(appName);
//		List<AlarmRuleDO> alarmRules = hbaseReadService.getAlarmRulesByApp(appName);
		if ( !ruleVOS.isEmpty() ){
//			Map<String, Map<String, List<AlarmRuleDO>>> groupRules = alarmRuleManager.groupAlarmRules(alarmRules);

			Map<String, Map<String, List<AlarmNewRuleVO>>> groupRules = alarmRuleManager.groupAlarmRulesNew(ruleVOS);
			groupRules = filtKVRulesNew(groupRules);
			//ֻ��ȡKV��������
			result.put("hasRuleMap",groupRules);
			Map<String, Map<String, List<AlarmNewRuleVO>>> noAlarmMap = new HashMap<String, Map<String, List<AlarmNewRuleVO>>>();//�����ݵ�Map
			Map<String,String> alarmMap = new HashMap<String,String>();
			for ( String ek:groupRules.keySet() ){
				noAlarmMap.put(ek,groupRules.get(ek));
				alarmMap.put(ek,ek);
			}
			/*encodeKey*/
			Map<String,Boolean> nodeHasAlarm = new HashMap<String,Boolean>();
			//���������ɸ���encodedKey��Map
			for ( MonitorLogNode node1:monitorLog ){
				for ( MonitorLogNode node2:node1.getChildren() ){
					for ( MonitorLogNode node3:node2.getChildren() ){
						if ( alarmMap.containsKey(node3.getEncodedKey()) ){
							nodeHasAlarm.put(node3.getEncodedKey(), true);
							nodeHasAlarm.put(node2.getEncodedKey(), true);
							nodeHasAlarm.put(node1.getEncodedKey(), true);
							noAlarmMap.remove(node3.getEncodedKey());
						}
					}
					if ( alarmMap.containsKey(node2.getEncodedKey()) ){
						nodeHasAlarm.put(node2.getEncodedKey(), true);
						nodeHasAlarm.put(node1.getEncodedKey(), true);
						noAlarmMap.remove(node2.getEncodedKey());
					}
				}
				if ( alarmMap.containsKey(node1.getEncodedKey()) ){
					nodeHasAlarm.put(node1.getEncodedKey(), true);
					noAlarmMap.remove(node1.getEncodedKey());
				}
			}
			if ( !noAlarmMap.isEmpty() ){
				Map<String,KeysDO> noDatas = new HashMap<String,KeysDO>();
				for ( String ek:noAlarmMap.keySet() ){
					noDatas.put(ek, new KeysDO(ek));
				}
				result.put("noAlarmDatas", noDatas);
			}
			result.put("hasAlarms", nodeHasAlarm);
		}
		//�鿴����hse���ݵ���ͼ
		List<SingleViewDO> views = ateyeViewService.listSViewOfApp(appName, LineDefDO.TYPE_KV);
		result.put("views",views);

		return MONITOR_LOG;
	}
	private Map<String, Map<String, List<AlarmRuleDO>>> filtKVRules(
			Map<String, Map<String, List<AlarmRuleDO>>> groupRules) {
		Map<String,Map<String,List<AlarmRuleDO>>> ret = new HashMap<String,Map<String,List<AlarmRuleDO>>>();
		for ( Map.Entry<String, Map<String, List<AlarmRuleDO>>> ent:groupRules.entrySet() ){
			Map<String, List<AlarmRuleDO>> value = ent.getValue();
			boolean isKVRule = false;
			for ( List<AlarmRuleDO> rules:value.values() ){
				for ( AlarmRuleDO rule:rules ){
					if (RuleTypeConstant.isTypeKV(rule)){
						isKVRule = true;
						break;
					}
				}
				if ( isKVRule ){
					break;
				}
			}
			if ( isKVRule ){
				ret.put(ent.getKey(), ent.getValue());
			}
		}
		return ret;
	}

	private Map<String, Map<String, List<AlarmNewRuleVO>>> filtKVRulesNew(
			Map<String, Map<String, List<AlarmNewRuleVO>>> groupRules) {
		Map<String,Map<String,List<AlarmNewRuleVO>>> ret = new HashMap<String,Map<String,List<AlarmNewRuleVO>>>();
		for ( Map.Entry<String, Map<String, List<AlarmNewRuleVO>>> ent:groupRules.entrySet() ){
			Map<String, List<AlarmNewRuleVO>> value = ent.getValue();
			boolean isKVRule = false;
			for ( List<AlarmNewRuleVO> rules:value.values() ){
				for ( AlarmNewRuleVO rule:rules ){
					if (RuleTypeConstant.isTypeKV(rule.getRuleContext().getItemDO().getRuleType())){
						isKVRule = true;
						break;
					}
				}
				if ( isKVRule ){
					break;
				}
			}
			if ( isKVRule ){
				ret.put(ent.getKey(), ent.getValue());
			}
		}
		return ret;
	}
	public static class KLevel{
		private String k1;
		private String k2;
		private String k3;
		public KLevel(MonitorLogNode node){
			String fullKey = node.getFullKey();
			if ( StringUtils.isNotBlank(fullKey) ){
				String[] keys = fullKey.split("" + (char)1);
				if ( keys.length > 0){
					setK1(keys[0]);
				}
				if ( keys.length > 1 ){
					setK2(keys[1]);
				}
				if ( keys.length > 2 ){
					setK3(keys[2]);
				}
			}
		}
		public void setK1(String k1) {
			this.k1 = k1;
		}
		public String getK1() {
			return k1;
		}
		public void setK2(String k2) {
			this.k2 = k2;
		}
		public String getK2() {
			return k2;
		}
		public void setK3(String k3) {
			this.k3 = k3;
		}
		public String getK3() {
			return k3;
		}
	}
	/*
	 * ��ȡ��һ������
	 */
	private MonitorLogNode[] _monitorLog1(String appName,final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String endDateStr = request.getParameter("endDate");
		String hour = request.getParameter("hour");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			Date dd = DateUtils.addHours(new Date(), -2);
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(dd));
			//Ϊ��ʱ,hourֵΪ��ǰֵ-2
			hour = CalendarUtil.toString(dd, "HH");
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		result.put("endDate", DateFormatUtil.formatToDay(endDate));
		int hourH = -1;
		if ( StringUtils.isNotBlank(hour) ){
			hourH = Integer.valueOf(hour);
			result.put("hour",hourH);
		}
		return _monitorLog(appName,startDate,endDate,hourH,-1,request,result,false);
	}
	/*
	 * ��ȡ�ڶ�������
	 */
	private MonitorLogNode[] _monitorLog2(String appName,final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate2");
		String endDateStr = request.getParameter("endDate2");
		String hour = request.getParameter("hour2");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			Date dd = DateUtils.addHours(new Date(), -1);
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(dd));
			//Ϊ��ʱ,hourֵΪ��ǰֵ-1
			hour = CalendarUtil.toString(dd, "HH");
		}

		result.put("startDate2", DateFormatUtil.formatToDay(startDate));
		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		result.put("endDate2", DateFormatUtil.formatToDay(endDate));
		int hourH = -1;
		if ( StringUtils.isNotBlank(hour) ){
			hourH = Integer.valueOf(hour);
			result.put("hour2",hourH);
		}
		return _monitorLog(appName,startDate,endDate,hourH,-1,request,result,false);
	}
	private MonitorLogNode[] _monitorLog(String appName, final HttpServletRequest request, ModelMap result, boolean beta) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String endDateStr = request.getParameter("endDate");
		String hour = request.getParameter("hour");
		String min5 = request.getParameter("min5");//��ѯ������
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		result.put("endDate", DateFormatUtil.formatToDay(endDate));
		int hourH = -1;
		if ( StringUtils.isNotBlank(hour) ){
			hourH = Integer.valueOf(hour);
			result.put("hour",hourH);
		}
		int min5H = -1;
		if ( StringUtils.isNotBlank(min5) ){
			min5H = Integer.valueOf(min5);
			result.put("min5H",min5H);
		}
		return _monitorLog(appName,startDate,endDate,hourH,min5H, request,result,beta);
	}
	private MonitorLogNode[] _monitorLog(String appName,Date startDate,Date endDate,int hour,int min5H,final HttpServletRequest request, ModelMap result,boolean beta) throws Exception {
		String k1Keyword = request.getParameter("kw");
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(endDate);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		endDate = calendar.getTime();
		result.put("endDate4HBase", DateFormatUtil.formatToDay(endDate));
		int total = 0;
		try {
			SortedSet<MonitorLogNode> results = new TreeSet<MonitorLogNode>();
			//���ERROR_DETAIL���������ⳡ�������ָ����K1���Ͳ�Ҫȫ�����ˣ�ֱ���ߵ������������ȥ
			if ( "_ERROR_DETAIL_".equals(appName) && StringUtils.isNotBlank(k1Keyword)){
				;//do nothing���ߺ�����߼�
			}else {
				if ( hour >= 0 ){
					if ( min5H >=0 ){
						Date dt = CalendarUtil.zerolizedTime(startDate);
						dt = DateUtils.addHours(dt, hour);
						dt = DateUtils.addMinutes(dt, min5H);
						results = monitorLogQueryService.newQuery5MinMonitorLogInfoOfApp(appName, dt,beta?EnvIdType.BETA.getEnvId():"");//��ѯ����ʱ��
					}else{
						results = monitorLogQueryService.newQueryHourMonitorLogInfoOfApp(appName, startDate, hour,beta?EnvIdType.BETA.getEnvId():"");//��ѯ����ʱ��
					}
				}else{
					results = monitorLogQueryService.newQueryMonitorLogInfoOfApp(appName, startDate, startDate,beta?EnvIdType.BETA.getEnvId():"");//��֧�ֲ�ѯ����ģ�����endDate���ó�startaDate����!! TODO:�޸�һ������
				}
			}
			//0.���Ĭ������������˵�����Key;���û������KWʱ�����ĳЩKey�Ͳ���չʾ�ˣ���������ʱ���չʾ����
			if ( StringUtils.isBlank(k1Keyword) || k1Keyword.equals("null")){
				Iterator<MonitorLogNode> iterator = results.iterator();
				while ( iterator.hasNext() ){
					MonitorLogNode mln= iterator.next();
					if ( mln.getSelfKey().startsWith("#DEFAULT#|__MLINK_ANALYSE__|")
					|| mln.getSelfKey().startsWith("#DEFAULT#|_TDDL_STAT5_|")
					|| mln.getSelfKey().startsWith("#DEFAULT#|_MSG_STAT_|")
					|| mln.getSelfKey().startsWith("#DEFAULT#|_TAIR_STAT_|")
					|| mln.getSelfKey().startsWith("#DEFAULT#_SYSTEM_")
					){
						iterator.remove();
					}
				}
			}
			//1.����йؼ��ʣ����ݹؼ��ʹ���һ��
			filtByK1Keywords(results,k1Keyword);
			//1.1.������˺�Ϊ�գ���level1����ȷ��ѯ
			if ( StringUtils.isNotBlank(k1Keyword) && results.isEmpty() ) {
				if ( hour >= 0 ){
					results = monitorLogQueryService.newQueryHourMonitorLogInfoOfApp(appName, k1Keyword, startDate, hour,beta?EnvIdType.BETA.getEnvId():"");//��ѯ����ʱ��
				}else{
					results = monitorLogQueryService.newQueryMonitorLogInfoOfApp(appName, k1Keyword, startDate, startDate,beta?EnvIdType.BETA.getEnvId():"");//��֧�ֲ�ѯ����ģ�����endDate���ó�startaDate����!! TODO:�޸�һ������
				}
			}
			//2.����
			//3....
			List<MonitorLogNode> rrs = sortNode(results);//����
			MonitorLogNode[] ret = rrs.toArray(new MonitorLogNode[0]);
			for ( MonitorLogNode node1:ret ){
				for ( MonitorLogNode node2:node1.getChildren() ){
					total+=node2.getChildren().size();
				}
				total+=node1.getChildren().size();
			}
			total+=ret.length;
			//4.��ȡ����KVϸ�ڵĽڵ�
			result.put("kvDetails",kvDetailManager.getHasKvDetailNodes(appName, startDate, hour));
			result.put("total", total);
			result.put("appName", appName);
			if(total>ateyeConfig.getKvViewMaxCount()){
				result.put("reduce", true);
				result.put("maxCount", ateyeConfig.getKvViewMaxCount());
				int maxK1Count = 0;
				int index = 0;
				for ( MonitorLogNode node1:ret ){
					maxK1Count++;
					for ( MonitorLogNode node2:node1.getChildren() ){
						total+=node2.getChildren().size();
						index+=node2.getChildren().size();
					}
					total+=node1.getChildren().size();
					index+=node1.getChildren().size();
					if(index > ateyeConfig.getKvViewMaxCount()){
						break;
					}
				}

				result.put("results", Arrays.copyOfRange(cutKeyLength(ret),0,maxK1Count));
			}else{
				result.put("results", cutKeyLength(ret));
			}

			return ret;
		} catch (Exception e) {
			log.error("HubMonitorController::queryMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
			return null;
		}
	}

	private MonitorLogNode[] cutKeyLength(MonitorLogNode[] ret) {
		if(ret!=null){
			for ( MonitorLogNode node1:ret ){
				node1.setSelfKey(subString(node1.getSelfKey()));
				if(node1.getChildren()==null){
					continue;
				}
				for ( MonitorLogNode node2:node1.getChildren() ){
					node2.setSelfKey(subString(node2.getSelfKey()));
					if(node2.getChildren()==null){
						continue;
					}
					for ( MonitorLogNode node3:node2.getChildren() ){
						node3.setSelfKey(subString(node3.getSelfKey()));

					}
				}
			}
		}
		return ret;
	}

	private String subString(String source){
		if(StringUtils.isNotEmpty(source) && source.length()>ateyeConfig.getKeyMaxLength()){
			return source.substring(0,ateyeConfig.getKeyMaxLength());
		}
		return source;
	}

	private void filtByK1Keywords(SortedSet<MonitorLogNode> results,
								  String k1Keyword) {
		if ( StringUtils.isBlank(k1Keyword) ){
			return;
		}
		String kw = StringUtils.lowerCase(k1Keyword);
		Iterator<MonitorLogNode> iterator = results.iterator();
		while ( iterator.hasNext() ){
			MonitorLogNode next = iterator.next();
			String selfKey = next.getSelfKey();
			//ȫתСд������������ؼ��֣�����˵�
			if (!StringUtils.lowerCase(selfKey).contains(kw) ){
				iterator.remove();
			}
		}
	}
	private MonitorLogNode[] _monitorLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String appName = SecurityUtil.escapeHtml(request.getParameter("app"));
		result.put("app", appName);
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		return _monitorLog(appName, request, result,beta);

	}
	private static Map<String,Integer> keyOrder = new LinkedHashMap<String,Integer>();
	private static int defaultOrder = 1000;
	static{
		keyOrder.put("DB", 1001);//�����.
		keyOrder.put("#HIT_RATE", 1);
		keyOrder.put("#RT", 2);
		keyOrder.put("#QPS", 3);
		keyOrder.put("#FAIL_RATE", 4);
	}
	private static Integer contains(MonitorLogNode node){
		String selfKey = node.getSelfKey();
		for ( String k:keyOrder.keySet() ){
			if ( selfKey.contains(k) ){
				return keyOrder.get(k);
			}
		}
		return defaultOrder;
	}
	private List<MonitorLogNode> sortNode(SortedSet<MonitorLogNode> results) {
		List<MonitorLogNode> cc = new ArrayList<MonitorLogNode>(results);
		Collections.sort(cc, new Comparator<MonitorLogNode>() {
			@Override
			public int compare(MonitorLogNode o1, MonitorLogNode o2) {
				return contains(o1)-contains(o2);
			}
		});
		return cc;
	}

	@RequestMapping("dumpHsfMonitorLog.htm")
	public String dumpHsfMonitorLog(final HttpServletRequest request, final HttpServletResponse response,ModelMap result) throws Exception {
		MonitorLogNode[] monitorLog = _hsfMonitorLog(request, result);
		_dumpMonitorLog(request, response, result, monitorLog,"hsf");
		return null;
	}

	@RequestMapping("dumpMonitorLog.htm")
	public String dumpMonitorLog(final HttpServletRequest request, final HttpServletResponse response,ModelMap result) throws Exception {
		MonitorLogNode[] monitorLog = _monitorLog(request,result);
		_dumpMonitorLog(request, response, result, monitorLog,"kv");
		return null;
	}
	private void _dumpMonitorLog(final HttpServletRequest request, final HttpServletResponse response,ModelMap result,MonitorLogNode[] monitorLog,String name) throws Exception {
		String app = SecurityUtil.escapeHtml(request.getParameter("app"));
		String day = request.getParameter("startDate");
		response.setContentType("application/csv;charset=gb18030");
		response.setHeader("Content-Disposition","attachment; filename=\"" + name+"_"+app+"_"+day + ".csv" + "\"");
		PrintWriter out = response.getWriter();
		for ( MonitorLogNode node:monitorLog ){
			out.printf("%s,%s,%s,%d,%d,%f,%f\n", node.getSelfKey(),"","",node.getValue1(),node.getValue2(),node.getV1v2(),node.getV2v1());
			SortedSet<MonitorLogNode> children = node.getChildren();
			for ( MonitorLogNode c2:children ){
				out.printf("%s,%s,%s,%d,%d,%f,%f\n", node.getSelfKey(),c2.getSelfKey(),"",c2.getValue1(),c2.getValue2(),c2.getV1v2(),c2.getV2v1());
				SortedSet<MonitorLogNode> children3 = c2.getChildren();
				for ( MonitorLogNode c3:children3 ){
					out.printf("%s,%s,%s,%d,%d,%f,%f\n", node.getSelfKey(),c2.getSelfKey(),c3.getSelfKey(),c3.getValue1(),c3.getValue2(),c3.getV1v2(),c3.getV2v1());
				}
			}
		}
		out.close();
	}
	@RequestMapping("hsfMonitorLog.htm")
	public String hsfMonitorLog(final HttpServletRequest request, ModelMap result) throws Exception {
		_hsfMonitorLog(request, result);
		return HSF_MONITOR_LOG;
	}
	@RequestMapping("serviceMonitorLog.htm")
	public String serviceMonitorLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String hsf = request.getParameter("hsf");
		result.put("hsf", hsf);
		String method = request.getParameter("method");
		result.put("method", method);
		//���⴦��searchTax~T�����Ѷ�ΪsearchTax�����
		if (StringUtils.isNotBlank(method) ){
			int ind= method.indexOf("~");
			if ( ind != -1 ){
				result.put("methodPrefix", method.substring(0, ind));
			}
		}
		String startDateStr = request.getParameter("startDate");
		String endDateStr = request.getParameter("endDate");

		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		result.put("endDate", DateFormatUtil.formatToDay(endDate));
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(endDate);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		endDate = calendar.getTime();
		result.put("endDate4HBase", DateFormatUtil.formatToDay(endDate));
		Map<String,String> typeDesc = new LinkedHashMap<String,String>();
		typeDesc.put("HSF-ProviderDetail","�ṩ��");
		typeDesc.put("HSF-Consumer","������");
		result.put("typeDesc",typeDesc);
		try {
			SortedSet<MonitorLogNode> results = monitorLogQueryService.getHsfStats(startDate, hsf);
			MonitorLogNode[] ret = results.toArray(new MonitorLogNode[0]);
			Map<String,MonitorLogNode> nodes = new HashMap<String,MonitorLogNode>();
			for ( MonitorLogNode n:ret ){
				for ( String type:typeDesc.keySet() ){
					if ( n.getSelfKey().equals(type) ){
						nodes.put(type, n);
					}
				}
			}
			result.put("nodes", nodes);
		} catch (Exception e) {
			log.error("HubMonitorController::queryHsfMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
		}
		return SERVICE_MONITOR_LOG;
	}
	private MonitorLogNode[] _hsfMonitorLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String appName = SecurityUtil.escapeHtml(request.getParameter("app"));
		result.put("app", appName);
		String startDateStr = request.getParameter("startDate");
		String endDateStr = request.getParameter("endDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		result.put("endDate", DateFormatUtil.formatToDay(endDate));
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(endDate);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		endDate = calendar.getTime();
		result.put("endDate4HBase", DateFormatUtil.formatToDay(endDate));
		try {
			SortedSet<MonitorLogNode> results = monitorLogQueryService.newQueryHsfMonitorLogInfoOfApp(appName, startDate, endDate);
			MonitorLogNode[] ret = results.toArray(new MonitorLogNode[0]);
			result.put("appName", appName);
			result.put("results", ret );
			return ret;
		} catch (Exception e) {
			log.error("HubMonitorController::queryHsfMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
			return null;
		}
	}
	@RequestMapping("trackerSpeed.htm")
	public String trackerSpeed(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		initBizMap(result);
		try {
			Map<Integer, Map<String, HbaseStat>> monitorLogStats = trackerInfoManager.getStatByAppAndType(startDate);
			result.put("statMap",monitorLogStats);
			//4.�����ͻ���
			Map<Integer,HbaseStat> sum = sum(monitorLogStats);
			result.put("sumMap", sum );
			result.put("typeMap", TrackerTypeConstant.typeDesc);
		} catch (Exception e) {
			log.error("HubMonitorController::queryMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
		}
		return SPEED_TRACKER;
	}

	@RequestMapping("trackerMonitor.htm")
	public String trackerMonitor(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		String all = request.getParameter("all");
		int limitNumber = 500;
		if ( StringUtils.isNotBlank(all) ){
			limitNumber = -1;
		}
		List<TrackerMonitorDO> statList = trackerInfoManager.getTrackerStatListByTask(startDate,limitNumber);
		result.put("statList",statList);
		result.put("app","tracker");
		result.put("total",getTotal(statList));
		return MONITOR_TRACKER;
	}
	@RequestMapping("trackerMonitorOfType.htm")
	public String trackerMonitorOfType(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		List<TrackerMonitorDO> statList = trackerInfoManager.getTrackerStatListByType(startDate);
		result.put("statList",statList);
		result.put("app","tracker");
		result.put("total",getTotal(statList));
		return MONITOR_TRACKER_TYPE;
	}
	private TrackerMonitorDO getTotal(List<TrackerMonitorDO> statList){
		TrackerMonitorDO total = new TrackerMonitorDO();
		for ( TrackerMonitorDO stat:statList ){
			total.add(stat);
		}
		return total;
	}
	@RequestMapping("trackerMonitorOfApp.htm")
	public String trackerMonitorOfApp(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		List<TrackerMonitorDO> statList = trackerInfoManager.getTrackerStatListByApp(startDate);
		result.put("statList",statList);
		result.put("app","tracker");
		result.put("total",getTotal(statList));
		return MONITOR_TRACKER_APP;
	}
	private Map<Integer, HbaseStat> sum(
			Map<Integer, Map<String, HbaseStat>> monitorLogStats) {
		Map<Integer,HbaseStat> ss = new HashMap<Integer,HbaseStat>();
		for ( Map.Entry<Integer, Map<String, HbaseStat>> ent:monitorLogStats.entrySet() ){
			ss.put(ent.getKey(), sumDetail(ent.getValue()));
		}
		return ss;
	}
	private HbaseStat sumDetail(Map<String,HbaseStat> stats){
		HbaseStat st = new HbaseStat();
		for ( HbaseStat s:stats.values() ){
			st.addIncrTimes(s.getTotalIncrTimes());
			st.addPutBytes(s.getTotalPutBytes());
			st.addPutTimes(s.getTotalPutTimes());
		}
		return st;
	}


	@RequestMapping("hsfMonitorLogList.htm")
	public String hsfMonitorLogList(final HttpServletRequest request, ModelMap result) throws Exception {
		result.put("to", "/hsf/appServiceList.htm");
		result.put("level2","HSF");
		result.put("level2Url","/hubmonitor/hsfMonitorLogList.htm");
		if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
		}
		return "screen/common/commonSelectApp";
	}
	@RequestMapping("monitorLogList.htm")
	public String monitorLogList(final HttpServletRequest request, ModelMap result) throws Exception {
		result.put("to", "/hubmonitor/monitorLog.htm");
		result.put("level2","K/V���");
		result.put("level2Url","/hubmonitor/monitorLogList.htm");
		if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
		}
		return "screen/common/commonSelectApp";
	}
	@RequestMapping("sqlmap.htm")
	public String sqlmap(final HttpServletRequest request, ModelMap result) throws Exception {
		String appName = SecurityUtil.escapeHtml(request.getParameter("app"));

		//1.��ȡ����
		String app= SecurityUtil.escapeHtml(request.getParameter("app"));
		String biz = request.getParameter("biz");
		if ( StringUtils.isEmpty(app) && StringUtils.isEmpty(biz) ){
			//����ҵ���ߵķ���
			result.put("to", "/hubmonitor/sqlmap.htm");
			result.put("level2","sqlmap");
			result.put("level2Url","/hubmonitor/sqlmap.htm");
			if ( initBizMapOwned(result) == null ){
				return "redirect:/noPermission.htm";
			}
			return "screen/common/commonSelectApp";
		}
		if ( StringUtils.isNotBlank(biz) ){
			result.put("biz",biz);
		}
		String startDateStr = request.getParameter("startDate");
		String endDateStr = request.getParameter("endDate");
		String sortBy = request.getParameter("sortBy");
		if ( StringUtils.isBlank(sortBy) ){
			sortBy = "0";
		}
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));

		Date endDate = null;
		if(StringUtils.isNotBlank(endDateStr)) {
			endDate = DateFormatUtil.parseByDay(endDateStr);
		} else {
			endDate = startDate;
		}
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(endDate);
		calendar.add(Calendar.DAY_OF_YEAR, 1);

		endDate = calendar.getTime();
		result.put("endDate4HBase", DateFormatUtil.formatToDay(endDate));
		result.put("endDate", DateFormatUtil.formatToDay(endDate));
		Long tic = System.currentTimeMillis();

		try {
			if ( StringUtils.isNotBlank(appName) ){
				SortedSet<MonitorLogNode> results = monitorLogQueryService.newQueryMonitorLogInfoOfApp(appName,"#RT#DB", startDate, startDate);
				result.put("app", appName);
				Map<OpType, List<StatementDO>> sts = statementManager.getStatements(results, Integer.valueOf(sortBy));
				result.put("sts",sts);
			}else if(StringUtils.isNotBlank(biz)){
				result.put("biz",biz);
				result.put("bizName", biz);

				List<AppDO> apps = appDAO.queryAppByBizType(biz);
				String[] appNameArray = new String[apps.size()];
				int idx =0;
				for ( AppDO appDO:apps ){
					appNameArray[idx++] = appDO.getAppName();
				}
				SortedSet<MonitorLogNode>  results = querySqlmapManager.newQueryMonitorLogInfoOfApp(appNameArray, startDate);
				Map<OpType, List<StatementDO>> sts = statementManager.getStatements(results, Integer.valueOf(sortBy));
				result.put("sts",sts);
				ColorUtil.assignColor(result, Arrays.asList(appNameArray), "app");

			}
			result.put("sortBy", sortBy);
			result.put("used",System.currentTimeMillis()-tic);
		} catch (Exception e) {
			log.error("HubMonitorController::queryMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
		}
		//2.��ȡ��������
		if ( StringUtils.isBlank(biz) ){
			AppDO appN= appDAO.getAppByName(appName);
			if ( appN == null ){
				return "";
			}
			boolean support = sqlMapBlackManager.isSupportBlackSqlMap(app);
			String black = request.getParameter("black");
			result.put("black",black);
			if ( StringUtils.isNotBlank(black) && black.equals("1")){
				//2.1.���汾�Ƿ�����
				if ( !support ){
					result.put("noSupport","ϵͳ��⵽���Ӧ��ateye-client�汾���ͣ���������1.6.2-SNAPSHOT����");
				}else{
					result.put("support", true);
				}
			}
			//2.1.��ȡ��black��sql
			if ( support ){
				Map<String, Set<String>> blackSqls = sqlMapBlackManager.getBlackSqlList(app);
				result.put("blackSqls", blackSqls);
			}
			List<MachineDO> machinesOfAnApp = machineDAO.getMachinesOfAnApp(appN.getId(), environmentService.getEnvironmentType().ordinal());
			result.put("servers", machinesOfAnApp);
			result.put("returnUrl", super.getWholeUrl(request,""));
		}
		return SQLMAP;
	}
	@RequestMapping("doBlackSql.htm")
	public String doBlackSql(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws Exception {
		String app = SecurityUtil.escapeHtml(request.getParameter("app"));
		String sql = request.getParameter("sql");
		String action = request.getParameter("action");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(sql) || StringUtils.isBlank(action) ){
			return "";
		}
		if ( action.equals("add") ){
			sqlMapBlackManager.batchAddSql(app, sql);
		}else if ( action.equals("remove")){
			sqlMapBlackManager.batchRemoveSql(app, sql);
		}
		return getRedirectUrl(request, response);
	}
	@RequestMapping("sqlmapHistory.htm")
	public String sqlmapHistory(final HttpServletRequest request, ModelMap result) throws Exception {
		result.put("app", request.getParameter("app"));
		String keys = request.getParameter("keys");
		String decodedKeys = URLDecoder.decode(request.getParameter("keys"), "utf8");
		keys = URLEncoder.encode(URLEncoder.encode(decodedKeys, "utf8"), "utf8");
		result.put("keys", keys);
		setStartAndEndDate(request,result);
		result.put("valueType", request.getParameter("valueType"));
		String sql = request.getParameter("sql");
		result.put("sql", sql);
		result.put("keys2", request.getParameter("keys"));

		return SQLMAP_HISTORY;
	}
	@RequestMapping("history2.htm")
	public String history2(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("appName");
		String valueType = request.getParameter("valueType");
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		result.put("beta",beta);
		result.put("app", app);
		result.put("valueType", valueType);
		String appName2 = request.getParameter("appName2");
		String valueType2 = request.getParameter("valueType2");
		result.put("appName2", appName2);
		result.put("valueType2", valueType2);
		String mday = request.getParameter("mday");
		String mday2 = request.getParameter("mday2");
		result.put("mday", mday);
		result.put("mday2", mday2);
		String keys = request.getParameter("keys");
		String decodedKeys = URLDecoder.decode(request.getParameter("keys"), "utf8");
		keys = URLEncoder.encode(URLEncoder.encode(decodedKeys, "utf8"), "utf8");
		setStartAndEndDate(request, result);
		result.put("keys", keys);
		result.put("keys2", request.getParameter("keys"));
		_commonRuleSetting(request, result, app, valueType, keys);
		result.put("ruleTypePrefix", RuleTypeConstant.PREFIX_TYPE_KV);
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByApp(app);
		result.put("alarmGrps", alarmGroups);
		KeysDO k = new KeysDO(keys);
		List<String> keyList = k.getKeys();
		if ( keyList.size() == 6){
			Map<String, String> ruleExamples = getRuleExample("kv",app, valueType,appName2,valueType2, keyList);
			result.put("examples",ruleExamples);
		}else{
			Map<String, String> ruleExamples = getRuleExample("kv",app, valueType, keyList);
			result.put("examples",ruleExamples);
		}
		if ( app.startsWith("_VIRTUAL_SCENE") || app.startsWith("_ERROR") ){
			result.put("isVirtualScene", "1");
			if ( app.equals("_VIRTUAL_SCENE")){
				SceneTrackerLog scene = TrackerLogConvertUtils.parseAteye(keyList.get(0), keyList.get(1), keyList.size()>=2?keyList.get(2):"");
				result.put("sceneObj", scene);
			}else if ( app.equals("_VIRTUAL_SCENE_ENTRY") ){
				if ( keyList.get(0).contains(SceneContants.KEY_INNER_SPLITTER_1) ){
					String[] parts = keyList.get(0).split(SceneContants.KEY_INNER_SPLITTER_1);
					result.put("entryObj",parts);
					result.put("entryName",parts[1]);
					result.put("entryObj2",keyList.size()>=2?keyList.get(1):"-");
				}
			}else if ( app.equals("_ERROR_DETAIL_") ){
				if ( keyList.get(0).contains("@@") ){
					String[] parts = keyList.get(0).split("@@");
					result.put("entryName",parts[0]);
					result.put("entryObj",parts);
				}
			}
		}else{
			result.put("isVirtualScene", "0");
		}
		return HISTORY_INFO2;
	}
	@RequestMapping("historyDay.htm")
	public String historyDay(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("appName");
		String valueType = request.getParameter("valueType");
		result.put("app", app);
		result.put("valueType", valueType);
		String appName2 = request.getParameter("appName2");
		String valueType2 = request.getParameter("valueType2");
		result.put("appName2", appName2);
		result.put("valueType2", valueType2);
		String keys = request.getParameter("keys");
		String decodedKeys = URLDecoder.decode(request.getParameter("keys"), "utf8");
		keys = URLEncoder.encode(URLEncoder.encode(decodedKeys, "utf8"), "utf8");
		setStartAndEndDate4Day(request, result);
		result.put("keys", keys);
		result.put("keys2", request.getParameter("keys"));

		return HISTORY_DAY;
	}
	private Map<String, String> getRuleExample(String type,String app, String valueType,
			List<String> keys2) {
		BaseDataConfig bdc = new BaseDataConfig();
		bdc.setApp(app);
		bdc.setType(type);
		bdc.setValueType(valueType);
		bdc.setK1(keys2.size()>0?keys2.get(0):"");
		bdc.setK2(keys2.size()>1?keys2.get(1):"");
		bdc.setK3(keys2.size()>2?keys2.get(2):"");
		Map<String,String> ruleExamples = new LinkedHashMap<String,String>();
		{
			bdc.setMday(0);
			bdc.setAggrType(AggrTypeEnum.MIN);
			bdc.encode();
			ruleExamples.put("����|����ʱ��ͼ", bdc.str());
		}
		{
			bdc.setMday(0);
			bdc.setAggrType(AggrTypeEnum.HOUR);
			bdc.encode();
			ruleExamples.put("����|Сʱ��״ͼ", bdc.str());
		}
		{
			bdc.setMday(0);
			bdc.setAggrType(AggrTypeEnum.DAYM);
			bdc.encode();
			ruleExamples.put("����|���ۻ�ͼ", bdc.str());
		}
		{
			bdc.setMday(-7);
			bdc.setAggrType(AggrTypeEnum.MIN);
			bdc.encode();
			ruleExamples.put("7��ǰ|����ʱ��ͼ", bdc.str());
		}
		return ruleExamples;
	}
	private Map<String, String> getRuleExample(String type,String app, String valueType,String appName2,String valueType2,
			List<String> keys2) {
		BaseDataConfig bdc1 = new BaseDataConfig();
		bdc1.setApp(app);
		bdc1.setType(type);
		bdc1.setValueType(valueType);
		bdc1.setK1(keys2.size()>0?keys2.get(0):"");
		bdc1.setK2(keys2.size()>1?keys2.get(1):"");
		bdc1.setK3(keys2.size()>2?keys2.get(2):"");
		BaseDataConfig bdc2 = new BaseDataConfig();
		bdc2.setApp(appName2);
		bdc2.setType(type);
		bdc2.setValueType(valueType2);
		bdc2.setK1(keys2.size()>3?keys2.get(3):"");
		bdc2.setK2(keys2.size()>4?keys2.get(4):"");
		bdc2.setK3(keys2.size()>5?keys2.get(5):"");
		Map<String,String> ruleExamples = new LinkedHashMap<String,String>();
		{
			bdc1.setMday(0);
			bdc1.setAggrType(AggrTypeEnum.MIN);
			bdc1.encode();
			bdc2.setMday(0);
			bdc2.setAggrType(AggrTypeEnum.MIN);
			bdc2.encode();
			DivDataConfig ddc = new DivDataConfig();
			ddc.setData1(bdc1);
			ddc.setData2(bdc2);
			ddc.encode();
			ruleExamples.put("����|����ʱ��ͼ", ddc.str());
		}
		{
			bdc1.setMday(0);
			bdc1.setAggrType(AggrTypeEnum.HOUR);
			bdc1.encode();
			bdc2.setMday(0);
			bdc2.setAggrType(AggrTypeEnum.HOUR);
			bdc2.encode();
			DivDataConfig ddc = new DivDataConfig();
			ddc.setData1(bdc1);
			ddc.setData2(bdc2);
			ddc.encode();
			ruleExamples.put("����|Сʱ��״ͼ", ddc.str());
		}
		{
			bdc1.setMday(0);
			bdc1.setAggrType(AggrTypeEnum.DAYM);
			bdc1.encode();
			bdc2.setMday(0);
			bdc2.setAggrType(AggrTypeEnum.DAYM);
			bdc2.encode();
			DivDataConfig ddc = new DivDataConfig();
			ddc.setData1(bdc1);
			ddc.setData2(bdc2);
			ddc.encode();
			ruleExamples.put("����|���ۻ�ͼ", ddc.str());
		}
		{
			bdc1.setMday(-7);
			bdc1.setAggrType(AggrTypeEnum.MIN);
			bdc1.encode();
			bdc2.setMday(-7);
			bdc2.setAggrType(AggrTypeEnum.MIN);
			bdc2.encode();
			DivDataConfig ddc = new DivDataConfig();
			ddc.setData1(bdc1);
			ddc.setData2(bdc2);
			ddc.encode();
			ruleExamples.put("7��ǰ|����ʱ��ͼ", ddc.str());
		}
		return ruleExamples;
	}
	private void _commonRuleSetting(final HttpServletRequest request,
									ModelMap result, String app, String valueType, String keys)
			throws DAOException, UnsupportedEncodingException {
		if(alarmSwitchManager.isNew(app)){
			result.put("newAlarm",true);
			List<AlarmNewRuleVO> rules = alarmRuleManager.getNewAlarmRulesOfKey(app, keys, valueType);
			
			if(rules!=null){
				result.put("rules",rules);
			}
		}else{
			List<AlarmRuleDO> alarmKeyRules = alarmRuleManager.getAlarmRulesOfKey(app, keys, valueType);
			if ( alarmKeyRules != null ){
				result.put("rules",alarmKeyRules);
				result.put("ruleObjs", alarmRuleManager.getRuleObj(alarmKeyRules));
			}
		}
		//3.����Ա
		AppDO apps = appDAO.getAppByName(app);
		result.put("admins",apps.getAdministrators());
		result.put("returnUrl", super.getWholeUrl(request));

	}

	private void setStartAndEndDate4Day(final HttpServletRequest request,
			ModelMap result) {
		String sd = request.getParameter("startDate");
		if ( StringUtils.isBlank(sd) ){//startDateΪ��,Ĭ��Ϊ��ǰ����-90
			sd = CalendarUtil.toString(DateUtils.addDays(new Date(), -90),"yyyy-MM-dd");
		}
		Date startD = CalendarUtil.toDate(sd, "yyyy-MM-dd");
		String ed = request.getParameter("endDate");
		if ( ed == null || StringUtils.isBlank(ed) ){//Ĭ�ϵ���
			ed = CalendarUtil.toString(new Date(),"yyyy-MM-dd");
		}
		Date endD = CalendarUtil.toDate(ed, "yyyy-MM-dd");
		Long td = endD.getTime() - startD.getTime();

		if ( td > 365*24*60*60*1000l ){// ����һ��
			result.put("startDate", CalendarUtil.toString(DateUtils.addYears(endD, -1),"yyyy-MM-dd"));
			result.put("endDate",ed);
		}else{
			result.put("startDate", sd);
			result.put("endDate",ed);
		}
	}
	public static void main(String[] args) {
		System.out.println(365*24*60*60*1000);
		System.out.println(10*24*60*60*1000);
	}

	private void setStartAndEndDate(final HttpServletRequest request,
									ModelMap result) {
		String sd = request.getParameter("startDate");
		Date startD = CalendarUtil.toDate(sd, "yyyy-MM-dd");
		String ed = request.getParameter("endDate");
		if ( ed == null || StringUtils.isBlank(ed) ){
			ed = CalendarUtil.toString(DateUtils.addDays(startD, 1),"yyyy-MM-dd");
		}
		Date endD = CalendarUtil.toDate(ed, "yyyy-MM-dd");
		Long td = endD.getTime() - startD.getTime();

		if ( td > 7*24*60*60*1000 ){// ����7�� 
			result.put("startDate", CalendarUtil.toString(DateUtils.addDays(endD, -7),"yyyy-MM-dd"));
			result.put("endDate",ed);
		}else{
			result.put("startDate", sd);
			result.put("endDate",ed);
		}
		result.put("startDate2", request.getParameter("startDate2"));
		result.put("endDate2",request.getParameter("endDate2"));
		result.put("startDateOfDay",CalendarUtil.toString(DateUtils.addDays(new Date(), -90),"yyyy-MM-dd"));
		result.put("endDateOfDay",CalendarUtil.toString(new Date(),"yyyy-MM-dd"));
	}
	@RequestMapping("history3.htm")
	public String history3(final HttpServletRequest request, ModelMap result) throws Exception {
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		result.put("beta",beta);
		result.put("app", request.getParameter("appName"));
		String app = request.getParameter("appName");
		String valueType = request.getParameter("valueType");
		result.put("valueType", request.getParameter("valueType"));
		String keys = request.getParameter("keys");
		String decodedKeys = URLDecoder.decode(request.getParameter("keys"), "utf8");
		keys = URLEncoder.encode(URLEncoder.encode(decodedKeys, "utf8"), "utf8");
		setStartAndEndDate(request, result);
		result.put("keys", keys);
		result.put("keys2", request.getParameter("keys"));
		_commonRuleSetting(request, result, request.getParameter("appName"), request.getParameter("valueType"), keys);
		result.put("ruleTypePrefix", RuleTypeConstant.PREFIX_TYPE_HSF);
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByApp(request.getParameter("appName"));
		result.put("alarmGrps", alarmGroups);
		KeysDO k = new KeysDO(keys);
		List<String> keyList = k.getKeys();
		if ( keyList.size() == 6){//�����ԣ�����hsf�ĳ�����Ĭ�϶�ʹ��v1���С�
			Map<String, String> ruleExamples = getRuleExample("hsf",app, "v1",app,"v1", keyList);
			result.put("examples",ruleExamples);
		}else{
			Map<String, String> ruleExamples = getRuleExample("hsf",app, valueType, keyList);
			result.put("examples",ruleExamples);
		}
		return HISTORY_INFO3;
	}
}
