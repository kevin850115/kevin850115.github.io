package com.taobao.ateye.controller.tracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ateye.alarm.manager.AlarmRuleManager;
import com.taobao.ateye.config.blacklist.ErrorLogMd5BlackListManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.LogFilePathDAO;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.LogFilePathDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.monitor.TrackerMonitorDO;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.tracker.TrackerInfoManager;
import com.taobao.ateye.tracker.performance.PerformanceManager;
import com.taobao.ateye.tracker.task.TrackerTaskConfigManager;
import com.taobao.ateye.util.DescUtils;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;
import com.taobao.tracker.collect.TrackerCollectInfoDO;
import com.taobao.tracker.collect.TrackerEntryInfoDO;
import com.taobao.tracker.collect.TrackerWorkInfoDO;
import com.taobao.tracker.domain.BufferStatMap;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.performance.HbaseCacheDO;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/tracker")
public class TrackerInfoController  extends AbstractController{
	
	private static final String DETAIL = "screen/tracker/detail";
	private static final String REAL_DETAIL = "screen/tracker/realDetail";
	private static final String OPLOG_DETAIL = "screen/tracker/opLogDetail";
	private static final String QUEUE = "screen/tracker/queueView";
	private static final String MD5_BLIST= "screen/tracker/md5Blist";
	private static final String CACHE_VIEW = "screen/tracker/cacheView";
	
	@Autowired
	TrackerInfoManager  trackerInfoManager;
	private HbaseReadService hbaseReadService;
	@Autowired
	private MachineDAO machineDAO;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private UrlGenerator urlGenerator;
	@Autowired
	private LogFilePathDAO logFilePathDAO;
	@Autowired
	private PerformanceManager performanceManager;
	@Autowired
	private AlarmRuleManager alarmRuleManager;
	@Autowired
	private ErrorLogMd5BlackListManager errorLogMd5BlackListManager;
	@Autowired
	private TrackerTaskConfigManager trackerTaskConfigManager;

	@RequestMapping("md5Blist.htm")
	public String md5Blist(final HttpServletRequest request, ModelMap result) throws Exception {
		
		Map<String,String> blackLists = errorLogMd5BlackListManager.getBlackList();
    	result.put("returnUrl",super.getWholeUrl(request));

		result.put("blist",blackLists);
		
		return MD5_BLIST;
	}
	@RequestMapping("deleteMd5.htm")
	public String deleteMd5(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws Exception {
		String md5 = request.getParameter("md5");
		if ( StringUtils.isNotEmpty(md5) ){
			errorLogMd5BlackListManager.remove(md5);
		}
		return getRedirectUrl(request, response);
	}
	@RequestMapping("addMd5.htm")
	public String addMd5(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws Exception {
		String md5 = request.getParameter("md5");
		String app = request.getParameter("app");
		if ( StringUtils.isNotEmpty(md5) && StringUtils.isNotEmpty(app)){
			errorLogMd5BlackListManager.add(md5, app);
		}
		return getRedirectUrl(request, response);
	}
	@RequestMapping("abandoneTask.htm")
	public String abandoneTask(final HttpServletRequest request, ModelMap result) throws Exception {
		String ip= request.getParameter("ip");
		String filePathId = request.getParameter("pathId");
		if ( StringUtils.isEmpty(ip) || StringUtils.isEmpty(filePathId)){
			return "";
		}
		AppDO app = appDAO.getAppByName("tracker");
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(app.getId(), environmentService.getEnvironmentType().ordinal());
		String port = "";
		for ( MachineDO mach:machines ){
			if ( mach.getIp().equals(ip) ){
				port = String.valueOf(mach.getPort());
				break;
			}
		}
		if ( StringUtils.isBlank(port) ){
			return "";
		}
		//����tracker
		openAbandone(ip,port,filePathId);
		return "redirect:/tracker/queueView.htm?ip="+ip;
	}
	@RequestMapping("queueView.htm")
	public String queueView(final HttpServletRequest request, ModelMap result) throws Exception {
		AppDO app = appDAO.getAppByName("tracker");
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(app.getId(), environmentService.getEnvironmentType().ordinal());
		result.put("ips", machines);
		result.put("ipGroups",getIpGroups(machines));
		String ip= request.getParameter("ip");
		String port = "";
		if ( StringUtils.isNotBlank(ip) ){
			for ( MachineDO mach:machines ){
				if ( mach.getIp().equals(ip) ){
					port = String.valueOf(mach.getPort());
					break;
				}
			}
			TrackerWorkInfoDO infoDO = callTrackerWorkInfo(ip,port);
			List<TrackerEntryInfoDO> entrys = infoDO.getEntrys();
			List<TrackerEntryInfoDO> prosMap = new ArrayList<TrackerEntryInfoDO>();
			List<TrackerEntryInfoDO> inThMap = new ArrayList<TrackerEntryInfoDO>();
			List<TrackerEntryInfoDO> inIoMap = new ArrayList<TrackerEntryInfoDO>();
			List<TrackerEntryInfoDO> waitMap = new ArrayList<TrackerEntryInfoDO>();
			List<TrackerEntryInfoDO> notInQueueMap = new ArrayList<TrackerEntryInfoDO>();
			for ( TrackerEntryInfoDO info:entrys){
				if ( info.isInIO() ){
					inIoMap.add(info);
				}else if ( info.isProcessing() ){
					prosMap.add(info);
				}else if ( info.isInThread() ){
					inThMap.add(info);
				}else if (info.getNextTriggerTime() == null ){
					notInQueueMap.add(info);
				}else{
					waitMap.add(info);
				}
			}
			
			Collections.sort(prosMap, new Comparator<TrackerEntryInfoDO>() {
				@Override
				public int compare(TrackerEntryInfoDO o1, TrackerEntryInfoDO o2) {
					return new Long(o1.getProcessMSecond()-o2.getProcessMSecond()).intValue();
				}
			});
			Collections.sort(waitMap, new Comparator<TrackerEntryInfoDO>() {
				@Override
				public int compare(TrackerEntryInfoDO o1, TrackerEntryInfoDO o2) {
					return new Long(o1.getNextTriggerTime().getTime()-o2.getNextTriggerTime().getTime()).intValue();
				}
			});
			result.put("processMap", prosMap);
			result.put("threadMap", inThMap);
			result.put("waitMap", waitMap);
			result.put("inIoMap", inIoMap);
			result.put("notInQueueMap", notInQueueMap);
			result.put("info", infoDO);
			result.put("now", new Date().getTime());
			result.put("ip",ip);
		}
		return QUEUE;
	}
	@RequestMapping("cacheView.htm")
	public String cacheView(final HttpServletRequest request, ModelMap result) throws Exception {
		AppDO app = appDAO.getAppByName("tracker");
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(app.getId(), environmentService.getEnvironmentType().ordinal());
		result.put("ips", machines);
		
		Map<String, HbaseCacheDO> hbaseCacheInfo = performanceManager.getHbaseCacheInfo();
		
		//Map<String, AlarmStatDO> alarmInfo = performanceManager.getAlarmInfo();
		
		Map<String, BufferStatMap> bufferStat = performanceManager.getBufferStat();
		
		Map<String, String> runningTime = performanceManager.getTrackerRunningTime();
		
		Set<String> processorSet = getProcessorSet(bufferStat);
		result.put("bufferStat",bufferStat);
		result.put("processors",processorSet);
		result.put("runningTime",runningTime);
		result.put("cacheInfo",hbaseCacheInfo);
		//result.put("alarmInfo",alarmInfo);
		

		result.put("ipGroups",getIpGroups(machines));
		
		/*
		List<AlarmRuleDO> rules = alarmRuleManager.getGlobalAlarmRulesOfType("tracker", RuleTypeConstant.GLOBAL_TRACKER_HBASE_CACHE);
		if ( rules != null ){
			result.put("rules",rules);
			result.put("ruleObjs", alarmRuleManager.getRuleObj(rules));
		}
		*/
		result.put("admins",app.getAdministrators());
		result.put("returnUrl", super.getWholeUrl(request));
		return CACHE_VIEW;
	}
	private List<Pair<String,String>> getIpGroups(List<MachineDO> machines){
		List<Pair<String, String>> ipGroups = trackerTaskConfigManager.getIpGroups();
		for ( MachineDO ma:machines ){
			String ip = ma.getIp();
			boolean findIp = false;
			for ( Pair<String,String> pp:ipGroups ){
				if ( ip.equals(pp.getLeft())) {
					findIp = true;
					break;
				}
			}
			if ( !findIp ){
				ipGroups.add(Pair.of(ip, "--"));
			}
		}
		return ipGroups;
	}
	private Set<String> getProcessorSet(Map<String, BufferStatMap> bufferStat) {
		Set<String> ss = new HashSet<String>();
		for ( BufferStatMap bsm:bufferStat.values() ){
			if ( bsm != null && bsm.getStatMap() != null ){
				ss.addAll(bsm.getStatMap().keySet());
			}
		}
		return ss;
	}
	private TrackerWorkInfoDO callTrackerWorkInfo(String ip,String port){
		Map<String,String> params1=new HashMap<String,String>();
    	params1.put("type", "INVOKER");
    	params1.put("action", "invoke");
    	params1.put("beanName", "trackerLogCollector");
    	params1.put("signature", "getCurrentWorkInfo()");

    	String url01="";
		try {
			url01 = urlGenerator.getUrl(ip, port, params1);
		} catch (Exception e1) {
			return null;
		}
		try {
			String json= HttpClientUtil.getResult(url01);
			JSONArray arr = JSON.parseArray(json);
			JSONObject obj = arr.getJSONObject(0);
			String ss = obj.get("returnValue").toString();
			return JSON.parseObject(ss, TrackerWorkInfoDO.class);
		}catch(Throwable t ){
			return null;
		}
	}
	private void openAbandone(String ip,String port,String filePathId){
		Map<String,String> params1=new HashMap<String,String>();
    	params1.put("type", "INVOKER");
    	params1.put("action", "invoke");
    	params1.put("beanName", "trackerLogCollector");
    	params1.put("signature", "openAbandoneMode(long)");
    	params1.put("paramCount", "1");
    	params1.put("param1", filePathId);

		try {
			String url01 = urlGenerator.getUrl(ip, port, params1);
			HttpClientUtil.getResult(url01);
		} catch (Throwable e1) {
			log.error("�����쳣",e1);
		}
	}	
	@RequestMapping("modifyOwner.htm")
	public String modifyOwner(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		String file = request.getParameter("file");
		if ( StringUtils.isBlank(file)){
			return "";
		}
		String newOwner = request.getParameter("newOwner");
		if ( StringUtils.isBlank(newOwner)){
			return "";
		}
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return "";
		}
		Long logFilePathId = null;
		List<LogFilePathDO> allLogFilePath = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(),environmentService.getEnvironmentType().getEnv());
		for ( LogFilePathDO path:allLogFilePath ){
			if ( path.getFilePath().equals(file) ){
				logFilePathId = path.getId();
				break;
			}
		}
		if ( logFilePathId != null ){
			logFilePathDAO.updateOwner(logFilePathId, newOwner,environmentService.getEnvironmentType().getEnv());
		}
		return detail(request,result);
	}
	@RequestMapping("realDetail.htm")
	public String realDetail(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String day = request.getParameter("day");
		Date date = null;
		if ( StringUtils.isBlank(day) ){
			date = CalendarUtil.zerolizedTime(new Date());
		}else{
			date = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		result.put("current",CalendarUtil.toString(date, CalendarUtil.DATE_FMT_3));
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app",app);
		Map<String, Map<String, TrackerCollectInfoDO>> infos = trackerInfoManager.getInfos(date,app);
		
		Map<String,Map<String,InfoVO>> newInfos = new HashMap<String,Map<String,InfoVO>>();
		Map<String,String> filesOwner = new HashMap<String,String>();
		for ( String ip:infos.keySet() ){
			Map<String,TrackerCollectInfoDO> mm = infos.get(ip);
			for ( String k:mm.keySet() ){
				filesOwner.put(k, "");
			}
			HashMap<String, InfoVO> si = new HashMap<String,InfoVO>();
			for ( Map.Entry<String, TrackerCollectInfoDO> ent:infos.get(ip).entrySet() ){
				si.put(ent.getKey(), convert(ent.getValue()));
			}
			newInfos.put(ip,si);
		}
		
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return DETAIL;
		}
		List<LogFilePathDO> paths = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(),environmentService.getEnvironmentType().getEnv());
		for ( LogFilePathDO path:paths ){
			if ( filesOwner.containsKey(path.getFilePath()) ){
				filesOwner.put(path.getFilePath(), path.getOwner());
			}
		}
		result.put("infos", newInfos);
		result.put("files",filesOwner);
		result.put("descUtil",new DescUtils());
		
		return REAL_DETAIL;
	}
	@RequestMapping("detail.htm")
	public String detail(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String day = request.getParameter("day");
		Date date = null;
		if ( StringUtils.isBlank(day) ){
			date = CalendarUtil.zerolizedTime(new Date());
		}else{
			date = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		result.put("current",CalendarUtil.toString(date, CalendarUtil.DATE_FMT_3));
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app",app);
		Map<String, Map<String, TrackerCollectInfoDO>> infos = trackerInfoManager.getInfos(date,app);
		
		Map<String,Map<String,InfoVO>> newInfos = new HashMap<String,Map<String,InfoVO>>();
		Map<String,String> filesOwner = new HashMap<String,String>();
		for ( String ip:infos.keySet() ){
			Map<String,TrackerCollectInfoDO> mm = infos.get(ip);
			for ( String k:mm.keySet() ){
				filesOwner.put(k, "");
			}
			HashMap<String, InfoVO> si = new HashMap<String,InfoVO>();
			for ( Map.Entry<String, TrackerCollectInfoDO> ent:infos.get(ip).entrySet() ){
				si.put(ent.getKey(), convert(ent.getValue()));
			}
			newInfos.put(ip,si);
		}
		
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return DETAIL;
		}
		List<LogFilePathDO> paths = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(),environmentService.getEnvironmentType().getEnv());
		for ( LogFilePathDO path:paths ){
			if ( filesOwner.containsKey(path.getFilePath()) ){
				filesOwner.put(path.getFilePath(), path.getOwner());
			}
		}
		result.put("infos", newInfos);
		result.put("files",filesOwner);
		//3.��ȡTracker�ռ���Ϣ�����.
		Map<String, TrackerMonitorDO> trackerStat = trackerInfoManager.getTrackerStat(app,date);
		result.put("stats",trackerStat);
		//4.�������
		Map<String,String> statResult = analyseStat(trackerStat);
		result.put("statsResult",statResult);
		result.put("descUtil",new DescUtils());
		
		return DETAIL;
	}
	@RequestMapping("detailOpLog.htm")
	public String detailOpLog(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String day = request.getParameter("day");
		String file = request.getParameter("file");
		Date date = null;
		if ( StringUtils.isBlank(day) ){
			date = CalendarUtil.zerolizedTime(new Date());
		}else{
			date = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		result.put("current",CalendarUtil.toString(date, CalendarUtil.DATE_FMT_3));
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(file) ){
			return "";
		}
		result.put("app",app);
		Map<String, Map<String, TrackerCollectInfoDO>> infos = trackerInfoManager.getHourlyInfos(date,app,file);
		
		Map<String,Map<String,InfoVO>> newInfos = new HashMap<String,Map<String,InfoVO>>();
		Set<String> files= new TreeSet<String>();
		for ( String ip:infos.keySet() ){
			Map<String,TrackerCollectInfoDO> mm = infos.get(ip);
			for ( String k:mm.keySet() ){
				files.add(k);
			}
			HashMap<String, InfoVO> si = new HashMap<String,InfoVO>();
			for ( Map.Entry<String, TrackerCollectInfoDO> ent:infos.get(ip).entrySet() ){
				si.put(ent.getKey(), convert(ent.getValue()));
			}
			newInfos.put(ip,si);
		}
		
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return DETAIL;
		}
		result.put("infos", newInfos);
		result.put("files",files);
		//3.��ȡTracker�ռ���Ϣ�����.
		Map<String, TrackerMonitorDO> trackerStat = trackerInfoManager.getTrackerStat(app,date);
		result.put("stats",trackerStat);
		//4.�������
		Map<String,String> statResult = analyseStat(trackerStat);
		result.put("statsResult",statResult);
		result.put("descUtil",new DescUtils());
		
		result.put("file",file);
		
		return OPLOG_DETAIL;
	}
	private Map<String, String> analyseStat( Map<String, TrackerMonitorDO> trackerStat) {
		Map<String,String> ret = new HashMap<String,String>();
		for ( String k:trackerStat.keySet() ){
			TrackerMonitorDO m = trackerStat.get(k);
			if ( m.getTotalTimes() != null ){
				if ( m.getTotalTimes().getValue().equals("0") ){
					ret.put(k, "red");
					continue;
				}
			}
			if ( m.getTotalErrorTimes() != null && m.getTotalTryTimes() != null ){
				Long errorTimes = Long.valueOf(m.getTotalErrorTimes().getValue());
				Long totalTimes = Long.valueOf(m.getTotalTryTimes().getValue());
				float rate = (float)errorTimes/(float)totalTimes;
				if ( rate > 0.1 ){//�ɼ������ʹ���
					ret.put(k, "red");
					continue;
				}
			}
			if ( m.getParseErrorRate() != null ){
				float rate = Float.valueOf(m.getParseErrorRate().getValue());
				if ( rate >= 0.01 ){
					ret.put(k, "red");//����ʧ���ʹ���
					continue;
				}
			}
			if ( m.getTimeoutFailRate() != null ){
				float rate = Float.valueOf(m.getTimeoutFailRate().getValue());
				if ( rate >= 0.01 ){
					ret.put(k, "red");//��������
					continue;
				}
			}
			ret.put(k,"green");
		}
		return ret;
	}
	private InfoVO convert(TrackerCollectInfoDO value) {
		InfoVO v = new InfoVO();
		v.setCode(value.getType());
		Date now = new Date();
		Long mm = (now.getTime()-value.getDate().getTime())/1000;
		v.setSecondsPast(String.valueOf(mm)+"s");
		if ( value.getLogDate() != null ){
			v.setLogDateStr(CalendarUtil.toString(value.getLogDate(), CalendarUtil.TIME_PATTERN));
		}
		return v;
	}
	public void setHbaseReadService(HbaseReadService hbaseReadService) {
		this.hbaseReadService = hbaseReadService;
	}
	public HbaseReadService getHbaseReadService() {
		return hbaseReadService;
	}
	static public class InfoVO{
		private String secondsPast;//
		private String code;//������
		private String logDateStr;
		public void setSecondsPast(String secondsPast) {
			this.secondsPast = secondsPast;
		}
		public String getSecondsPast() {
			return secondsPast;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public String getLogDateStr() {
			return logDateStr;
		}
		public void setLogDateStr(String logDateStr) {
			this.logDateStr = logDateStr;
		}
	}
}
