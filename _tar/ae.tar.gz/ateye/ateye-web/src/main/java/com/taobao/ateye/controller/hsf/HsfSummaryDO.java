package com.taobao.ateye.controller.hsf;

import java.util.HashMap;
import java.util.Map;

import com.taobao.ateye.util.DescUtils;

public class HsfSummaryDO {
	private long totalInvokeCount=0;//���ô���
	private Map<String,Long> serviceInvokeCounts=new HashMap<String,Long>();//ÿ������ĵ��ô���
	private Map<String,Long> methodInvokeCounts=new HashMap<String,Long>();//ÿ�������ĵ��ô���
	public int getServiceNumber() {
		return serviceInvokeCounts.size();
	}
	public String getServiceNumberDesc() {
		return DescUtils.descTimes(getServiceNumber());
	}
	public int getMethodNumber() {
		return methodInvokeCounts.size();
	}
	public String getMethodNumberDesc() {
		return DescUtils.descTimes(getMethodNumber());
	}
	public void addServiceInvokeCount(String service,long count){
		Long cc = serviceInvokeCounts.get(service);
		if ( cc == null ){
			serviceInvokeCounts.put(service, count);
		}else{
			serviceInvokeCounts.put(service, cc + count);
		}
	}
	public void addMethodInvokeCount(String service,long count){
		Long cc = methodInvokeCounts.get(service);
		if ( cc == null ){
			methodInvokeCounts.put(service, count);
		}else{
			methodInvokeCounts.put(service, cc + count);
		}
	}
	public void addTotalInvokeCount(long totalInvokeCount) {
		this.totalInvokeCount += totalInvokeCount;
	}
	public long getTotalInvokeCount() {
		return totalInvokeCount;
	}
	public String getTotalInvokeCountDesc() {
		
		return DescUtils.descTimes(getTotalInvokeCount());
	}
}
