package com.taobao.ateye.controller.loginusers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.platform.buc.sso.common.dto.SimpleSSOUser;
import com.taobao.ateye.authority.SSOThreadLocal;
import com.taobao.ateye.dataobject.ResourceDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.operate.OperateLogger;
import com.taobao.ateye.service.ResourceService;
import com.taobao.ateye.service.RoleService;

@Controller
@RequestMapping("/manage/resource")
public class ManageResourceController {
    @Autowired
    OperateLogger operateLogger;
    @Autowired
    private ResourceService ateyeResourceService;
    @Autowired
    private RoleService ateyeRoleService;

    @Autowired
    private AclSyncUtil aclSyncUtil;
    private void init(Map<String, Object> result) {
        List<RoleDO> list = ateyeRoleService.getAllRoleList();
        result.put("allRoles", list);
    }

    @RequestMapping(value = "addResource.htm", method = RequestMethod.GET)
    public final ModelAndView addResourceForm(final HttpServletRequest request, final HttpServletResponse response) {
        Map<String, Object> result = new HashMap<String, Object>();
        this.init(result);
        return new ModelAndView("manage/resource/addResource", result);
    }

    @RequestMapping(value = "saveResource.htm", method = RequestMethod.POST)
    public final ModelAndView saveResource(final HttpServletRequest request, final HttpServletResponse response) throws DAOException {
        ResourceDO resource = new ResourceDO();
        Map<String, Object> result = new HashMap<String, Object>();
        resource.setName(request.getParameter("name").trim());
        resource.setPath(request.getParameter("path").trim());
        resource.setSort(Integer.parseInt(request.getParameter("sort")));
        String[] roleIds = request.getParameterValues("roleId");

        boolean flag = ateyeResourceService.insertResource(resource, roleIds);

        if (!flag) {
            result.put("error", " ������Դʧ��");
            operateLogger.logError("������Դʧ��", -1, resource.getName(),resource.getPath());
        } else {
        	SimpleSSOUser ssoUser = SSOThreadLocal.get();
            try {
                aclSyncUtil.syncResourceRoles(resource.getName(), roleIds, ssoUser.getId().toString());
                result.put("info", "������Դ�ɹ�");
                operateLogger.logInfo("������Դ�ɹ�", -1,  resource.getName(),resource.getPath());
            } catch(Throwable t) {
                result.put("error", t.getCause());
            }
        }
        return queryResource(null, response);

    }

    @RequestMapping(value = "queryResource.htm")
    public final ModelAndView queryResource(final HttpServletRequest request, final HttpServletResponse response) {
        Map<String, Object> result = new HashMap<String, Object>();
        this.init(result);
        List<ResourceDO> resList = null;
        if ( request == null ){
            resList = ateyeResourceService.getAllResourceList();
        }else{
	        String name = StringUtil.trim(request.getParameter("name"));
	        String path = StringUtil.trim(request.getParameter("path"));
	        String roleId = StringUtil.trim(request.getParameter("roleId"));
	        if (StringUtil.isNotBlank(name) || StringUtil.isNotBlank(path) || StringUtil.isNotBlank(roleId)) {
	            ResourceDO resource = new ResourceDO();
	            resource.setName(name);
	            resource.setPath(path);
	            resource.setRoleId(Long.parseLong(roleId));
	            resList = ateyeResourceService.findResource(resource);
	        } else {
	            resList = ateyeResourceService.getAllResourceList();
	        }
        }
        result.put("allResources", resList);
        return new ModelAndView("manage/resource/queryResource", result);
    }

    @RequestMapping(value = "editResource.htm", method = RequestMethod.GET)
    public final ModelAndView editResource(@RequestParam("id") Long resId, final HttpServletRequest request,
            final HttpServletResponse response) {
        Map<String, Object> result = new HashMap<String, Object>();
        this.init(result);
        ResourceDO resource = ateyeResourceService.getResourceById(resId);
        List<RoleDO> resourceRoleList = ateyeRoleService.getResourceRoleList(resId);
        resource.setRoleList(resourceRoleList);
        result.put("resource", resource);
        return new ModelAndView("manage/resource/editResource", result);
    }

    @RequestMapping("updateResource.htm")
    public final ModelAndView updateResource(final HttpServletRequest request, final HttpServletResponse response) throws DAOException {
        Map<String, Object> result = new HashMap<String, Object>();
        Long resId = Long.parseLong(request.getParameter("id"));
        ResourceDO resource = new ResourceDO();
        resource.setId(resId);
        resource.setName(request.getParameter("name").trim());
        resource.setSort(Integer.parseInt(request.getParameter("sort")));
        resource.setPath(request.getParameter("path").trim());
        String[] roleIds = request.getParameterValues("roleId");

        boolean flag = ateyeResourceService.updateResource(resource, roleIds);
        if (!flag) {
            result.put("error", "������Դʧ��");
            operateLogger.logError("������Դʧ��", -1, resource.getName(),resource.getPath());
        } else {
        	SimpleSSOUser ssoUser = SSOThreadLocal.get();
            try {
                aclSyncUtil.syncResourceRoles(resource.getName(), roleIds, ssoUser.getId().toString());

                result.put("info", "������Դ�ɹ�");
                operateLogger.logInfo("������Դ�ɹ�", -1,  resource.getName(),resource.getPath());
            }
            catch(Throwable t)
            {
                result.put("error", t.getCause());
            }

        }
        return queryResource(null, response);
    }

    @RequestMapping("deleteResource.htm")
    public final ModelAndView deleteResource(@RequestParam("id") Long id, final HttpServletRequest request,
            final HttpServletResponse response, final ModelMap result) throws DAOException {
        boolean flag = ateyeResourceService.deleteResource(id);

        if (!flag) {
            result.put("error", "ɾ����Դʧ��");
            operateLogger.logError("ɾ����Դʧ��", -1, id);
        } else {
            result.put("info", "ɾ����Դ�ɹ�");
            operateLogger.logInfo("ɾ����Դ�ɹ�", -1, id);
        }
        return queryResource(null, response);
    }

}
