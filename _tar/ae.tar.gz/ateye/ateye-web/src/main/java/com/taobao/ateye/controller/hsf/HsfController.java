package com.taobao.ateye.controller.hsf;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.taobao.ateye.alarm.config.RuleTypeConstant;
import com.taobao.ateye.alarm.manager.AlarmGroupManager;
import com.taobao.ateye.alarm.manager.AlarmRuleManager;
import com.taobao.ateye.alarm.n.data.AlarmNewRuleVO;
import com.taobao.ateye.alarm.n.manager.AlarmSwitchManager;
import com.taobao.ateye.config.app.AppConfig;
import com.taobao.ateye.config.app.AppDescDO;
import com.taobao.ateye.config.app.impl.AppConfigManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.HsfInterfaceDAO;
import com.taobao.ateye.dal.HsfMethodDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.HsfInterfaceDO;
import com.taobao.ateye.doc.DocumentType;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.hsf.relation.HsfMethodDO;
import com.taobao.ateye.hsf.relation.HsfRelationManager;
import com.taobao.ateye.hsf.relation.HsfServiceMethodDO;
import com.taobao.ateye.hsf.relation.HsfStatAsProviderDO;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.kv.KvGraphParam;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.scene.manager.SceneDynamicOprHisManager;
import com.taobao.ateye.scene.manager.SceneVersionManager;
import com.taobao.ateye.scene.manager.data.HSFMethodDomain;
import com.taobao.ateye.scene.manager.hsf.HsfMetaDataManager;
import com.taobao.ateye.score.db.DbQpsDO;
import com.taobao.ateye.score.db.DbQpsManager;
import com.taobao.ateye.score.flow.FlowScoreDO;
import com.taobao.ateye.score.flow.FlowScoreManager;
import com.taobao.ateye.score.health.HealthScoreManager;
import com.taobao.ateye.score.health.TotalScoreResult;
import com.taobao.ateye.score.rt.RtScoreDO;
import com.taobao.ateye.score.rt.RtScoreManager;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.hbase.AlarmRuleDO;
import com.taobao.tracker.hbase.DocumentDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.HsfConsumerDO;
import com.taobao.tracker.hbase.HsfProviderDO;
import com.taobao.tracker.hbase.MethodDetailDO;
import com.taobao.tracker.hbase.ServiceDetailDO;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.AlarmGroupDO;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;

@Controller
@RequestMapping("/hsf")
public class HsfController extends AbstractController{
	

	private static final String SUMMARY = "screen/hsf/summary";
	private static final String APP_SCORE = "screen/hsf/appScore";
	private static final String HEALTH_SCORE_DETAIL = "screen/hsf/healthScoreDetail";
	private static final String SUMMARY_BY_ORDER = "screen/hsf/summaryByOrder";
	private static final String PROVIDE_SERVICE_LIST = "screen/hsf/provideServiceList";
	private static final String CONSUME_SERVICE_LIST = "screen/hsf/consumeServiceList";
	private static final String APP_SERVICE_LIST = "screen/hsf/appServiceList";
	private static final String SERVICE_DETAIL = "screen/hsf/serviceDetail";
	@Autowired
	private MonitorLogQueryService monitorLogQueryService;
	@Autowired
	private HsfRelationManager hsfRelationManager;
	@Autowired
	private HealthScoreManager healthScoreManager;
	@Autowired
	private RtScoreManager rtScoreManager;
	@Autowired
	private FlowScoreManager flowScoreManager;
	@Autowired
	private AlarmRuleManager alarmRuleManager;
	@Autowired
	private DbQpsManager dbQpsManager;
	@Autowired
	private HbaseReadService hbaseReadService;
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private AlarmGroupManager alarmGroupManager;

	@Autowired
	private AlarmSwitchManager alarmSwitchManager;
	@Autowired
	private HsfMethodDAO hsfMethodDAO;
	@Autowired
	private HsfInterfaceDAO hsfInterfaceDAO;

	@Autowired
	private AppConfigManager appConfigManager;

	@Autowired
	private SceneVersionManager sceneVersionManager;

	@Autowired
	private HsfMetaDataManager hsfMetaDataManager;

	@Autowired
	private SceneDynamicOprHisManager sceneDynamicOprHisManager;
	
	@RequestMapping("appScore.htm")
    public String appScore(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		Date startDate = getDayDefaultYesterday(request,result);
		String all = request.getParameter("all");
		if ( StringUtils.isNotBlank(all) ){
			result.put("all",true);
		}
		String biz = request.getParameter("biz");
		if ( biz == null ){
			biz = "-1";
		}
		result.put("sbiz",biz);
		initBizMap(result);
		{
			DocumentDO document = hbaseReadService.getDocument(startDate, DocumentType.GLOBAL_APP, DocumentType.TYPE_APP_RANK);
			if ( document != null ){
				String doc = document.getDoc();
				Map<String,Double> ranks = new HashMap<String,Double>();
				ranks = JSON.parseObject(doc, ranks.getClass());
				result.put("ranks", ranks);
			}
		}
		{
			Map<String, TotalScoreResult> allHealthScore = healthScoreManager.getAllScores(startDate);
			result.put("healths", allHealthScore);
		}
		{
			Map<String, RtScoreDO> scores = rtScoreManager.getAllScores(startDate);
			result.put("rts", scores);
		}
		{
			Map<String, FlowScoreDO> scores = flowScoreManager.getAllScores(startDate);
			result.put("flows", scores);
		}
		{
			Map<String, DbQpsDO> scores = dbQpsManager.getAllScores(startDate);
			result.put("dbQpss", scores);
		}
		result.put("appBiz", AppConfig.getAppDesc());
		

		return APP_SCORE;
	}
	@RequestMapping("healthScoreDetail.htm")
    public String healthScoreDeetail(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		Date startDate = getDayDefaultYesterday(request,result);
		String app = request.getParameter("app");
		result.put("app",app);
		TotalScoreResult tsr = healthScoreManager.getScoreOfApp(app, startDate);
		result.put("result", tsr);

		return HEALTH_SCORE_DETAIL;
	}
	@RequestMapping("summary.htm")
    public String summary(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		Date startDate = getDay2(request,result);
		initBizMap(result);
		List<HsfProviderDO> allHsfProviders = hbaseReadService.getAllHsfProviders(startDate);
		//1.��ʼ����ͳ��(������ҵ��ά�ȣ�Ӧ��γ��)
		HsfSummaryDO total = new HsfSummaryDO();
		HsfSummaryMap bizTotal = new HsfSummaryMap();
		HsfSummaryMap appTotal = new HsfSummaryMap();
		Map<String, AppDescDO> appDesc = AppConfig.getAppDesc();
		for ( HsfProviderDO hr:allHsfProviders ){
			String appProvider = hr.getAppProvider();
			List<ServiceDetailDO> details = hr.getDetails();
			for ( ServiceDetailDO sd:details ){
				List<MethodDetailDO> methodDetails = sd.getMethodDetails();
				for ( MethodDetailDO md:methodDetails ){
					//1.1.��������
					total.addTotalInvokeCount(md.getTotalTimes());
					total.addMethodInvokeCount(sd.getService()+md.getMethod(), md.getTotalTimes());
					total.addServiceInvokeCount(sd.getService(), md.getTotalTimes());
					//1.2.ҵ������
					AppDescDO appDescDO = appDesc.get(appProvider);
					if ( appDescDO != null ){
						bizTotal.addTotalInvokeCount(appDescDO.getProductName(), md.getTotalTimes());
						bizTotal.addMethodInvokeCount(appDescDO.getProductName(),sd.getService()+md.getMethod(), md.getTotalTimes());
						bizTotal.addServiceInvokeCount(appDescDO.getProductName(),sd.getService(), md.getTotalTimes());
					}
					//1.3.Ӧ������
					appTotal.addTotalInvokeCount(appProvider, md.getTotalTimes());
					appTotal.addMethodInvokeCount(appProvider,sd.getService()+md.getMethod(), md.getTotalTimes());
					appTotal.addServiceInvokeCount(appProvider,sd.getService(), md.getTotalTimes());
				}
			}
		}
		//2.���ñ���
		result.put("total", total);
		result.put("bizTotal", bizTotal);
		result.put("appTotal", appTotal);
        return SUMMARY;
    }	
	
	@RequestMapping("summaryByOrder.htm")
    public String summaryByOrder(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		String orderBy = request.getParameter("orderBy");
		if ( orderBy == null ){
			orderBy = "count";
		}
		result.put("orderBy",orderBy);
		String biz = request.getParameter("biz");
		if ( biz == null ){
			biz = "-1";
		}
		result.put("sbiz",biz);
		Map<String, AppDescDO> appDesc = AppConfig.getAppDesc();
		Date startDate = getDay2(request,result);
		initBizMap(result);
		List<HsfProviderDO> allHsfProviders = hbaseReadService.getAllHsfProviders(startDate);
		//1.��ʼ����ͳ��(Ӧ��γ��)
		HsfSummaryMap appTotal = new HsfSummaryMap();
		for ( HsfProviderDO hr:allHsfProviders ){
			AppDescDO appDescDO = appDesc.get(hr.getAppProvider());
			if ( appDescDO == null ){
				continue;
			}
			if ( !biz.equals("-1") && !biz.equals(appDescDO.getProductName())  ){
				continue;
			}
			String appProvider = hr.getAppProvider();
			List<ServiceDetailDO> details = hr.getDetails();
			for ( ServiceDetailDO sd:details ){
				List<MethodDetailDO> methodDetails = sd.getMethodDetails();
				for ( MethodDetailDO md:methodDetails ){
					//1.3.Ӧ������
					appTotal.addTotalInvokeCount(appProvider, md.getTotalTimes());
					appTotal.addMethodInvokeCount(appProvider,sd.getService()+md.getMethod(), md.getTotalTimes());
					appTotal.addServiceInvokeCount(appProvider,sd.getService(), md.getTotalTimes());
				}
			}
		}
		List<Entry<String, HsfSummaryDO>> ss = new ArrayList<Entry<String,HsfSummaryDO>>(appTotal.entrySet());
		//2.���ñ���
		if ( orderBy.equals("count") ){
			Collections.sort(ss, new Comparator<Entry<String, HsfSummaryDO>>() {
				@Override
				public int compare(Entry<String, HsfSummaryDO> o1,
						Entry<String, HsfSummaryDO> o2) {
					return -(int)(o1.getValue().getTotalInvokeCount() - o2.getValue().getTotalInvokeCount());
				}
			});
		}else if ( orderBy.equals("service") ){
			Collections.sort(ss, new Comparator<Entry<String, HsfSummaryDO>>() {
				@Override
				public int compare(Entry<String, HsfSummaryDO> o1,
						Entry<String, HsfSummaryDO> o2) {
					return -(int)(o1.getValue().getServiceNumber() - o2.getValue().getServiceNumber());
				}
			});
		}else if ( orderBy.equals("method") ){
			Collections.sort(ss, new Comparator<Entry<String, HsfSummaryDO>>() {
				@Override
				public int compare(Entry<String, HsfSummaryDO> o1,
						Entry<String, HsfSummaryDO> o2) {
					return -(int)(o1.getValue().getMethodNumber() - o2.getValue().getMethodNumber());
				}
			});
		}
		result.put("appSums", ss);
		result.put("appBiz", AppConfig.getAppDesc());

        return SUMMARY_BY_ORDER;
    }	
	@RequestMapping("provideServiceList.htm")
    public String provideServiceList(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		String orderBy = request.getParameter("orderBy");
		if ( orderBy == null ){
			orderBy = "count";
		}
		result.put("orderBy",orderBy);
		String biz = request.getParameter("biz");
		if ( biz == null ){
			biz = "-1";
		}
		result.put("sbiz",biz);
		Date startDate = getDay2(request,result);
		initBizMap(result);
		List<HsfProviderDO> allProviders = hbaseReadService.getAllHsfProviders(startDate);
		Map<String, AppDescDO> appDesc = AppConfig.getAppDesc();
		//1.��ʼ����ͳ��(
		List<HsfMethodDO> methods = new ArrayList<HsfMethodDO>();
		for ( HsfProviderDO hr:allProviders){
			String app = hr.getAppProvider();
			AppDescDO appDescDO = appDesc.get(app);
			if ( appDescDO == null ){
				continue;
			}
			if ( !biz.equals("-1") && !biz.equals(appDescDO.getProductName())  ){
				continue;
			}
			List<ServiceDetailDO> details = hr.getDetails();
			List<HsfMethodDO> mds = hsfRelationManager.convertToMethodDetail(app, details);
			methods.addAll(mds);
		}
		//2.����
		sortMethods(orderBy, methods);
		
		result.put("methods", methods);
		result.put("appBiz", AppConfig.getAppDesc());
        return PROVIDE_SERVICE_LIST;
    }
	@RequestMapping("consumeServiceList.htm")
    public String consumeServiceList(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		String orderBy = request.getParameter("orderBy");
		if ( orderBy == null ){
			orderBy = "count";
		}
		result.put("orderBy",orderBy);
		String biz = request.getParameter("biz");
		if ( biz == null ){
			biz = "-1";
		}
		result.put("sbiz",biz);
		Date startDate = getDay2(request,result);
		initBizMap(result);
		List<HsfConsumerDO> allConsumers = hbaseReadService.getAllHsfConsumers(startDate);
		Map<String, AppDescDO> appDesc = AppConfig.getAppDesc();
		//1.��ʼ����ͳ��(
		List<HsfMethodDO> methods = new ArrayList<HsfMethodDO>();
		Set<String> uniqMethod = new HashSet<String>();
		for ( HsfConsumerDO hr:allConsumers){
			String app = hr.getApp();
			AppDescDO appDescDO = appDesc.get(app);
			if ( appDescDO == null ){
				continue;
			}
			if ( !biz.equals("-1") && !biz.equals(appDescDO.getProductName())  ){
				continue;
			}
			List<ServiceDetailDO> details = hr.getDetails();
			List<HsfMethodDO> mds = hsfRelationManager.convertToMethodDetail(app, details);
			methods.addAll(mds);
			for ( HsfMethodDO md:mds ){
				uniqMethod.add( md.getService() + ":"+md.getMethod() );
			}
		}
		//2.����
		sortMethods(orderBy, methods);
		result.put("methods", methods);
		result.put("uniqMethods", uniqMethod);
		result.put("appBiz", AppConfig.getAppDesc());
        return CONSUME_SERVICE_LIST;
    }
	@RequestMapping("serviceDetail.htm")
	public String serviceDetail(final HttpServletRequest request, ModelMap result) throws Exception {
		String hsf = request.getParameter("hsf");
		String method = request.getParameter("method");
		String key = request.getParameter("key");
		if (StringUtils.isNotBlank(key)) {
			//������sentianlKey�Ĳ�ѯ��ʽ
			List<com.taobao.ateye.dataobject.HsfMethodDO> methodDO = hsfMethodDAO.getBySentinelResourceName(key,environmentService.getEnvironmentType().getEnv());
			for ( com.taobao.ateye.dataobject.HsfMethodDO mm:methodDO ) {
				Long interfaceId = mm.getInterfaceId();
				HsfInterfaceDO ido = hsfInterfaceDAO.getById(interfaceId);
				if ( ido == null ) {
					continue;
				}
				if ( ido.getAppNodeGroup().endsWith("spe")) {
					continue;
				}
				if ( ido.getAppNodeGroup().contains("gray")) {
					continue;
				}
				if ( ido.getUniqueServiceName().endsWith(".beta") ) {
					continue;
				}
				hsf = ido.getUniqueServiceName();
				method = mm.getEagleeyeUniqueName();
				break;
			}
		}
		result.put("hsf", hsf);
		result.put("_method", method);
		//���⴦��searchTax~T�����Ѷ�ΪsearchTax�����
		String methodPrefix=null;
		if (StringUtils.isNotBlank(method) ){
			int ind= method.indexOf("~");
			if ( ind != -1 ){
				methodPrefix = method.substring(0, ind);
				result.put("methodPrefix", methodPrefix);
			}
		}
		Date startDate = getDay2(request,result);
		try {
			SortedSet<MonitorLogNode> results = monitorLogQueryService.getHsfStats(startDate, hsf);
			if ( results != null ){
				Map<String,HsfServiceMethodDO> serviceProviderConsumers = hsfRelationManager.getServiceProviderConsumers(hsf,results);
				result.put("spcs",serviceProviderConsumers);
				//��ͼ
				if ( StringUtils.isNotBlank(method) ) {//������ָ����method�����
					HsfServiceMethodDO selMethod = getSelectedMethod(serviceProviderConsumers,method,methodPrefix);
					if ( selMethod != null ) {
						Map<String,List<KvGraphMonitorItemDO>> items = buildKvGraphParams(selMethod);
						List<String> customeParams = kvGraphManager.buildParam(items,DataBuilder.graphSizeMap.get("xxs"));
						result.put("customParams", customeParams);
						result.put("items",buildArr(items));
						List<String> customeBigParams = kvGraphManager.buildParam(items,DataBuilder.defaultSize);
						result.put("customeBigParams", customeBigParams);
					}
				}
			}
		} catch (Exception e) {
			log.error("HubMonitorController::queryHsfMonitorLogInfoOfApp �쳣", e);
			result.put("errorMsg", e.getMessage());
		}
		return SERVICE_DETAIL;
	}
	private HsfServiceMethodDO getSelectedMethod(Map<String, HsfServiceMethodDO> serviceProviderConsumers,
			String method, String methodPrefix) {
		HsfServiceMethodDO hsfServiceMethodDO = serviceProviderConsumers.get(method);
		if ( hsfServiceMethodDO != null ) {
			return hsfServiceMethodDO;
		}
		return serviceProviderConsumers.get(methodPrefix);
	}
	private Map<String, List<KvGraphMonitorItemDO>> buildKvGraphParams(HsfServiceMethodDO value) {
		Map<String,List<KvGraphMonitorItemDO>> ret  = new LinkedHashMap<String,List<KvGraphMonitorItemDO>>();
		List<HsfMethodDO> appProviders = value.getAppProviders();
		for (HsfMethodDO method:appProviders ) {
			HsfStatAsProviderDO providerDO = new HsfStatAsProviderDO(method.getApp(),method.getService(),method.getMethod());
			//��ʼ����ͼ
			ret.put(method.getApp()+method.getService()+method.getMethod()+":����", 
					Arrays.asList(
					new KvGraphMonitorItemDO(method.getApp()+"|����",providerDO.getTotalCountNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|����",providerDO.getTotalCountNode(), KvGraphParam.DT_TYPE_HSF,-1)
					));
			ret.put(method.getApp()+method.getService()+method.getMethod()+":�ɹ���", 
					Arrays.asList(
					new KvGraphMonitorItemDO(method.getApp()+"|�ɹ���",providerDO.getTotalSuccCountNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|�ɹ���",providerDO.getTotalSuccCountNode(), KvGraphParam.DT_TYPE_HSF,-1)
					));
			ret.put(method.getApp()+method.getService()+method.getMethod()+":RT(ms)", 
					Arrays.asList(
					new KvGraphMonitorItemDO(method.getApp()+"|RT(ms)",providerDO.getTotalRtNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|RT(ms)",providerDO.getTotalRtNode(), KvGraphParam.DT_TYPE_HSF,-1)
					));
			ret.put(method.getApp()+method.getService()+method.getMethod()+":�ɹ�/��ʱ/�쳣��", 
					Arrays.asList(
					new KvGraphMonitorItemDO(method.getApp()+"|�ɹ���",providerDO.getTotalSuccRateNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|��ʱ��",providerDO.getTotalTimeoutRateNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|ҵ���쳣��",providerDO.getTotalBizExceptionRateNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|�����쳣��",providerDO.getTotalExceptionRateNode(), KvGraphParam.DT_TYPE_HSF,0)
					));
			ret.put(method.getApp()+method.getService()+method.getMethod()+":��ʱ/�쳣��", 
					Arrays.asList(
					new KvGraphMonitorItemDO(method.getApp()+"|��ʱ��",providerDO.getTotalTimeoutCountNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|ҵ���쳣��",providerDO.getTotalBizExceptionCountNode(), KvGraphParam.DT_TYPE_HSF,0),
					new KvGraphMonitorItemDO(method.getApp()+"|�����쳣��",providerDO.getTotalExceptionCountNode(), KvGraphParam.DT_TYPE_HSF,0)
					));
			
		}
		return ret;
	}
	private void sortMethods(String orderBy, List<HsfMethodDO> methods) {
		//2.���ñ���
		if ( orderBy.equals("count") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					return -(int)(o1.getTotalSuccCount()-o2.getTotalSuccCount());
				}
			
			});
		}else if ( orderBy.equals("tcount") ){
				Collections.sort(methods, new Comparator<HsfMethodDO>() {
					@Override
					public int compare(HsfMethodDO o1, HsfMethodDO o2) {
						return -(int)(o1.getTotalTimeoutCount()-o2.getTotalTimeoutCount());
					}
				
				});
		}else if ( orderBy.equals("allcount") ){
				Collections.sort(methods, new Comparator<HsfMethodDO>() {
					@Override
					public int compare(HsfMethodDO o1, HsfMethodDO o2) {
						return -(int)(o1.getTotalCount()-o2.getTotalCount());
					}
				
				});
		}else if ( orderBy.equals("ecount") ){
				Collections.sort(methods, new Comparator<HsfMethodDO>() {
					@Override
					public int compare(HsfMethodDO o1, HsfMethodDO o2) {
						return -(int)(o1.getTotalExceptionCount()-o2.getTotalExceptionCount());
					}
				
				});
		}else if ( orderBy.equals("becount") ){
				Collections.sort(methods, new Comparator<HsfMethodDO>() {
					@Override
					public int compare(HsfMethodDO o1, HsfMethodDO o2) {
						return -(int)(o1.getTotalBizExceptionCount()-o2.getTotalBizExceptionCount());
					}
				
				});
		}else if ( orderBy.equals("rt") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					if ( o1.getAvgRT() < o2.getAvgRT() ){
						return 1;
					}else if ( o1.getAvgRT() > o2.getAvgRT() ){
						return -1;
					}
					return 0;
				}
			});
		}else if ( orderBy.equals("tsucc_percent") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					if ( o1.getSucPercent() < o2.getSucPercent() ){
						return 1;
					}else if ( o1.getSucPercent() > o2.getSucPercent() ){
						return -1;
					}
					return 0;
				}
			});
		}else if ( orderBy.equals("tcount_percent") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					if ( o1.getTimeoutPercent() < o2.getTimeoutPercent() ){
						return 1;
					}else if ( o1.getTimeoutPercent() > o2.getTimeoutPercent() ){
						return -1;
					}
					return 0;
				}
			});
		}else if ( orderBy.equals("ecount_percent") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					if ( o1.getExceptionPercent() < o2.getExceptionPercent() ){
						return 1;
					}else if ( o1.getExceptionPercent() > o2.getExceptionPercent() ){
						return -1;
					}
					return 0;
				}
			});
		}else if ( orderBy.equals("becount_percent") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					if ( o1.getBizExceptionPercent() < o2.getBizExceptionPercent() ){
						return 1;
					}else if ( o1.getBizExceptionPercent() > o2.getBizExceptionPercent() ){
						return -1;
					}
					return 0;
				}
			});
		}else if ( orderBy.equals("service") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					return o1.getService().compareTo(o2.getService());
				}
			
			});
		}else if ( orderBy.equals("app") ){
			Collections.sort(methods, new Comparator<HsfMethodDO>() {
				@Override
				public int compare(HsfMethodDO o1, HsfMethodDO o2) {
					return o1.getApp().compareTo(o2.getApp());
				}
			});
		}
	}

	@RequestMapping("appServiceList.htm")
    public String appServiceList(final HttpServletRequest request, ModelMap result) throws DAOException, ParseException {
		String orderBy = request.getParameter("orderBy");
		String corderBy = request.getParameter("corderBy");
//		boolean fromsafe = Boolean.parseBoolean(request.getParameter("fromsafe"));
		result.put("fromsafe",sceneVersionManager.isRandomRTVersion(request.getParameter("app")));
		result.put("hsfMetaVersion",sceneVersionManager.isHsfMetaVersion(request.getParameter("app")));
		String selectedTab = "f_pro";//�����ṩ
		//0.ȷ����ǰѡ�е�tab
		if ( corderBy != null ){
			selectedTab = "f_con";//����
		}
		String alarmConf = request.getParameter("alarm");
		if ( StringUtils.isNotBlank(alarmConf) ){
			selectedTab = "f_alarm";
		}
		result.put("selectedTab",selectedTab);
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		result.put("beta",beta);
		if ( orderBy == null ){
			orderBy = "service";
		}
		result.put("orderBy",orderBy);
		if ( corderBy == null ){
			corderBy = "service";
		}
		result.put("corderBy",corderBy);
		String app = request.getParameter("app");
		if ( app == null ){
			return APP_SERVICE_LIST;
		}
		result.put("app",app);
		Date startDate = getDay2(request,result);
		HSFMethodDomain hsfMetadata = hsfMetaDataManager.fetchHsfMethodMetadata(app);
		result.put("hsfMetadata",hsfMetadata);
		result.put("ips",hsfMetaDataManager.fetchIps(app));

		result.put("hsfOprDescMap",sceneDynamicOprHisManager.fetchTimeOutOprDesc(app));

		//1.��ȡ�����ṩ��
		List<ServiceDetailDO> hsfProviderDetails = hsfRelationManager.getHsfProviderDetails(app, startDate,beta);
		if ( hsfProviderDetails != null ){
			//2.��ȡ�ṩ�ߣ�ת��Ϊmethodγ��
			List<HsfMethodDO> methods = hsfRelationManager.convertToMethodDetail(app, hsfProviderDetails);
			//3.����
			sortMethods(orderBy, methods);
			//4.����ɫ
			Set<String> services = new HashSet<String>();
			for ( HsfMethodDO method:methods ){
				services.add(method.getService());
			}
			ColorUtil.assignColor(result, services, "service");
			result.put("methods", methods);
			result.put("services",services);
		}
		//5.��ȡ������:
		List<ServiceDetailDO> hsfConsumerDetails = hsfRelationManager.getHsfConsumerDetails(app, startDate,beta);
		if ( hsfConsumerDetails != null ){
			List<HsfMethodDO> cmethods = hsfRelationManager.convertToMethodDetail(app, hsfConsumerDetails);
			//6.����
			sortMethods(corderBy, cmethods);
			//7.����ɫ
			Set<String> cservices = new HashSet<String>();
			for ( HsfMethodDO cmethod:cmethods ){
				cservices.add(cmethod.getService());
			}
			ColorUtil.assignColor(result, cservices, "cservice");
			result.put("cmethods", cmethods);
			result.put("cservices",cservices);
		}
		List<String> allTypes = Arrays.asList(RuleTypeConstant.GLOBAL_HSF_EXCEPTION,RuleTypeConstant.GLOBAL_HSF_TIMEOUT);
		//6.��ȡ������Ϣ
		if(alarmSwitchManager.isNew(app)){
			result.put("newAlarm",true);
			List<AlarmNewRuleVO> allRules = new ArrayList<AlarmNewRuleVO>();
			for ( String type:allTypes ){
				List<AlarmNewRuleVO> rules = alarmRuleManager.getNewGlobalAlarmRulesOfType(app, type);
				if ( rules != null && !rules.isEmpty() ){
					allRules.addAll(rules);
				}
			}
			if ( allRules != null && !allRules.isEmpty() ){
				result.put("rules",allRules);
			}
		}else{

			List<AlarmRuleDO> allRules = new ArrayList<AlarmRuleDO>();
			for ( String type:allTypes ){
				List<AlarmRuleDO> rules = alarmRuleManager.getGlobalAlarmRulesOfType(app, type);
				if ( rules != null && !rules.isEmpty() ){
					allRules.addAll(rules);
				}
			}
			if ( allRules != null && !allRules.isEmpty() ){
				result.put("rules",allRules);
				result.put("ruleObjs", alarmRuleManager.getRuleObj(allRules));
			}
		}

		//6.1.����Ա
		AppDO apps = appDAO.getAppByName(app);
		result.put("admins",apps.getAdministrators());
		result.put("returnUrl", super.getWholeUrl(request,"&alarm=1"));
		//7.0 �鿴����hsf���ݵ���ͼ
		/*
		List<SingleViewDO> views = ateyeViewService.listSViewOfApp(app, LineDefDO.TYPE_HSF);
		result.put("views",views);
		*/
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByApp(app);
		result.put("alarmGrps", alarmGroups);
		
        return APP_SERVICE_LIST;
    }	
	private Date getDayDefaultYesterday(final HttpServletRequest request,ModelMap result) throws ParseException{
		String day = request.getParameter("day");
		if ( day == null ){
			String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),-1));
			result.put("current",formatToDay);
			Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
			result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
			return DateFormatUtil.parseByDay(formatToDay);
		}
		result.put("current",day);
		Date dayObj = com.taobao.util.CalendarUtil.toDate(day, "yyyy-MM-dd");
		result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
		return CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
	}
	private Date getDay2(final HttpServletRequest request,ModelMap result) throws ParseException{
		String day = request.getParameter("day");
		if ( day == null ){
			String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),0));
			result.put("current",formatToDay);
			Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
			result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
			return DateFormatUtil.parseByDay(formatToDay);
		}
		result.put("current",day);
		Date dayObj = com.taobao.util.CalendarUtil.toDate(day, "yyyy-MM-dd");
		result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
		return CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
	}
}
