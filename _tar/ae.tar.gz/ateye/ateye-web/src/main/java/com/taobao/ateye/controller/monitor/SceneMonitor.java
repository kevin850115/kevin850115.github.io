package com.taobao.ateye.controller.monitor;

import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.scene.index.create.SceneHistoryManager;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.relation.builder.RTreeBuilder;
import com.taobao.ateye.relation.manager.SceneManager;
import com.taobao.ateye.relation.model.RNode;
import com.taobao.ateye.relation.model.RTree;
import com.taobao.ateye.relation.model.RTreeResult;
import com.taobao.ateye.util.CalendarUtil;

@Controller
@RequestMapping("/monitor")
public class SceneMonitor {
	private Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private SceneManager sceneManager;

	@Autowired
	private SceneHistoryManager historyManager;
	
	private void outPut(PrintWriter w,String s){
		w.println(s);
	}
	@RequestMapping("querySingleSceneServiceRelation.htm")
    public String querySingleSceneServiceRelation(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String sceneName = request.getParameter("sceneName");
		if ( StringUtils.isBlank(sceneName) ){
			return "";
		}
		historyManager.his(sceneName);
		String type = request.getParameter("type");
		String day = request.getParameter("day");
		String entryPointType = request.getParameter("entryPointType");
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		String clientAppName = request.getParameter("clientAppName");
		String includeDAO = request.getParameter("includeDAO");
		String onlyMainPath = request.getParameter("onlyMainPath"); 
		RTreeResult tree = sceneManager.buildSingleSceneServiceRelation(sceneName,type,clientAppName,dayObj,entryPointType,
				StringUtils.isNotBlank(includeDAO),
				StringUtils.isNotBlank(onlyMainPath)
				);
		String buildJson = tree.toJson();
		PrintWriter out = response.getWriter();
		outPut(out,buildJson);
		return null;
    }
	@RequestMapping("querySingleSceneAppRelation.htm")
    public String querySingleSceneAppRelation(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String sceneName = request.getParameter("sceneName");
		if ( StringUtils.isBlank(sceneName) ){
			return "";
		}
		historyManager.his(sceneName);
		String type = request.getParameter("type");
		String day = request.getParameter("day");
		String entryPointType = request.getParameter("entryPointType");
		String clientAppName = request.getParameter("clientAppName");
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		RTree tree = sceneManager.buildSingleSceneAppRelation(sceneName,type,clientAppName,dayObj,entryPointType);
		String buildJson = RTreeBuilder.buildJson(tree);
		PrintWriter out = response.getWriter();
		outPut(out,buildJson);
		return null;
    }
	@RequestMapping("querySceneByService.htm")
    public String querySceneByService(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String service = request.getParameter("service");
		if ( StringUtils.isBlank(service) ){
			return "";
		}
		String type = request.getParameter("type");
		String day = request.getParameter("day");
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		RTree tree = sceneManager.buildSceneByService(service,type,dayObj);
		String buildJson = RTreeBuilder.buildJson(tree);
		PrintWriter out = response.getWriter();
		outPut(out,buildJson);
		return null;
    }
	@RequestMapping("querySceneByAppNodeGroup.htm")
    public String querySceneByAppNodeGroup(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String appNodeGroup = request.getParameter("appNodeGroup");
		if ( StringUtils.isBlank(appNodeGroup) ){
			return "";
		}
		String type = request.getParameter("type");
		String day = request.getParameter("day");
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		RTree tree = sceneManager.buildSceneByAppNodeGroup(appNodeGroup, type, dayObj);
		String buildJson = RTreeBuilder.buildJson(tree);
		PrintWriter out = response.getWriter();
		outPut(out,buildJson);
		return null;
    }
	@RequestMapping("queryTest.htm")
    public String queryTest(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		RTree tree = new RTree();
		RNode root = new RNode();
		tree.setRoot(root);
		root.setColor("red");
		root.setUniqName("���ڵ�");
		root.setPopUpText("<a href='http://ateye.trip.taobao.com' target='_blank'>����1</a><br>" +
				"<a href='http://ateye.trip.taobao.com' style='color:red' target='_blank'>����2</a>" +
				"<h1>�����</h1>");
		RNode n1 = new RNode();
		n1.setColor("green");
		n1.setUniqName("�ڵ�1");
		n1.setPopUpText("�ڵ�1��Ϣ");
		RNode n2 = new RNode();
		n2.setColor("red");
		n2.setUniqName("�ڵ�2");
		n2.setPopUpText("�ڵ�2��Ϣ");
		RNode n3 = new RNode();
		n3.setColor("red");
		n3.setUniqName("�ڵ�3");
		n3.setPopUpText("�ڵ�3��Ϣ");
		RNode n4 = new RNode();
		n4.setColor("blue");
		n4.setUniqName("�ڵ�4");
		n4.setPopUpText("�ڵ�4��Ϣ");
		RNode n5 = new RNode();
		n5.setColor("blue");
		n5.setUniqName("�ڵ�5");
		n5.setPopUpText("�ڵ�6��Ϣ");
		RNode n6 = new RNode();
		n6.setColor("blue");
		n6.setUniqName("�ڵ�6");
		n6.setPopUpText("�ڵ�6��Ϣ");
		n5.addChild(n6);
		n5.addChild(n4);
		n2.addChild(n3);
		n1.addChild(n2);
		root.addChild(n1);
		root.addChild(n2);
		root.addChild(n3);
		root.addChild(n5);
		String buildJson = RTreeBuilder.buildJson(tree);
		PrintWriter out = response.getWriter();
		outPut(out,buildJson);
		return null;
    }
}
