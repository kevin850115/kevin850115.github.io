package com.taobao.ateye.controller.scene;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.fault.location.AbstractGraphFaultManager;
import com.taobao.ateye.fault.location.ContextDO;
import com.taobao.ateye.fault.location.manager.SceneFaultLocationManager;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.app.model.AppModelDO;
import com.taobao.ateye.cache.AppCache;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.SceneCatDAO;
import com.taobao.ateye.dal.SceneLevelDAO;
import com.taobao.ateye.dataobject.SceneEntryPoint;
import com.taobao.ateye.dataobject.SceneExtendModel;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.monitor.MonitorItemDO;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.realtime.RealTimeRecordModelListDO;
import com.taobao.ateye.relation.manager.SceneManager;
import com.taobao.ateye.relation.model.RNode;
import com.taobao.ateye.relation.model.RNodeExtInfo;
import com.taobao.ateye.relation.model.RTreeResult;
import com.taobao.ateye.relation.tree.param.TreeBuilderParam;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.scene.DependencyType;
import com.taobao.ateye.scene.index.create.SceneHistoryManager;
import com.taobao.ateye.scene.manager.SceneEntryManager;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.ateye.scene.manager.SceneErrorStat;
import com.taobao.ateye.scene.monitor.SceneMonitorManager;
import com.taobao.ateye.scene.monitor.SceneMonitorResult;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.user.UserManager;
import com.taobao.security.util.SecurityUtil;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/scene")
public class SceneEntryController extends AbstractController{

	private static final String ENTRY_LIST = "screen/scene/entryList";
	private static final String SUPPORT_ENTRY_LIST = "screen/scene/supportEntryList";
	private static final String SCENE_DETAIL = "screen/scene/scene";
	private static final String SCENE_GRAPH = "screen/scene/sceneGraph";


	@Autowired
	private SceneEntryManager sceneEntryManager;
	@Autowired
	private SceneLevelDAO sceneLevelDAO;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private SceneCatDAO sceneCatDAO;
	@Autowired
	private SceneManager sceneManager;
	@Autowired
	private UserManager userManager;
	@Autowired
	private SceneMonitorManager sceneMonitorManager;

	@Autowired
	private SceneHistoryManager historyManager;
	@RequestMapping("entryList.htm")
	public String entryList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltTag = request.getParameter("fltTag");
		if ( StringUtils.isNotBlank(fltTag) ){
			flts.put("tag", fltTag);
			result.put("fltTag",fltTag);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltCat= request.getParameter("fltCat");
		if ( StringUtils.isNotBlank(fltCat) ){
			flts.put("cat", fltCat);
			result.put("fltCat",fltCat);
		}
		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltType= request.getParameter("fltType");
		if ( StringUtils.isNotBlank(fltType) ){
			flts.put("typeDesc", fltType);
			result.put("fltType",fltType);
		}
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		SceneEntryModel model = sceneEntryManager.getEntryList(flts);
		Map<String, List<Pair<String, Integer>>> fltMap = model.getFltMap();
		result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
		result.put("typeFlt", fltMap.get("typeDesc"));
		result.put("appFlt", fltMap.get("app"));
        result.put("tagFlt", fltMap.get("tag"));
        result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("bizMap",getBizMap());
		result.put("catFlt", formatToLong(fltMap.get("cat")));
		result.put("levelFlt", formatToLong(fltMap.get("level")));
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("entrys",model.getRetList());
		result.put("model",model);
		result.put("allCats",sceneCatDAO.getAllMap());
		result.put("allLevels", sceneLevelDAO.getAllMap());
		result.put("fullShow", "true");

		return ENTRY_LIST;
    }
	@RequestMapping("supportEntryList.htm")
	public String supportEntryList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		//1.ȷ������Ӧ���б��ķ�Χ
		String owner = request.getParameter("owner");
		Set<String> fltApps = new HashSet<String>();
		if ( StringUtils.isNotBlank(owner) ){
			fltApps = userManager.getOwnApps(owner);
		}
		result.put("owner",owner);
		String app = request.getParameter("app");
		if ( StringUtils.isNotBlank(app) ){
			fltApps.clear();
			fltApps.add(app);
		}
		result.put("app",app);
		String biz = request.getParameter("biz");
		result.put("biz", biz);
		if ( StringUtils.isNotBlank(biz) ){
			Integer nBiz = Integer.valueOf(biz);
			fltApps = AppCache.getBizApps().get(nBiz);
		}
		//2.ȷ��ɸѡ��Χ
		String fltCat= request.getParameter("fltCat");
		if ( StringUtils.isNotBlank(fltCat) ){
			flts.put("cat", fltCat);
			result.put("fltCat",fltCat);
		}
		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltType= request.getParameter("fltType");
		if ( StringUtils.isNotBlank(fltType) ){
			flts.put("type", fltType);
			result.put("fltType",fltType);
		}
		//3.��ȡģ��
		SceneEntryModel model = sceneEntryManager.getAppSupportEntryList(fltApps, flts);
		Map<String, List<Pair<String, Integer>>> fltMap = model.getFltMap();
		result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
		result.put("typeFlt", fltMap.get("type"));
		result.put("bizMap",getBizMap());
		result.put("catFlt", formatToLong(fltMap.get("cat")));
		result.put("levelFlt", formatToLong(fltMap.get("level")));
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("entrys",model.getRetList());
		result.put("model",model);
		result.put("allCats",sceneCatDAO.getAllMap());
		result.put("allLevels", sceneLevelDAO.getAllMap());
		result.put("fullShow", "true");

		return SUPPORT_ENTRY_LIST;
    }
	@RequestMapping("sceneOpenDetect.htm")
	public String openSceneDetect(final HttpServletRequest request, final ModelMap result) throws Exception {
		String sceneId = request.getParameter("id");
		if ( StringUtils.isBlank(sceneId) ){
			return null;
		}
		sceneEntryManager.openDetect(Long.valueOf(sceneId));
		return "redirect:/scene/scene.htm?id="+sceneId;
	}
	@RequestMapping("sceneCloseDetect.htm")
	public String closeSceneDetect(final HttpServletRequest request, final ModelMap result) throws Exception {
		String sceneId = request.getParameter("id");
		if ( StringUtils.isBlank(sceneId) ){
			return null;
		}
		sceneEntryManager.closeDetect(Long.valueOf(sceneId));
		return "redirect:/scene/scene.htm?id="+sceneId;
	}
	@RequestMapping("sceneGraph.htm")
	public String viewSceneGraph(final HttpServletRequest request, final ModelMap result) throws Exception {
		String sceneGraph = request.getParameter("graph");
		result.put("cp",sceneGraph);
		return SCENE_GRAPH;
	}
	/*
	 * ����ID����Name����λ����
	 */
	private SceneEntryPoint getEntryPoint(final HttpServletRequest request) throws Exception {
		String sceneId = request.getParameter("id");
		if (StringUtils.isNotBlank(sceneId)) {
			Long id = Long.valueOf(sceneId);	
			SceneEntryPoint epDO = sceneEntryPointDAO.getEntryPointById(id);
			return epDO;
		}
		String name = request.getParameter("name");
		if (StringUtils.isNotBlank(name)) {
			return getEntryPointByName(name);
		}
		return null;
	}
	@RequestMapping("scene.htm")
	public String viewScene(final HttpServletRequest request, final ModelMap result) throws Exception {
		SceneEntryPoint epDO = getEntryPoint(request);
		if ( epDO == null ) {
			return null;
		}
		result.put("entry",epDO);
		if ( epDO != null ){
			historyManager.his(epDO.getName());
			String appName = epDO.getAppName();
			AppModelDO appModelDO = AppCache.getApps().get(appName);
			if ( appModelDO != null ){
				result.put("appInfo",appModelDO);
			}
		}
		Long id = epDO.getId();
		result.put("id",id);
		String day = request.getParameter("day");
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		SceneExtendModel extendInfo = sceneEntryManager.getExtendInfo(id);
		result.put("extendInfo",extendInfo);
		
		Date today = CalendarUtil.zerolizedTime(new Date());
		result.put("day", CalendarUtil.toString(dayObj, CalendarUtil.DATE_FMT_3));
		result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("allCats",sceneCatDAO.getAllMap());
		result.put("allLevels", sceneLevelDAO.getAllMap());
		//1.��ȡÿ��������
		RNodeExtInfo stat = sceneEntryManager.getSceneDayStat(epDO, dayObj);
		result.put("extInfoDay",stat);
		//2.��ȡ���������
		SceneErrorStat sceneErrorStat = sceneEntryManager.getSceneDayErrorStat(epDO, dayObj);
		result.put("errorStatsDay",sceneErrorStat);
		//3.����ǵ��죬ȡ��ǰСʱ
		boolean istoday = false;
		if ( today.equals(CalendarUtil.zerolizedTime(dayObj)) ){
			istoday = true;
		}
		result.put("istoday",istoday);
		if ( istoday ){
			RNodeExtInfo hourStat = sceneEntryManager.getSceneHourStat(epDO, dayObj);
			result.put("extInfoHour",hourStat);
			//2.��ȡ���������
			SceneErrorStat sceneHourErrorStat = sceneEntryManager.getSceneHourErrorStat(epDO, dayObj);
			result.put("errorStatsHour",sceneHourErrorStat);
		}
		//3.3.
		//4.��ȡʵʱץ��·�б�
		if ( DependencyType.MTOP.getType().equals(epDO.getType())){
			Map<String, String> flts = new HashMap<String,String>();
			flts.put("app", epDO.getAppName());
			RealTimeRecordModelListDO rtrList = realTimeRecordManager.queryRealTimeRecordList(flts, new Date());
			if ( rtrList != null ){
				result.put("rtrList",rtrList.getTopNRetList(5));
				result.put("rtrCnt",rtrList.getRetList().size());
			}
			result.put("showRealTimeRecord","true");
		}
		//5.��ȡ���������б�
		/*
		SimModelListDO simModel = simModelManager.querySimListByScene(epDO.getId(),DateUtils.addDays(new Date(), -7),new Date());
		if ( simModel != null){
			result.put("sims",simModel.getTopNRetList(5));
			result.put("simCnt",simModel.getRetList().size());
		}
		*/
		//6.�Զ���ͼ��չʾ
		SceneFaultLocationManager faultLocationManager = (SceneFaultLocationManager) AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.SCENE_MONITOR);
		Map<String,List<KvGraphMonitorItemDO>> items = faultLocationManager.buildGraph(epDO,stat,sceneErrorStat,result,dayObj,new ContextDO());

		result.put("bizMap",getBizMap());
		result.put("empIdMap",userCache.getEmpIdMap());
		List<String> customeParams = kvGraphManager.buildParam(items,DataBuilder.graphSizeMap.get("xxs"));
		result.put("customParams", customeParams);
		List<String> customeBigParams = kvGraphManager.buildParam(items,DataBuilder.defaultSize);
		result.put("customeBigParams", customeBigParams);
		
		result.put("app",epDO.getAppName());
		//10.������������־
		String detectUrl = buildDetectLogUrl(id);
		result.put("detectUrl",detectUrl);
		return SCENE_DETAIL;
	}
	private String buildDetectLogUrl(Long id) {
		KeysDO keys = new KeysDO("#QPS#������ڼ��",String.valueOf(id),"");
		return MonitorItemDO.getKvDetailUrl(keys, "ateye:ateye_jobhost", DateUtils.addMinutes(new Date(), -10));
	}
	@RequestMapping("detectScene.htm")
	public String detectScene(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		if ( StringUtils.isBlank(id) ){
			return null;
		}
		Long sceneId = Long.valueOf(id);
		PrintWriter out = response.getWriter();
		SceneMonitorResult rs = sceneMonitorManager.monitorScene(sceneId, new Date());
		if ( rs == null ){
			return null;
		}
		String json = rs.toJson();
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }	
	public static void main(String[] args) {
		String json = "{'ok':'<table><tr><td>ʱ��</td><td'}";
		System.out.println(SecurityUtil.escapeJson(json));
	}
	@RequestMapping("updateSceneLevelAjax.htm")
	public String updateSceneLevelAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String entryId = request.getParameter("entryId");
		String levelId = request.getParameter("levelId");
		PrintWriter out = response.getWriter();
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(entryId) && StringUtils.isNotBlank(levelId) ){
			update = sceneEntryPointDAO.updateLevel(Long.valueOf(entryId),Long.valueOf(levelId));
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }	
	@RequestMapping("updateSceneCatAjax.htm")
	public String updateSceneCatAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String entryId = request.getParameter("entryId");
		String catId = request.getParameter("catId");
		PrintWriter out = response.getWriter();
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(entryId) && StringUtils.isNotBlank(catId) ){
			update = sceneEntryPointDAO.updateCat(Long.valueOf(entryId),Long.valueOf(catId));
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }	
	@RequestMapping("updateSceneDescAjax.htm")
	public String updateSceneDescAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String entryId = request.getParameter("entryId");
		String desc = request.getParameter("desc");
		PrintWriter out = response.getWriter();
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(entryId) && StringUtils.isNotBlank(desc) ){
			update = sceneEntryPointDAO.updateDesc(Long.valueOf(entryId),desc);
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }

	@RequestMapping("addSceneTagAjax.htm")
	public String addSceneTagAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String sceneId = request.getParameter("sceneId");
		String tag = request.getParameter("tag");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( org.apache.commons.lang3.StringUtils.isNotBlank(sceneId) && org.apache.commons.lang3.StringUtils.isNotBlank(tag) ){
			boolean isSucc = sceneEntryManager.addSceneTag(Long.valueOf(sceneId), tag);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
	}

	@RequestMapping("removeSceneTagAjax.htm")
	public String removeSceneTagAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String sceneId = request.getParameter("sceneId");
		String tag = request.getParameter("tag");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(sceneId) && StringUtils.isNotBlank(tag) ){
			boolean isSucc = sceneEntryManager.removeSceneTag(Long.valueOf(sceneId), tag);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
	}
}
