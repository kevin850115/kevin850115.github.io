package com.taobao.ateye.controller.alarm.data;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Created by sunqiang on 2018/12/17.
 */
public class AlarmSubRelation {
    /**
     * ����
     */
    private long confId;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * �ۺϱ�������
     */
    private String name;

    /**
     * 0-��Ч,1-��ͣ 2-�߼�ɾ��
     */
    private int status;

    /**
     * �����м���ͣһ��ʱ��
     */
    private Date reopenDate;

    /**
     * Ψһ��ʾ
     */
    private String uuid;

    /**
     * �Ƿ�ۺϱ��� 0-�� 1-��
     */
    private int isAggr;


    /**
     * ��������
     */
    private int alarmCount;
    /**
     * ������ ������Ÿ���
     */
    private String subStr;

    private Set<Long> subIds = Sets.newHashSet();

    /**
     * app��Χ������ ������Ÿ���
     */
    private String appScopeSubStr;

    /**
     * Ӧ������
     */
    private String app;

    /**
     * ������k1
     */
    private String k1;
    /**
     * ������k2
     */
    private String k2;
    /**
     * ������k3
     */
    private String k3;
    /**
     * ������k4
     */
    private String k4;
    /**
     * ������k5
     */
    private String k5;
    /**
     * ������k6
     */
    private String k6;

    /**
     * ������KVʱ���ڶ���ֵ��ValueType:v1,v2,v1v2,v2v1
     */
    private String type2;

    /**
     * ������KVʱ���ڶ���ֵ��Ӧ����
     */
    private String app2;

    /**
     * ҵ������,KV EXCEPTION��
     */
    private String ruleType;

    /**
     * ҵ������,KV EXCEPTION��
     */
    private String ruleTypeDetail;

    /**
     * ����
     */
    private String env;

    /**
     * ����KV��,��ʾv1,v2,v1v2,v2v1
     */
    private String type;

    public String getRuleTypeDetail() {
        return ruleTypeDetail;
    }

    public void setRuleTypeDetail(String ruleTypeDetail) {
        this.ruleTypeDetail = ruleTypeDetail;
    }

    public String getK1() {
        return k1;
    }

    public void setK1(String k1) {
        this.k1 = k1;
    }

    public String getK2() {
        return k2;
    }

    public void setK2(String k2) {
        this.k2 = k2;
    }

    public String getK3() {
        return k3;
    }

    public void setK3(String k3) {
        this.k3 = k3;
    }

    public String getK4() {
        return k4;
    }

    public void setK4(String k4) {
        this.k4 = k4;
    }

    public String getK5() {
        return k5;
    }

    public void setK5(String k5) {
        this.k5 = k5;
    }

    public String getK6() {
        return k6;
    }

    public void setK6(String k6) {
        this.k6 = k6;
    }

    public String getType2() {
        return type2;
    }

    public void setType2(String type2) {
        this.type2 = type2;
    }

    public String getApp2() {
        return app2;
    }

    public void setApp2(String app2) {
        this.app2 = app2;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getConfId() {
        return confId;
    }

    public void setConfId(long confId) {
        this.confId = confId;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getIsAggr() {
        return isAggr;
    }

    public void setIsAggr(int isAggr) {
        this.isAggr = isAggr;
    }

    public String getSubStr() {
        return subStr;
    }

    public void setSubStr(String subStr) {
        this.subStr = subStr;
    }

    public String getAppScopeSubStr() {
        return appScopeSubStr;
    }

    public void setAppScopeSubStr(String appScopeSubStr) {
        this.appScopeSubStr = appScopeSubStr;
    }

    public int getAlarmCount() {
        return alarmCount;
    }

    public void setAlarmCount(int alarmCount) {
        this.alarmCount = alarmCount;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public Date getReopenDate() {
        return reopenDate;
    }

    public void setReopenDate(Date reopenDate) {
        this.reopenDate = reopenDate;
    }

    public Set<Long> getSubIds() {
        return subIds;
    }

    public void setSubIds(Set<Long> subIds) {
        this.subIds = subIds;
    }
}
