package com.taobao.ateye.controller.arch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.arch.AppServiceDescManager;
import com.taobao.ateye.arch.AppServiceIndexManager;
import com.taobao.ateye.arch.ArchitectureManager;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.AppServiceDescDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.hsf.relation.HsfMethodDO;
import com.taobao.ateye.hsf.relation.HsfRelationManager;
import com.taobao.ateye.hsf.relation.HsfServiceMethodDO;
import com.taobao.tracker.hbase.ServiceDetailDO;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.util.CalendarUtil;

/**
 * ��������ҳ���߼�
 * 
 * @author saite.wd
 * @version $Id: ServiceController.java, v 0.1 2016��2��15�� ����8:37:53 saite Exp $
 */
@Controller
@RequestMapping("/arch")
public class ServiceController extends AbstractController {
    
    @Resource
    private HsfRelationManager hsfRelationManager;
    
    @Resource
    private AppServiceDescManager appServiceDescManager;
    
    @Resource
    private AppServiceIndexManager appServiceIndexManager;
    
    @Resource
    private MonitorLogQueryService monitorLogQueryService;
    
    @Resource
    private ArchitectureManager architectureManager;
    
    @RequestMapping("manageServices.htm")
    public String manageServices(final HttpServletRequest request, ModelMap result) throws Exception {
        result.put("to", "/arch/appServices.htm");
        result.put("level2","Ӧ�÷�������");
        if ( initBizMapOwned(result) == null ){
            return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    }
    
    @RequestMapping("securityServices.htm")
    public String securityServices(final HttpServletRequest request, ModelMap result) throws Exception {
        result.put("to", "http://console.alibaba-inc.com/#/spas/service/hsf/offered");
        result.put("level2","Ӧ�÷���ȫ");
        result.put("newWindow", true);
        result.put("needAppId", true);
        if ( initBizMapOwned(result) == null ){
            return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    }
    
    @RequestMapping("searchServices.htm")
    public String searchServices(final HttpServletRequest request, ModelMap result) throws Exception {
        String keywords = request.getParameter("keywords");
        if (StringUtils.isEmpty(keywords)) {
            result.put("isQuery", true);
        } else {
            List<AppServiceDescDO> serviceDescs = appServiceIndexManager.query(keywords);
            result.put("categoryMap", AppServiceDescDO.CATEGORIES);
            result.put("keywords", keywords);
            result.put("serviceDescs", serviceDescs);
        }
        return "screen/arch/searchServices";
    }
    
    private String queryApps(final HttpServletRequest request, ModelMap result, boolean queryFinish) throws Exception {
        Date day = CalendarUtil.zerolizedTime(new Date());
        List<AppDO> unfinishedApps = new ArrayList<AppDO>();
        List<AppDO> apps = appDAO.getAllAppAsList();
        int totalServices = 0;
        int totalMethods = 0;
        int unfinishTotalServices = 0;
        int unfinishTotalMethods = 0;
        for (AppDO app : apps) {
            String appName = app.getAppName();
            List<ServiceDetailDO> hsfProviderDetails = hsfRelationManager.getHsfProviderDetails(appName, day, false);
            if (CollectionUtils.isEmpty(hsfProviderDetails)) {
                continue;
            }
            for (ServiceDetailDO service : hsfProviderDetails) {
                totalServices++;
                totalMethods += service.getMethodDetails().size();
            }
            List<AppServiceDescDO> appDescs = appServiceDescManager.queryByApp(appName);
            if (CollectionUtils.isEmpty(appDescs)) {
                unfinishedApps.add(app);
                for (ServiceDetailDO service : hsfProviderDetails) {
                    unfinishTotalServices++;
                    unfinishTotalMethods += service.getMethodDetails().size();
                }
                continue;
            }
            int methodSize = 0;
            int serviceSize = 0;
            int realMethodSize = 0;
            int realServiceSize = 0;
            for (ServiceDetailDO service : hsfProviderDetails) {
                serviceSize += 1;
                methodSize += service.getMethodDetails().size();
            }
            for (AppServiceDescDO appDesc : appDescs) {
                String method = appDesc.getMethod();
                if (StringUtils.isEmpty(method)) {
                    realServiceSize++;
                } else {
                    realMethodSize++;
                }
            }
            if (realServiceSize < serviceSize) {
                unfinishedApps.add(app);
                unfinishTotalMethods += Math.max(methodSize - realMethodSize, 0);
                unfinishTotalServices += Math.max(serviceSize - realServiceSize, 0);
                continue;
            }
        }
        result.put("to", "/arch/appServices.htm");
        if (!queryFinish) {
            result.put("level2","δ��ɷ���������Ӧ��(" + unfinishedApps.size() + ")[�ܷ�����:" + unfinishTotalServices + ",�ܷ�����:" + unfinishTotalMethods + "]");
        } else {
            result.put("level2","��ɷ���������Ӧ��(" + (apps.size() - unfinishedApps.size()) + ")[�ܷ�����:" + (totalServices - unfinishTotalServices) + ",�ܷ�����:" + (totalMethods - unfinishTotalMethods) + "]");
        }
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return null;
        }
        List<AppDO> appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
        List<AppDO> filteredApps = new ArrayList<AppDO>();
        if (!queryFinish) {
            for (AppDO unfinishedApp : unfinishedApps) {
                for (AppDO app : appDOList) {
                    if (app.getAppName().equals(unfinishedApp.getAppName())) {
                        filteredApps.add(unfinishedApp);
                        break;
                    }
                }
            }
        } else {
            for (AppDO app : appDOList) {
                boolean found = false;
                for (AppDO unfinishedApp : unfinishedApps) {
                    if (app.getAppName().equals(unfinishedApp.getAppName())) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    filteredApps.add(app);
                }
            }
        }
        result.put("allApps", filteredApps);
        if (initBizMap(result, filteredApps) == null) {
            return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    }
    
    @RequestMapping("unfinishedAppServices.htm")
    public String unfinishedAppServices(final HttpServletRequest request, ModelMap result) throws Exception {
        return queryApps(request, result, false);
    }
    
    @RequestMapping("finishedAppServices.htm")
    public String finishedAppServices(final HttpServletRequest request, ModelMap result) throws Exception {
        return queryApps(request, result, true);
    }
    
    @RequestMapping("serviceInMultiApp.htm")
    public String serviceInMultiApp(final HttpServletRequest request, ModelMap result) throws Exception {
        Date day = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), -1);
        List<AppDO> allApps = appDAO.getAllAppAsList();
        Map<String, Set<String>> serviceMap = new HashMap<String, Set<String>>();
        Map<String, AppDO> appMap = new HashMap<String, AppDO>();
        for (AppDO app : allApps) {
            appMap.put(app.getAppName(), app);
            try {
                SortedSet<MonitorLogNode> monitorLogs = monitorLogQueryService
                    .newQueryHsfMonitorLogInfoOfAppIgnoreEnv(app.getAppName(), day, day);
                if (monitorLogs == null || monitorLogs.isEmpty()) {
                    continue;
                }
                for (MonitorLogNode node : monitorLogs) {
                    String k1 = node.getSelfKey();
                    if (k1.equals("HSF-ProviderDetail")) {
                        //��Ϊ�ṩ��
                        SortedSet<MonitorLogNode> services = node.getChildren();
                        for (MonitorLogNode service : services) {
                            Set<String> apps = serviceMap.get(service.getSelfKey());
                            if (apps == null) {
                                apps = new HashSet<String>();
                                serviceMap.put(service.getSelfKey(), apps);
                            }
                            apps.add(app.getAppName());//��¼ÿ�������Owner
                        }
                    }
                }
            } catch (Throwable t) {
                log.error("ͳ��HSF�����쳣", t);
            }
        }
        Iterator<Entry<String, Set<String>>> iter = serviceMap.entrySet().iterator();
        while (iter.hasNext()) {
            Entry<String, Set<String>> e = iter.next();
            Set<String> v = e.getValue();
            if (CollectionUtils.isEmpty(v)) {
                iter.remove();
                continue;
            }
            if (v.size() == 1) {
                iter.remove();
                continue;
            }
        }
        result.put("serviceMap", serviceMap);
        result.put("appMap", appMap);
        result.put("bizTypes", AppChangeLogConstants.bizTypes);
        result.put("subBizTypes", AppChangeLogConstants.subBizTypes);
        result.put("appTypes", AppChangeLogConstants.appTypes);
        result.put("colorConfigs", ArchitectureManager.bizTypeColorConfigMap);
        Date current = CalendarUtil.zerolizedTime(new Date());
        result.put("current", CalendarUtil.formatDate(current, CalendarUtil.DATE_FMT_3));
        return "screen/arch/serviceInMultiApp";
    }
    
    @RequestMapping("appServices.htm")
    public String appServices(final HttpServletRequest request, ModelMap result) throws Exception {
        String appName = request.getParameter("app");
        if (StringUtils.isBlank(appName)) {
            return StringUtils.EMPTY;
        }
        result.put("app", appName);
        Date day = CalendarUtil.zerolizedTime(new Date());
        result.put("current", CalendarUtil.formatDate(day, CalendarUtil.DATE_FMT_3));
        result.put("currentPlus1", CalendarUtil.formatDate(DateUtils.addDays(day, 1), CalendarUtil.DATE_FMT_3));
        result.put("returnUrl", "/arch/appServices.htm?app=" + appName);
        //1.��ȡ�����ṩ��
        List<ServiceDetailDO> hsfProviderDetails = hsfRelationManager.getHsfProviderDetails(appName, day, false);
        if (hsfProviderDetails != null) {
            //2.��ȡ�ṩ�ߣ�ת��Ϊmethodγ��
            List<HsfMethodDO> methods = hsfRelationManager.convertToMethodDetail(appName,
                hsfProviderDetails);
            Collections.sort(hsfProviderDetails, new Comparator<ServiceDetailDO>() {
                @Override
                public int compare(ServiceDetailDO left, ServiceDetailDO right) {
                    long diff = left.getTimes() - right.getTimes();
                    return diff <= 0 ? 1 : -1;
                }
            });
            List<String> services = new ArrayList<String>();
            for (ServiceDetailDO detail : hsfProviderDetails) {
                services.add(detail.getService());
            }
            result.put("methods", methods);
            result.put("services", services);
            List<AppServiceDescDO> appDescs = appServiceDescManager.queryByApp(appName);
            Map<String, AppServiceDescDO> serviceDescMap = new HashMap<String, AppServiceDescDO>();
            Map<String, String> methodDescMap = new HashMap<String, String>();
            if (!CollectionUtils.isEmpty(appDescs)) {
                for (AppServiceDescDO appDesc : appDescs) {
                    String method = appDesc.getMethod();
                    if (StringUtils.isEmpty(method)) {
                        String key = appDesc.getApp() + appDesc.getService();
                        serviceDescMap.put(key, appDesc);
                    } else {
                        String key = appDesc.getApp() + appDesc.getService() + appDesc.getMethod();
                        methodDescMap.put(key, appDesc.getDescription());
                    }
                }
            }
            result.put("serviceDescMap", serviceDescMap);
            result.put("methodDescMap", methodDescMap);
            result.put("categoryMap", AppServiceDescDO.CATEGORIES);
        }
        return "screen/arch/appServices";
    }
    
    @RequestMapping("serviceDetail.htm")
    public String serviceDetail(final HttpServletRequest request, ModelMap result) throws Exception {
        String appName = request.getParameter("app");
        Date day = CalendarUtil.zerolizedTime(new Date());
        Map<String, Map<String, HsfServiceMethodDO>> providerServiceData = getServiceData(appName, day, true);
        Map<String, Map<String, HsfServiceMethodDO>> consumerServiceData = getServiceData(appName, day, false);
        String gtxt = architectureManager.generateServiceGraph(appName, providerServiceData, consumerServiceData);
        result.put("refreshTime", CalendarUtil.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
        result.put("app", appName);
        result.put("gtxt", gtxt);
        return "screen/arch/serviceDetail";
    }
    
    private Map<String, Map<String, HsfServiceMethodDO>> getServiceData(String appName, Date day, boolean provider) throws Exception {
        Map<String, Map<String, HsfServiceMethodDO>> serviceData = new HashMap<String, Map<String, HsfServiceMethodDO>>();
        List<ServiceDetailDO> hsfDetails = null;
        if (provider) {
            hsfDetails = hsfRelationManager.getHsfProviderDetails(appName, day, false);
        } else {
            hsfDetails = hsfRelationManager.getHsfConsumerDetails(appName, day, false);
        }
        if (hsfDetails != null) {
            for (ServiceDetailDO hsfDetail : hsfDetails) {
                String service = hsfDetail.getService();
                SortedSet<MonitorLogNode> results = monitorLogQueryService.getHsfStats(day, service);
                if (results != null) {
                    Map<String, HsfServiceMethodDO> serviceProviderConsumers = hsfRelationManager
                        .getServiceProviderConsumers(service, results);
                    if (serviceProviderConsumers != null) {
                        serviceData.put(service, serviceProviderConsumers);
                    }
                }
            }
        }
        return serviceData;
    }
    
    @RequestMapping("updateServiceDesc.htm")
    public String updateServiceDesc(final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws Exception {
        String app = request.getParameter("app");
        String service = request.getParameter("service");
        String desc = request.getParameter("desc");
        appServiceDescManager.updateAppServiceDesc(app, service, desc);
        return getRedirectUrl(request, response);
    }
    
    @RequestMapping("updateMethodDesc.htm")
    public String updateMethodDesc(final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws Exception {
        String app = request.getParameter("app");
        String service = request.getParameter("service");
        String method = request.getParameter("method");
        String desc = request.getParameter("desc");
        appServiceDescManager.updateAppServiceMethodDesc(app, service, method, desc);
        return getRedirectUrl(request, response);
    }
    
    @RequestMapping("updateServiceCat.htm")
    public String updateServiceCat(final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws Exception {
        String app = request.getParameter("app");
        String service = request.getParameter("service");
        Integer cat = Integer.parseInt(request.getParameter("cat"));
        appServiceDescManager.updateAppServiceCategory(app, service, cat);
        return getRedirectUrl(request, response);
    }
    
}
