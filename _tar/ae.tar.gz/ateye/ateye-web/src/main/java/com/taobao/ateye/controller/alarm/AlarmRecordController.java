package com.taobao.ateye.controller.alarm;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ateye.alarm.n.enu.RuleTypeEnum;
import com.taobao.ateye.alarm.n.enu.RuleTypeMergeEnum;
import com.taobao.ateye.alarm.n.enu.SubscriberEnu;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.alarm.data.AlarmRecord;
import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.tracker.hbase.AlarmRuleLogDO;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by sunqiang on 2018/12/21.
 */
@Controller
@RequestMapping("/alarm")
public class AlarmRecordController extends AbstractAlarmController {

    private static final String ALARM_HISTORY_LOG = "screen/alarm/listAlarm";

    @RequestMapping("listAlarm.htm")
    public String listAllAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        Integer biz = getBiz(request);
        String startDate = request.getParameter("startDate");
        String uuid = request.getParameter("uuid");
        String extendUUID = request.getParameter("extendUUID");
        if(StringUtils.isEmpty(startDate)){
            startDate = CalendarUtil.formatDate(CalendarUtil.getCurrentDate(),CalendarUtil.DATE_FMT_3);
        }
        String appName = request.getParameter("appName");
        String ruleMergeType = request.getParameter("ruleMergeType");
        String alarmGroup = request.getParameter("alarmGroup");
        Long subId = null;
        if(StringUtils.isNotEmpty(alarmGroup)){
            AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.getByUk(alarmGroup,environmentService.getEnvironmentType().getEnv(),0);
            if(subscriberDO != null){
                subId = subscriberDO.getId();
            }else{
                subId = 0l;
            }
        }
        //1���������Ĺ�ϵ
        Set<Long> confIds = null;
        if(biz != null){
            confIds = getConfIdByBiz(biz);
        }

        List<AteyeAlarmRecordDO> alarmRecords = Lists.newArrayList();
        Date alarmStartDate = null;
        if(StringUtils.isNotEmpty(startDate)){
            alarmStartDate = CalendarUtil.toDate(startDate,CalendarUtil.DATE_FMT_3);
        }
        if(!CollectionUtils.isEmpty(confIds)){
            alarmRecords = recordDAO.select(Lists.newArrayList(confIds),alarmStartDate,uuid,extendUUID,appName,subId,environmentService.getEnvironmentType().getEnv());
            if(alarmRecords==null){
                alarmRecords = Lists.newArrayList();
            }
        }else{
            alarmRecords = recordDAO.select(null,alarmStartDate,uuid,extendUUID,appName,subId,environmentService.getEnvironmentType().getEnv());
            if(alarmRecords==null){
                alarmRecords = Lists.newArrayList();
            }
        }

        //2������
        if(StringUtils.isNotEmpty(ruleMergeType)){
            filter(alarmRecords,RuleTypeMergeEnum.getRuleTypesByName(ruleMergeType));
        }else{
            filter(alarmRecords, RuleTypeEnum.getRuleTypeSet());
        }
        //4����ʱ�䵹��
        List<Pair<String,List<AteyeAlarmRecordDO>>> sortedAlarmLogs = sortAlarmLogs(alarmRecords);
        //5������ָ���������������
        String count = request.getParameter("count");
        if(StringUtils.isNotEmpty(count) && NumberUtils.isNumber(count) && CollectionUtils.isNotEmpty(sortedAlarmLogs)){
            List<Pair<String,List<AteyeAlarmRecordDO>>> recentlyRecords = Lists.newArrayList();
            Pair<String,List<AteyeAlarmRecordDO>> pair = sortedAlarmLogs.get(0);
            recentlyRecords.add(Pair.<String,List<AteyeAlarmRecordDO>>of(pair.getLeft(),Lists.newArrayList(pair.getValue().get(0))));
            sortedAlarmLogs = recentlyRecords;
        }
        //���ķ���Ϣ

        Map<Long,String> subMap = Maps.newHashMap();
        List<AteyeAlarmSubscriberDO>  subs = subscriberDAO.selectAll();
        for (AteyeAlarmSubscriberDO sub : subs) {
            subMap.put(sub.getId(),sub.getName());
        }
        result.put("subMap",subMap);
        //��ɫ
        List<String> hours = getHours(sortedAlarmLogs);

        ColorUtil.assignColor(result, hours, "time");
        result.put("count", alarmRecords.size());
        result.put("ruleMergeMap", RuleTypeMergeEnum.getMap());
        result.put("startDate",startDate);
        result.put("uuid",uuid);
        result.put("extendUUID",extendUUID);
        result.put("biz",biz);
        result.put("alarmGroup",alarmGroup);
        result.put("appName",appName);
        result.put("ruleMergeType",ruleMergeType);
        result.put("bizMap", getBizMap());
        result.put("alarmLogs",sortedAlarmLogs);
        result.put("nick", user.getNick());
        result.put("bizMap", getBizMap());
        result.put("subTypeMap", SubscriberEnu.getSubTypeMap());
        return ALARM_HISTORY_LOG;
    }

    private List<String> getHours(
            List<Pair<String,List<AteyeAlarmRecordDO>>> sortedAlarmLogs ) {
        List<String> ret = new ArrayList<String>();
        for ( Pair<String,List<AteyeAlarmRecordDO>> pp:sortedAlarmLogs ){
            ret.add(pp.getLeft());
        }
        return ret;
    }

    private List<Pair<String, List<AteyeAlarmRecordDO>>> sortAlarmLogs(
            List<AteyeAlarmRecordDO> alarmRecords) {
        Collections.sort(alarmRecords, new Comparator<AteyeAlarmRecordDO>(){
            @Override
            public int compare(AteyeAlarmRecordDO o1, AteyeAlarmRecordDO o2) {
                return o1.getAlarmTime().after(o2.getAlarmTime())?-1:1;
            }
        });
        List<Pair<String, List<AteyeAlarmRecordDO>>> ret = new ArrayList<Pair<String,List<AteyeAlarmRecordDO>>>();
        String prev_hour = null;
        List<AteyeAlarmRecordDO> currentLogs = null;
        for ( AteyeAlarmRecordDO arl: alarmRecords ){
            Date date = arl.getAlarmTime();
            String hour = com.taobao.util.CalendarUtil.toString(date,"yyyy-MM-dd HH");
            if ( prev_hour == null || !prev_hour.equals(hour) ){
                currentLogs = new ArrayList<AteyeAlarmRecordDO>();
                ret.add(Pair.of(hour, currentLogs));
            }
            currentLogs.add(arl);
            prev_hour = hour;
        }
        return ret;
    }


    private void filter(List<AteyeAlarmRecordDO> alarmRecords, Set<String> ruleTypesByName) {
        Iterator<AteyeAlarmRecordDO> iterator = alarmRecords.iterator();
        while(iterator.hasNext()){
            AteyeAlarmRecordDO recordDO = iterator.next();
            if(!ruleTypesByName.contains(recordDO.getRuleType())){
                iterator.remove();
            }
        }
    }


}
