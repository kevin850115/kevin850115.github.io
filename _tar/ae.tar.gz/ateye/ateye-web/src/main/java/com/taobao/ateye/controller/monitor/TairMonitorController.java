package com.taobao.ateye.controller.monitor;

import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.monitor.AggrTairStatMonitorDO;
import com.taobao.ateye.tracker.TrackerInfoManager;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/monitor")
public class TairMonitorController extends AbstractController{

	private static final String STAT_MONITOR = "screen/monitor/tair_stat";
	private static final String STAT_GROUP_MONITOR = "screen/monitor/tair_group_stat";

	@Autowired
	private TrackerInfoManager trackerInfoManager;

	@RequestMapping("tairStat.htm")
	public String tairStat(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		String app=request.getParameter("app");
		String biz=request.getParameter("biz");
		if ( StringUtils.isBlank(app) && StringUtils.isBlank(biz)){
			return "";
		}
		result.put("app", app);
		Set<String> needApps = new HashSet<String>();
		//���ҵ��������
		if ( StringUtils.isNotBlank(biz) ){
			List<AppDO> apps = appDAO.queryAppByBizType(biz);
			result.put("bizName", biz);
			result.put("biz",biz);
			for ( AppDO a:apps ){
				needApps.add(a.getAppName());
			}
		}else{
			needApps.add(app);
		}
		if ( StringUtils.isBlank(app) ){
			app = "_TAIR_";
		}
		AggrTairStatMonitorDO tairStat = trackerInfoManager.getTairStatOfApp(app,needApps, startDate);
		result.put("tairStat",tairStat);
		return STAT_MONITOR;
	}	
	@RequestMapping("tairGroupStat.htm")
	public String tairGroupStat(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		String group=request.getParameter("group");
		String namespace=request.getParameter("namespace");
		if ( StringUtils.isBlank(group)){
			return "";
		}
		AggrTairStatMonitorDO tairStat = trackerInfoManager.getTairStatOfGroup(startDate, group, namespace);
		result.put("tairStat",tairStat);
		return STAT_GROUP_MONITOR;
	}	
}
