package com.taobao.ateye.controller.monitor;

import java.text.ParseException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.db.TddlAppRelationDO;
import com.taobao.ateye.db.TddlAppRelationManager;
import com.taobao.ateye.monitor.TddlStatMonitorDO;
import com.taobao.ateye.tracker.TrackerInfoManager;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/monitor")
public class TddlMonitorController extends AbstractController{

	private static final String STAT_MONITOR = "screen/monitor/app_stat";
	private static final String STAT_TDDL_MONITOR = "screen/monitor/app_tddl_stat";

	@Autowired
	private TrackerInfoManager trackerInfoManager;
	@Autowired
	TddlAppRelationManager tddlAppRelationManager;

	@RequestMapping("appStat.htm")
	public String appStat(final HttpServletRequest request, ModelMap result) throws Exception {
		Pair<Date,Integer> startDate = getDay2(request,result);
		String app=request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app", app);
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return "";
		}
		
		String biz=request.getParameter("biz");

		String showDsKey = request.getParameter("showDsKey");
		if ( "1".equals(showDsKey) ){
			result.put("showDsKey", "1");
		}
		Collection<TddlStatMonitorDO> statList = trackerInfoManager.getTddlStatOfApp(app, startDate.getLeft(),startDate.getRight());
		//�Ƿ�����ʾdsKey
		if ( !"1".equals(showDsKey) ){
			Iterator<TddlStatMonitorDO> iterator = statList.iterator();
			while ( iterator.hasNext() ){
				TddlStatMonitorDO sm = iterator.next();
				if ( StringUtils.isNotBlank( sm.getTddlDsKey() ) ){
					iterator.remove();
				}
			}
		}
		//���ҵ��������
		if ( StringUtils.isNotBlank(biz) ){
			Set<String> needTddlApps = new HashSet<String>();
			TddlAppRelationDO tddlDO = tddlAppRelationManager.getTddlDO();
			List<AppDO> apps = appDAO.queryAppByBizType(biz);
			result.put("bizName", biz);
			result.put("biz",biz);
			if ( tddlDO == null ){
				return "";
			}
			for ( AppDO a:apps ){
				Set<String> tas = tddlDO.getTddlAppsOfApp(a.getAppName());
				if ( tas != null ){
					needTddlApps.addAll(tas);
				}
			}
			Iterator<TddlStatMonitorDO> iterator = statList.iterator();
			while ( iterator.hasNext() ){
				TddlStatMonitorDO sm = iterator.next();
				if ( !needTddlApps.contains(sm.getTddlAppName()) ){
					iterator.remove();
				}
			}
		}
		result.put("statList",statList);
		TddlAppRelationDO tddlDO = tddlAppRelationManager.getTddlDO();
		if ( tddlDO != null ){
			result.put("tddlMap", tddlDO.getTddls2app());
		}
		return STAT_MONITOR;
	}	
	@RequestMapping("appTddlStat.htm")
	public String appTddlStat(final HttpServletRequest request, ModelMap result) throws Exception {
		Pair<Date,Integer> startDate = getDay2(request,result);
		String app=request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app", app);
		String tddlApp=request.getParameter("tddlApp");
		if ( StringUtils.isBlank(tddlApp) ){
			return "";
		}
		result.put("tddlApp", tddlApp);
		String showDsKey = request.getParameter("showDsKey");
		if ( "1".equals(showDsKey) ){
			result.put("showDsKey", "1");
		}
		TddlAppRelationDO tddlDO = tddlAppRelationManager.getTddlDO();
		if ( tddlDO == null ){
			return "";
		}
		Set<String> apps = tddlDO.getAppsOfTddlApp(tddlApp);
		Map<String,Collection<TddlStatMonitorDO>> ret = new HashMap<String,Collection<TddlStatMonitorDO>>();
		for ( String ap:apps ){
			Collection<TddlStatMonitorDO> statList = trackerInfoManager.getTddlStatOfApp(ap, startDate.getLeft(),startDate.getRight());
			if ( statList != null && statList.size() > 0 ){
				Iterator<TddlStatMonitorDO> iterator = statList.iterator();
				while ( iterator.hasNext() ){
					TddlStatMonitorDO next = iterator.next();
					if ( !next.getTddlAppName().equals(tddlApp) ){
						iterator.remove();
					}
				}
				ret.put(ap, statList);
			}
		}
		Collection<TddlStatMonitorDO> statList = trackerInfoManager.getTddlStatOfApp(app, startDate.getLeft(),startDate.getRight());
		if ( statList != null && statList.size() > 0 ){
			Iterator<TddlStatMonitorDO> iterator = statList.iterator();
			while ( iterator.hasNext() ){
				TddlStatMonitorDO next = iterator.next();
				if ( !next.getTddlAppName().equals(tddlApp) ){
					iterator.remove();
				}
			}
			ret.put(app, statList);
		}
		result.put("statMap",ret);
		return STAT_TDDL_MONITOR;
	}		
	private Pair<Date,Integer> getDay2(final HttpServletRequest request,ModelMap result) throws ParseException{
		String hour = request.getParameter("hour");
		String day = request.getParameter("day");
		if ( day == null ){
			String formatToDay = DateFormatUtil.formatToDay(new Date());
			result.put("current",formatToDay);
			//Ϊ��ʱ,hourֵΪ��ǰֵ
			hour = CalendarUtil.toString(new Date(), "HH");
			result.put("hour",Integer.valueOf(hour));
			return Pair.of(DateFormatUtil.parseByDay(formatToDay),Integer.valueOf(hour));
		}
		result.put("current",day);
		int hourH = -1;
		if ( StringUtils.isNotBlank(hour) ){
			hourH = Integer.valueOf(hour);
			result.put("hour",hourH);
		}
		return Pair.of(CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3),hourH);
	}	
}
