package com.taobao.ateye.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.ModelMap;

public class ColorUtil {

	/*
	 * �Զ�Ϊ�б����ñ���ɫ��ǰ��ɫ
	 */
	public static void assignColor(ModelMap result,Collection<String> keys,String prefix){
		String[] colors = new String[]{"red:white",
				"green:white",
				"yellow:black",
				"darkgray:white",
				"blue:white",
				"darkblue:white",
				"aqua:black",
				"lime:black",
				"purple:white",
				"navy:white",
				"aqua:black",
				"fuchsia:white",
				"olive:white",
				"silver:black",
				"teal:white",
				"white:black",
				"black:white",
				};
		Map<String,String> bizFontColor = new HashMap<String,String>();
		Map<String,String> bizBackColor = new HashMap<String,String>();
		int idx = 0;
		for ( String key:keys){
			String tt = colors[idx%colors.length];
			String[] split = tt.split(":");
			bizBackColor.put(key,split[0]);
			bizFontColor.put(key,split[1]);
			idx ++;
		}
		result.put(prefix+"FontColor",bizFontColor);
		result.put(prefix+"BackColor",bizBackColor);	
	}
}
