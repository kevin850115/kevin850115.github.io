package com.taobao.ateye.controller.audit;

import java.io.UnsupportedEncodingException;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.google.common.collect.Lists;
import com.taobao.ateye.base.Pair;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.scene.manager.SceneDynamicOprHisManager;
import com.taobao.ateye.scene.manager.data.DynamicConfigDomain;
import com.taobao.ateye.scene.manager.hsf.HsfMetaDataManager;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.dataobject.UserAuditDO;
import com.taobao.ateye.service.UserAuditService;
import com.taobao.ateye.user.UserNameConverter;

@Controller
@RequestMapping("audit")
public class OpHistoryController {
	private static final String OP_HISTORY2="screen/audit/op_history2";
	private static final String SAFE_DYNAMIC_CONFIG_HISTORY="screen/audit/safe_dynamic_config_history";
	 @Autowired
	 private UserAuditService userAuditService;

	 @Autowired
	 private SceneDynamicOprHisManager sceneDynamicOprHisManager;
	@RequestMapping("opHistory2.htm")
    public String opHistory2(final HttpServletRequest request, ModelMap result) throws UnsupportedEncodingException{
		return _opHistory(request,result,OP_HISTORY2);
	}
    public String _opHistory(final HttpServletRequest request, ModelMap result,String page) throws UnsupportedEncodingException {
    	String appName=request.getParameter("appName");
    	String name =request.getParameter("name");
    	String fieldName =request.getParameter("field");
    	String ip=request.getParameter("ip");
    	String opType=request.getParameter("type");
    	if ( StringUtils.isBlank(appName) || 
    		 opType == null
    			){
    		throw new IllegalArgumentException("����������");
    	}
    	UserAuditDO userAuditDO=new UserAuditDO();
    	userAuditDO.setAppName(appName);
    	if ( StringUtils.isNotBlank(ip) ){
	    	userAuditDO.setIp(ip);
    	}
    	if ( StringUtils.isNotBlank(name) ){
	    	userAuditDO.setOpBean(name);
    	}
    	if ( StringUtils.isNotBlank(fieldName) ){
	    	userAuditDO.setOpField(fieldName);
    	}
    	userAuditDO.setOpType(Integer.valueOf(opType));
    	
    	List<UserAuditDO> userAuditLIst=userAuditService.getAuditLogByParam(userAuditDO);
    	result.put("auditList", userAuditLIst);
    	result.put("app", appName);
    	result.put("ip", ip);
    	result.put("name", name);
    	result.put("field", fieldName);
    	result.put("type", opType);
    	Set<String> nicks = new HashSet<String>();
    	for (UserAuditDO ua:userAuditLIst){
    		nicks.add(ua.getUserNick());
    	}
    	result.put("userNames", UserNameConverter.convert(nicks));
	    return page;
    }
	@RequestMapping("safeDynamicConfigHisotry.htm")
    public String safeDynamicConfigHisotry(final HttpServletRequest request, ModelMap result) throws UnsupportedEncodingException, DAOException {
		return safeDynamicConfigHisotry(request,result,SAFE_DYNAMIC_CONFIG_HISTORY);
	}

	private String safeDynamicConfigHisotry(HttpServletRequest request, ModelMap result, String page) throws DAOException, UnsupportedEncodingException {
		String ateyeViewAppName=request.getParameter("appName");
		if ( StringUtils.isBlank(ateyeViewAppName)){
			throw new IllegalArgumentException("����������");
		}
		String nodeGroup = "";
		Pair<String/*appName*/,String/*nodeGroup*/> pair = HsfMetaDataManager.parseAteyeViewAppName(ateyeViewAppName);
		if(pair==null){
			return null;
		}
		String appName = pair.getFirst();
		nodeGroup = pair.getSecond();
		String resourceName = request.getParameter("resourceName");;
		Calendar calendar = Calendar.getInstance();
		//5����
		calendar.add(Calendar.DAY_OF_MONTH,-7);
		Map<String/*resourceName*/,List<DynamicConfigDomain>>resource2Config = sceneDynamicOprHisManager.fetchOprs(appName,nodeGroup,"timeout",calendar.getTime());
		List<DynamicConfigDomain> dynamicList = Lists.newArrayList();
		if(StringUtils.isNotEmpty(resourceName)){
			List<DynamicConfigDomain> configs = resource2Config.get(resourceName);
			if(configs != null){
				dynamicList.addAll(configs);
			}
		}else{
			for (List<DynamicConfigDomain> dynamicConfigDomains : resource2Config.values()) {
				dynamicList.addAll(dynamicConfigDomains);
			}

		}
		Collections.sort(dynamicList, new Comparator<DynamicConfigDomain>() {
			@Override
			public int compare(DynamicConfigDomain o1, DynamicConfigDomain o2) {
				long t1 = o1.getUserAuditDO().getCreatedTime().getTime();
				long t2 = o2.getUserAuditDO().getCreatedTime().getTime();
				if(t1 > t2){
					return -1;
				}else if(t1 < t2 ){
					return 1;
				}else{
					return 0;
				}
			}
		});

		result.put("dynamicList", dynamicList);
		result.put("app", appName);
		result.put("ateyeViewAppName", ateyeViewAppName);
		Set<String> nicks = new HashSet<String>();
		for (DynamicConfigDomain dynamicConfigDomain:dynamicList){
			nicks.add(dynamicConfigDomain.getUserAuditDO().getUserNick());
		}
		result.put("userNames", UserNameConverter.convert(nicks));
		return page;
	}

}
