package com.taobao.ateye.controller.bizs;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.alarm.manager.AlarmGroupManager;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.biz.BizAppInfoDO;
import com.taobao.ateye.biz.BizManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.AlarmGroupDAO;
import com.taobao.ateye.dal.BizLineDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.AteyeAlarmGroupDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.ateye.view.manager.CViewIndexManager;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.hbase.AlarmRuleLogDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.AlarmGroupDO;
import com.taobao.tracker.hbase.view.BaseViewDO;
import com.taobao.tracker.hbase.view.LineDefDO;
import com.taobao.tracker.hbase.view.MultiViewDO;
import com.taobao.tracker.hbase.view.SingleViewDO;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("bizs")
public class BizsController extends AbstractController
{
	private static final String BIZ_DETAIL = "screen/bizs/detail";
	private static final String BIZ_LIST_APP = "screen/bizs/listApp";
	private static final String BIZ_LIST_ALARM = "screen/bizs/listAlarm";
	private static final String BIZ_LIST_CVIEW = "screen/bizs/listCView";
	private static final String BIZ_LIST_ALARMGROUP= "screen/bizs/listAlarmGroup";
	private static final String BIZ_UPDATE_CVIEW = "screen/bizs/updateCView";
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private BizManager bizManager;
	@Autowired
	private HbaseReadService hbaseReadService;
	@Autowired
	CViewIndexManager cViewIndexManager;
	@Autowired
	AlarmGroupManager alarmGroupManager;
	@Autowired
	private AlarmGroupDAO alarmGroupDAO;
	@Autowired
	private BizLineDAO bizLineDAO;

	@RequestMapping("listApp.htm")
    public String listApp(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz)){
			return null;
		}
		BizAppInfoDO bizInfo = bizManager.getAppsInfo(biz);
		result.put("bizInfo", bizInfo);
    	return BIZ_LIST_APP;
    }
	@RequestMapping("listAlarmGroup.htm")
    public String listAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		result.put("errorMsg", request.getParameter("errorMsg"));
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz)){
			return null;
		}
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByBiz(biz);
		result.put("groups", alarmGroups);
		result.put("nick", user.getNick());
		result.put("biz",biz);
		result.put("bizMap",getBizMap());
    	return BIZ_LIST_ALARMGROUP;
    }
	@RequestMapping("listAllAlarmGroup.htm")
    public String listAllAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		result.put("errorMsg", request.getParameter("errorMsg"));
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAll();
		result.put("groups", alarmGroups);
		result.put("nick", user.getNick());
		result.put("readonly", false);
		result.put("bizMap",getBizMap());
    	return BIZ_LIST_ALARMGROUP;
    }

	@RequestMapping("updateAlarmGroupBiz.htm")
	public String updateAlarmGroupBiz(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String biz = request.getParameter("biz");//biz��ҵ��������
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(id) && StringUtils.isNotBlank(biz) ){
			BizLineDO bizLineDO = bizLineDAO.getAllBizLineMapByName().get(biz);
			if ( bizLineDO == null ){
				ret.put("success", "false");
			}else{
				int update = alarmGroupDAO.updateBiz(id, (int)bizLineDO.getId());
				ret.put("success", update>0?"true":"false");
			}
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAlarmGroupToken.htm")
	public String updateAlarmGroupToken(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String token = request.getParameter("token");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(id) && StringUtils.isNotBlank(token) ){
			int update = alarmGroupDAO.updateToken(id,token);
			ret.put("success", update>0?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("addAlarmGroup.htm")
    public String addAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException
    {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz) ){
			return null;
		}
		String uniqName = request.getParameter("uniqName");
		String dingding = request.getParameter("dingdingToken");
		if ( StringUtils.isBlank(uniqName) || StringUtils.isBlank(dingding) ){
			result.put("errorMsg","�����������Ϊ��");
			return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
		}
		/*
		{
			AlarmGroupDO group = new AlarmGroupDO();
			group.setBiz(-100);
			group.setDingdingToken(dingding);
			group.setUniqName(uniqName);
			group.setOwner(user.getNick());
			group.setProductName(biz);
			boolean isSucc = hbaseReadService.addAlarmGroup(group);
	    }
	    */
		BizLineDO bizLineDO = bizLineDAO.getAllBizLineMapByName().get(biz);
		if ( bizLineDO == null ){
			return "";
		}
		AteyeAlarmGroupDO group = new AteyeAlarmGroupDO();
		group.setBiz((int)bizLineDO.getId());
		group.setName(uniqName);
		group.setOperator(user.getNick());
		group.setToken(dingding);
		try{
			alarmGroupDAO.insert(group);
		}catch(Throwable t){
			result.put("errorMsg","����ʧ�ܣ����������ظ�!");
		}
		return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
    }
	@RequestMapping("updateAlarmGroup.htm")
    public String updateAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException
    {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz) ){
			return null;
		}
		String uniqName = request.getParameter("uniqName");
		String dingding = request.getParameter("dingdingToken");
		String owner = request.getParameter("owner");
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uniqName) || StringUtils.isBlank(dingding) 
		  || StringUtils.isBlank(owner) || StringUtils.isBlank(uuid) 
				){
			result.put("errorMsg","�����������Ϊ��");
			return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
		}
		AlarmGroupDO group = new AlarmGroupDO();
		group.setUuid(uuid);
		group.setBiz(-100);
		group.setProductName(biz);
		group.setDingdingToken(dingding);
		group.setUniqName(uniqName);
		group.setOwner(owner);
		boolean isSucc = hbaseReadService.updateAlarmGroup(uuid,group);
		if ( !isSucc ){
			result.put("errorMsg","����ʧ�ܣ����������ظ�!");
		}
		return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
    }
	@RequestMapping("removeAlarmGroup.htm")
    public String removeAlarmGroup(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException
    {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz) ){
			return null;
		}
		String uuid = request.getParameter("uuid");
		if (StringUtils.isBlank(uuid) ){
			result.put("errorMsg","�����������Ϊ��");
			return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
		}
		alarmGroupManager.removeAlarmGroup(uuid);
	
		return "redirect:/bizs/listAlarmGroup.htm?biz="+UrlUtil.encode(biz);
    }
	@RequestMapping("updateCView.htm")
    public String updateCView(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException
    {
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz)){
			return null;
		}
		String cviewDesc = cViewIndexManager.getCViewDesc(biz);
		String  newDesc = request.getParameter("desc");
		if ( StringUtils.isNotBlank(newDesc) ){
			cViewIndexManager.updateCViewDesc(biz,newDesc);
			return "redirect:/bizs/listCView.htm?biz="+UrlUtil.encode(biz);
		}
		result.put("biz", biz);
		result.put("desc", cviewDesc);
		return BIZ_UPDATE_CVIEW;
    }
	@RequestMapping("listCView.htm")
    public String listCView(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz)){
			return null;
		}
		result.put("biz", biz);
		long tic = System.currentTimeMillis();
		Map<String, Map<String,String>> cViewIndexConfigs = cViewIndexManager.getCViewIndexConfigs(biz);
		
		result.put("used",System.currentTimeMillis()-tic);
		result.put("cviewMap", cViewIndexConfigs);

		return BIZ_LIST_CVIEW;
    }
	@RequestMapping("listAlarm.htm")
    public String listAlarm(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz)){
			return null;
		}
		result.put("biz", biz);
		
		String startDate = request.getParameter("startDate");
		Date startDateObj = new Date();
		if ( StringUtils.isNotBlank(startDate) ){
			startDateObj = CalendarUtil.toDate(startDate, "yyyy-MM-dd");
		}
		result.put("startDate",CalendarUtil.toString(startDateObj,"yyyy-MM-dd"));
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsOfDay(CalendarUtil.zerolizedTime(startDateObj));
		List<AppDO> apps = appDAO.queryAppByBizType(biz);
		//��ȡҵ���Ӧ�ı�����־
		alarmLogs = pickBizAlarmLogs(alarmLogs,apps);
		//��ʱ�䵹��
		List<Pair<String,List<AlarmRuleLogDO>>> sortedAlarmLogs = sortAlarmLogs(alarmLogs);
		//��ɫ
		List<String> hours = getHours(sortedAlarmLogs);
		ColorUtil.assignColor(result, hours, "time");
		
		result.put("alarmLogs",sortedAlarmLogs);
		result.put("count",alarmLogs.size());

    	return BIZ_LIST_ALARM;
    }
	
	private List<String> getHours(
			List<Pair<String, List<AlarmRuleLogDO>>> sortedAlarmLogs) {
		List<String> ret = new ArrayList<String>();
		for ( Pair<String,List<AlarmRuleLogDO>> pp:sortedAlarmLogs ){
			ret.add(pp.getLeft());
		}
		return ret;
	}

	private List<Pair<String, List<AlarmRuleLogDO>>> sortAlarmLogs(
			List<AlarmRuleLogDO> alarmLogs) {
		Collections.sort(alarmLogs, new Comparator<AlarmRuleLogDO>(){
			@Override
			public int compare(AlarmRuleLogDO o1, AlarmRuleLogDO o2) {
				return o1.getDate().after(o2.getDate())?-1:1;
			}
		});
		List<Pair<String, List<AlarmRuleLogDO>>> ret = new ArrayList<Pair<String,List<AlarmRuleLogDO>>>();
		String prev_hour = null;
		List<AlarmRuleLogDO> currentLogs = null;
		for ( AlarmRuleLogDO arl: alarmLogs ){
			Date date = arl.getDate();
			String hour = CalendarUtil.toString(date,"yyyy-MM-dd HH");
			if ( prev_hour == null || !prev_hour.equals(hour) ){
				currentLogs = new ArrayList<AlarmRuleLogDO>();
				ret.add(Pair.of(hour, currentLogs));
			}
			currentLogs.add(arl);
			prev_hour = hour;
		}
		return ret;
	}

	private List<AlarmRuleLogDO> pickBizAlarmLogs(
			List<AlarmRuleLogDO> alarmLogs, List<AppDO> appDOs) {
		Set<String> apps = new HashSet<String>();
		for ( AppDO appDO:appDOs ){
			apps.add(appDO.getAppName());
		}
		List<AlarmRuleLogDO> ret = new ArrayList<AlarmRuleLogDO>();
		for ( AlarmRuleLogDO arl:alarmLogs ){
			String app = arl.getApp();
			if ( apps.contains(app) ){
				ret.add(arl);
			}
		}
		return ret;
	}

	@RequestMapping("detail2.htm")
    public String appDetail2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
		String biz = request.getParameter("biz");
		List<AppDO> apps = appDAO.queryAppByProduct(biz);
		String bizName = biz;
		//2.<ҵ���Ӧ��Ӧ���б�>
		Map<String, List<List<String>>> bizMap = initBizMap(result);
		List<List<String>> list = bizMap.get(bizName);
		result.put("appList",list);
		result.put("biz",biz);
		result.put("bizName",bizName);
		//3.��ȡ����ҵ�����ݵ���ͼ
		try{
			result.put("mviews",getAllViewOfApps(apps));
		}catch(Throwable t){
			
		}
    	return BIZ_DETAIL;
    }

	private Set<MultiViewDO> getAllViewOfApps(List<AppDO> apps){
		Set<MultiViewDO> ret = new HashSet<MultiViewDO>();
		//1.app�б�
		Set<String> appNames = new HashSet<String>();
		for ( AppDO app:apps ){
			appNames.add(app.getAppName());
		}
		//2.��ȡ������ͼ
		List<BaseViewDO> allViews = ateyeViewService.listAllViews();
		Map<String,BaseViewDO> viewMap = new HashMap<String,BaseViewDO>();
		for ( BaseViewDO bv:allViews ){
			viewMap.put(bv.getUuid(),bv);
		}
		//3.�ж���ͼ���Ƿ����Ӧ��
		for ( BaseViewDO view:allViews ){
			if ( view.getType() != BaseViewDO.TYPE_MULTI ){
				continue;
			}
			MultiViewDO mvo = (MultiViewDO)view;
			boolean isSaved=false;
			for ( String uuid:mvo.getSingleViewUUids() ){
				BaseViewDO bvo = viewMap.get(uuid);
				if ( bvo == null ){
					continue;
				}
				SingleViewDO svo = (SingleViewDO)bvo;
				for ( LineDefDO ld:svo.getLines() ){
					String app = ld.getApp();
					if ( appNames.contains(app) ){
						ret.add(mvo);
						isSaved = true;
						break;
					}
				}
				if ( isSaved ){
					break;
				}
			}
		}
		return ret;

	}
}
