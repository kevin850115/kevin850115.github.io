package com.taobao.ateye.controller.ops;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.server.thread.ThreadInfoJsonDO;
import com.taobao.ateye.server.thread.ThreadManager;
import com.taobao.ateye.server.thread.ThreadManager.ThreadCpuUsage;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.util.HttpUtil;
import com.taobao.ateye.util.UrlGenerator;

@Controller
@RequestMapping("/ops")
public class OpsController extends AbstractController{
	
	private static final String SYSTME_INFO="screen/ops/viewSystemInfo";
	
	private static final String THREAD_INFO="screen/ops/viewThreads";
	
	private static final String ENV_OPS_LIST = "screen/ops/envOpsList";
	
	private static final String THREAD_OPS_LIST = "screen/ops/threadOpsList";
	
	
	@Autowired
	private UrlGenerator urlGenerator;
	@Autowired
	private OpsServic opsServic;
	@Autowired
	private AppService appService;

	
	@RequestMapping("threadOpsList.htm")
	public String queryMachineAndAppListThread(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		String appName = request.getParameter("app");
		List<MachineDO> machines=new ArrayList<MachineDO>();
		Map<AppDO,List<MachineDO>> allMachines = new HashMap<AppDO, List<MachineDO>>();
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		if(StringUtils.isNotBlank(appName)){
			 machines = opsServic.getAllMachinesBelongToAnApp(appName);
			AppDO appDO=appService.getAppByAppName(appName);
			allMachines.put(appDO, machines);
		}else{
		    allMachines = opsServic.getAllMachinesBelongToAUser(user.getId());
		}
		if(machines.size()==0){
			result.put("error", "û���ҵ���Ӧ�ù����Ļ���");
		}else{
	    	result.put("allMachines", allMachines);
		}
		return THREAD_OPS_LIST;
	}
	
	@RequestMapping("envOpsList.htm")
	public String queryMachineAndAppListEnv(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		String appName = request.getParameter("app");
		List<MachineDO> machines=new ArrayList<MachineDO>();
		Map<AppDO,List<MachineDO>> allMachines = new HashMap<AppDO, List<MachineDO>>();
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		if(StringUtils.isNotBlank(appName)){
			 machines = opsServic.getAllMachinesBelongToAnApp(appName);
			AppDO appDO=appService.getAppByAppName(appName);
			allMachines.put(appDO, machines);
		}else{
		    allMachines = opsServic.getAllMachinesBelongToAUser(user.getId());
		}
		if(machines.size()==0){
			result.put("error", "û���ҵ���Ӧ�ù����Ļ���");
		}else{
			result.put("allMachines", allMachines);
		}
		return ENV_OPS_LIST;
	}
	@RequestMapping("selectApp4Threads2.htm")
    public String selectApp4Threads2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/ops/threadOpsList.htm");
    	result.put("level2","�鿴�߳�");
    	result.put("level2Url","/ops/selectApp4Threads2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
	@RequestMapping("selectApp4SystemInfo2.htm")
    public String selectApp4SystemInfo2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/ops/envOpsList.htm");
    	result.put("level2","�鿴ϵͳ����");
    	result.put("level2Url","/ops/selectApp4SystemInfo2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
	
	@RequestMapping("viewSystemInfo.htm")
	public String viewEviromentVaries(final HttpServletRequest request, ModelMap result){
		String type = "ENVIROMENT";//�����ֲ�ͬ�Ĳ���
		String operate = "getEnvInfo";//������ͬһ��ģ���µĲ�ͬ����
		String dns_ip = request.getParameter("dns_ip");
		String dns_app = request.getParameter("app");
		String port = request.getParameter("port");
		Map<String,String> params=new HashMap<String, String>();
		params.put("type", type);
		params.put("operate", operate);
    	String appUrl="";
		try {
			appUrl = urlGenerator.getUrl(dns_ip, port, params);
		} catch (Exception e) {
			result.put("error", e.getMessage());
			return SYSTME_INFO;
		}
//    	appUrl="http://127.0.0.1/agent.ateye?operate=getEnvInfo&type=ENVIROMENT";
    	String responseBody="";
    	responseBody=HttpUtil.get(appUrl, 1000);
    	if(null!=responseBody && !responseBody.equals("")){
    		JSONObject obj = JSONObject.fromObject(responseBody);
            Map<String, String> map = new TreeMap<String, String>();
            Set<String> keySet = obj.keySet();
            for (String key : keySet) {
                map.put(key, obj.getString(key));
            }
            result.put("env", map);
            
    	}else{
	        result.put("error", "��ȡϵͳ����ʧ��");
	    }
    	result.put("app", dns_app);
        result.put("ip", dns_ip);
		return SYSTME_INFO;
	}
	@RequestMapping("viewThreads.htm")
	public String viewThreads(final HttpServletRequest request, ModelMap result){
		String type = "THREAD";//�����ֲ�ͬ�Ĳ���
		String dns_ip = request.getParameter("dns_ip");
		String dns_app = request.getParameter("app");
		String port = request.getParameter("port");
		Map<String,String> params=new HashMap<String, String>();
		params.put("type", type);
    	String appUrl="";
		try {
			appUrl = urlGenerator.getUrl(dns_ip, port, params);
		} catch (Exception e) {
			result.put("error", e.getMessage());
			return THREAD_INFO;
		}
//    	appUrl="http://127.0.0.1/agent.ateye?operate=getAllThreads&type=THREAD";
    	String responseBody="";
    	responseBody=HttpUtil.get(appUrl, 1000);
    	if(null!=responseBody && !responseBody.equals("")){
    		JSONObject obj = JSONObject.fromObject(responseBody);
			 result.put("stat", ThreadManager.getStat(obj));
	         List<ThreadInfoJsonDO> threads = ThreadManager.getThreadInfos(obj);
	         result.put("threads", threads);
	         result.put("groups", ThreadManager.groupThread(threads));
	         result.put("stacks", ThreadManager.getThreadStackTrace(obj));
    	}else{
	        result.put("error", "��ȡӦ���߳�ʧ��");
	    }
    	result.put("port", port);
    	result.put("app", dns_app);
        result.put("ip", dns_ip);
		return THREAD_INFO;
	}
	
	 @RequestMapping("viewThreadsOrderByCpu.htm")
	    public final String getThreadInfoOrderByCpu(final HttpServletRequest request, ModelMap result) throws Exception {
		 	String type = "THREAD";//�����ֲ�ͬ�Ĳ���
			String order="cpu";		//�����ְ�cpu�����
			String dns_ip = request.getParameter("dns_ip");
			String dns_app = request.getParameter("app");
			String port = request.getParameter("port");
			Map<String,String> params=new HashMap<String, String>();
			params.put("type", type);
			params.put("order", order);
	    	String appUrl=urlGenerator.getUrl(dns_ip, port, params);
	    	
	         String responseBody = "";
	         responseBody = HttpUtil.get(appUrl, 10000);
             if (StringUtils.isNotBlank(responseBody)) {
            	 JSONObject obj = JSONObject.fromObject(responseBody);
            	 result.put("threads", ThreadManager.getThreadCpuUsage(obj));
            	 Map<Long, ThreadCpuUsage> threads=ThreadManager.getThreadCpuUsage(obj);
            	 if(threads.isEmpty()){
            		 result.put("error", "��ȡthreadsʧ��,��ȷ�Ͻ����Ӧ���ѳɹ�����linuxϵͳ��");
            	 }
     	         result.put("stacks", ThreadManager.getThreadStackOfJstack(obj));
             }else{
     	        result.put("error", "��ȡ��cpu������߳�ʧ��");
     	    }
	        result.put("app", dns_app);
	        result.put("ip", dns_ip);
	        result.put("port", port);
	        return "screen/ops/viewThreadsOrderByCpu";
	    }

	
	@RequestMapping(value = "/viewHubUrl.htm", method = RequestMethod.GET)
    public final String getServerHubUrl(@RequestParam("serverId") Integer serverId, ModelMap result) throws Exception {
//        ServerInfoDO serverInfo = serverDAO.getServerInfoById(serverId);
//        String url = "http://monitor.taobao.com/monitorportal/main/mainHost.htm?confId="+serverInfo.getHubId()+"&hostname="+serverInfo.getName();
//        return "redirect:" + url;
		return "";
    }
}
