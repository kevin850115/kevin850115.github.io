package com.taobao.ateye.filter;

import com.taobao.ateye.threadlocal.AteyeThreadLocal;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ��filter������ҳ���г�ʼ��һЩֵ������������ȡ� Ŀǰ��������������ʼֵ�� 1. ��ǰ��½��url����������չ�����menu 2. �ǳ���url���á�
 * 
 * @author guangu.lj
 * @verion 0.1.0
 */
public class ConfigFilter implements Filter {
	public String bucServerUrl;
	public String ateyeDomain;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		bucServerUrl = filterConfig.getInitParameter("bucServerUrl");
		ateyeDomain = filterConfig.getInitParameter("ateyeDomain");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpRresponse = (HttpServletResponse) response;
		String uri = httpRequest.getRequestURI();
		String midIndex = uri.substring(1);
		if (midIndex.indexOf("/") != -1) {
			uri = uri.substring(0, midIndex.indexOf("/") + 1);
			/**
			 * ���������url
			 */
			uri = dealSpecialUrl(uri);

			httpRequest.setAttribute("url", uri);
		} else {
			httpRequest.setAttribute("url", uri);
		}
		
		/**
		 * ��ȡ�ǳ�url
		 */
		httpRequest.setAttribute("loginoutUrl", bucServerUrl + "/ssoLogout.htm");
		/**
		 * ����ateye ����url���û��ǳ������
		 */
		httpRequest.setAttribute("ateyeUrl", "http://" + ateyeDomain);
		try {
			setUpRequestHeaderInfo(httpRequest);
			chain.doFilter(httpRequest, httpRresponse);
		} finally {
			AteyeThreadLocal.context.remove();
		}
	}

	private void setUpRequestHeaderInfo(HttpServletRequest request) {
		String traceId = request.getHeader("EagleEye-TraceId");
		if(org.apache.commons.lang3.StringUtils.isNotBlank(traceId)) {
			AteyeThreadLocal.context.get().put(AteyeThreadLocal._EAGLE_EYE_TRACE_ID, traceId);
		}
	}

	/**
	 * ��/template->/set /templatetask-/set
	 * 
	 * @param uri
	 * @return
	 */
	private String dealSpecialUrl(String uri) {
		if ("/template".equalsIgnoreCase(uri) || "/templatetask".equalsIgnoreCase(uri)) {
			uri = "/set";
		}
		return uri;
	}

	@Override
	public void destroy() {
	}

	/**
	 * @return the bucServerUrl
	 */
	public String getBucServerUrl() {
		return bucServerUrl;
	}

	/**
	 * @param bucServerUrl the bucServerUrl to set
	 */
	public void setBucServerUrl(String bucServerUrl) {
		this.bucServerUrl = bucServerUrl;
	}

	/**
	 * @return the ateyeDomain
	 */
	public String getAteyeDomain() {
		return ateyeDomain;
	}

	/**
	 * @param ateyeDomain the ateyeDomain to set
	 */
	public void setAteyeDomain(String ateyeDomain) {
		this.ateyeDomain = ateyeDomain;
	}

}
