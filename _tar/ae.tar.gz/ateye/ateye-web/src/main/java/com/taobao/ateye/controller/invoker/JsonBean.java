package com.taobao.ateye.controller.invoker;

public class JsonBean {
	String returnValue;
	String failData;
	String timeData;
	String lineData;

	
	

	public String getFailData() {
		return failData;
	}

	public void setFailData(String failData) {
		this.failData = failData;
	}

	public String getTimeData() {
		return timeData;
	}

	public void setTimeData(String timeData) {
		this.timeData = timeData;
	}

	public String getLineData() {
		return lineData;
	}

	public void setLineData(String lineData) {
		this.lineData = lineData;
	}

	public String getReturnValue() {
		return returnValue;
	}

	public void setReturnValue(String returnValue) {
		this.returnValue = returnValue;
	}

}
