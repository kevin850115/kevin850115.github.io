package com.taobao.ateye.filter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;

/**
 * Created by IntelliJ IDEA.
 * User: wayaya
 * Date: 11-11-22
 * Time: ����2:48
 */
public class LogoutHandler implements org.springframework.security.web.authentication.logout.LogoutHandler {
    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        for (Cookie cookie : request.getCookies()) {
            if (cookie.getName().equals("cookie15")) {
                cookie.setMaxAge(0);
                response.addCookie(cookie);
                break;
            }
        }
        request.getSession().invalidate();

    }
}
