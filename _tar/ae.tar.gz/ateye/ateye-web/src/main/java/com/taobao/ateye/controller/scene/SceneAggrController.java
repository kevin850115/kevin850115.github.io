package com.taobao.ateye.controller.scene;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.alarm.log.AlarmLogModelListDO;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.SceneAppRelationDAO;
import com.taobao.ateye.dataobject.SceneAppRelation;
import com.taobao.ateye.dataobject.SceneCatDO;
import com.taobao.ateye.dataobject.SceneEntryPoint;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.goc.emg.GocEmgExtendModel;
import com.taobao.ateye.goc.emg.GocEmgManager;
import com.taobao.ateye.goc.emg.GocEmgModelDO;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.monitor.MonitorItemDO;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.relation.model.RNodeExtInfo;
import com.taobao.ateye.relation.tree.node.NodeExtUtils;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.scene.SceneContants;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.DescUtils;

/*
 * �����ۺ�ҳ��
 */
@Controller
@RequestMapping("/scene")
public class SceneAggrController extends AbstractController{
	private static final String AGGR = "screen/scene/aggr";
	@Autowired
	private SceneAppRelationDAO sceneAppRelationDAO;
	@Autowired
	private GocEmgManager gocEmgManager;

	@RequestMapping("aggrByEmg.htm")
	public String aggrByEmg(final HttpServletRequest request, final ModelMap result) throws Exception {
		String alarmId = request.getParameter("alarmId");
		if ( StringUtils.isBlank(alarmId) ) {
			return null;
		}
		GocEmgModelDO modelDO = gocEmgManager.queryGocEmgByAlarmId(alarmId);
		GocEmgExtendModel extendModel = modelDO.getExtendModel();
		if ( extendModel == null ) {
			return null;
		}
		List<String> scenes = extendModel.getScenes();
		List<SceneEntryPoint> entrys = new ArrayList<SceneEntryPoint>();
		for (String sc:scenes ) {
			SceneEntryPoint sep = getEntryPointByName(sc);
			if ( sep != null ) {
				entrys.add(sep);
			}
		}
		SceneEntryModel model = sceneEntryManager.buildEntryModel(entrys);
		
		result.put("gocEmg", modelDO);

		return _commonAggr(request,result,model);
		
	}
	
	private String _commonAggr(final HttpServletRequest request, final ModelMap result,SceneEntryModel model) throws Exception {
		List<SceneEntryPoint> retList = model.getRetList();
		if ( retList.isEmpty() ){
			return "";
		}
		result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
		result.put("totalEntryCnt",retList.size());
		result.put("entrys",model.getRetList());
		result.put("model",model);
		result.put("entryCnt",model.getRetList().size());
		//1.1.�����쳣��Ϣ
		Map<Long,Map<String,MonitorItemDO>> entryExceptions = loadEntryExceptions(model);
		//���������ϵ��쳣�����ܺ�
		Map<Long, MonitorItemDO> chainException = getTotalChainException(entryExceptions);
		//1.2.����ͼ��
		List<Pair<Long, Long>> entryList = sortByFlow(model);
		Map<String,List<KvGraphMonitorItemDO>> items = buildKvGraphParams(model,chainException,entryList);
		List<String> customeParams = kvGraphManager.buildParam(items,DataBuilder.graphSizeMap.get("xxs"));
		result.put("customParams", customeParams);
		result.put("items",buildArr(items));
		result.put("entryListId",entryList);
		result.put("entryMap",toMap(model.getRetList()));
		List<String> customeBigParams = kvGraphManager.buildParam(items,DataBuilder.defaultSize);
		result.put("customeBigParams", customeBigParams);
		//2.��ȡ����App
		List<String> relateApps = getRelateApps(retList);
		if (!relateApps.isEmpty() ){
			//3.��ȡ���������Ϣ
			{
				Map<String, String> cflts = new HashMap<String,String>();
				cflts.put("app", StringUtils.join(relateApps,","));
				ChangeModelListDO changeList = changeManager.queryChangeList(cflts, DateUtils.addHours(new Date(), -3), new Date());
				result.put("changes",changeList.getRetList());
				result.put("changeCnt",changeList.getRetList().size());
			}
			//4.��ȡ����������Ϣ
			{
				Map<String, String> aflts = new HashMap<String,String>();
				aflts.put("app", StringUtils.join(relateApps,","));
				aflts.put("source", "sunfire,ateye");
				AlarmLogModelListDO alarmLogList = alarmLogModelManager.queryRecentLogList(aflts, -3);
				result.put("alarmLogList",alarmLogList.getTopNRetList(1000));
			}
		}
		result.put("fullShow","true");
		super.setIsMobile(request, result);
		result.put("allCats",sceneCatDAO.getAllMap());
		result.put("allLevels", sceneLevelDAO.getAllMap());
		result.put("bizMap",getBizMap());
		result.put("empIdMap",userCache.getEmpIdMap());
		return AGGR;
	}
	
	@RequestMapping("aggr.htm")
	public String aggr(final HttpServletRequest request, final ModelMap result) throws Exception {
		String aggrType = request.getParameter("type");
		String aggrValue = request.getParameter("value");
		if ( StringUtils.isBlank(aggrType) && StringUtils.isBlank(aggrValue) ){
			return "";
		}
		Map<String, String> flts = new HashMap<String,String>();
		if ( aggrType.equals("cat") ) {
			flts.put("cat", aggrValue);
			flts.put("tag", "core");//ֻչʾ���Ľӿ�
			SceneCatDO sceneCatDO = sceneCatDAO.getAllMap().get(Long.valueOf(aggrValue));
			result.put("catDO",sceneCatDO);
		}else if ( aggrType.equals("tag") ){
			flts.put("tag",aggrValue);
			result.put("tag", aggrValue);
		}
		//1.��ȡ��س������
		SceneEntryModel model = sceneEntryManager.getEntryList(flts);
		if ( model == null ){
			return "";
		}
		return _commonAggr(request,result,model);
	
	}


	private Map<Long,SceneEntryPoint> toMap(List<SceneEntryPoint> retList) {
		Map<Long,SceneEntryPoint> mm = new HashMap<Long,SceneEntryPoint>();
		for (SceneEntryPoint sep:retList){
			mm.put(sep.getId(), sep);
		}
		return mm;
	}


	private Map<Long,MonitorItemDO> getTotalChainException(Map<Long, Map<String, MonitorItemDO>> exps){
		Map<Long,MonitorItemDO> ret = new HashMap<Long,MonitorItemDO>();
		for (Map.Entry<Long, Map<String,MonitorItemDO>> ent:exps.entrySet()){
			if (ent.getValue() == null){
				continue;
			}
			MonitorItemDO monitorItemDO = ent.getValue().get("_TOTAL_");
			if ( monitorItemDO != null ){
				ret.put(ent.getKey(), monitorItemDO);
			}
		}
		return ret;
	}
	private Map<Long, Map<String, MonitorItemDO>> loadEntryExceptions(
			SceneEntryModel model) throws Exception {
		Map<Long, Map<String, MonitorItemDO>> mm = new HashMap<Long,Map<String, MonitorItemDO>>();
		List<SceneEntryPoint> retList = model.getRetList();
		for (SceneEntryPoint sep:retList ){
			Map<String, MonitorItemDO> exps = sceneEntryManager.getEntryException(sep);
			if (exps != null){
				mm.put(sep.getId(), exps);
			}
		}
		return mm;
	}

	
	/*
	 * <ID,����>
	 */
	private List<Pair<Long,Long>> sortByFlow(SceneEntryModel model){
		//�������������������,3���ӿ�һ��ͼ
		Map<Long, RNodeExtInfo> statInfoMap = model.getStatInfoMap();
		//<ID,����>
		List<Pair<Long,Long>> lst = new ArrayList<Pair<Long,Long>>();
		for (Map.Entry<Long, RNodeExtInfo> ent:statInfoMap.entrySet() ){
			RNodeExtInfo value = ent.getValue();
			if ( value == null ){
				continue;
			}
			long flow = value.getFlow();
			if ( flow == 0 ){
				continue;
			}
			lst.add(Pair.of(ent.getKey(), flow));
		}
		Collections.sort(lst, new Comparator<Pair<Long,Long>>(){
			@Override
			public int compare(Pair<Long, Long> arg0, Pair<Long, Long> arg1) {
				return (int)(arg1.getRight() - arg0.getRight());
			}
			
		});
		return lst;
	}
	/*
	 * ����:1:����Model  2.������·�쳣Map
	 */
	private Map<String, List<KvGraphMonitorItemDO>> buildKvGraphParams(
			SceneEntryModel model, 
			Map<Long, MonitorItemDO> chainExceptionMap,
			List<Pair<Long,Long>> lst
			){
		Map<String, List<KvGraphMonitorItemDO>> ret = new LinkedHashMap<String, List<KvGraphMonitorItemDO>>();
		Map<Long, RNodeExtInfo> statInfoMap = model.getStatInfoMap();
		int cnt = 0 ;//����
		for (Pair<Long,Long> pp:lst ){
			int idx = cnt / 3;
			List<KvGraphMonitorItemDO> flowList = getList(ret,"����-"+idx);
			List<KvGraphMonitorItemDO> rtList = getList(ret,"RT-"+idx);
			List<KvGraphMonitorItemDO> failRateList = getList(ret,"FailRate-"+idx);
			List<KvGraphMonitorItemDO> chainExceptions = getList(ret,"CException-"+idx);
			RNodeExtInfo rNodeExtInfo = statInfoMap.get(pp.getLeft());
			String lineName = "-";
			if ( rNodeExtInfo != null ){
				lineName = getLineName(rNodeExtInfo);
				flowList.add(new KvGraphMonitorItemDO(lineName,rNodeExtInfo.getFlowNode(),0));
				rtList.add(new KvGraphMonitorItemDO(lineName,rNodeExtInfo.getRtNode(),0));
				failRateList.add(new KvGraphMonitorItemDO(lineName,rNodeExtInfo.getFailRateNode(),0));
			}else{
				flowList.add(KvGraphMonitorItemDO.getEmptyDO());
				rtList.add(KvGraphMonitorItemDO.getEmptyDO());
				failRateList.add(KvGraphMonitorItemDO.getEmptyDO());
			}
			MonitorItemDO cItemDO= chainExceptionMap.get(pp.getLeft());
			if ( cItemDO != null ){
				chainExceptions.add(new KvGraphMonitorItemDO(lineName,cItemDO,0));
			}else{
				chainExceptions.add(KvGraphMonitorItemDO.getEmptyDO());
			}
			cnt ++;
		}
		return ret;
	}
	/*
	 * -#DEFAULT#@_@mtop.trip.uilayout.queryuilayoutwithlogin:1.0@_@MTOP_errorcode [��] [�Ա�] 
	 */
	private String getLineName(RNodeExtInfo nodeExtInfo){
		MonitorItemDO flowNode = nodeExtInfo.getFlowNode();
		if ( flowNode == null ){
			return "-";
		}
		KeysDO keys = new KeysDO(flowNode.getNode());
		String k1 = keys.getKeys().get(0);
		String[] parts = k1.split(SceneContants.KEY_INNER_SPLITTER_1);
		if ( parts.length >= 2 ){
			return DescUtils.descEntryPoint5(parts[1]);
		}
		return "-";
	}
	private List<KvGraphMonitorItemDO> getList(Map<String, List<KvGraphMonitorItemDO>> retList,String key){
		List<KvGraphMonitorItemDO> list = retList.get(key);
		if ( list == null ){
			list = new ArrayList<KvGraphMonitorItemDO>();
			retList.put(key, list);
		}
		return list;
	}

	/*
	 * ���ݳ�������б���ȡ����Ӧ��
	 */
	private List<String> getRelateApps(List<SceneEntryPoint> entryPoints) throws DAOException {
		List<String> apps = new ArrayList<String>();
		Set<String> nodeGroups = new HashSet<String>();
		for ( SceneEntryPoint entryPoint:entryPoints ){
			List<SceneAppRelation> relations = sceneAppRelationDAO.queryRelationsByEntryPoint(entryPoint.getId(), new Date(),environmentService.getEnvironmentType().getEnv());
			for (SceneAppRelation sar:relations ){
				String providerAppNodeGroup = sar.getProviderAppNodeGroup();
				String consumerAppNodeGroup = sar.getConsumerAppNodeGroup();
				if (providerAppNodeGroup != null && providerAppNodeGroup.endsWith("host")){
					nodeGroups.add(providerAppNodeGroup);
				}
				if (consumerAppNodeGroup != null && consumerAppNodeGroup.endsWith("host")){
					nodeGroups.add(consumerAppNodeGroup);
				}
			}
		}
		for (String ng:nodeGroups ){
			String app = NodeExtUtils.getAppFromNodeGroup(ng);
			if ( app!= null){
				apps.add(app);
			}
		}
		return apps;
	}
	
}
