package com.taobao.ateye.monitor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.time.DateUtils;

import com.taobao.ateye.util.CalendarUtil;
import com.taobao.tracker.generalerror.domain.TimePeriodEnum;

public class TimePeriodUtils {
	public static final String ROWKEY_DATE_FORMAT = "yyyy-MM-dd HH:mm";
	public static String[] getTimeRange(Date date,int rangeInMinutes) {
		String[] timeRange = new String[2];
		GregorianCalendar calender = new GregorianCalendar();
		calender.setTime(date);
		int minute = calender.get(Calendar.MINUTE);
		int division = minute / rangeInMinutes;
		SimpleDateFormat format = new SimpleDateFormat(ROWKEY_DATE_FORMAT);
		calender.set(Calendar.MINUTE, division * rangeInMinutes);
		timeRange[0] = format.format(calender.getTime());
		calender.add(Calendar.MINUTE, rangeInMinutes);
		timeRange[1] = format.format(calender.getTime());
		return timeRange;
	}
	public static void main(String[] args) {
		String[] bb = TimePeriodUtils.getTimeRange(DateUtils.addHours(new Date(),1),2);
		System.out.println(bb[0]);
		System.out.println(bb[1]);
	}
	public static  String[] getDay(Date date) {
		String[] timeRange = new String[2];
		Date start = CalendarUtil.zerolizedTime(date);
		SimpleDateFormat format = new SimpleDateFormat(ROWKEY_DATE_FORMAT);
		timeRange[0] = format.format(start);
		timeRange[1] = format.format(DateUtils.addSeconds(DateUtils.addDays(start,1),-1));
		return timeRange;
	}
	public static int getTimePeriodDiffInMinutes(TimePeriodEnum period){
		if ( period.equals(TimePeriodEnum.ONEM)){
			return 1;
		}else if ( period.equals(TimePeriodEnum.TWOM) ){
			return 2;
		}else if ( period.equals(TimePeriodEnum.FIVEM) ){
			return 5;
		}else if ( period.equals(TimePeriodEnum.TENM) ){
			return 10;
		}else if ( period.equals(TimePeriodEnum.ONEH) ){
			return 60;
		}else if ( period.equals(TimePeriodEnum.ONED) ){
			return 60*24;
		}
		return 5;
	}
	public static String[] getTimePeriod(TimePeriodEnum period,Date beginTime){
		if ( period.equals(TimePeriodEnum.ONEM)){
			String beginTimeStr = CalendarUtil.toString(beginTime, TimePeriodUtils.ROWKEY_DATE_FORMAT);
			return new String[]{beginTimeStr,beginTimeStr};
		}else if ( period.equals(TimePeriodEnum.TWOM) ){
			return TimePeriodUtils.getTimeRange(beginTime, 2);
		}else if ( period.equals(TimePeriodEnum.FIVEM) ){
			return TimePeriodUtils.getTimeRange(beginTime, 5);
		}else if ( period.equals(TimePeriodEnum.TENM) ){
			return TimePeriodUtils.getTimeRange(beginTime, 10);
		}else if ( period.equals(TimePeriodEnum.ONEH) ){
			return TimePeriodUtils.getHourRange(beginTime);
		}else if ( period.equals(TimePeriodEnum.ONED) ){
			return TimePeriodUtils.getDay(beginTime);
		}
		return null;
	}

	public static  String[] getHourRange(Date date) {
		String[] timeRange = new String[2];
		GregorianCalendar calender = new GregorianCalendar();
		calender.setTime(date);
		SimpleDateFormat format = new SimpleDateFormat(ROWKEY_DATE_FORMAT);
		calender.set(Calendar.MINUTE, 0);
		timeRange[0] = format.format(calender.getTime());
		calender.add(Calendar.HOUR, 1);
		timeRange[1] = format.format(calender.getTime());
		return timeRange;
	}
}
