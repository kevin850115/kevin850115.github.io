package com.taobao.ateye.controller.logger;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dal.MetaDataDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.LogFilePathDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.MetaDataDO;
import com.taobao.ateye.dataobject.TargetMachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.LogFilePathService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.TargetMachineService;
import com.taobao.ateye.service.UserService;
import com.taobao.ateye.util.HttpUtil;
import com.taobao.ateye.util.UrlGenerator;

@Controller
@RequestMapping("/logpath")
public class LogPathController {

	private static final String LOG_PATH_LIST2 = "screen/logtrace/queryAppLogPathList2";
	private static final String ADD_PATH2 = "screen/logtrace/addPath2";
	private static final String EDIT_PATH = "screen/logtrace/editPath";
	// Ĭ����־������IP
	public static final String OWNER_IP = "0.0.0.0";
	private Logger logger = Logger.getLogger("LogPathController");

	@Autowired
	private OpsServic opsServic;

	@Autowired
	private LogFilePathService logFilePathService;

	@Autowired
	private AppService appService;

	@Autowired
	private MachineDAO machineDAO;

	@Autowired
	private TargetMachineService targetMachineService;

	@Autowired
	private UserService userService;


	@Autowired
	private MetaDataDAO metaDataDAO;
	
	@Autowired
	private UrlGenerator urlGenerator;


	@RequestMapping("logPathList2.htm")
	public String queryLogPathList2(final HttpServletRequest request, ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		result.put("user", user);
		if (userService.isAdminRole(user.getId())) {// �Ƿ�Ϊϵͳ����Ա
			result.put("isAdmin", true);
		}
		String app = request.getParameter("app");
		if (StringUtils.isNotBlank(app)) {
			AppDO appDO = appService.getAppByAppName(app);
			List<LogFilePathDO> logPathes = new ArrayList<LogFilePathDO>();
			try {
				logPathes = logFilePathService.getAllLogFilePathDOsInAnApp(appDO.getId());
			} catch (DAOException e) {
				logger.info("get all logFilePathDO failed .", e);
			}
			result.put("logPathes", logPathes);
			result.put("app", app);
		} else {
			result.put("error", "û�л�ȡ����ص�Ӧ������");
		}

		return LOG_PATH_LIST2;
	}

	// ��������־ҳ��
	@RequestMapping("addPath2.htm")
	public String addPath2(final HttpServletRequest request, ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String app = request.getParameter("app");
		List<MachineDO> machineLists = new ArrayList<MachineDO>();
		if (StringUtil.isNotBlank(app)) {
			try {
				machineLists = opsServic.getAllMachinesBelongToAnApp(app);
			} catch (DAOException e) {
				logger.info("get machineLists by app failed .", e);
			}
		}
		result.put("machineLists", machineLists);
		result.put("app", app);
		return ADD_PATH2;
	}
	// �򿪱༭��־ҳ��
	@RequestMapping("editPath.htm")
	public String editPath(final HttpServletRequest request, ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String id = request.getParameter("id");
		String app = request.getParameter("app");
		List<MachineDO> machineLists = new ArrayList<MachineDO>();
		if (StringUtil.isBlank(id)) {
			result.put("error", "idֵ�Ƿ�");
		}
		try {
			long logPathId = Long.valueOf(id);
			LogFilePathDO log = logFilePathService.getLogFilePathDO(logPathId);
			if(log == null){
				return queryLogPathList2(request, result);
			}
			machineLists = opsServic.getAllMachinesBelongToAnApp(app);
			List<TargetMachineDO> targetMachines = targetMachineService.getTargetMachinesByLogFilePathId(log.getId());
			result.put("log", log);
			/**
			 * �ж��Ƿ���б༭Ȩ��
			 */
			if(checkPermission(log.getOperator(), user)){
				result.put("isAllowEdit", "true");
			}
			
			if (userService.isAdminRole(user.getId())) {// �Ƿ�Ϊϵͳ����Ա
				result.put("isAdmin", true);
			}else{
				result.put("isAdmin", false);
			}
			
			if (targetMachines == null || targetMachines.size() <= 0) {// û��target����ѡ��ȫ��
				result.put("selectAll", "1");
			} else {
				result.put("selectAll", "0");
				result.put("targetMachines", targetMachines);
			}
		} catch (DAOException e) {
			logger.info("get machineLists by app failed .", e);
		}
		result.put("machineLists", machineLists);
		//Ԫ����
		List<MetaDataDO> metaDatas = new ArrayList<MetaDataDO>();
		try {
			metaDatas = metaDataDAO.getMetaDatasByStatus(1);
		} catch (DAOException e) {
			logger.info("��ȡԪ�����б����� .", e);
		}
		result.put("metaDatas", metaDatas);
		result.put("app", app);
		return EDIT_PATH;
	}
	/**
	 * ����
	 * 
	 * @param request
	 * @param result
	 * @return
	 * @throws DAOException
	 */
	@RequestMapping("savePath.htm")
	@Deprecated
	public String savePath(final HttpServletRequest request, ModelMap result) {
		try{
        		UserDO user = (UserDO) MyThreadLocal.get();
        		if (user == null) {
        			return "redirect:/noPermission.htm";
        		}
        		String app = request.getParameter("app");
        		String filePaths = request.getParameter("path");
        		String[] machineIds = request.getParameterValues("machine");
        		// �����Ƿ�ȫѡ
        		boolean selectAll = false;
        		if (null != request.getParameter("selectAll")) {
        			selectAll = request.getParameter("selectAll").equals("1");
        		}
        		List<MachineDO> machines = null;
        		if (!selectAll) {
        			machines = new ArrayList<MachineDO>();
        			for (String machineId : machineIds) {
        				try {
        					Long id = Long.valueOf(machineId);
        					MachineDO machine = machineDAO.getMachineByid(id);
        					if (machine != null) {
        						machines.add(machine);
        					}
        				} catch (NumberFormatException e) {
        					logger.error("machineId is not int: " + machineId);
        				} catch (DAOException e) {
        				}
        			}
        		}
        
        		String[] path = null;
        		if (filePaths.contains(";")) path = filePaths.split(";");
        		else {
        			path = new String[1];
        			path[0] = filePaths;
        		}
        		String logType = request.getParameter("log_type");
        		String scriptType = request.getParameter("script_type");
        		String script = request.getParameter("script");
        		String dataId = request.getParameter("dataId");
        
        		if (StringUtils.isBlank(app)) {
        			result.put("error", "������ѡ����ЧӦ��");
        			return queryLogPathList2(request, result);
        		}
        		StringBuilder failurePathList = new StringBuilder(" ");
        		for (int i = 0; i < path.length; i++) {
        			path[i] = path[i].trim();
        			if (StringUtils.isBlank(path[i]) || !path[i].substring(0, 12).equalsIgnoreCase("/home/admin/")) {
        				// result.put("error", "���������� ��Ч����־·��(/home/admin/��ͷ)");
        				// return queryLogPathList2(request, result);
        				failurePathList.append(path[i] + ":��־·����Ч;");
        				continue;
        			}
        			Boolean isExist = false;
        			try {
        				if (logFilePathService.shouldCheckPath()) {
        					isExist = isPathFileExist(app, path[i]);
        				} else {
        					// ����⣬ֱ��Ĭ���ļ�����
        					isExist = true;
        				}
        			} catch (UnsupportedEncodingException e1) {
        				logger.info("url encoding exception ", e1);
        			} catch (DAOException e1) {
        				logger.info("get machine exception ", e1);
        			}
        			if (!isExist) {
        				result.put("error", "����־�ļ�·��������");
        				return queryLogPathList2(request, result);
        			}
        
        			Boolean isContain = false;
        			isContain = isContainPath(app, path[i]); // �ж��Ƿ����ݿ����Ѿ�����
        			if (isContain) {
        				failurePathList.append(path[i] + ":��·���Ѿ������ݿ��д���;");
        				continue;
        				// result.put("error", path[i]+"�Ѿ������ݿ��д���");
        				// queryLogPathList2(request, result);
        			}
        			AppDO appDO = appService.getAppByAppName(app);
        			LogFilePathDO pathDo = new LogFilePathDO();
        			pathDo.setAppId(appDO.getId());
        			// pathDo.setType(1);
        			pathDo.setFilePath(path[i]);
        			pathDo.setType(Integer.parseInt(logType));
        			pathDo.setScriptType(Integer.parseInt(scriptType));
        			pathDo.setDataId(Long.parseLong(dataId));
        
        			// �滻���з���\r\n��λlinux����
        			if (StringUtil.isNotBlank(script)) {
        				script = script.trim();
        				script = script.replaceAll("\r\n", "\n");
        				pathDo.setScript(script);
        			}
        
        			pathDo.setOperator(user.getNick());
        			pathDo.setOwner(OWNER_IP);
        
        			boolean saveOk = false;
        			try {
        				if (selectAll) {// ��ѡ��ȫѡ
        					saveOk = logFilePathService.saveLogFilePathDO(pathDo);
        				} else if (pathDo != null && machines != null && machines.size() != 0) {
        					saveOk = logFilePathService.saveLogFilePathWithMachine(pathDo, machines);
        				}
        			} catch (DAOException e) {
        				logger.info("save logFilePathDo Exception", e);
        			}
        			if (!saveOk) {
        				// result.put("error", "�����µ���־�ļ�·��ʧ��");
        				failurePathList.append(path[i] + "��·������ʧ��;");
        			}
        		}
        
        		if (!StringUtil.isBlank(failurePathList.toString())) result.put("error", failurePathList);
		}catch (NumberFormatException e) {
			result.put("error", "�����Ƿ�");
		}catch (Exception e1) {
			result.put("error", "ϵͳ����");
		}
		return queryLogPathList2(request, result);
	}
	/**
	 * ����
	 * 
	 * @param request
	 * @param result
	 * @return
	 * @throws DAOException
	 */
	@RequestMapping("savePath2.htm")
	public String savePath2(final HttpServletRequest request, ModelMap result) {
		try{
        		UserDO user = (UserDO) MyThreadLocal.get();
        		if (user == null) {
        			return "redirect:/noPermission.htm";
        		}
        		String app = request.getParameter("app");
        		String filePaths = request.getParameter("path");
        		// �����Ƿ�ȫѡ
        		String[] path = null;
        		if (filePaths.contains(";")) path = filePaths.split(";");
        		else {
        			path = new String[1];
        			path[0] = filePaths;
        		}
        		String logType = request.getParameter("log_type");
        		String scriptType = "0";
        		String script = "";
        		String dataId = "0";
        
        		if (StringUtils.isBlank(app)) {
        			result.put("error", "������ѡ����ЧӦ��");
        			return queryLogPathList2(request, result);
        		}
        		StringBuilder failurePathList = new StringBuilder(" ");
        		for (int i = 0; i < path.length; i++) {
        			path[i] = path[i].trim();
        			if (StringUtils.isBlank(path[i]) || !path[i].substring(0, 12).equalsIgnoreCase("/home/admin/")) {
        				// result.put("error", "���������� ��Ч����־·��(/home/admin/��ͷ)");
        				// return queryLogPathList2(request, result);
        				failurePathList.append(path[i] + ":��־·����Ч;");
        				continue;
        			}
        			Boolean isExist = false;
        			try {
        				if (logFilePathService.shouldCheckPath()) {
        					isExist = isPathFileExist(app, path[i]);
        				} else {
        					// ����⣬ֱ��Ĭ���ļ�����
        					isExist = true;
        				}
        			} catch (UnsupportedEncodingException e1) {
        				logger.info("url encoding exception ", e1);
        			} catch (DAOException e1) {
        				logger.info("get machine exception ", e1);
        			}
        			if (!isExist) {
        				result.put("error", "����־�ļ�·��������");
        				return queryLogPathList2(request, result);
        			}
        
        			Boolean isContain = false;
        			isContain = isContainPath(app, path[i]); // �ж��Ƿ����ݿ����Ѿ�����
        			if (isContain) {
        				failurePathList.append(path[i] + ":��·���Ѿ������ݿ��д���;");
        				continue;
        				// result.put("error", path[i]+"�Ѿ������ݿ��д���");
        				// queryLogPathList2(request, result);
        			}
        			AppDO appDO = appService.getAppByAppName(app);
        			LogFilePathDO pathDo = new LogFilePathDO();
        			pathDo.setAppId(appDO.getId());
        			pathDo.setFilePath(path[i]);
        			pathDo.setType(Integer.parseInt(logType));
        			pathDo.setScriptType(Integer.parseInt(scriptType));
        			pathDo.setDataId(Long.parseLong(dataId));
        
        			// �滻���з���\r\n��λlinux����
        			if (StringUtil.isNotBlank(script)) {
        				script = script.trim();
        				script = script.replaceAll("\r\n", "\n");
        				pathDo.setScript(script);
        			}
        
        			pathDo.setOperator(user.getNick());
        			pathDo.setOwner(OWNER_IP);
        
        			boolean saveOk = false;
        			try {
    					saveOk = logFilePathService.saveLogFilePathDO(pathDo);
        			} catch (DAOException e) {
        				logger.info("save logFilePathDo Exception", e);
        			}
        			if (!saveOk) {
        				// result.put("error", "�����µ���־�ļ�·��ʧ��");
        				failurePathList.append(path[i] + "��·������ʧ��;");
        			}
        		}
        
        		if (!StringUtil.isBlank(failurePathList.toString())) result.put("error", failurePathList);
		}catch (NumberFormatException e) {
			result.put("error", "�����Ƿ�");
		}catch (Exception e1) {
			result.put("error", "ϵͳ����");
		}
		return queryLogPathList2(request, result);
	}

	private Boolean isPathFileExist(String appName, String path) throws DAOException, Exception {
		boolean isExist = false;
		String type = "THREAD";// �����ֲ�ͬ�Ĳ���
		String order = "isExist"; // �����ֲ鿴�ļ����ڵ�
		List<MachineDO> machines = queryMachineAndAppList(appName);
		if (machines != null && !machines.isEmpty()) {
			MachineDO machine = machines.get(0);
			String ip = machine.getIp();
			Integer port = machine.getPort();
			Map<String, String> params = new HashMap<String, String>();
			params.put("type", type);
			params.put("order", order);
			params.put("path", path);
			// ip="127.0.0.1"; //��Ŀ�������ڲ���
			// port=80; //���ڲ���
			String url = urlGenerator.getUrl(ip, port.toString(), params);
			String responseBody = "";
			responseBody = HttpUtil.get(url, 10000);
			if (StringUtils.isNotBlank(responseBody)) {
				if (responseBody != null && responseBody.toString().trim().equals("true")) {
					isExist = true;
				}
			}
		}
		return isExist;
	}

	private List<MachineDO> queryMachineAndAppList(String appName) throws DAOException {
		List<MachineDO> machines = new ArrayList<MachineDO>();
		machines = opsServic.getAllMachinesBelongToAnApp(appName);
		return machines;
	}

	/**
	 * �ж����Ѿ��д�path�ļ�¼��
	 * 
	 * @param app
	 * @param path
	 * @return
	 */
	private Boolean isContainPath(String app, String path) {
		AppDO appDO = appService.getAppByAppName(app);
		List<LogFilePathDO> logPathes = new ArrayList<LogFilePathDO>();
		try {
			logPathes = logFilePathService.getAllLogFilePathDOsInAnApp(appDO.getId());
		} catch (DAOException e) {
			logger.info("get all logFilePathDO failed .", e);
		}
		for (LogFilePathDO logFilePathDO : logPathes) {
			if (path.trim().equals(logFilePathDO.getFilePath().trim())) {
				return true;
			}
		}
		return false;
	}

	@RequestMapping("delPath2.htm")
	public String delPath2(final HttpServletRequest request, ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String filePathId = request.getParameter("pathId");
		
		/**
		 * Ȩ���ж�
		 */
		LogFilePathDO logPathDO = null;
		try {
			logPathDO = logFilePathService.getLogFilePathDO(Long.valueOf(filePathId));
		} catch (Exception e1) {
		}
		if(logPathDO == null){
			return queryLogPathList2(request, result);
		}
		if(!checkPermission(logPathDO.getOperator(), user)){
			return "redirect:/noPermission.htm";
		}
		
		boolean delOk = false;
		try {
			delOk = logFilePathService.deleteLogFilePathDO(Long.valueOf(filePathId));
		} catch (NumberFormatException e) {
			logger.info("translate numberFormat Exception", e);
		} catch (DAOException e) {
			logger.info("delete logFilePathDo exception", e);
		}
		if (!delOk) {
			result.put("error", "ɾ���ļ�·����¼ʧ��");
		}
		return queryLogPathList2(request, result);
	}
	/**
	 * У��Ȩ�ޡ�һ�����ַ���true
	 * 1. logUserΪ��/Ϊ��ȥ���ˣ�û��Ȩ��
	 * 2. userΪϵͳ����Ա
	 * 3. logUser=user.nick
	 * @param logUser
	 * @param user
	 */
	public boolean checkPermission(String logUser, UserDO user){
		if(user == null){
			return false;
		}
		/*if(StringUtil.isBlank(logUser)){
			return true;
		}*/
		if (userService.isAdminRole(user.getId())) {// �Ƿ�Ϊϵͳ����Ա
			return true;
		}
		if(StringUtil.isBlank(logUser)){
			return false;
		}
		if(user.getNick().equals(logUser)){
			return true;
		}else{
			return false;
		}
		
	}
}
