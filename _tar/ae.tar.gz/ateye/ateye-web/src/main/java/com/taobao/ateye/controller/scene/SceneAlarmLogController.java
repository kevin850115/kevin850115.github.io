package com.taobao.ateye.controller.scene;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.alarm.log.AlarmLogModelListDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/scene")
public class SceneAlarmLogController extends AbstractController{
	private static final String ALARM_LOG_LIST = "screen/scene/alarmLogList";


	@RequestMapping("alarmLogList.htm")
	public String alarmLogList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltRule= request.getParameter("fltRule");
		if ( StringUtils.isNotBlank(fltRule) ){
			flts.put("rule", fltRule);
			result.put("fltRule",fltRule);
		}
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltApp = request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltSource= request.getParameter("fltSource");
		if ( StringUtils.isNotBlank(fltSource) ){
			flts.put("source", fltSource);
			result.put("fltSource",fltSource);
		}
		Date day = new Date();
		int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		String dayStr = request.getParameter("day");
		if ( StringUtils.isNotBlank(dayStr) ){
			day = CalendarUtil.toDate(dayStr, CalendarUtil.DATE_FMT_3);
		}
		String hourStr = request.getParameter("hour");
		if ( StringUtils.isNotBlank(hourStr) ){
			hour = Integer.valueOf(hourStr);
		}
		result.put("hour", hour);
		result.put("day",CalendarUtil.toString(day, CalendarUtil.DATE_FMT_3));
		AlarmLogModelListDO alarmLogList = alarmLogModelManager.queryLogList(flts, day,hour);
		
		Map<String, List<Pair<String, Integer>>> fltMap = alarmLogList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("sourceFlt", fltMap.get("source"));
		result.put("levelFlt", fltMap.get("level"));
		result.put("ruleFlt", fltMap.get("rule"));
		result.put("appFlt", fltMap.get("app"));
		result.put("bizMap",getBizMap());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("alarmLogList",alarmLogList.getTopNRetList(1000));
		result.put("totalCnt",alarmLogList.getRetList().size());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return ALARM_LOG_LIST; 
		
	}
}
