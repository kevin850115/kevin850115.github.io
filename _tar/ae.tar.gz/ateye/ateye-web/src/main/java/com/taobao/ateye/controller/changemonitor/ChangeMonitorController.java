package com.taobao.ateye.controller.changemonitor;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.alarm.log.AlarmLogGraphManager;
import com.taobao.ateye.alarm.log.AlarmLogGraphParam;
import com.taobao.ateye.app.AppModelManager;
import com.taobao.ateye.app.model.AppModelDO;
import com.taobao.ateye.app.model.AppModelListDO;
import com.taobao.ateye.applog.AppLog;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.base.EnvIdType;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.AppChangeMonitor;
import com.taobao.ateye.changemonitor.AppModelVO;
import com.taobao.ateye.changemonitor.ChangeMonitorService;
import com.taobao.ateye.changemonitor.ResultModel;
import com.taobao.ateye.changemonitor.common.ChangeMonitorTaskStatus;
import com.taobao.ateye.changemonitor.entry.ChangeStableResponse;
import com.taobao.ateye.changemonitor.server.ChangeMonitorDataAnalysis;
import com.taobao.ateye.changemonitor.server.ChangeMonitorManager;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.config.app.impl.AppExtendManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.ChangeFreeDAO;
import com.taobao.ateye.dataobject.*;
import com.taobao.ateye.db.model.DbModelListDO;
import com.taobao.ateye.db.model.TairModelListDO;
import com.taobao.ateye.detect.DetectResultDO;
import com.taobao.ateye.detect.SystemDetectManager;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.graph.base.GraphParamDO;
import com.taobao.ateye.hsf.manager.HsfManager;
import com.taobao.ateye.kv.KvGraphManager;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.realtime.RealTimeRecordModelListDO;
import com.taobao.ateye.relation.tree.node.NodeExtUtils;
import com.taobao.ateye.scene.manager.RealTimeTrackerManager;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.ateye.ssql.SSqlModelListDO;
import com.taobao.ateye.system.SystemManager;
import com.taobao.ateye.system.SystemMonitorDO;
import com.taobao.ateye.util.ExtUrlUtil;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.except.ExceptionTypeConstant;
import com.taobao.tracker.generalerror.domain.TimePeriodEnum;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.util.CalendarUtil;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.*;

@Controller
@RequestMapping("/changemonitor")
public class ChangeMonitorController extends AbstractController{
	private static final String CHANGE_MONITOR = "screen/changemonitor/changemonitor";
	
	@Autowired
	private ChangeMonitorDataAnalysis changeMonitorDataAnalysis;

	@Autowired
	private ChangeMonitorManager changeMonitorManager;

	@Autowired
	private ChangeMonitorService changeMonitorService;

	@Autowired
	private ChangeFreeDAO changeFreeDAO;

	@RequestMapping("changemonitor.htm")
	public String app(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app)){
			return "";
		}
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return "";
		}
		ChangeFreeDO changeFreeDO = changeFreeDAO.getLatestPubOfApp(app);
		if ( changeFreeDO == null ){
			return "";
		}
		result.put("changeFreeDO",changeFreeDO);

		Map<String, String> flts = new HashMap<String,String>();;
		flts.put("app", app);
		result.put("app",app);
		result.put("bizMap",getBizMap());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("urlStr",NodeExtUtils.buildAppExtensionUrl(appDO, "btn white btn-info mr2",false));

		//1.��ȡӦ��
		AppModelListDO appModel = appModelManager.queryAppList(flts,true);
		AppModelDO appInfo = appModel.getRetList().iterator().next();
		result.put("appInfo",appInfo);
		//2����ȡϵͳ�������
		ChangeStableResponse changeStableResponse = changeMonitorManager.getChangeStableResponse(appInfo,changeFreeDO);
		//2��ϵͳ���
		Map<String,Object> commonBodyMap = changeMonitorDataAnalysis.genCommonBodyMap(changeStableResponse,true);

		String sysSummary = genSysSummary(commonBodyMap);
		result.put("sysSummary",sysSummary);

		super.setIsMobile(request, result);
		return "";
	}

	private String genSysSummary(Map<String,Object> commonBodyMap){
		StringBuffer resultStr = new StringBuffer();
		if(commonBodyMap.get("alarmCount") !=null && (Integer)commonBodyMap.get("alarmCount") > 0){
			resultStr.append("��������:");
			resultStr.append(commonBodyMap.get("alarmCount"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("hisAlarmCt")!=null && (Float)commonBodyMap.get("hisAlarmCt") > 0){
			resultStr.append("ǰ1Сʱ��������:");
			resultStr.append(commonBodyMap.get("hisAlarmCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("excpCount") !=null && (Long)commonBodyMap.get("excpCount") > 0){
			resultStr.append("�쳣����:");
			resultStr.append(commonBodyMap.get("excpCount"));
			resultStr.append("��;");

		}
		if(commonBodyMap.get("hisExcpCount") !=null && (Float)commonBodyMap.get("hisExcpCount") > 0){
			resultStr.append("ǰ1Сʱ�쳣����:");
			resultStr.append(commonBodyMap.get("hisExcpCount"));
			resultStr.append("��;");

		}
		if(commonBodyMap.get("hisDayExcpCount") !=null && (Float)commonBodyMap.get("hisDayExcpCount") > 0){
			resultStr.append("ǰ3��ͬʱ���쳣��ֵ:");
			resultStr.append(commonBodyMap.get("hisDayExcpCount"));
			resultStr.append("��;");

		}
		if(commonBodyMap.get("coreExcpCt") !=null && (Long)commonBodyMap.get("coreExcpCt") > 0){
			resultStr.append("�����쳣����:");
			resultStr.append(commonBodyMap.get("coreExcpCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("hisCoreExcpCt") !=null && (Float)commonBodyMap.get("hisCoreExcpCt") > 0){
			resultStr.append("ǰ1Сʱ�����쳣����:");
			resultStr.append(commonBodyMap.get("hisCoreExcpCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("hisDayCoreExcpCt") !=null && (Float)commonBodyMap.get("hisDayCoreExcpCt") > 0){
			resultStr.append("ǰ3��ͬʱ�������쳣��ֵ:");
			resultStr.append(commonBodyMap.get("hisDayCoreExcpCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("loadIssueCt") !=null && (Integer)commonBodyMap.get("loadIssueCt") > 0){
			resultStr.append("����load��������:");
			resultStr.append(commonBodyMap.get("loadIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("threadsIssueCt") !=null && (Integer)commonBodyMap.get("threadsIssueCt") > 0){
			resultStr.append("�����̹߳�������:");
			resultStr.append(commonBodyMap.get("threadsIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("jvmMemIssueCt") !=null && (Integer)commonBodyMap.get("jvmMemIssueCt") > 0){
			resultStr.append("����Jvm��������:");
			resultStr.append(commonBodyMap.get("jvmMemIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("oldPercentIssueCt") !=null && (Integer)commonBodyMap.get("oldPercentIssueCt") > 0){
			resultStr.append("����Old��ռ�ȹ�������:");
			resultStr.append(commonBodyMap.get("oldPercentIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("hsfOnlineIssueCt") !=null && (Integer)commonBodyMap.get("hsfOnlineIssueCt") > 0){
			resultStr.append("����HSF����������:");
			resultStr.append(commonBodyMap.get("hsfOnlineIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("jvmAliveIssueCt") !=null && (Integer)commonBodyMap.get("jvmAliveIssueCt") > 0){
			resultStr.append("����Jvm����������:");
			resultStr.append(commonBodyMap.get("jvmAliveIssueCt"));
			resultStr.append("��;");
		}
		if(commonBodyMap.get("ngAliveIssueCt") !=null && (Integer)commonBodyMap.get("ngAliveIssueCt") > 0){
			resultStr.append("����NG����������:");
			resultStr.append(commonBodyMap.get("ngAliveIssueCt"));
			resultStr.append("��;");
		}

		return resultStr.toString();
	}
}
