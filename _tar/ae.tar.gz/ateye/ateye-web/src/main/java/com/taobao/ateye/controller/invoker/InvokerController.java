package com.taobao.ateye.controller.invoker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.alarm.n.manager.AlarmDetectorManager;
import com.taobao.ateye.changefree.CFType;
import com.taobao.ateye.changefree.ChangeFreeRS;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.taobao.ateye.applog.AppLog;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.AppChangeMonitor;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserAuditDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.invoker.Invoker;
import com.taobao.ateye.invoker.ParamInfoView;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.UserAuditService;
import com.taobao.ateye.useaudit.UserAuditHistoryManager;
import com.taobao.ateye.util.AgentVersionUtil;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;

@Controller
@RequestMapping("/invoker")
public class InvokerController extends AbstractController{
	private static Logger logger=Logger.getLogger("InvokerLogger");
	
	private ExecutorService exec = Executors.newCachedThreadPool();

	private static final String DIMENSION2="screen/invoker/machineList2";
	private static final String ALL_INVOKERS_OF_AN_APP2="screen/invoker/invokers_list_all2";
	private static final String ALL_INVOKERS_OF_A_SINGLE_MACHINE2="screen/invoker/allInvokersOfSingleMachine2";
	private static final String SINGLE_INVOKER_OF_A_SINGLE_MACHINE2="screen/invoker/singleIvokerOfSingleMachine2";
	private static final String SINGLE_INVOKER_OF_A_SINGLE_MACHINE_ALL2="screen/invoker/singleIvokerOfSingleMachine_all2";
	private static final String INVOKER_PARAMDESC_SEPERATOR="&";
	
	@Autowired
    private OpsServic opsServic;
	@Autowired
	private UrlGenerator  urlGenerator;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private AgentVersionUtil agentVersionUtil;
	@Autowired
	private UserAuditHistoryManager userAuditHistoryManager;
	@Autowired
	private UserAuditService userAuditService;

	@Autowired
	private AlarmDetectorManager detectorManager;
	
    private void checkEnvIsMatch(String ip,String app) {
    	boolean isMatch = environmentService.checkEnvMatch(app, ip);
    	if ( !isMatch ){
    		throw new RuntimeException("App��IP��ƥ��");
    	}
    }
    @RequestMapping("selectApp2.htm")
    public String selectApp2(final HttpServletRequest request, ModelMap result) throws DAOException {
        //����ҵ���ߵķ���
    	result.put("to", "/invoker/invokerDimension2.htm");
    	result.put("level2","��������");
    	result.put("level2Url","/invoker/selectApp2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 

    @RequestMapping("invokerDimension2.htm")
    public String invokerDimension2(final HttpServletRequest request, ModelMap result) throws DAOException{
    	return _invokerDimension(request, result, DIMENSION2);
    }
    private String _invokerDimension(final HttpServletRequest request, ModelMap result,String page) throws DAOException {
    	String app=request.getParameter("app");
    	List<MachineDO> machines=opsServic.getAllMachinesBelongToAnApp(app);

		result.put("env",this.environmentService.getEnvironmentType().getEnv());

		String refreshed = request.getParameter("refreshed");
		if(org.apache.commons.lang.StringUtils.isNotBlank(refreshed)){
			result.put("refreshed",refreshed);
		}
    	result.put("machines", machines);
    	result.put("app", app);
    	return page;
    }
    @RequestMapping("queryRemoteInvokers2.htm")
    public String queryRemoteInvokers2(final HttpServletRequest request, ModelMap result) {
    	return _queryRemoteInvokers(request,result,ALL_INVOKERS_OF_A_SINGLE_MACHINE2);
    }
    private String _queryRemoteInvokers(final HttpServletRequest request, ModelMap result,String page) {
    	UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
    	String app=request.getParameter("app");
    	String machineName=request.getParameter("machineName");
    	String ip=request.getParameter("ip");
    	String port=request.getParameter("port");
    	
    	checkEnvIsMatch(ip, app);
    	
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "INVOKER");
    	params.put("action", "list");
    	String url="";
		try {
			url = urlGenerator.getUrl(ip, port, params);
		} catch (Exception e1) {
			result.put("errorMsg", e1.getMessage());
			return page;
		}
		List<Invoker> allInvokers=new ArrayList<Invoker>();
		try {
			String json=HttpClientUtil.getResult(url);
			JSONArray jsonArray=new JSONArray(json);
			int type=environmentService.getEnvironmentType().ordinal();//��ȡ��ǰ����
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(i);
				Invoker iv=Invoker.getInvoker(jsonObject);
				if(iv!=null){
					if(type>0&&iv.getInvokerType().contains("DAILY"))//��ǰ������Ϊdaily����Invoker TypeΪdaily
						continue;
					allInvokers.add(iv);
				}
					
			}
			
		} catch (Exception e) {
			logger.error("��ȡ����:"+ip+":"+port+" ��Invoker�쳣",e);
			result.put("errorMsg", e.getMessage());
		}
		List<List<Invoker>> sortInvokders = userAuditHistoryManager.sortInvokders(allInvokers, user.getNick(), app);
		result.put("invokerList", sortInvokders);
		if(sortInvokders.get(0).size() > 0) {
			result.put("hasRecentlyUsedInvokers", "true");
		}
		if(sortInvokders.get(1).size() > 0) {
			result.put("hasHeavilyUsedInvokers", "true");
		}
		if(sortInvokders.get(2).size() > 0) {
			result.put("hasOtherInvokers", "true");
		}
		result.put("app", app);
		result.put("machineName", machineName);
		result.put("ip", ip);
		result.put("port", port);
    	return page;
    }
    @RequestMapping("querySingleInvoker2.htm")
    public String querySingleInvoker2(final HttpServletRequest request, ModelMap result) {
    	return _querySingleInvoker(request, result, SINGLE_INVOKER_OF_A_SINGLE_MACHINE2);
    }
    private String _querySingleInvoker(final HttpServletRequest request, ModelMap result,String page) {
    	String app=request.getParameter("app");
    	String machineName=request.getParameter("machineName");
    	String ip=request.getParameter("ip");
    	String port=request.getParameter("port");
    	String beanName=request.getParameter("beanName");
    	String signature=request.getParameter("signature");
    	
    	checkEnvIsMatch(ip, app);
    	
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "INVOKER");
    	params.put("action", "single");
    	params.put("beanName", beanName);
    	params.put("signature", signature);
    	String url="";
		try {
			url = urlGenerator.getUrl(ip, port, params);
		} catch (Exception e1) {
			result.put("errorMsg", e1.getMessage());
			return page;
		}
		try {
			String json= HttpClientUtil.getResult(url);
			JSONObject jsonM=new JSONObject(json);
			//it's OK
			if(jsonM.opt("errorMsg")==null)
			{
				Invoker iv=Invoker.getInvoker(jsonM);
				result.put("invoker", iv);
				String paramDesc=iv.getParamDesc();
				if(paramDesc==null)
				{
					paramDesc="";
				}
				String[] paramTypes=iv.getParamTypeList();
				String[] realDescs=paramDesc.split(INVOKER_PARAMDESC_SEPERATOR);
				List<ParamInfoView> paramList=new ArrayList<ParamInfoView>();
				for(int i=0;i<paramTypes.length;i++)
				{
					String pDesc = null;
					if(i<realDescs.length)
					{
						pDesc=realDescs[i];
					}
					else
					{
						pDesc="���޲�������";
					}
					paramList.add(new ParamInfoView(paramTypes[i], pDesc));
				}
				result.put("paramList", paramList);
			}
			else
			{
				result.put("errorMsg", jsonM.opt("errorMsg"));
			}
		} catch (Exception e) {
			logger.error("��ȡInvoker��Ϣʱ�쳣"+" ip:"+ip+" port:"+port+" bean:"+beanName+" signature:"+signature,e);
			result.put("errorMsg", e.getMessage());
		}
		/**
		 * ��ȡateye�汾���鿴�Ƿ����1.0.3
		 */
		boolean isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
		result.put("isSupportNull", isSupportNull);
		
		result.put("app", app);
		result.put("machineName", machineName);
		result.put("ip", ip);
		result.put("port", port);
    	return page;
    }
    @RequestMapping("invokeAMethod2.htm")
    public String invokeAMethod2(final HttpServletRequest request,  @RequestParam(value = "nullParams", required = false) String[] nullParams,  ModelMap result){
    	return _invokeAMethod(request, nullParams, result, SINGLE_INVOKER_OF_A_SINGLE_MACHINE2);
    }
    private String _invokeAMethod(final HttpServletRequest request,  @RequestParam(value = "nullParams", required = false) String[] nullParams,  ModelMap result,String page) {
    	UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	String app=request.getParameter("app");
    	String machineName=request.getParameter("machineName");
    	String ip=request.getParameter("ip");
    	String port=request.getParameter("port");
    	String beanName=request.getParameter("beanName");
    	String signature=request.getParameter("signature");
    	String paramCountStr=request.getParameter("paramCount");

		String approve=request.getParameter("approve");
		if(StringUtil.isNotEmpty(approve) && "true".equalsIgnoreCase(approve)){
			ChangeFreeRS rs = approveManager.check(CFType.METHOD,user.getEmpId()+"",app,beanName,signature);
			if(!rs.isPass() && StringUtil.isNotEmpty(rs.getApproveUrl())){
				return "redirect:"+rs.getApproveUrl();
			}
		}
    	checkEnvIsMatch(ip, app);
    	
    	StringBuilder newValue=new StringBuilder();
    	int paramCount = Integer.parseInt(paramCountStr);
    	boolean isSuccess=false;
    	
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "INVOKER");
    	params.put("action", "invoke");
    	params.put("beanName", beanName);
    	params.put("signature", signature);
    	for(int i=1;i<=paramCount;i++) {
    		String param=request.getParameter("param"+i);
    		params.put("param"+i,param);
    		newValue.append("param"+i+"="+param+";");
    	}
    	
    	//��ֵ���
    	 if(nullParams != null && nullParams.length>0){
    		 params.put("nullParams", paraseArrayToString(nullParams));
    	 }
    	 
    	String url="";
		try {
			url = urlGenerator.getUrl(ip, port, params);
		} catch (Exception e1) {
			result.put("errorMsg", e1.getMessage());
			return page;
		}
		url=url.replace(" ", "%20");
		try {
			String json= HttpClientUtil.getResult(url);
			if ( StringUtils.isBlank(json) ){
				logger.error("�������÷��ؿ�,ip:"+ip+" port:"+port+" params:"+params);
				return page;
			}
			JSONArray array=new JSONArray(json);
			JSONObject callResult = array.getJSONObject(0);
			if(array.length()==2&&callResult.opt("errorMsg")==null) {
				isSuccess=true;
				JSONObject invokerJson = array.getJSONObject(1);
				Invoker iv=Invoker.getInvoker(invokerJson);
				String paramDesc=iv.getParamDesc();
				if(paramDesc==null) {
					paramDesc="";
				}
				String[] paramTypes=iv.getParamTypeList();
				String[] realDescs=paramDesc.split(INVOKER_PARAMDESC_SEPERATOR);
				List<ParamInfoView> paramList=new ArrayList<ParamInfoView>();
				for(int i=0;i<paramTypes.length;i++)
				{
					String pDesc = null;
					if(i<realDescs.length)
					{
						pDesc=realDescs[i];
					}
					else
					{
						pDesc="���޲�������";
					}
					paramList.add(new ParamInfoView(paramTypes[i], pDesc));
				}
				/**
				 * ��ȡateye�汾���鿴�Ƿ����1.0.3
				 */
				boolean isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
				result.put("isSupportNull", isSupportNull);				
				
				result.put("paramList", paramList);
				result.put("invoker", iv);
				result.put("returnValue", callResult.opt("returnValue"));
				result.put("ateyeOut", callResult.opt("ateyeOut"));
				result.put("exception", callResult.opt("exception"));
			}
			else
			{  
				result.put("errorMsg", callResult.opt("errorMsg"));
			}
		} catch (Exception e) {
			logger.error("���������쳣ip:"+ip+" port:"+port+" params:"+params,e);
			result.put("errorMsg", e.getMessage());
		}
		AppLog.log("��������",app,beanName+":"+signature,"�������óɹ�,"+beanName+":"+signature+":"+paramCountStr);

		if(!signature.startsWith("find") && !signature.startsWith("get") && !signature.startsWith("view") && !signature.startsWith("query")) {
			AppChangeLogVO changeLog = AppChangeMonitor.createMethodInvokeChangeLog(beanName, signature, newValue.toString(), result, user.getNick(), UUID.randomUUID().toString(), ip, app);
//			detectorManager.sendAteyeMethod(changeLog,isSuccess);
			super.appChangeLogService.addOneChangeLog(changeLog);
		}

		/**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),app,ip,UserAuditDO.INVOKER,beanName,signature,newValue.toString()+"&isSuccess="+isSuccess);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("app", app);
		result.put("machineName", machineName);
		result.put("ip", ip);
		result.put("port", port);
    	return page;
    }
    
	    /**
	 * @param nullParams
	 * @return
	 */
	private String paraseArrayToString(String[] nullParams) {
	   	 if(nullParams == null || nullParams.length == 0){
	   		 return null;
	   	 }
	   	 StringBuffer result = new StringBuffer();
	   	 for(int i = 0 ;i < nullParams.length; i++){
	   		 if(i > 0){
	   			 result.append(",");
	   		 }
	   		 result.append(nullParams[i]);
	   	 }
	   	 return result.toString();
	}
	@RequestMapping("listAllInvokersOfAnApp2.htm")
    public String listAllInvokers2(final HttpServletRequest request, ModelMap result){
		return _listAllInvokers(request, result, ALL_INVOKERS_OF_AN_APP2);
	}
    private String _listAllInvokers(final HttpServletRequest request, ModelMap result,String page){
    	UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
	    String app=request.getParameter("app");
    	List<MachineDO> machines=null;
		try {
			machines = opsServic.getAllMachinesBelongToAnApp(app);
		} catch (DAOException e2) {
			logger.info("opsService failure",e2);
		}
    	List<Invoker> allInvokers = Lists.newArrayList();
    	if(machines == null){
    		return null;
    	}
    	for(MachineDO machine:machines)
    	{
    		String ip=machine.getIp();
    		String port=machine.getPort()+"";
        	Map<String,String> params=new HashMap<String,String>();
        	params.put("type", "INVOKER");
	    	params.put("action", "list");
	    	String url="";
			try {
				url = urlGenerator.getUrl(ip, port, params);
			} catch (Exception e1) {
				continue;
			}
			try {
				String json=HttpClientUtil.getResult(url);
				JSONArray jsonArray=new JSONArray(json);
				int type=environmentService.getEnvironmentType().ordinal();//��ȡ��ǰ����
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					Invoker iv=Invoker.getInvoker(jsonObject);
					if(iv!=null){
						if(type>0&&iv.getInvokerType().contains("DAILY"))//��ǰ������Ϊdaily����Invoker TypeΪdaily
							continue;
						allInvokers.add(iv);
					}
					
				}
				if(allInvokers.size()>0)
					break;
			} catch (Exception e) {
				logger.error("��ȡ����:"+ip+":"+port+" ��Invoker�쳣",e);
			}
    	}
    	if(allInvokers.size()>0)
    	{
    		List<List<Invoker>> sortInvokders = userAuditHistoryManager.sortInvokders(allInvokers, user.getNick(), app);
    		result.put("invokerList", sortInvokders);
    		if(sortInvokders.get(0).size() > 0) {
    			result.put("hasRecentlyUsedInvokers", "true");
    		}
    		if(sortInvokders.get(1).size() > 0) {
    			result.put("hasHeavilyUsedInvokers", "true");
    		}
    		if(sortInvokders.get(2).size() > 0) {
    			result.put("hasOtherInvokers", "true");
    		}
    	}
    	else
    	{
    		result.put("errorMsg", "δ���Ӧ��"+app+"�µĻ����ķ����б�");
    	}
    	result.put("app", app);
    	return page;
    }
    @RequestMapping("querySingleInvoker_Batch2.htm")
    public String querySingleInvoker_Batch2(final HttpServletRequest request, ModelMap result) {
    	return _querySingleInvoker_Batch(request, result, SINGLE_INVOKER_OF_A_SINGLE_MACHINE_ALL2);
    }
    private String _querySingleInvoker_Batch(final HttpServletRequest request, ModelMap result,String page) {
    	String app=request.getParameter("app");
    	String beanName=request.getParameter("beanName");
    	String signature=request.getParameter("signature");
    	
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "INVOKER");
    	params.put("action", "single");
    	params.put("beanName", beanName);
    	params.put("signature", signature);
    	
    	String url="";
    	List<MachineDO> machines=null;
		try {
			machines = opsServic.getAllMachinesBelongToAnApp(app);
		} catch (DAOException e2) {
			logger.info("opsFree service failure",e2);
			result.put("errorMsg", "��ȡ�����б�ʧ��");
			return page;
		}
    	for(MachineDO machine:machines)
    	{
    		String ip=machine.getIp();
    		String port=machine.getPort()+"";
    		try {
    			url = urlGenerator.getUrl(ip, port, params);
    		} catch (Exception e1) {
    			continue;
    		}
    		try {
    			String json = HttpClientUtil.getResult(url);
				JSONObject jsonM=new JSONObject(json);
				//it's OK
				if(jsonM.opt("errorMsg")==null)
				{
					Invoker iv=Invoker.getInvoker(jsonM);
					result.put("invoker", iv);
					String paramDesc=iv.getParamDesc();
					if(paramDesc==null)
					{
						paramDesc="";
					}
					String[] paramTypes=iv.getParamTypeList();
					String[] realDescs=paramDesc.split(INVOKER_PARAMDESC_SEPERATOR);
					List<ParamInfoView> paramList=new ArrayList<ParamInfoView>();
					for(int i=0;i<paramTypes.length;i++)
					{
						String pDesc = null;
						if(i<realDescs.length)
						{
							pDesc=realDescs[i];
						}
						else
						{
							pDesc="���޲�������";
						}
						paramList.add(new ParamInfoView(paramTypes[i], pDesc));
					}
					result.put("paramList", paramList);
					/**
					 * ��ȡateye�汾���鿴�Ƿ����1.0.3
					 */
					boolean isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
					result.put("isSupportNull", isSupportNull);
					break;
				}
    		} catch (Exception e) {
    			logger.error("��ȡInvoker��Ϣʱ�쳣"+" ip:"+ip+" port:"+port+" bean:"+beanName+" signature:"+signature,e);
    		}
    	}
		if(StringUtil.isBlank(result.get("invoker").toString())){
			result.put("errorMsg", "��ȡ������ϸ��Ϣʧ��");
		}
		result.put("app", app);
    	return page;
    }
    @RequestMapping("invokeAMethod_Batch2.htm")
    public String invokeAMethod_Batch2(final HttpServletRequest request, @RequestParam(value = "nullParams", required = false) String[] nullParams,ModelMap result) throws DAOException{
    	return _invokeAMethod_Batch(request, nullParams, result, SINGLE_INVOKER_OF_A_SINGLE_MACHINE_ALL2);
    }
    private String _invokeAMethod_Batch(final HttpServletRequest request, @RequestParam(value = "nullParams", required = false) String[] nullParams,ModelMap result,String page) throws DAOException
    {
    	final UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	final String app=request.getParameter("app");
    	final String beanName=request.getParameter("beanName");
    	final String signature=request.getParameter("signature");
    	final  StringBuilder newValue=new StringBuilder();
    	String paramCountStr=request.getParameter("paramCount");
    	int paramCount = Integer.parseInt(paramCountStr);

		String approve=request.getParameter("approve");
		if(StringUtil.isNotEmpty(approve) && "true".equalsIgnoreCase(approve)){
			ChangeFreeRS rs = approveManager.check(CFType.METHOD,user.getEmpId()+"",app,beanName,signature);
			if(!rs.isPass() && StringUtil.isNotEmpty(rs.getApproveUrl())){
				return "redirect:"+rs.getApproveUrl();
			}
		}
    	
    	final Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "INVOKER");
    	params.put("action", "invoke");
    	params.put("beanName", beanName);
    	params.put("signature", signature);

   	//��ֵ�Ϳ��ַ������
  	 if(nullParams != null && nullParams.length>0){
  		 params.put("nullParams", paraseArrayToString(nullParams));
  	 }
    	for(int i=1;i<=paramCount;i++)
    	{
    		String param=request.getParameter("param"+i);
    		params.put("param"+i,param);
    		newValue.append("param"+i+"="+param+";");
    	}
    	
    	List<MachineDO> machines = opsServic.getAllMachinesBelongToAnApp(app);
    	final ConcurrentMap<String,Object> invokerInfo = new ConcurrentHashMap<String,Object>();
    	final Set<Map<String,String>> batchInvokeResults = Collections.synchronizedSet(new HashSet<Map<String,String>>());
    	List<Future<?>> callList = new ArrayList<Future<?>>();
    	
    	for(final MachineDO machine: machines)
    	{
    		Future<?> fu = exec.submit(new Runnable()
    		{
    			public void run()
    			{
    				Map<String,String> singleResult=new HashMap<String,String>();
    	    		singleResult.put("machineName", machine.getMachineName());
    	    		singleResult.put("ip", machine.getIp());
    	    		
    	    		String ip=machine.getIp();
    	    		String port=machine.getPort()+"";
    	    		String url="";
    	    		boolean isSuccess=false;
    				try {
    					url = urlGenerator.getUrl(ip, port, params);
    				} catch (Exception e1) {
    	    			singleResult.put("errorMsg", e1.getMessage());
    	    			batchInvokeResults.add(singleResult);
    	    			return;
    				}
    	    		try {
    	    			String json=HttpClientUtil.getResult(url);
    	    			JSONArray array=new JSONArray(json);
    	    			JSONObject callResult = array.getJSONObject(0);
    	    			if(array.length()==2&&callResult.opt("errorMsg")==null)
    	    			{
    	    				
    	    				isSuccess=true;
    	    				JSONObject invokerJson = array.getJSONObject(1);
    	    				Invoker iv=Invoker.getInvoker(invokerJson);
    	    				
    	    				String paramDesc=iv.getParamDesc();
    	    				if(paramDesc==null)
    	    				{
    	    					paramDesc="";
    	    				}
    	    				String[] paramTypes=iv.getParamTypeList();
    	    				String[] realDescs=paramDesc.split(INVOKER_PARAMDESC_SEPERATOR);
    	    				List<ParamInfoView> paramList=new ArrayList<ParamInfoView>();
    	    				for(int i=0;i<paramTypes.length;i++)
    	    				{
    	    					String pDesc = null;
    	    					if(i<realDescs.length)
    	    					{
    	    						pDesc=realDescs[i];
    	    					}
    	    					else
    	    					{
    	    						pDesc="���޲�������";
    	    					}
    	    					paramList.add(new ParamInfoView(paramTypes[i], pDesc));
    	    				}
            	    			/**
            	    			 * ��ȡateye�汾���鿴�Ƿ����1.0.3
            	    			 */
            	    			boolean isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
            	    			invokerInfo.put("isSupportNull", isSupportNull);
    	    			
    	    				invokerInfo.putIfAbsent("paramList", paramList);
    	    				invokerInfo.putIfAbsent("invoker", iv);
    	    				singleResult.put("returnValue", (String)callResult.opt("returnValue"));
    	    				singleResult.put("ateyeOut", (String)callResult.opt("ateyeOut"));
    	    				singleResult.put("exception", (String)callResult.opt("exception"));
    	    			}
    	    			else
    	    			{  
    	    				singleResult.put("errorMsg", (String)callResult.opt("errorMsg"));
    	    			}
    	    		} catch (Exception e) {
    	    			logger.error("���÷���ʱ�쳣ip:"+ip+" port:"+port+" params:"+params, e);
    	    			singleResult.put("errorMsg", "�����쳣"+e.getMessage());
    	    		}
					batchInvokeResults.add(singleResult);
					/**
					 * ���� �����û������Ϣ
					 */
					UserAuditDO userAuditDO = new UserAuditDO(user.getNick(), app, ip, UserAuditDO.INVOKER, beanName, signature, newValue.toString() + "&isSuccess=" + isSuccess);
					userAuditService.addUserAuditLog(userAuditDO);
    			}
    		});
    		callList.add(fu);
    	}
    	//�ȴ��߳�ִ����ϣ����ÿ��ǳ�ʱ����ʱ������HttpClient�ĳ�ʱ��������֤
    	try
    	{
    		for(Future<?> f:callList)
        	{
        		f.get();//���Է���ֵ
        	}
    	}
    	catch(Exception e){}//������û��Interrupt��Runnableִ�еĴ���Ჶ���쳣
            	result.put("isSupportNull",invokerInfo.get("isSupportNull"));
            	result.put("batchInvokeResults", batchInvokeResults);
            	result.put("paramList", invokerInfo.get("paramList"));
		result.put("invoker", invokerInfo.get("invoker"));
		result.put("app", app);

		if(!signature.startsWith("find") && !signature.startsWith("get") && !signature.startsWith("view") && !signature.startsWith("query")) {
			AppChangeLogVO changeLog = AppChangeMonitor.createMethodInvokeChangeLog(beanName, signature, newValue.toString(), result, user.getNick(), UUID.randomUUID().toString(), "ȫ��������", app);
			detectorManager.sendAteyeMethod(changeLog,true);
			super.appChangeLogService.addOneChangeLog(changeLog);
		}

    	return page;
    }
}
