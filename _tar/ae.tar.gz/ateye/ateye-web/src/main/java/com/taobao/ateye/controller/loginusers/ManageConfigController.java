package com.taobao.ateye.controller.loginusers;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.exception.DAOException;
import com.taobao.tracker.hbase.HbaseReadService;

@Controller
@RequestMapping("/manage/config")
public class ManageConfigController extends AbstractController{
    @Autowired
    HbaseReadService hbaseReadService;

    @RequestMapping("list.htm") 
    public String list(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	Map<String, String> configList = hbaseReadService.configList();
    	result.put("lst",configList);
		return "/manage/config/list";
    }
    @RequestMapping("delete.htm") 
    public String delete(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String k = request.getParameter("k");
    	if ( StringUtils.isBlank(k) ){
    		return null;
    	}
    	hbaseReadService.configDel(k);
		return "redirect:/manage/config/list.htm";
    	
    }
    @RequestMapping("set.htm") 
    public String set(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String k = request.getParameter("k");
    	String v = request.getParameter("v");
    	if ( StringUtils.isBlank(k) || StringUtils.isBlank(v) ){
    		return null;
    	}
    	hbaseReadService.configSet(k, v);
		return "redirect:/manage/config/list.htm";
    	
    } 
}