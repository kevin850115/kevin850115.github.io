package com.taobao.ateye.controller.scene;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.view.manager.CViewIndexManager;
@Controller
@RequestMapping("/scene")
public class SceneToolController extends AbstractController{
	private static final String TOOL = "screen/scene/tool";
	private static final String UPDATE_TOOL = "screen/scene/updateTool";

	@Autowired
	CViewIndexManager cViewIndexManager;
	@RequestMapping("tool.htm")
	public String tool(final HttpServletRequest request, final ModelMap result) throws Exception {
		String biz = "tool";
		long tic = System.currentTimeMillis();
		Map<String, Map<String,String>> cViewIndexConfigs = cViewIndexManager.getCViewIndexConfigs(biz);
		
		result.put("used",System.currentTimeMillis()-tic);
		result.put("cviewMap", cViewIndexConfigs);

		return TOOL;
	}
	@RequestMapping("updateTool.htm")
    public String updateCView(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException
    {
		String biz = "tool";
		String cviewDesc = cViewIndexManager.getCViewDesc(biz);
		String  newDesc = request.getParameter("desc");
		if ( StringUtils.isNotBlank(newDesc) ){
			cViewIndexManager.updateCViewDesc(biz,newDesc);
			return "redirect:/scene/tool.htm";
		}
		result.put("biz", biz);
		result.put("desc", cviewDesc);
		return UPDATE_TOOL;
    }
	
}
