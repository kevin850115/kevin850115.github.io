package com.taobao.ateye.job.permission;


/**
 * Move to web project by dongbi, this may not be a good design;
 * For that buc/acl related jobs are done in web project.
 * 2015-10-20 10:11
 */

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.taobao.ateye.controller.loginusers.AclSyncUtil;
import com.taobao.ateye.dataobject.PermissionApplyDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.job.BaseJob;
import com.taobao.ateye.job.Cron;
import com.taobao.ateye.permission.PermissionManager;
import com.taobao.ateye.service.PermissionApplyService;

@Cron(value = "0 0/1 * * * ?", desc = "�Զ�����")
public class AutoApprovePermissionJob extends BaseJob {
    Logger logger = Logger.getLogger(AutoApprovePermissionJob.class);

    @Autowired
    private PermissionManager permissionManager;

    @Autowired
    private PermissionApplyService permissionApplyService;

    @Autowired
    private AclSyncUtil aclSyncUtil;

    @Override
    protected void work() throws Exception {
        try {
            List<PermissionApplyDO> notApproveApplys = permissionApplyService.getNotApproveApplys();
            if (notApproveApplys == null)
                return;
            for (PermissionApplyDO pa : notApproveApplys) {
                permissionManager.approve(pa.getId());

                syncAclPermission(pa.getId());
            }
        } catch (DAOException e) {
            log.error("ApproveȨ�޷����쳣", e);
        }
    }


    private void syncAclPermission(int applyId) {
        try {
            //����acl��ɫ��url����Ȩ��
            aclSyncUtil.grantUserAclRolePermission(applyId);

        } catch (Exception e) {

            logger.error("Ȩ������ʧ��,aclͬ������ʱ������apply id��" + applyId, e);
        }

    }
}
