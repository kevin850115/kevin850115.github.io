package com.taobao.ateye.controller.cae;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.annotation.AteyeInvoker;
import com.taobao.ateye.controller.loginusers.AclSyncUtil;
import com.taobao.common.payway.alipay.model.request.AlipayBailQueryRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayBtnStatusQueryRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayCustomerSignBTCRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayCustomerSignQueryRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayCustomerUnsignBTCRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayQueryAccountOrderRequestDO;
import com.taobao.common.payway.alipay.model.request.AlipayUserQueryRequestDO;
import com.taobao.common.payway.alipay.model.response.AlipayBailQueryResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayBtnStatusQueryResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayCustomerSignBTCResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayCustomerSignQueryResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayCustomerUnsignBTCResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayQueryAccountOrderResponseDO;
import com.taobao.common.payway.alipay.model.response.AlipayUserQueryResponseDO;
import com.taobao.common.payway.alipay.service.AlipayBailQueryService;
import com.taobao.common.payway.alipay.service.AlipayBtnStatusQueryService;
import com.taobao.common.payway.alipay.service.AlipayCustomerSignBTCService;
import com.taobao.common.payway.alipay.service.AlipayCustomerSignQueryService;
import com.taobao.common.payway.alipay.service.AlipayCustomerUnsignBTCService;
import com.taobao.common.payway.alipay.service.AlipayQueryAccountOrderService;
import com.taobao.common.payway.alipay.service.AlipayUserQueryService;
import com.taobao.common.payway.alipay.tc.model.SingleTradeQueryRequestDO;
import com.taobao.common.payway.alipay.tc.model.SingleTradeQueryResponseDO;
import com.taobao.common.payway.alipay.tc.service.SingleTradeQueryService;
import com.taobao.common.payway.core.PaywayException;
import com.taobao.common.payway.enumtype.AlipayErrorCodeEnum;
import com.taobao.util.crypter.Base32;

/**
 * Created by IntelliJ IDEA.
 * User: wayaya
 * Date: 11-11-16
 * Time: ����11:47
 */
@Controller
@RequestMapping("/cae")
public class CAEController {

	private static Logger logger = Logger.getLogger("CAEController");
	
    @Autowired
    private AlipayCustomerSignQueryService alipayCustomerSignQueryService;

    @Autowired
    private AlipayCustomerSignBTCService alipayCustomerSignBTCService;

    @Autowired
    private AlipayCustomerUnsignBTCService alipayCustomerUnsignBTCService;

    @Autowired
    private AlipayUserQueryService alipayUserQueryService;

    @Autowired
    private SingleTradeQueryService singleTradeQueryService;

    @Autowired
    private AlipayBailQueryService alipayBailQueryService;
    
    @Autowired
    private AlipayQueryAccountOrderService alipayQueryAccountOrderService;
    
    @Autowired
    private AlipayBtnStatusQueryService alipayBtnStatusQueryService;
    
    private static String CRYPTER_FOR_ACCOUNT_NAME = "sign";
    
    @RequestMapping("customer_sign_query_view.htm")
    public String customerSignQueryView() {
        return "/screen/cae/customer_sign_query_view";
    }

    @RequestMapping("customer_sign_query_action.htm")
    public String customerSingQueryAction(final HttpServletRequest request, ModelMap result) {
    	String searchType = request.getParameter("search_type");
        String customerCode = request.getParameter("customer_code");
        String typeCode = request.getParameter("type_code");
        String outSignNo = request.getParameter("out_sign_no");
        String logonId = request.getParameter("logon_id");
        String accountNo = request.getParameter("account_no");

        AlipayCustomerSignQueryRequestDO requestDO = new AlipayCustomerSignQueryRequestDO();
        if(!"advance_search".equals(searchType)){
        	if(customerCode != null){
        		requestDO.setCustomerCode(customerCode);
        		try {
                    AlipayCustomerSignQueryResponseDO responseDO = alipayCustomerSignQueryService.service(requestDO);
                    result.put("responseDO", responseDO);
                    result.put("customer_code", customerCode);
                } catch (PaywayException e) {
                    result.put("error", "������");
                    e.printStackTrace();
                }
        	}
        }else{
        	/**
        	 * four cases:
        	 * 1.customerCode
        	 * 2.typeCode + outSingNo
        	 * 3.typeCode + logonId
        	 * 4.typeCode + accountNo
        	 */
        	if(customerCode != null || (typeCode != null && (outSignNo != null || logonId != null || accountNo != null))){
        		requestDO.setCustomerCode(customerCode);
                requestDO.setTypeCode(typeCode);
                requestDO.setOutSignNo(outSignNo);
                requestDO.setLogonId(logonId);
                requestDO.setAccountNo(accountNo);
                try {
                    AlipayCustomerSignQueryResponseDO responseDO = alipayCustomerSignQueryService.service(requestDO);
                    result.put("responseDO", responseDO);
                    result.put("customer_code", customerCode);
                    result.put("type_code", typeCode);
                    result.put("out_sign_no", outSignNo);
                    result.put("logon_id", logonId);
                    result.put("account_no", accountNo);
                } catch (PaywayException e) {
                    result.put("error", "������");
                    e.printStackTrace();
                }
        	}
        }
        result.put("search_type", searchType);

        return "/screen/cae/customer_sign_query_view";
    }

    @RequestMapping("customer_sign_form.htm")
    public String customerSignForm() {
        return "/screen/cae/customer_sign_form";
    }

    @RequestMapping("customer_sign_action.htm")
    public String customerSignAction(final HttpServletRequest request, ModelMap result) {
    	String typeCode = request.getParameter("type_code");
        String customerEmail = request.getParameter("customer_email");
        String transAccountOut = request.getParameter("trans_account_out");
        String customerAccountName = request.getParameter("customer_account_name");
        String outSignNo = request.getParameter("out_sign_no");
        String accountReadOnly = request.getParameter("is_account_read_only");
        
        //edited by xia lin
        String returnURL = "";
        //ָ��at eye ҳ��
        if(!AclSyncUtil.CUSTOMER_SIGN_RETURN_TO_HSCF) {
        	returnURL = "http://" + request.getServerName() + "/cae/customer_sign_return.htm";
        } else {
        	//ָ��hscf
        	returnURL = AclSyncUtil.CUSTOMER_SIGN_RETURN_BASE_HSCF + "/freelogin/cae/customer_sign_return.htm";
        }
        
        if (typeCode != null && (customerEmail != null || transAccountOut != null || customerAccountName != null)) {
            AlipayCustomerSignBTCRequestDO requestDO = new AlipayCustomerSignBTCRequestDO();
            requestDO.setTypeCode(typeCode);
            requestDO.setCustomerEmail(customerEmail);
            requestDO.setTransAccountOut(transAccountOut);
            requestDO.setCustomerAccountName(customerAccountName);
            requestDO.setOutSignNo(outSignNo);
            requestDO.setReturnUrl(returnURL);
            if(accountReadOnly != null && accountReadOnly.length() == 1){
            	char readOnly = accountReadOnly.toCharArray()[0];
            	switch(readOnly){
            	case '0':{
            		break;
            	}
            	case '1':{
            		requestDO.setAccountReadOnly(true);
                	break;
            	}
            	case '2':{
            		requestDO.setAccountReadOnly(false);
            		break;
            	}
            	}
            }
            
            try {
            	
//            	requestDO.setAccountReadOnly(true);
//            	requestDO.setCustomerEmail("tbtest1101@yahoo.cn");
//            	requestDO.setReturnUrl("http://www.taobao.com");
//            	requestDO.setTransAccountOut("20881010088621940156");
//            	requestDO.setTypeCode("TBJPCG100011000102");
            	
                AlipayCustomerSignBTCResponseDO responseDO = alipayCustomerSignBTCService.service(requestDO);
                String url = responseDO.getGeneratedURL();
                
                //�����ص�ַ�����һ�Լ��ܲ���
                if(AclSyncUtil.CUSTOMER_SIGN_RETURN_TO_HSCF && 
                		AclSyncUtil.ADD_ENCODED_PARAS_TO_CUSTOMER_SIGN_RETURN) {                	
                	url  = url.concat(addEncodedParasForReturnPage(transAccountOut));
                }
                
                result.put("generated_url", url);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            } catch (Exception e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }
        return "/screen/cae/customer_sign_popup";
    }
    
    /**
     * ���û�����ָ������base32���ܺ� ��ɲ�����ֵ��
     * @param source
     * @return
     */
    private String addEncodedParasForReturnPage(String customerAccountName)  {
    	
    	//��customer_sign_return.htm& ����Ĳ�������   	
    	StringBuilder suffix  = new StringBuilder("&suffix=");
		try {
			String encodedParas = Base32.encodeString(CRYPTER_FOR_ACCOUNT_NAME + 
					customerAccountName);
			suffix.append(encodedParas);
		} catch (Exception e) {
			logger.error("encrypt error:" + customerAccountName, e);		
		}  
    	
    	return suffix.toString();
    }
    
    @AteyeInvoker(paraDesc = "֧��������ǩԼ��ַ",description = "����֧��������ǩԼ���ܻ�����ַ����")
    public String testEncodeParasForReturnPage(String source) {
       return addEncodedParasForReturnPage(source);
    }
    
    @RequestMapping("customer_sign_return.htm")
    public String customerSignReturn(final HttpServletRequest request, ModelMap result) {
    	
    	AlipayCustomerSignBTCResponseDO alipayResponse = new AlipayCustomerSignBTCResponseDO();
    	alipayResponse.setTypeCode(request.getParameter("type_code"));
        alipayResponse.setEmail(request.getParameter("email"));
        alipayResponse.setCustomerCode(request.getParameter("customer_code"));
        alipayResponse.setOutSignNo(request.getParameter("out_sign_no"));
        alipayResponse.setSignAccountNo(request.getParameter("sign_account_no"));
        alipayResponse.setSignUserId(request.getParameter("sign_user_id"));
        alipayResponse.setSignUserName(request.getParameter("sign_user_name"));
        alipayResponse.setCertType(request.getParameter("cert_type"));
        alipayResponse.setCertNo(request.getParameter("cert_no"));
        alipayResponse.setUserAddress(request.getParameter("user_address"));
        alipayResponse.setSmsService(request.getParameter("sms_service"));
        alipayResponse.setUserCell(request.getParameter("user_cell"));
        alipayResponse.setUserPhone(request.getParameter("user_phone"));
        alipayResponse.setDebitDate(request.getParameter("debit_date"));
        alipayResponse.setAmount(request.getParameter("amount"));
        alipayResponse.setKatongBank(request.getParameter("katong_bank"));
        alipayResponse.setBankCardNo(request.getParameter("bank_card_no"));
        alipayResponse.setSuccess("T".equals(request.getParameter("is_success")));
        
        result.put("responseDO", alipayResponse);
    	
        return "/screen/cae/customer_sign_result";
    }

    @RequestMapping("customer_unsign_form.htm")
    public String customerUnsignForm() {
        return "/screen/cae/customer_unsign_form";
    }

    @RequestMapping("customer_unsign_action.htm")
    public String customerUnsignAction(final HttpServletRequest request, ModelMap result) {
    	String customerCode = request.getParameter("customer_code");
    	String typeCode = request.getParameter("type_code");
    	String bizType = request.getParameter("biz_type");
    	String transAccountOut = request.getParameter("trans_account_out");
        String userEmail = request.getParameter("user_email");
        
        if ((customerCode != null || typeCode != null || bizType != null) &&
        		(transAccountOut != null || userEmail != null)) {
            AlipayCustomerUnsignBTCRequestDO requestDO = new AlipayCustomerUnsignBTCRequestDO();
            requestDO.setCustomerCode(customerCode);
            requestDO.setTypeCode(typeCode);
            requestDO.setBizType(bizType);
            requestDO.setTransAccountOut(transAccountOut);
            requestDO.setUserEmail(userEmail);
            try {
                AlipayCustomerUnsignBTCResponseDO responseDO = alipayCustomerUnsignBTCService.service(requestDO);
                result.put("responseDO", responseDO);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }
        return "/screen/cae/customer_unsign_result";
    }

    @RequestMapping("user_query_view.htm")
    public String userQueryForm() {
        return "/screen/cae/user_query_view";
    }

    @RequestMapping("user_query_action.htm")
    public String userQueryAction(final HttpServletRequest request, ModelMap result) {
        String userId = request.getParameter("user_id");
        String loginEmail = request.getParameter("login_email");
        String merchantUserId = request.getParameter("merchant_user_id");
        AlipayUserQueryRequestDO requestDO = new AlipayUserQueryRequestDO();
        if (userId != null || loginEmail != null) {
        	requestDO.setUserId(userId);
            requestDO.setEmail(loginEmail);
            try {
                AlipayUserQueryResponseDO responseDO = alipayUserQueryService.service(requestDO);
                result.put("responseDO", responseDO);
                result.put("user_id", userId);
                result.put("login_email", loginEmail);
                result.put("merchant_user_id", merchantUserId);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }
        return "/screen/cae/user_query_view";
    }

    /**
     * ������ѯ-����
     * �ο��ĵ���http://sources.alipay.net/svn/exterfacedoc/trunk/WorkOn/�̻�/old/����ϵͳ��ѯ���������ӿ�(single_query_order).pdf
     *
     * @return url
     */
    @RequestMapping(value = "single_query_order_view.htm")
    public String singleQueryOrderView() {
        return "/screen/cae/single_query_order_view";
    }

    /**
     * ������ѯ-����
     * In fact, this function invoked the interface:single_trade_query
     *
     * @return url
     */

    @RequestMapping("single_query_order_action.htm")
    public String singleQueryAction(final HttpServletRequest request, ModelMap result) {
        String outOrderNo = request.getParameter("out_order_no");
        //alipay trade number
        String tradeNo = request.getParameter("trade_no");
        if (outOrderNo != null || tradeNo != null) {
        	SingleTradeQueryRequestDO  requestDO = new SingleTradeQueryRequestDO ();
            requestDO.setOutTradeNo(outOrderNo);
            requestDO.setTradeNo(tradeNo);
            try {
            	SingleTradeQueryResponseDO  responseDO = singleTradeQueryService.service(requestDO);
                result.put("responseDO", responseDO);
                result.put("out_order_no", outOrderNo);
                result.put("trade_no", tradeNo);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }

        return "/screen/cae/single_query_order_view";
    }

    /**
     * ��֤������ѯ
     *
     * @return url
     */
    @RequestMapping("bail_query_view.htm")
    public String bailQueryView() {
        return "/screen/cae/bail_query_view";
    }

    /**
     * ��֤������ѯ
     *
     * @return url and result
     */
    @RequestMapping("bail_query_action.htm")
    public String bailQueryAction(final HttpServletRequest request, ModelMap result) {
        String userAccount = request.getParameter("user_account");
        if (userAccount != null) {
            AlipayBailQueryRequestDO requestDO = new AlipayBailQueryRequestDO();
            requestDO.setUserAccount(userAccount);
            try {
                AlipayBailQueryResponseDO responseDO = alipayBailQueryService.service(requestDO);
                result.put("responseDO", responseDO);
                result.put("user_account", userAccount);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }

        }
        return "/screen/cae/bail_query_view";
    }
    
    /**
     * ���۶�����ѯ
     *
     * @return url
     */
    @RequestMapping("query_account_order_view.htm")
    public String queryAccountOrderView() {
        return "/screen/cae/query_account_order_view";
    }
    
    /**
     * ���۶�����ѯ
     *
     * @return url and result
     */
    @RequestMapping("query_account_order_action.htm")
    public String queryAccountOrder(final HttpServletRequest request, ModelMap result) {
        String outOrderNo = request.getParameter("out_order_no");
        //alipay order number
        String orderNo = request.getParameter("order_no");
        String exterfaceName = request.getParameter("exterface_name");
        //String opType = request.getParameter("op_type");
        if (outOrderNo != null || orderNo != null) {
        	AlipayQueryAccountOrderRequestDO  requestDO = new AlipayQueryAccountOrderRequestDO ();
            requestDO.setOutOrderNo(outOrderNo);
            requestDO.setOrderNo(orderNo);
            requestDO.setExterfaceName(exterfaceName);
            //requestDO.setOp_type(opType);
            try {
            	AlipayQueryAccountOrderResponseDO  responseDO = alipayQueryAccountOrderService.service(requestDO);
            	this.parseXmlToResult(responseDO.getResponseXml(),result);
                result.put("out_order_no", outOrderNo);
                result.put("order_no", orderNo);
                result.put("exterface_name", exterfaceName);
                //result.put("op_type", opType);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }

        return "/screen/cae/query_account_order_view";
    }
    
    public String tmp_queryAccountOrder(String filePath) {
    	Map<String,String> keyMap = new HashMap<String, String>();
    	keyMap.put("orderNo", "֧���������ţ�");
    	keyMap.put("outOrderNo", "�ⲿ�����ţ�");
    	keyMap.put("orderType", "�������ͣ�");
    	keyMap.put("amount", "��");
    	keyMap.put("subject", "��Ʒ���ƣ�");
    	keyMap.put("buyerUserId", "���ID��");
    	keyMap.put("buyerName", "���������");
    	keyMap.put("transAccountOut", "���֧�����˻���");
    	keyMap.put("sellerUserId", "����ID��");
    	keyMap.put("sellerName", "����������");
    	keyMap.put("transAccountIn", "����֧�����˻���");
    	keyMap.put("status", "״̬��");
    	keyMap.put("gmtCreate", "��������ʱ�䣺");
    	keyMap.put("gmtPay", "����֧��ʱ�䣺");
    	BufferedReader in = null;
    	PrintWriter out = null;
    	try{
    		in = new BufferedReader(new FileReader(filePath));
    		out = new PrintWriter(new FileOutputStream("/tmp/tmp_ace_query_result.txt"));
    		String line = null;
    		int i = 0;
    		while((line = in.readLine()) != null){
    			String out_no = line.trim();
    			if(out_no.length()>0){
    				AlipayQueryAccountOrderRequestDO  requestDO = new AlipayQueryAccountOrderRequestDO ();
                    requestDO.setOutOrderNo(out_no);
                    if(i>0){
                    	out.println();
                    }
                    out.println("�ⲿ�����ţ�"+out_no);
                    out.println("===================");
                    try {
                    	AlipayQueryAccountOrderResponseDO  responseDO = alipayQueryAccountOrderService.service(requestDO);
                    	String error = null;
                    	String xml = responseDO.getResponseXml().trim();
                    	if(xml.startsWith("<")){
                    		SAXBuilder sb = new SAXBuilder();
                            StringReader reader = null;
                            try {
                                reader = new StringReader(xml);
                                Document doc = sb.build(reader);
                                Element root = doc.getRootElement();
                                String isSuccess = (root.getChild("is_success") == null) ? null : root.getChild("is_success").getTextTrim();
                                if("F".equals(isSuccess)){
                                	error = root.getChild("error").getTextTrim();
                                }else{
                                	List<Element> lsEles = root.getChildren();
                                    for(Element e:lsEles){
                                    	if(keyMap.containsKey(e.getName())){
                                    		out.println(keyMap.get(e.getName())+e.getTextTrim());
                                    	}
                                    }
                                }
                            } catch (Exception ex) {
                                error = xml;
                            } finally {
                                sb = null;
                                if (reader != null) {
                                    reader.close();
                                }
                            }
                    	}else{
                    		error = xml;
                    	}
                    	
                    	if(error != null){
                    		AlipayErrorCodeEnum errorCodeEnum = null;
                    		error = error.toUpperCase();
                    		try {
                                //֧�������ݹ�����ö��ֵ����û���Ա��ж���
                                errorCodeEnum = AlipayErrorCodeEnum.valueOf(AlipayErrorCodeEnum.class, error);
                                out.println("payway���ؽ������"+errorCodeEnum.getName());
                            } catch (RuntimeException ex) {
                            	out.println("payway���ؽ������"+error);
                            }
                    		
                    	}
                    } catch (Exception e) {
                    	out.println("����alipay�쳣:"+e.getMessage());
                    }
    			}
    			i++;
    		}
    		return "success";
    	}catch(Exception e){
    		return "IO�쳣:"+e.getMessage();
    	}finally{
    		try {
    			if ( in != null ){
					in.close();
    			}
			} catch (IOException e) {}
			if ( out != null ){
				out.close();
			}
    	}
    }
    
    /**
     * ��������״̬��ѯ
     *
     * @return url
     */
    @RequestMapping("btn_status_query_view.htm")
    public String btnStatusQuery() {
        return "/screen/cae/btn_status_query_view";
    }
    
    /**
     * ��������״̬��ѯ
     *
     * @return url
     */
    @RequestMapping("btn_status_query_action.htm")
    public String btnStatusQueryView(final HttpServletRequest request, ModelMap result) {
    	
    	String email = request.getParameter("email");
        String batchNo = request.getParameter("batch_no");
        if (email != null && batchNo != null) {
        	AlipayBtnStatusQueryRequestDO  requestDO = new AlipayBtnStatusQueryRequestDO();
            requestDO.setEmail(email);
            requestDO.setBatchNo(batchNo);
            try {
            	AlipayBtnStatusQueryResponseDO  responseDO = alipayBtnStatusQueryService.service(requestDO);
            	result.put("responseDO", responseDO);
                result.put("email", email);
                result.put("batch_no", batchNo);
            } catch (PaywayException e) {
                result.put("error", "������");
                e.printStackTrace();
            }
        }
    	
        return "/screen/cae/btn_status_query_view";
    }
    
    
    
    

    //AlipayQueryAccountOrderResponseParserû�н������ɴ˺����������
    private void parseXmlToResult(String xml,ModelMap result){
    	//�ýӿڳɹ�ʱ����xml��ʽ��������ʱ����ֱ�ӷ��ش�����Ϣ��Ҳ������xml��ʽ���ش�����Ϣ
    	String error = null;
    	xml = xml.trim();
    	if(xml.startsWith("<")){
    		SAXBuilder sb = new SAXBuilder();
            StringReader reader = null;
            try {
                reader = new StringReader(xml);
                Document doc = sb.build(reader);
                Element root = doc.getRootElement();
                String isSuccess = (root.getChild("is_success") == null) ? null : root.getChild("is_success").getTextTrim();
                if("F".equals(isSuccess)){
                	error = root.getChild("error").getTextTrim();
                }else{
                	result.put("success", true);
                	List<Element> lsEles = root.getChildren();
                    for(Element e:lsEles){
                    	result.put(e.getName(), e.getTextTrim());
                    }
                }
                
            } catch (Exception ex) {
                error = xml;
            } finally {
                sb = null;
                if (reader != null) {
                    reader.close();
                }
            }
    	}else{
    		error = xml;
    	}
    	
    	if(error != null){
    		result.put("success", false);
    		AlipayErrorCodeEnum errorCodeEnum = null;
    		error = error.toUpperCase();
    		try {
                //֧�������ݹ�����ö��ֵ����û���Ա��ж���
                errorCodeEnum = AlipayErrorCodeEnum.valueOf(AlipayErrorCodeEnum.class, error);
                result.put("alipayerror", errorCodeEnum.getName());
            } catch (RuntimeException ex) {
            	result.put("alipayerror", error);
            }
    		
    	}
    }

}
