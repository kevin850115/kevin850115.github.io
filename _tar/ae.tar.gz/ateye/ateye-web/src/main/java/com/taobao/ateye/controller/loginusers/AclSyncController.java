package com.taobao.ateye.controller.loginusers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.buc.api.AccessControlService;
import com.alibaba.buc.api.ActionService;
import com.alibaba.buc.api.EnhancedUserQueryService;
import com.alibaba.buc.api.PermissionService;
import com.alibaba.buc.api.Principal;
import com.alibaba.buc.api.condition.PageCondition;
import com.alibaba.buc.api.condition.PermissionDetailCondition;
import com.alibaba.buc.api.exception.BucException;
import com.alibaba.buc.api.grant.GrantRolesToUserParam;
import com.alibaba.buc.api.model.Page;
import com.alibaba.buc.api.param.Action;
import com.alibaba.buc.api.permission.CreatePermissionParam;
import com.alibaba.buc.api.permission.GetPermissionParam;
import com.alibaba.buc.api.permission.UpdatePermissionParam;
import com.alibaba.buc.api.result.PermissionResultModel;
import com.alibaba.buc.api.role.CreateRoleParam;
import com.alibaba.buc.api.role.GetRoleParam;
import com.alibaba.platform.buc.sso.common.dto.SimpleSSOUser;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.taobao.ateye.annotation.AteyeInvoker;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.authority.SSOThreadLocal;
import com.taobao.ateye.dataobject.ResourceDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.permission.PermissionManager;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.ResourceService;
import com.taobao.ateye.service.RoleService;
import com.taobao.ateye.service.UserService;
import com.taobao.ateye.util.Ateye;

/**
 * Created by wangj.w on 2015/9/7.
 * <p/>
 * ͬ��
 * ********************ͬ��********************
 * <p/>
 * 1.����Ȩ��, Permission(path)
 * 2.���ӽ�ɫ
 * 3.����ɫ��Ȩ
 * <p/>
 * ********************ͬ��********************
 * <p/>
 * ********************��֤********************
 * 1.��ȡӦ������Ȩ��,
 * 2.����url-permission��Map,
 * 3.ƥ��url��permission,
 * 4.��֤
 * ********************��֤********************
 */
@Controller
@Component
public class AclSyncController {

    private static Logger logger = Logger.getLogger("AclLogger");
    private static Principal principal = null;
    //


    @Autowired
    private RoleService roleService;
    @Autowired
    private UserService userService;
    @Autowired
    private ResourceService ateyeResourceService;
    @Autowired
    private PermissionManager permissionManager;
    @Autowired
    private UserService ateyeUserService;

    @Autowired
    private AccessControlService aclAccessControlService; //provide the authentication
    @Autowired
    private PermissionService aclPermissionService;
    @Autowired
    private ActionService aclActionService;    //url
    @Autowired
    private com.alibaba.buc.api.RoleService aclRoleService;
    @Autowired
    private com.alibaba.buc.api.GrantService aclGrantService;

    @Autowired
    protected EnvironmentService environmentService;

    @Autowired
    private EnhancedUserQueryService enhancedUserQueryService;

    @Autowired
    private AclSyncUtil aclSyncUtil;

    //private final static String[] sysAdminResource = new String[]{"ȫ��"};

    private final static String USERID_DAILY = "111304818";     //ateye-acl
    private final static String USERID_PRODUCTION = "700374";   //ateye-acl
    private final static String DEFAULT_ROLE_NAME = "ROLE_ADMIN";

    private static Map<String, String>/* PermissionName cn->en */ permissionMap = new ConcurrentHashMap<String, String>();

    static {
//        permissionMap.put("��������", "invoke");
//        permissionMap.put("ʱ�����", "");
//        permissionMap.put("��־����", "");
//        permissionMap.put("��־��ѯ", "");
//        permissionMap.put("��������", "");
//        permissionMap.put("֧����", "");
//        permissionMap.put("��Ϣ����", "");
//        permissionMap.put("ȫ��", "");
//        permissionMap.put("��ʷ����", "");
//        permissionMap.put("����", "");
//        permissionMap.put(" ��־·������", "");
//        permissionMap.put("��ݹ���", "");
//        permissionMap.put("���ݱ���", "");
//        permissionMap.put("Ȩ������", "");
//        permissionMap.put("Ԫ���ݶ���", "");
//        permissionMap.put("�־û�����", "");
//        permissionMap.put("����", "");
//        permissionMap.put("ģ��", "");
//        permissionMap.put(" ģ������", "");
//        permissionMap.put("�澯����", "");
//        permissionMap.put("Ӧ�ñ���б�","");


    }


    @RequestMapping("/aclSync/permissionSync.htm")
    public String permissionApply(HttpServletRequest request, final ModelMap result) {
        try {
            String nick = (String) request.getAttribute("ateye_nick");
            if (StringUtils.isBlank(nick)) {
                return "redirect:/noPermission.htm";
            }

            UserDO user = (UserDO) MyThreadLocal.get();

            SimpleSSOUser ssoUser = SSOThreadLocal.get();

            // ��ʼ��ҳ������
            List<RoleDO> list = roleService.getAllRoleList();
            result.put("nick", nick);
            result.put("allRoles", list);

            List<ResourceDO> resourceList = ateyeResourceService.getAllResourceList();

            setPermissionNameMap(resourceList);

            List<RoleDO> roleList = roleService.getAllRoleList();

            result.put("allResource", resourceList);


            //syncPermission(resourceList, ssoUser.getId().toString());
            syncAclPermission(resourceList, roleList, ssoUser.getId().toString());

            List<PermissionResultModel> aclPermissions = getAllAclPermission();
            result.put("aclPermissions", aclPermissions);

        } catch (Exception e) {
            result.put("error", "ϵͳ�쳣������ϵ����Ա");
            logger.error("ͬ��Ȩ�������쳣 ", e);
        }
        return "screen/aclSync/permissionList";
    }

    @RequestMapping("/aclSync/permissionList.htm")
    public String permissionList(HttpServletRequest request, final ModelMap result) {
        //query all acl permission of ateye

        List<PermissionResultModel> aclPermissions = getAllAclPermission();

        result.put("aclPermissions", aclPermissions);


        return "screen/aclSync/permissionList";
    }

    private List<PermissionResultModel> getAllAclPermission() {
        PermissionDetailCondition permissionDetailCondition = new PermissionDetailCondition();
        PageCondition<PermissionDetailCondition> condition = new PageCondition<PermissionDetailCondition>();
        // ���ø�������Ҫ�Ĳ���
        permissionDetailCondition.setAppName("ateye");
        condition.setPage(1);
        condition.setSizePerPage(100);

        condition.setParam(permissionDetailCondition);


        Page<PermissionResultModel> allPermissionsModel = null;
        try {
            allPermissionsModel = aclPermissionService.pagePermission(condition);
        } catch (BucException e) {
            logger.error("Error occurs when query acl permission", e);
        }

        return allPermissionsModel.getItems();
    }

    private void setPermissionNameMap(List<ResourceDO> resourceList) {

        for (ResourceDO resourceDO : resourceList) {
            String resourceEnName = resourceDO.getPath().replace("/", "").replace("*", "");

            permissionMap.put(resourceDO.getName(), resourceEnName.isEmpty() ? "all" : resourceEnName);
        }
    }


    private void syncAclPermission(List<ResourceDO> resourceList, List<RoleDO> roleList, String userId) {
        //1.Sync permission
        syncPermission(resourceList, userId);

        //2.Sync role
        syncRoles(roleList, userId);

        //3.Grant role to user
        grantRoleToUser();
    }


    /**
     * Sync permission according to the resource
     *
     * @param resourceList
     */
    private void syncPermission(List<ResourceDO> resourceList, String userId) {

        for (ResourceDO resourceDO : resourceList) {


            try {
                GetPermissionParam getPermission = new GetPermissionParam();
                getPermission.setPermissionName(getAclPermissionName(resourceDO.getName()));
                if (aclPermissionService.getPermissionByName(getPermission) != null) {

                    UpdatePermissionParam updatePermissionParam = aclSyncUtil.createUpdatePermisionParam(resourceDO, userId);
                    aclPermissionService.updatePermission(updatePermissionParam);

                    logger.info("update permission:" + updatePermissionParam.getName());
                } else {
                    CreatePermissionParam createPermissionParam = aclSyncUtil.createPermisionParam(resourceDO, userId);
                    aclPermissionService.createPermission(createPermissionParam);
                    logger.info("Create permission:" + createPermissionParam.getName());
                }
            } catch (BucException e) {
                logger.error("Error occurs when query or create permission with name:" + resourceDO.getName(), e);
            }
        }

    }



    private void grantRoleToUser() {


        List<RoleDO> roles = roleService.getAllRoleList();

        List<UserDO> allUsers = new ArrayList<UserDO>();

        for (RoleDO role : roles) {
            List<UserDO> users = ateyeUserService.getRoleUserList(role.getId());
            for (final UserDO user : users) {
                Object o = CollectionUtils.find(allUsers, new Predicate() {
                    @Override
                    public boolean evaluate(Object object) {
                        return ((UserDO) object).getId().longValue() == user.getId().longValue();
                    }
                });
                if (o != null)
                    continue;
                allUsers.add(user);
            }
        }

        for (UserDO user : allUsers) {
            try {

                aclGrantService.grantRolesToUser(createGrantRolesToUserParam(user));
            } catch (BucException e) {
                logger.error("Error occurs when grant role to user:" + user.getNick(), e);
            }

        }


        //Grant appadmin role to default user;
        if (environmentService.getEnvironmentType().ordinal() == 0) {
            try {

                aclGrantService.grantRolesToUser(createDefaultGrantRolesToUserParam());
            } catch (BucException e) {
                logger.error("Error occurs when grant role to default user:ateye-acl", e);
            }
        }


    }


    @AteyeInvoker(description="ͬ��acl��ɫ",paraDesc="ucId&&roleName")
    public void grantUserRole(Integer ucId, String roleName)
    {

        try {

            aclGrantService.grantRolesToUser(this.createGrantRolesToUserParam(ucId, roleName));

            

        } catch (Throwable e) {
            Ateye.out.println(e.getStackTrace());
        }
    }

    private void syncRoles(List<RoleDO> roleList, String userId) {

        for (RoleDO role : roleList) {
            CreateRoleParam roleParam = aclSyncUtil.createRoleParam(role, userId);
            try {
                if (aclRoleService.getRole(new GetRoleParam(role.getName())) == null) {
                    aclRoleService.createRole(roleParam);
                } else {
                    aclRoleService.updateRole(aclSyncUtil.createUpdateRoleParam(role, userId));
                }

                aclSyncUtil.grantAclPermissionToRole(role);


            } catch (BucException e) {

                logger.error("Error[BUC Exception] occurs when create or update role with name:" + role.getName(), e);
            } catch (Throwable t) {

                logger.error("Error occurs when create or update role with name:" + role.getName(), t);
            }
        }

    }




    private GrantRolesToUserParam createGrantRolesToUserParam(Integer userId, String roleName) {
        GrantRolesToUserParam rolePermission = new GrantRolesToUserParam();

        //rolePermission.setPrincipalUserId();
        rolePermission.setAppName("ateye");

        List<String> roles = new ArrayList<String>();
        roles.add(roleName);
        rolePermission.setRoleNames(roles);


        rolePermission.setUserId(userId); //?should be sso userId

        rolePermission.setPrincipalUserId(Integer.parseInt(aclSyncUtil.getAteyeActUserId()));
        rolePermission.setAction(Action.Grant);

        return rolePermission;
    }

    private GrantRolesToUserParam createGrantRolesToUserParam(UserDO user) {
        GrantRolesToUserParam rolePermission = new GrantRolesToUserParam();

        //rolePermission.setPrincipalUserId();
        rolePermission.setAppName("ateye");

        List<RoleDO> userRoleList = roleService.getUserRoleList(user.getId());
        rolePermission.setRoleNames(Lists.transform(userRoleList, new Function<RoleDO, String>() {

            @Nullable
            @Override
            public String apply(@Nullable RoleDO input) {
                return ((RoleDO) input).getName();
            }
        }));


        try {
            rolePermission.setUserId(enhancedUserQueryService.getUserByNickNameCn(user.getNick()).getId()); //?should be sso userId
        } catch (Throwable e) {
            logger.error("Error occurs when grant acl role to user:" + user.getNick(), e);
        }
        rolePermission.setPrincipalUserId(Integer.parseInt(aclSyncUtil.getAteyeActUserId()));
        rolePermission.setAction(Action.Grant);

        return rolePermission;
    }


    private GrantRolesToUserParam createDefaultGrantRolesToUserParam() {
        GrantRolesToUserParam rolePermission = new GrantRolesToUserParam();

        rolePermission.setAppName("ateye");
        rolePermission.setRoleNames(Arrays.asList(new String[]{DEFAULT_ROLE_NAME}));
        rolePermission.setUserId(Integer.parseInt(USERID_DAILY));
        rolePermission.setPrincipalUserId(Integer.parseInt(aclSyncUtil.getAteyeActUserId()));
        rolePermission.setAction(Action.Grant);
        return rolePermission;
    }



    private static Principal getPrincipal(UserDO user) {
        if (principal == null) {
            principal = new Principal();
            principal.setUserId(user.getId().toString());   //?Which params
        }

        return principal;
    }




    private String getAclPermissionName(String resourceName) {
        return "acl_ateye_" + permissionMap.get(resourceName);
    }









}
