package com.taobao.ateye.controller.alarm;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ateye.alarm.config.AbstractAlarmConfig;
import com.taobao.ateye.alarm.detector.AbstractAlarmRuleDetector;
import com.taobao.ateye.alarm.n.data.AlarmContext;
import com.taobao.ateye.alarm.n.enu.AppScopeEnum;
import com.taobao.ateye.alarm.n.enu.CompareTypeEnu;
import com.taobao.ateye.alarm.n.enu.RuleTypeEnum;
import com.taobao.ateye.alarm.n.enu.RuleTypeMergeEnum;
import com.taobao.ateye.alarm.n.enu.SourceEnu;
import com.taobao.ateye.alarm.n.enu.StatusEnu;
import com.taobao.ateye.alarm.n.enu.TimeEnu;
import com.taobao.ateye.controller.alarm.data.AlarmAppScopeRelation;
import com.taobao.ateye.controller.alarm.data.AlarmSubRelation;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.dataobject.AteyeAlarmItemDO;
import com.taobao.ateye.dataobject.AteyeAlarmItemRuleSingleDO;
import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubRelationDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.tracker.hbase.AlarmRuleDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.util.CalendarUtil;

/**
 * Created by sunqiang on 2018/12/17.
 */
@Controller
@RequestMapping("/alarm")
public class AlarmSubRelController extends AbstractAlarmController {
    private static final String ALARM_SUB_REL_LIST = "screen/alarm/subRelConf";
    private static final String ALARM_APP_SCOPE_CONFIG= "screen/alarm/appScopeConf";

    @Autowired
    private HbaseReadService hbaseReadService;

    @RequestMapping("subRelConf.htm")
    public String subRelConf(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
        Integer biz = getBiz(request);
        String appName = request.getParameter("appName");
        String alarmGroup = request.getParameter("alarmGroup");
        String ruleMergeType = request.getParameter("ruleMergeType");
        result.put("biz",biz);
        result.put("appName",appName);
        result.put("alarmGroup",alarmGroup);
        result.put("ruleMergeType",ruleMergeType);
        result.put("bizMap", getBizMap());
        Long alarmGroupIp = null;
        if(StringUtils.isNotEmpty(alarmGroup)){

            AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.getByUk(alarmGroup,environmentService.getEnvironmentType().getEnv(),0);
            if(subscriberDO!=null){
                alarmGroupIp = subscriberDO.getId();
            }
            if(biz == null){
                biz = subscriberDO.getBiz();
            }
        }

        result.put("ruleMergeMap", RuleTypeMergeEnum.getMap());
        //1���������Ĺ�ϵ
        Set<Long> confIds = getConfIdByBiz(biz);
        List<AlarmSubRelation> relations = buildRelation(confIds);
        //2������
        if(StringUtils.isNotEmpty(ruleMergeType)){
            filterRelation(relations,appName,RuleTypeMergeEnum.getRuleTypesByName(ruleMergeType),alarmGroupIp);
        }else{
            filterRelation(relations,appName,RuleTypeEnum.getRuleTypeSet(),alarmGroupIp);
        }

        //3.���챨������
        Map<Long,Integer> confId2Count = buildRecord(confIds);
        setRecordSize(relations,confId2Count);
        //�������Ĺ�ϵ
        result.put("relations", relations);
        //��Ⱥ����
        List<AteyeAlarmSubscriberDO> alarmGroups = Lists.newArrayList();
        if(biz!=null){
            alarmGroups.addAll(subscriberDAO.select(biz,null,null));
        }

        result.put("alarmGrps", alarmGroups);

        String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),0));
        result.put("current",formatToDay);
        Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
        result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
        result.put("returnUrl",super.getWholeUrl(request));
        return ALARM_SUB_REL_LIST;
    }
    @RequestMapping("appScopeConf.htm")
    public String appScopeConf(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
        String subId = request.getParameter("subId");
        if(StringUtils.isNotEmpty(subId) && NumberUtils.isNumber(subId)){
            //1.�������Ĺ�ϵ
            AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.selectById(Long.parseLong(subId));
            //2.�������Ĺ�ϵ
            List<AlarmAppScopeRelation> relations = buildAppScopeConf(Long.parseLong(subId),null);
            result.put("relations", relations);
            if(subscriberDO==null){
                result.put("subName", "");
            }else{
                result.put("subName", subscriberDO.getName());
            }
            //3.��ȡҵ����
            if (subscriberDO != null ){
            	Integer biz = subscriberDO.getBiz();
            	BizLineDO bizLineDO = bizLineDAO.getAllBizLineMap().get(Long.valueOf(biz));
            	if ( bizLineDO != null ){
            		result.put("bizLineDO", bizLineDO);
            	}
            }

        }else{
            List<AlarmAppScopeRelation> relations = buildAppScopeConf(null,null);
            result.put("relations", relations);
            result.put("subName", "");
        }
        result.put("compareMap",CompareTypeEnu.getMap());
        result.put("appScope", 1);
        result.put("bizMap", getBizMap());
        result.put("ruleMergeGroupMap", RuleTypeMergeEnum.getGroupMap());
        result.put("ruleMergeMap", RuleTypeMergeEnum.getMap());
        result.put("name2GroupMap", RuleTypeMergeEnum.getName2GroupMap());
        result.put("appScopeMap",AppScopeEnum.getMap());
        result.put("detailDescMap", JSON.toJSONString(AppScopeEnum.getDetailDescMap()));
        String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),0));
        result.put("current",formatToDay);
        Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
        result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
        result.put("returnUrl",super.getWholeUrl(request));
        return ALARM_APP_SCOPE_CONFIG;
    }

    @RequestMapping("addAppScope.htm")
    public String addAppScope(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String appScopeType = request.getParameter("appScopeType");
        String appScopeValue = request.getParameter("appScopeValue");
        String ruleType = request.getParameter("ruleType");
        String nicks = request.getParameter("nicks");
        String addBiz = request.getParameter("addBiz");
        if(appScopeType.equals(AppScopeEnum.BIZ.getValue()+"") || appScopeType.equals(AppScopeEnum.CORE_APP.getValue()+"")){
            appScopeValue = addBiz;
        }
        List<String> recvs = AbstractAlarmConfig.formatRecvs(nicks);
        Long confId = insertAppScopeDefaultConf(request);
        insertAppScopeSingleRule(confId,ruleType,request);
        addAppScope(recvs,confId,ruleType,Integer.parseInt(appScopeType),appScopeValue);
        return getRedirectUrl(request, response);
    }

    private void insertAppScopeSingleRule(Long confId, String ruleType,HttpServletRequest request) throws DAOException {
        AteyeAlarmItemRuleSingleDO itemRule = new AteyeAlarmItemRuleSingleDO();
        itemRule.setAlarmConfId(confId);
        itemRule.setEnv(environmentService.getEnvironmentType().getEnv());
        if(RuleTypeMergeEnum.HSF_EXCEPTION.getName().equals(ruleType) || RuleTypeMergeEnum.HSF_TIMEOUT.getName().equals(ruleType) ||
                RuleTypeMergeEnum.BETA_HSF_EXCEPTION.getName().equals(ruleType) || RuleTypeMergeEnum.BETA_HSF_TIMEOUT.getName().equals(ruleType)){
            String continueMin = request.getParameter("continueMinHE");
            String percentThreshold = request.getParameter("thresholdHE");
            if(RuleTypeMergeEnum.HSF_TIMEOUT.getName().equals(ruleType) || RuleTypeMergeEnum.BETA_HSF_TIMEOUT.getName().equals(ruleType)){
                continueMin = request.getParameter("continueMinHT");
                percentThreshold = request.getParameter("thresholdHT");
            }
            itemRule.setTimeType(TimeEnu.MIN.getValue());
            itemRule.setContinuousTime(new BigDecimal(continueMin));
            itemRule.setCompareType(CompareTypeEnu.BIGGER.getValue());
            itemRule.setThreshold(new BigDecimal(percentThreshold).divide(new BigDecimal(100)).setScale(2));
        }else if(RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE.getName().equals(ruleType) ||
                RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_BASE.getName().equals(ruleType) ||
                RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_DAO.getName().equals(ruleType) ||
                RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_HSF.getName().equals(ruleType) ||
                RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_SENTINEL.getName().equals(ruleType)||
                RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE.getName().equals(ruleType) ||
                RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_BASE.getName().equals(ruleType) ||
                RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_DAO.getName().equals(ruleType) ||
                RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_HSF.getName().equals(ruleType) ||
                RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_SENTINEL.getName().equals(ruleType) ||
                RuleTypeMergeEnum.EXCEPTION_TYPE_INCR_HIGH_CRITICAL.getName().equals(ruleType)
                ){
            String nThreshold = request.getParameter("thresholdGE");
            itemRule.setCompareType(CompareTypeEnu.BIGGER.getValue());
            itemRule.setTimeType(TimeEnu.HOUR.getValue());
            itemRule.setRelativeDay(3);
            itemRule.setRelativeDayTimes(new BigDecimal(nThreshold));
        }
        alarmItemRuleSingleDAO.insert(itemRule);

    }

    private void addAppScope(List<String> recvs, Long confId, String ruleType,Integer appScopeType,String appScopeValue) throws DAOException {
        List<String> addRecvs = Lists.newArrayList(recvs);
        alarmOprManager.addRecvs(addRecvs,confId,ruleType,appScopeType,appScopeValue);
    }



    private Long insertAppScopeDefaultConf(final HttpServletRequest request) throws DAOException {
        AteyeAlarmConfDO confDO = new AteyeAlarmConfDO();
        confDO.setEnv(environmentService.getEnvironmentType().getEnv());
        confDO.setAlarmIntervalInMin(5);
        String start = request.getParameter("hStart");
        String end = request.getParameter("hEnd");
        int startI = 0;
        int endI = 24;
        if ( StringUtils.isNotBlank(start) ){
        	startI = Integer.valueOf(start);
        }
        if ( StringUtils.isNotBlank(end) ){
        	endI = Integer.valueOf(end);
        }
        confDO.setHourStart(startI);
        confDO.setHourEnd(endI);
        confDO.setUuid(UUID.randomUUID().toString());
        confDO.setReopenDate(CalendarUtil.zerolizedTime(new Date()));
        confDO.setSource(SourceEnu.NEW.getValue());
        confDO.setAppScope(1);
        return confDAO.insert(confDO);
    }

    @RequestMapping("updateNotifier.htm")
    public String updateNotifier(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String confId = request.getParameter("confId");
        String nicks = request.getParameter("nicks");
        String ruleType = request.getParameter("ruleType");
        String appScope = request.getParameter("appScope");

        List<String> recvs = AbstractAlarmConfig.formatRecvs(nicks);
        alarmOprManager.updateRecvs(recvs,Long.parseLong(confId),ruleType, BooleanUtils.toBooleanDefaultIfNull(Boolean.valueOf(appScope),false));

        //�����ϵ�
        String app = request.getParameter("appName");
        String uuid = request.getParameter("uuid");
        AlarmRuleDO alarmRule = hbaseReadService.getAlarmRule(app, uuid);
        if ( alarmRule == null ){
            return "";
        }
        AbstractAlarmRuleDetector detector = AbstractAlarmRuleDetector.getDetector(alarmRule);
        AbstractAlarmConfig config = detector.getAlarmConfig().fromJSON(alarmRule.getRuleDesc());
        config.setNotifyNicksByString(nicks);
        alarmRule.setRuleDesc(config.toJSON());
        hbaseReadService.addOrUpdateAlarmRule(alarmRule);

        return getRedirectUrl(request, response);
    }

    @RequestMapping("delAlarmRule.htm")
    public String delAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String confId = request.getParameter("confId");
        confDAO.updateStatus(Long.parseLong(confId),StatusEnu.DELETE.getValue());

        //ɾ���ϵ��߼�
        AteyeAlarmConfDO confDO = confDAO.selectById(Long.parseLong(confId));
        List<AteyeAlarmItemRuleSingleDO> singleDOs =alarmItemRuleSingleDAO.selectByConfId(confDO.getId());
        if(CollectionUtils.isNotEmpty(singleDOs)){
            for (AteyeAlarmItemRuleSingleDO singleDO : singleDOs) {
                AteyeAlarmItemDO itemDO = itemDAO.selectById(singleDO.getAlarmItemId());
                if(itemDO != null){
                    hbaseReadService.deleteAlarmRule(itemDO.getApp(), confDO.getUuid());
                }
            }
        }
        return getRedirectUrl(request, response);
    }
    @RequestMapping("pauseAlarmRule.htm")
    public String pauseAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String confId = request.getParameter("confId");
        confDAO.updateStatus(Long.parseLong(confId), StatusEnu.PAUSE.getValue());
        return getRedirectUrl(request, response);
    }
    @RequestMapping("resumeAlarmRule.htm")
    public String resumeAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String app = request.getParameter("appName");
        String confId = request.getParameter("confId");
        confDAO.updateStatus(Long.parseLong(confId), StatusEnu.VALID.getValue());

        return getRedirectUrl(request, response);
    }

    @RequestMapping("pauseNHourAlarmRule.htm")
    public String pauseNHourAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException, DAOException {
        String app = request.getParameter("appName");
        String confId = request.getParameter("confId");
        String hourStr = request.getParameter("hour");
        Double hour = Double.valueOf(hourStr);

        confDAO.updateReopenDate(confId,DateUtils.addMinutes(new Date(), (int)(hour*60)));//�����´δ�ʱ��
        return getRedirectUrl(request, response);
    }

    private void setRecordSize(List<AlarmSubRelation> relations, Map<Long, Integer> confId2Count) {
        for (AlarmSubRelation relation : relations) {
            Integer count = confId2Count.get(relation.getConfId());
            relation.setAlarmCount(count==null?0:count);
        }
    }

    private Map<Long,Integer> buildRecord(Set<Long> confIds) throws DAOException {
        Map<Long,Integer> confId2Count = Maps.newHashMap();

        if(CollectionUtils.isNotEmpty(confIds)){
            List<AteyeAlarmRecordDO> records = recordDAO.getTodayByConfIds(CalendarUtil.zerolizedTime(new Date()),Lists.<Long>newArrayList(confIds),environmentService.getEnvironmentType().getEnv());
            if(CollectionUtils.isNotEmpty(records)){
                for (AteyeAlarmRecordDO record : records) {
                    if(!confId2Count.containsKey(record.getAlarmConfId())){
                        confId2Count.put(record.getAlarmConfId(),1);
                    }else{
                        confId2Count.put(record.getAlarmConfId(),confId2Count.get(record.getAlarmConfId())+1);
                    }
                }
            }
        }
        return confId2Count;
    }
    private List<AlarmSubRelation> buildRelation(Set<Long> confIds) throws DAOException {
        List<AlarmSubRelation> relations = Lists.newArrayList();
        if(CollectionUtils.isEmpty(confIds)){
            return relations;
        }
        List<AlarmContext> alarmContexts = alarmManager.fetchAlarmRulesByConfIds(confIds);

        Map<Long,Set<Long>> confId2SubIdsMap = alarmDetectorManager.getRealConfId2SubIdsMap();
        if(CollectionUtils.isNotEmpty(alarmContexts)){
            for (AlarmContext alarmContext : alarmContexts) {
                AteyeAlarmItemDO itemDO = alarmContext.getRuleContexts().get(0).getItemDO();
                if(itemDO == null){
                    continue;
                }
                AteyeAlarmConfDO conf = alarmContext.getConfDO();
                AlarmSubRelation relation = new AlarmSubRelation();
                relation.setRuleType(itemDO.getRuleType());
                relation.setRuleTypeDetail(itemDO.getRuleTypeDetail());
                relation.setApp(alarmContext.getSimpleApp());
                relation.setConfId(conf.getId());
                relation.setGmtCreate(conf.getGmtCreate());
                relation.setGmtModified(conf.getGmtModified());
                relation.setName(fomatName(alarmContext));
                relation.setReopenDate(conf.getReopenDate());
                relation.setIsAggr(conf.getIsAggr());
                relation.setStatus(conf.getStatus());
                relation.setApp2(itemDO.getApp2());
                relation.setType(itemDO.getType());
                relation.setType2(itemDO.getType2());
                relation.setK1(itemDO.getK1());
                relation.setK2(itemDO.getK2());
                relation.setK3(itemDO.getK3());
                relation.setK4(itemDO.getK4());
                relation.setK5(itemDO.getK5());
                relation.setK6(itemDO.getK6());
                relation.setUuid(conf.getUuid());
                relation.getSubIds().addAll(confId2SubIdsMap.get(conf.getId()));
                relation.setSubStr(fetchSubName(confId2SubIdsMap,conf.getId()));
                relation.setAppScopeSubStr(fetchAppScopeSubStr(conf.getId(),alarmContext.getRuleContexts().get(0).getItemDO().getRuleType()));
                relations.add(relation);
            }
        }

        return relations;
    }


}
