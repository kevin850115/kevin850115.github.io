package com.taobao.ateye.controller.scene;

import static com.taobao.ateye.scene.util.DynamicConfigParserUtils.UPDATE_ONE_ITEM;

import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.fault.location.AbstractGraphFaultManager;
import com.taobao.ateye.fault.location.GraphMonitorItemDO;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.alarm.log.AlarmLogGraphManager;
import com.taobao.ateye.alarm.log.AlarmLogGraphParam;
import com.taobao.ateye.app.AppModelManager;
import com.taobao.ateye.app.model.AppModelDO;
import com.taobao.ateye.app.model.AppModelListDO;
import com.taobao.ateye.applog.AppLog;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.base.EnvIdType;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.AppChangeMonitor;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.controller.beanfield.BeanFieldController;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.db.model.DbModelListDO;
import com.taobao.ateye.db.model.TairModelListDO;
import com.taobao.ateye.detect.DetectResultDO;
import com.taobao.ateye.detect.SystemDetectManager;
import com.taobao.ateye.diamond.impl.GroupAppWhiteList;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.graph.base.GraphParamDO;
import com.taobao.ateye.hsf.manager.HsfManager;
import com.taobao.ateye.kv.KvGraphManager;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.realtime.RealTimeRecordModelListDO;
import com.taobao.ateye.relation.tree.node.NodeExtUtils;
import com.taobao.ateye.scene.manager.RealTimeTrackerManager;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.ateye.scene.manager.hsf.HsfMetaDataManager;
import com.taobao.ateye.scene.util.DynamicConfigParserUtils;
import com.taobao.ateye.ssql.SSqlModelListDO;
import com.taobao.ateye.system.SystemManager;
import com.taobao.ateye.system.SystemMonitorDO;
import com.taobao.ateye.util.ExtUrlUtil;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.except.ExceptionTypeConstant;
import com.taobao.tracker.generalerror.domain.TimePeriodEnum;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/scene")
public class SceneAppController extends AbstractController{
	private static final String APP_LIST = "screen/scene/appList";
	private static final String APP_ARCH_LIST = "screen/scene/appArchList";
	private static final String CHANGE_LIST = "screen/scene/changeList";
	private static final String SSQL_LIST = "screen/scene/ssqlList";
	private static final String RTR_LIST = "screen/scene/rtrList";
	private static final String BIZ_LIST = "screen/scene/bizList";
	private static final String APP = "screen/scene/app";
	private static final String DETECT = "screen/scene/detect";
	private static final String APP_SERVER = "screen/scene/appServer";
	
	@Autowired
	private AppModelManager appModelManager;

	@Autowired
	private SystemDetectManager systemDetectManager;
	@Autowired
	private RealTimeTrackerManager realTimeTrackerManager;
	@Autowired
	private KvGraphManager kvGraphManager;
	@Autowired
	private SystemManager systemManager;
	@Autowired
	protected MonitorLogQueryService logQueryService;
	@Autowired
	private AppDAO appDAO;
	@Autowired
	protected GroupAppWhiteList groupAppWhiteList;
	@Autowired
	private HsfMetaDataManager hsfMetaDataManager;

	@Autowired
	private HsfManager hsfManager;

	@RequestMapping("detect.htm")
	public String detect(final HttpServletRequest request, final ModelMap result) throws Exception {
		String ip = request.getParameter("ip");
		if ( StringUtils.isBlank(ip) ){
			return "";
		}
		long tic = System.currentTimeMillis();
		Map<String,DetectResultDO> rs = systemDetectManager.detect(ip);
		result.put("result",rs);
		result.put("used", System.currentTimeMillis()-tic);
		result.put("ip",ip);
		result.put("app",request.getParameter("app"));
		result.put("returnUrl",super.getWholeUrl(request));
		return DETECT;
	}

	@RequestMapping("offline.htm")
	public String offline(final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String ip = request.getParameter("ip");
		if ( StringUtils.isBlank(ip) ){
			return "";
		}
		String app = request.getParameter("app");
		long tic = System.currentTimeMillis();
		boolean suc =  hsfManager.offlineHSF(ip,user.getNick());
		if(suc){
			result.put("hsfMsg","���߳ɹ�,���Եȼ����ˢ��");
		}else{
			result.put("hsfMsg","����ʧ��,���Եȼ��������");
		}

		AppLog.log("����hsf",app,"ip:"+ip,"����hsf");

		AppChangeLogVO changeLog = AppChangeMonitor.createHSFOnLineOrOFFline(app, ip, "����hsf", user.getNick());
		super.appChangeLogService.addOneChangeLog(changeLog);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("online.htm")
	public String online(final HttpServletRequest request, final HttpServletResponse response, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String ip = request.getParameter("ip");
		if ( StringUtils.isBlank(ip) ){
			return "";
		}
		String app = request.getParameter("app");
		boolean suc = hsfManager.onlineHSF(ip,user.getNick());
		if(suc){
			result.put("hsfMsg","���߳ɹ�,���Եȼ����ˢ��");
		}else{
			result.put("hsfMsg","����ʧ��,���Եȼ��������");
		}
		AppLog.log("����hsf",app,"ip:"+ip,"����hsf");

		AppChangeLogVO changeLog = AppChangeMonitor.createHSFOnLineOrOFFline(app, ip, "����hsf", user.getNick());
		super.appChangeLogService.addOneChangeLog(changeLog);

		return getRedirectUrl(request, response);
	}

	@RequestMapping("appSug.htm")
	public String appSug(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("input");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		app = StringUtils.trim(app);
		//������Ӧ�������ң�Ȼ�����ݻ���IP����
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			MachineDO machine = machineDAO.getMachineByIp(app);
			if ( machine != null ){
				appDO = appDAO.getAppById(machine.getAppId());
			}
			if ( appDO == null ){
				return "";
			}
		}
		return "redirect:/scene/app.htm?app="+appDO.getAppName();
	}
	private static String getSpeHost(String ng) {
		if ( ng.contains("host") ) {
			return ng+"_spe";
		}else {
			return ng+":"+ng+"host_spe";
		}
	}
	@RequestMapping("app.htm")
	public String app(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return "";
		}
		boolean isMultiGroup = groupAppWhiteList.isInWhiteList(app);
		result.put("isMultiGroup", isMultiGroup);
		//0.��ȡ���з���
		Set<String> ngs = opsServic.getNGNameOfApp(appDO);
		result.put("ngs", ngs);
		String selectNg = request.getParameter("nodeGroup");
		if ( StringUtils.isBlank(selectNg)) {
			//selectNg��ֵ��
			if ( isMultiGroup ){
				selectNg= pickDefault(ngs);
			}else {
				selectNg = app;
			}
		}
		String selectNgSpe = getSpeHost(selectNg);
		boolean isContainSpe = ngs.contains(selectNgSpe);
		result.put("selectNg", selectNg);
		result.put("selectNgSpe", selectNgSpe);
		List<String> otherNgs = getOtherNgs(ngs,selectNg);
		result.put("otherNgs", otherNgs);
		{
			//Map<String, String> flts = new HashMap<String,String>();;
			//flts.put("app", app);
			result.put("bizMap",getBizMap());
			result.put("empIdMap",userCache.getEmpIdMap());
			result.put("urlStr",NodeExtUtils.buildAppExtensionUrl(appDO, "btn white btn-info mr2",false,selectNg));
			//1.��ȡӦ��
			AppModelListDO appModel = appModelManager.queryAppModel(app);
			AppModelDO appInfo = appModel.getRetList().iterator().next();
			result.put("appInfo",appInfo);
			result.put("machineCnt",appInfo.getMachines().size());
			//2.��ȡ������ĳ���
			SceneEntryModel model = sceneEntryManager.getEntryModel(app);
			result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
			result.put("entryCnt",model.getRetList().size());
			result.put("entrys",model.getTopNRetList(10));
			result.put("model",model);
			result.put("allCats",sceneCatDAO.getAllMap());
			result.put("allLevels", sceneLevelDAO.getAllMap());
			//2.1.��ȡ��֧�ŵĳ���
			Set<String> appSet = new HashSet<String>();
			appSet.add(app);
			Map<String, String> sptFlts = new HashMap<String,String>();
			SceneEntryModel supportModel = sceneEntryManager.getAppSupportEntryList(appSet,sptFlts);
			if ( supportModel != null){
				result.put("supportEntrys",supportModel.getTopNRetList(10));
				result.put("supportEntryCnt",supportModel.getRetList().size());
				result.put("supportModel",supportModel);
			}
			//3.��ȡ�쳣�б�
			Map<String,String> ss = new LinkedHashMap<String,String>();
			ss.putAll(ExceptionTypeConstant.typeMap);
			ss.put(ExceptionTypeConstant.DEFAULT_TYPE,"Default");
			result.put("allTypes",ss);
			Map<String, Map<String, Long>> showMap = generalErrorLogSearchService.getExceptionTypeStat(selectNg, 
					new Date[]{DateUtils.addMinutes(new Date(), -5),new Date()},
					TimePeriodEnum.ONEM);
			result.put("minMap", showMap);
			//��ȫ��������?
			if ( isContainSpe ) {
				Map<String, Map<String, Long>> showMapSpe = generalErrorLogSearchService.getExceptionTypeStat(selectNgSpe,
						new Date[]{DateUtils.addMinutes(new Date(), -5),new Date()},
						TimePeriodEnum.ONEM);
				result.put("minSpeMap", showMapSpe);
			}
			//������������������������չʾ
			//Set<String> nodeGroups = getExtendNodeGroups(app,appInfo.getMachines());
			/*
			if ( nodeGroups != null && !nodeGroups.isEmpty() ){
				Map<String,Map<String, Map<String, Long>>> nodeMinMap = new HashMap<String,Map<String,Map<String,Long>>>();
				for (String ng:nodeGroups ){
					Map<String, Map<String, Long>> sm = generalErrorLogSearchService.getExceptionTypeStat(ng,
							new Date[]{DateUtils.addMinutes(new Date(), -5),new Date()},
							TimePeriodEnum.ONEM);
					if ( sm != null ){
						nodeMinMap.put(ng, sm);
					}
				}
				result.put("ngMinMap", nodeMinMap);
			}
			*/
			//3.1��ȡbeta�쳣�б�
			if ( environmentService.isProduction() ) {
				Map<String, Map<String, Long>> betaShowMap = generalErrorLogSearchService.getExceptionTypeStat(selectNg,
						new Date[]{DateUtils.addMinutes(new Date(), -5),new Date(),},
						TimePeriodEnum.ONEM, EnvIdType.BETA.getEnvId());
				result.put("minMapBeta", betaShowMap);
			}
			//������������������������չʾ
			/*
			if ( nodeGroups != null && !nodeGroups.isEmpty() ){
				Map<String,Map<String, Map<String, Long>>> nodeMinMapBeta = new HashMap<String,Map<String,Map<String,Long>>>();
				for (String ng:nodeGroups ){
					Map<String, Map<String, Long>> sm = generalErrorLogSearchService.getExceptionTypeStat(ng,
							new Date[]{DateUtils.addMinutes(new Date(), -5),new Date()},
							TimePeriodEnum.ONEM,EnvIdType.BETA.getEnvId());
					if ( sm != null ){
						nodeMinMapBeta.put(ng, sm);
					}
				}
				result.put("ngMinMapBeta", nodeMinMapBeta);
			}
			*/
			//3.2.��ȡӦ�õ�ͼ
			//3.3.��ȡ�������
			List<String> customeParams  = new ArrayList<String>();
			{
				GraphParamDO gp = new GraphParamDO();
				gp.setName(AlarmLogGraphManager.ALARM_LOG_GRAPH);
				AlarmLogGraphParam param = new AlarmLogGraphParam();
				param.setApps(app);
				param.setEnd(new Date());
				param.setStart(DateUtils.addHours(new Date(),-1));
				param.setQueryType(AlarmLogGraphParam.QUERY_TYPE_APP);
				gp.setParam(param);
				customeParams.add(gp.toCustomParam());
			}
			Map<String,GraphMonitorItemDO> graphItems = buildGraph4App(selectNg,isContainSpe?selectNgSpe:null);
			if ( graphItems != null ){
				List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(graphItems),DataBuilder.graphSizeMap.get("xxs"));
				if ( kvParams != null && !kvParams.isEmpty() ){
					customeParams.addAll(kvParams);
				}
			}
			result.put("kvGraphTitles", graphItems.keySet());
			result.put("customParams", customeParams);
			//4.��ȡ�����DB
			DbModelListDO dbList = dbManager.queryDb(app);
			result.put("dbList",dbList.getRetList());
			TairModelListDO tairList = tairModelManger.queryTair(app);
			result.put("tairList",tairList.getGroups());
		}
		//5.��ȡӦ�ñ��
		{
			Map<String, String> flts = new HashMap<String,String>();
			flts.put("app", app);
			ChangeModelListDO changeList = changeManager.queryChangeList(flts, CalendarUtil.zerolizedTime(new Date()), new Date());
			result.put("changes",changeList.getTopNRetList(10));
			result.put("changeCnt",changeList.getRetList().size());
			
			SSqlModelListDO sList = ssqlManager.querySSqlList(flts);
			if ( sList != null ){
				result.put("ssqlList", sList.getTopNRetList(10));
				result.put("slowSqlCnt",sList.getRetList().size());
			}
			
			RealTimeRecordModelListDO rtrList = realTimeRecordManager.queryRealTimeRecordList(flts, new Date());
			if ( rtrList != null ){
				result.put("rtrList",rtrList.getTopNRetList(5));
				result.put("rtrCnt",rtrList.getRetList().size());
			}
		}

		//10.��ҳչʾ��дģʽ
		result.put("fullShow", "false");	
		result.put("app",app);
		result.put("ateyeDomain",ateyeConfig.getAteyeDomain());
		
		super.setIsMobile(request, result);
		return APP;
	}
	private List<String> getOtherNgs(Set<String> ngs, String selectNg){
		List<String> ret = new ArrayList<String>();
		for (String ng:ngs) {
			if ( ng.endsWith("_spe") ) {
				continue;
			}
			if (ng.equals(selectNg)) {
				continue;
			}
			ret.add(ng);
		}
		Collections.sort(ret);
		return ret;
	}

	//Ĭ��չʾ��Host�������core��ȡcore������ȡĬ����host�棬������ȡ��һ������
	private String pickDefault(Set<String> ngs) {
		String def = null;
		for (String ng:ngs ) {
			if ( ng.endsWith("_spe")) {
				continue;
			}
			if ( ng.endsWith("corehost") ) {
				return ng;
			}
			if ( !ng.contains("host") ) {//Ĭ��ֵ
				def = ng;
			}
		}
		if ( def == null ) {
			return ngs.iterator().next();
		}
		return def;
	}

	private Map<String, GraphMonitorItemDO> buildGraph4App(String nodeGroup,String speNg) throws Exception {
		Map<String,GraphMonitorItemDO> ret = new LinkedHashMap<String, GraphMonitorItemDO>();
		List<String> allNg = new ArrayList<String>();
		allNg.add(nodeGroup);
		if ( StringUtils.isNotBlank(speNg) ) {
			allNg.add(speNg);
		}
		for ( String ap:allNg ){
			ret.putAll(buildGraph(ap));
		}
		return ret;
	}
	private String showNg(String ng){
		String[] split = ng.split(":");
		if ( split.length !=2 ){
			return ng;
		}
		return split[1];
	}
	private Map<String, GraphMonitorItemDO> buildGraph(String ng) throws Exception {
		Map<String,GraphMonitorItemDO> ret = new LinkedHashMap<String,GraphMonitorItemDO>();
		Date startDate = CalendarUtil.zerolizedTime(new Date());
		String ap = showNg(ng);
		SortedSet<MonitorLogNode> nodes = logQueryService.newQueryMonitorLogInfoOfApp("_VIRTUAL_SYSTEM_",ng,startDate,startDate);
		if ( nodes == null || nodes.isEmpty() ){
			fillMock(ap,ret);
			return ret;
		}
		SystemMonitorDO systemDO = systemManager.extractSystemMonitorDO(nodes.iterator().next());
		if ( systemDO == null ){
			fillMock(ap,ret);
			return ret;
		}
		//��ʼƴͼ
		{
			List<KvGraphMonitorItemDO> lst = new ArrayList<KvGraphMonitorItemDO>();
			lst.add(new KvGraphMonitorItemDO("Load",systemDO.getLoad(),0));
			lst.add(new KvGraphMonitorItemDO("Load",systemDO.getLoad(),-1));
			lst.add(new KvGraphMonitorItemDO("Load",systemDO.getLoad(),-7));
			List<KvGraphMonitorItemDO> slst = new ArrayList<KvGraphMonitorItemDO>();
			slst.add(new KvGraphMonitorItemDO("Load",systemDO.getLoad(),0));
			ret.put(ap+"|Load", new GraphMonitorItemDO(lst,slst));
		}
		{
			List<KvGraphMonitorItemDO> lst = new ArrayList<KvGraphMonitorItemDO>();
			lst.add(new KvGraphMonitorItemDO("HSF�߳���",systemDO.getHsfThreads(),0));
			lst.add(new KvGraphMonitorItemDO("���߳���",systemDO.getTotalThreads(),0));
			List<KvGraphMonitorItemDO> slst = new ArrayList<KvGraphMonitorItemDO>();
			slst.add(new KvGraphMonitorItemDO("HSF�߳���",systemDO.getHsfThreads(),0));
			slst.add(new KvGraphMonitorItemDO("���߳���",systemDO.getTotalThreads(),0));
			ret.put(ap+"|�߳���", new GraphMonitorItemDO(lst,slst));
		}
		{
			List<KvGraphMonitorItemDO> lst = new ArrayList<KvGraphMonitorItemDO>();
			//lst.add(new KvGraphMonitorItemDO("OS�ڴ�",systemDO.getTotalMem(),0));
			//lst.add(new KvGraphMonitorItemDO("JVM�ڴ�",systemDO.getJvmMemTotal(),0));
			lst.add(new KvGraphMonitorItemDO("Old������",systemDO.getOldTotal(),0));
			lst.add(new KvGraphMonitorItemDO("Old������",systemDO.getOldUsed(),0));
			lst.add(new KvGraphMonitorItemDO("Eden������",systemDO.getEdenTotal(),0));
			lst.add(new KvGraphMonitorItemDO("Eden������",systemDO.getEdenUsed(),0));
			ret.put(ap+"|�ڴ�", new GraphMonitorItemDO(lst));
		}
		{
			List<KvGraphMonitorItemDO> lst = new ArrayList<KvGraphMonitorItemDO>();
			lst.add(new KvGraphMonitorItemDO("Old��ռ��",systemDO.getOldPercent(),0));
			lst.add(new KvGraphMonitorItemDO("Old��ռ��",systemDO.getOldPercent(),-1));
			ret.put(ap+"|OLD��ռ��", new GraphMonitorItemDO(lst));
		}
		{
			List<KvGraphMonitorItemDO> lst = new ArrayList<KvGraphMonitorItemDO>();
			lst.add(new KvGraphMonitorItemDO("Ygc",systemDO.getYgc(),0));
			lst.add(new KvGraphMonitorItemDO("Ygc",systemDO.getYgc(),-1));
			lst.add(new KvGraphMonitorItemDO("Fgc",systemDO.getFgc(),0));
			lst.add(new KvGraphMonitorItemDO("Fgc",systemDO.getFgc(),-1));
			ret.put(ap+"|GC����", new GraphMonitorItemDO(lst));
		}
		return ret;
	}
	private void fillMock(String ap, Map<String,GraphMonitorItemDO> ret){
		ret.put(ap+"|Load", new GraphMonitorItemDO(Arrays.asList(KvGraphMonitorItemDO.getEmptyDO())));
		ret.put(ap+"|�߳���", new GraphMonitorItemDO(Arrays.asList(KvGraphMonitorItemDO.getEmptyDO())));
		ret.put(ap+"|�ڴ�", new GraphMonitorItemDO(Arrays.asList(KvGraphMonitorItemDO.getEmptyDO())));
		ret.put(ap+"|OLD��ռ��", new GraphMonitorItemDO(Arrays.asList(KvGraphMonitorItemDO.getEmptyDO())));
		ret.put(ap+"|GC����", new GraphMonitorItemDO(Arrays.asList(KvGraphMonitorItemDO.getEmptyDO())));
	}
	@RequestMapping("appServers.htm")
	public String appServers(final HttpServletRequest request, final ModelMap result) throws Exception {
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		Map<String, String> flts = new HashMap<String,String>();;
		flts.put("app", app);
		AppModelListDO model = appModelManager.queryAppList(flts,true);
		result.put("appInfo",model.getRetList().iterator().next());
		result.put("app", app);
		
		return APP_SERVER;
	}
	@RequestMapping("appArchList.htm")
	public String appArchList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltType = request.getParameter("fltType");
		if ( StringUtils.isNotBlank(fltType) ){
			flts.put("type", fltType);
			result.put("fltType",fltType);
		}
		String fltOps = request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltDomain= request.getParameter("fltDomain");
		if ( StringUtils.isNotBlank(fltDomain) ){
			flts.put("domain", fltDomain);
			result.put("fltDomain",fltDomain);
		}
		String fltStatus = request.getParameter("fltStatus");
		if ( StringUtils.isNotBlank(fltStatus) ){
			flts.put("status", fltStatus);
			result.put("fltStatus",fltStatus);
		}
		String fltGrade = request.getParameter("fltGrade");
		if ( StringUtils.isNotBlank(fltGrade) ){
			flts.put("grade", fltGrade);
			result.put("fltGrade",fltGrade);
		}
		AppModelListDO appList = appModelManager.queryAppList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = appList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("opsFlt", formatToLong(fltMap.get("ops")));
		result.put("typeFlt", fltMap.get("type"));
		result.put("domainFlt", fltMap.get("domain"));
		result.put("statusFlt", fltMap.get("status"));
		result.put("gradeFlt", fltMap.get("grade"));
		result.put("bizMap",getBizMap());
		result.put("appTypeList",appTypeList.getAppTypes());
		result.put("appDomains",appDomainList.getAppDomainDesc().entrySet());
		result.put("appStatusList",appStatusList.getAppStatus());
		result.put("appList",appList);
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("apps",appList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return APP_ARCH_LIST;
    }
	@RequestMapping("appList.htm")
	public String appList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltTag = request.getParameter("fltTag");
		if ( StringUtils.isNotBlank(fltTag) ){
			flts.put("tag", fltTag);
			result.put("fltTag",fltTag);
		}
		String fltOps = request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltVersion = request.getParameter("fltVersion");
		if ( StringUtils.isNotBlank(fltVersion) ){
			flts.put("version", fltVersion);
			result.put("fltVersion",fltVersion);
		}
		String fltLevel = request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltGrade = request.getParameter("fltGrade");
		if ( StringUtils.isNotBlank(fltGrade) ){
			flts.put("grade", fltGrade);
			result.put("fltGrade",fltGrade);
		}
		String fltJava = request.getParameter("fltJava");
		if ( StringUtils.isNotBlank(fltJava) ){
			flts.put("java", fltJava);
			result.put("fltJava",fltJava);
		}
		String fltSafe = request.getParameter("fltSafe");
		if ( StringUtils.isNotBlank(fltSafe) ){
			flts.put("safe", fltSafe);
			result.put("fltSafe",fltSafe);
		}
		String fltSpe = request.getParameter("fltSpe");
		if ( StringUtils.isNotBlank(fltSpe) ){
			flts.put("spe", fltSpe);
			result.put("fltSpe",fltSpe);
		}
		AppModelListDO appList = appModelManager.queryAppList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = appList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("opsFlt", formatToLong(fltMap.get("ops")));
		result.put("versionFlt", fltMap.get("version"));
		result.put("tagFlt", fltMap.get("tag"));
		result.put("levelFlt", fltMap.get("level"));
		result.put("gradeFlt", fltMap.get("grade"));
		result.put("javaFlt", fltMap.get("java"));
		result.put("safeFlt", fltMap.get("safe"));
		result.put("speFlt", fltMap.get("spe"));
		result.put("bizMap",getBizMap());
		result.put("appList",appList);
		result.put("serversCnt", appList.getServerCount());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("apps",appList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return APP_LIST;
    }
	@RequestMapping("changeList.htm")
	public String changeList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		/*
		 * ʱ�䴦��
		 */
		Date s_time = CalendarUtil.zerolizedTime(new Date());
		Date e_time = new Date();
		String start_time = request.getParameter("start_time");
		String end_time = request.getParameter("end_time");
		String start_hhmm = request.getParameter("start_hhmm");
		String end_hhmm = request.getParameter("end_hhmm");
		if(!StringUtil.isBlank(start_time)&&!StringUtil.isBlank(end_time)
			&& !StringUtil.isBlank(start_hhmm)&&!StringUtil.isBlank(end_hhmm)
				){//�������򸲸�ԭ��ʱ��
			s_time=stringToDate(start_time,start_hhmm);
			e_time=stringToDate(end_time,end_hhmm);
		}
		result.put("start_time",CalendarUtil.toString(s_time, CalendarUtil.DATE_FMT_3));
		result.put("end_time",CalendarUtil.toString(e_time, CalendarUtil.DATE_FMT_3));
		result.put("start_hhmm",CalendarUtil.toString(s_time, "HH:mm"));
		result.put("end_hhmm",CalendarUtil.toString(e_time, "HH:mm"));

		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltOps = request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltType= request.getParameter("fltType");
		if ( StringUtils.isNotBlank(fltType) ){
			flts.put("type", fltType);
			result.put("fltType",fltType);
		}
		String fltSrc = request.getParameter("fltSrc");
		if ( StringUtils.isNotBlank(fltSrc) ){
			flts.put("src", fltSrc);
			result.put("fltSrc",fltSrc);
		}
		String fltEnv = request.getParameter("fltEnv");
		if ( StringUtils.isNotBlank(fltEnv) ){
			flts.put("env", fltEnv);
			result.put("fltEnv",fltEnv);
		}
		ChangeModelListDO changeList = changeManager.queryChangeList(flts,s_time,e_time);
		
		Map<String, List<Pair<String, Integer>>> fltMap = changeList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("opsFlt", formatToLong(fltMap.get("ops")));
		result.put("typeFlt", fltMap.get("type"));
		result.put("srcFlt", fltMap.get("src"));
		result.put("appFlt", fltMap.get("app"));
		result.put("envFlt", fltMap.get("env"));
		result.put("bizMap",getBizMap());
		result.put("changeList",changeList);
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("changes",changeList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return CHANGE_LIST;
    }	
	@RequestMapping("ssqlList.htm")
	public String ssqlList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();

		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltCluster= request.getParameter("fltCluster");
		if ( StringUtils.isNotBlank(fltCluster) ){
			flts.put("cluster", fltCluster);
			result.put("fltCluster",fltCluster);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		String fltGrade= request.getParameter("fltGrade");
		if ( StringUtils.isNotBlank(fltGrade) ){
			flts.put("grade", fltGrade);
			result.put("fltGrade",fltGrade);
		}
		SSqlModelListDO ssqlList = ssqlManager.querySSqlList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = ssqlList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("appFlt", fltMap.get("app"));
		result.put("clusterFlt", fltMap.get("cluster"));
		result.put("gradeFlt", fltMap.get("grade"));
		result.put("bizMap",getBizMap());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("ssqlList",ssqlList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return SSQL_LIST;
    }	
	@RequestMapping("beginRt.htm")
	public String beginRt(final HttpServletRequest request, final ModelMap result) throws Exception {
		String userInfo = request.getParameter("ui");
		String appName = request.getParameter("appName");
		if ( StringUtils.isBlank(appName) || StringUtils.isBlank(userInfo) ){
			return "";
		}
		UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
 		String operator = user.getNick();
 		realTimeTrackerManager.insertAndPubish(userInfo, appName, operator);
 		return "redirect:"+ExtUrlUtil.getOpLogUrl("_REALTIME_", "1", userInfo, new Date(), DateUtils.addDays(new Date(),1));
	}

	@RequestMapping("beginRandomRt.htm")
	public String beginRandomRt(final HttpServletRequest request, final ModelMap result) throws Exception {

		String interfaceName = request.getParameter("interfaceName");
		String methodName = request.getParameter("methodName");
		if ( StringUtils.isBlank(interfaceName) || StringUtils.isBlank(methodName) ){
			return "";
		}
		String targetName = interfaceName+":"+methodName;
		String appName = request.getParameter("appName");
		if ( StringUtils.isBlank(appName) || StringUtils.isBlank(targetName) ){
			return "";
		}
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String operator = user.getNick();
		String uuid = UUID.randomUUID().toString();
		realTimeTrackerManager.insertRandomAndPubish(targetName,uuid, appName, operator);
		return "redirect:"+ExtUrlUtil.getOpLogUrl("_REALTIME_", "1", uuid, new Date(), DateUtils.addDays(new Date(),1));
	}

	@RequestMapping("hsfTimeOutSetting.htm")
	public String hsfTimeOutSetting(final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String appName = request.getParameter("appName");
		String ips = request.getParameter("ips");
		String sentinelResourceName = request.getParameter("sentinelResourceName");
		String timeout = request.getParameter("timeout");
		String value = DynamicConfigParserUtils.build(UPDATE_ONE_ITEM,sentinelResourceName,"timeout",timeout);
		return hsfMetaDataManager.batchSetDynamicConfig(appName,ips,value,result,BeanFieldController.BATCH_SET_RESULT2);
	}

	@RequestMapping("rtrList.htm")
	public String rtrList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		Date day = new Date();
		String dayStr = request.getParameter("day");
		if ( StringUtils.isNotBlank(dayStr) ){
			day = CalendarUtil.toDate(dayStr, CalendarUtil.DATE_FMT_3);
		}
		result.put("day",CalendarUtil.toString(day, CalendarUtil.DATE_FMT_3));
		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltOps= request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltOwner= request.getParameter("fltOwner");
		if ( StringUtils.isNotBlank(fltOwner) ){
			flts.put("owner", fltOwner);
			result.put("fltOwner",fltOwner);
		}
		RealTimeRecordModelListDO rtrList = realTimeRecordManager.queryRealTimeRecordList(flts,day);
		
		Map<String, List<Pair<String, Integer>>> fltMap = rtrList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("appFlt", fltMap.get("app"));
		result.put("opsFlt", fltMap.get("ops"));
		result.put("bizMap",getBizMap());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("rtrList",rtrList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return RTR_LIST;
    }	
	@RequestMapping("bizList.htm")
	public String bizList(final HttpServletRequest request, final ModelMap result) throws Exception {
	
		List<BizLineDO> bizs = bizLineDAO.getAllBizLineList();
		
		result.put("bizs",bizs);
		
		return BIZ_LIST;
    }
	@RequestMapping("addBiz.htm")
	public String addBiz(final HttpServletRequest request, final ModelMap result) throws Exception {
		String bizName = request.getParameter("bizName");
		String bizOwner = request.getParameter("bizOwner");
		if ( StringUtils.isNotBlank(bizName) && StringUtils.isNotBlank(bizOwner) ){
			BizLineDO bizLineDO = new BizLineDO();
			bizLineDO.setGmtCreate(new Date());
			bizLineDO.setGmtModified(new Date());
			bizLineDO.setName(bizName);
			bizLineDO.setOwner(bizOwner);
			bizLineDO.setOperator("AUTO");
			try{
				bizLineDAO.insertBizLine(bizLineDO);
			}catch(DAOException e){
				log.error("дDB�쳣",e);
			}
		}
		return "redirect:/scene/bizList.htm";
    }
	@RequestMapping("updateAppBizAjax.htm")
	public String updateAppBizAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String bizId = request.getParameter("bizId");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(bizId) ){
			int update = appDAO.updateAppBizType(Long.valueOf(appId), Integer.valueOf(bizId));
			ret.put("success", update>0?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAppTypeAjax.htm")
	public String updateAppTypeAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String name= request.getParameter("name");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(name) ){
			appExtendManager.updateAppType(Long.valueOf(appId), name);
			ret.put("success", "true");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAppDomainAjax.htm")
	public String updateAppDomainAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String name= request.getParameter("name");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(name) ){
			appExtendManager.updateAppDomain(Long.valueOf(appId), name);
			ret.put("success", "true");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAppStatusAjax.htm")
	public String updateAppStatusAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String name= request.getParameter("name");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(name) ){
			appExtendManager.updateAppStatus(Long.valueOf(appId), name);
			ret.put("success", "true");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAppMemoAjax.htm")
	public String updateAppMemoAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String name= request.getParameter("name");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId)){
			appExtendManager.updateAppMemo(Long.valueOf(appId), name);
			ret.put("success", "true");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateAppDeadlineAjax.htm")
	public String updateAppDeadlineAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String name= request.getParameter("name");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(name) ){
			appExtendManager.updateAppDeadline(Long.valueOf(appId), name);
			ret.put("success", "true");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("removeAppTagAjax.htm")
	public String removeAppTagAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String tag = request.getParameter("tag");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(tag) ){
			boolean isSucc = appExtendManager.removeAppTag(Long.valueOf(appId), tag);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("addAppTagAjax.htm")
	public String addAppTagAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appId = request.getParameter("appId");
		String tag = request.getParameter("tag");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(tag) ){
			boolean isSucc = appExtendManager.addAppTag(Long.valueOf(appId), tag);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateBizAjax.htm")
	public String updateBizAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String bizId = request.getParameter("bizId");
		String bizName = request.getParameter("bizName");
		if ( StringUtils.isNotBlank(bizName) ){
			bizName = URLDecoder.decode(bizName, "utf-8");
		}
		PrintWriter out = response.getWriter();
		String bizOwner = request.getParameter("bizOwner");
		String bizDetail = request.getParameter("bizDetail");
		if ( StringUtils.isNotBlank(bizDetail) ){
			bizDetail = URLDecoder.decode(bizDetail, "utf-8");
		}
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(bizId) && StringUtils.isNotBlank(bizName) ){
			update = bizLineDAO.updateBizName(bizId,bizName);
		}else if ( StringUtils.isNotBlank(bizId) && StringUtils.isNotBlank(bizOwner) ){
			update = bizLineDAO.updateBizOwner(bizId,bizOwner);
		}else if ( StringUtils.isNotBlank(bizId) && StringUtils.isNotBlank(bizDetail) ){
			update = bizLineDAO.updateBizDetail(bizId,bizDetail);
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
}
