package com.taobao.ateye.controller.scene;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.sim.SimDetailDO;
import com.taobao.ateye.sim.SimManager;
import com.taobao.ateye.sim.SimModelListDO;
import com.taobao.ateye.sim.engine.SimEngine;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/scene")
public class SceneSimController extends AbstractController{
	private static final String SIM_LIST = "screen/scene/simList";
	private static final String SIM_DETAIL = "screen/scene/simDetail";
	
	@Autowired
	private SimManager simManager;
	@Autowired
	private SimEngine simEngine;

	@RequestMapping("simList.htm")
	public String simList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();
		/*
		 * ʱ�䴦��
		 */
		Date s_time = CalendarUtil.zerolizedTime(new Date());
		Date e_time = new Date();
		String start_time = request.getParameter("start_time");
		String end_time = request.getParameter("end_time");
		String start_hhmm = request.getParameter("start_hhmm");
		String end_hhmm = request.getParameter("end_hhmm");
		if(!StringUtil.isBlank(start_time)&&!StringUtil.isBlank(end_time)
			&& !StringUtil.isBlank(start_hhmm)&&!StringUtil.isBlank(end_hhmm)
				){//�������򸲸�ԭ��ʱ��
			s_time=stringToDate(start_time,start_hhmm);
			e_time=stringToDate(end_time,end_hhmm);
		}
		result.put("start_time",CalendarUtil.toString(s_time, CalendarUtil.DATE_FMT_3));
		result.put("end_time",CalendarUtil.toString(e_time, CalendarUtil.DATE_FMT_3));
		result.put("start_hhmm",CalendarUtil.toString(s_time, "HH:mm"));
		result.put("end_hhmm",CalendarUtil.toString(e_time, "HH:mm"));

		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltApp= request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltOps = request.getParameter("fltOps");
		if ( StringUtils.isNotBlank(fltOps) ){
			flts.put("ops", fltOps);
			result.put("fltOps",fltOps);
		}
		String fltScene = request.getParameter("fltScene");
		if ( StringUtils.isNotBlank(fltScene) ){
			flts.put("scene", fltScene);
			result.put("fltScene",fltScene);
		}
		SimModelListDO simList = simModelManager.querySimList(flts, s_time, e_time);
		
		Map<String, List<Pair<String, Integer>>> fltMap = simList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("opsFlt", formatToLong(fltMap.get("ops")));
		result.put("appFlt", fltMap.get("app"));
		result.put("bizMap",getBizMap());
		result.put("simList",simList);
		result.put("sims",simList.getRetList());
		result.put("fullShow", "true");
		return SIM_LIST;
	}
	@RequestMapping("beginSim.htm")
	public String beginSim(final HttpServletRequest request, final ModelMap result) throws Exception {
		String userNick = request.getParameter("ui");
		String n = request.getParameter("n");
		String sceneId = request.getParameter("sceneId");
		if ( StringUtils.isBlank(userNick) || StringUtils.isBlank(n) || StringUtils.isBlank(sceneId) ){
			return "";
		}
		UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
 		String operator = user.getNick();
 		int num = Integer.valueOf(n);
 		if ( num > 10 ){
 			num = 10;
 		}
 		Long sId = Long.valueOf(sceneId);
 		long simId = simManager.addNewSim(sId, userNick, num,operator);
 		//����ģ�⿪ʼ
 		simEngine.beginSim(simId);
 		return "redirect:/scene/simDetail.htm?id="+simId;
	}	
	@RequestMapping("simDetail.htm")
	public String simDetail(final HttpServletRequest request, final ModelMap result) throws Exception {
		String simId = request.getParameter("id");
		if ( StringUtils.isBlank(simId) ){
			return "";
		}
		Long id = Long.valueOf(simId);
		SimDetailDO simDetail = simManager.getSimDetail(id);
		result.put("sd", simDetail);
		return SIM_DETAIL;
	}	
}
