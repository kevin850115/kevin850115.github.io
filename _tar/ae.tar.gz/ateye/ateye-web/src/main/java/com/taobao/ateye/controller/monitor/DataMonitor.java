package com.taobao.ateye.controller.monitor;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.security.util.crypto.Base64;
import com.taobao.ateye.concc.ConcDO;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.data.obj.HsfVO;
import com.taobao.ateye.data.retriver.GraphRetriver;
import com.taobao.ateye.data.retriver.GraphRetriverDO;
import com.taobao.ateye.data.retriver.LineRetriver;
import com.taobao.ateye.graph.base.AbstractGraphManager;
import com.taobao.ateye.monitor.MonitorLogLineManager;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.monitor.data.LineObjDO;
import com.taobao.ateye.report.analyse.RtAnalyseManager;
import com.taobao.ateye.report.analyse.RtDistributeDO;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.tair.TairCache.TairResult;
import com.taobao.ateye.tair.TairMemCache;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.ateye.view.AteyeViewManager;
import com.taobao.ateye.view.VirtualViewDO;
import com.taobao.ateye.view.config.ViewConfig;
import com.taobao.ateye.view.manager.ViewDataManager;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.generalerror.domain.GeneralErrorDetailStatDO;
import com.taobao.tracker.generalerror.domain.TimePeriodEnum;
import com.taobao.tracker.generalerror.service.GeneralErrorLogSearchService;
import com.taobao.tracker.hbase.CViewDO;
import com.taobao.tracker.hbase.service.AteyeCViewService;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.BaseViewDO;
import com.taobao.tracker.hbase.view.LineDefDO;
import com.taobao.tracker.hbase.view.MultiViewDO;
import com.taobao.tracker.hbase.view.SingleViewDO;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.tracker.service.monitor.MonitorValue;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/monitor")
public class DataMonitor {
	private Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private GeneralErrorLogSearchService generalErrorLogSearchService;
	@Autowired
	private MonitorLogQueryService monitorLogQueryService;
	@Autowired
	RtAnalyseManager rtAnalyseManager;
	@Autowired
	MonitorLogLineManager monitorLogLineManager;
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private AteyeConfig ateyeConfig;
	@Autowired
	private AteyeViewManager ateyeViewManager;
	@Autowired
	private AteyeCViewService ateyeCViewService;	
	@Autowired
	private ViewDataManager viewDataManager;
	@Resource
	private TairMemCache tairMemCache;
	public static String TYPE_ERROR = "error";
	public static String TYPE_MONITOR_LOG = "monitorLog";
	public static String TYPE_MONITOR_LOG_OF_DAY = "monitorLogOfDay";
	public static String TYPE_HSF_MONITOR_LOG = "hsfMonitorLog";
	public static String TYPE_SQLMAP = "sqlmap";
	public static String TYPE_TRACKER= "_tracker_";//tracker������Ϣ
	public static String TYPE_VIEW= "view";//��ͼ
	public static String TYPE_CVIEW= "cview";//�°���ͼ
	public static String TYPE_CUSTOM = "custom";//�Զ���ͼ��
	
	private void outPut(PrintWriter w,String s){
		w.println(s);
	}

	@RequestMapping("queryData.htm")
    public String queryData(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String type = request.getParameter("type");
		if ( type == null ){
			return null;
		}
		if ( type.equals(TYPE_ERROR) ){
			_queryDataForError(request,response);
		}else if ( type.equals(TYPE_MONITOR_LOG)){
			_queryDataForMonitorLog(request,response);
		}else if ( type.equals(TYPE_MONITOR_LOG_OF_DAY)){
			_queryDataForMonitorLogOfDay(request,response);
		}else if ( type.equals(TYPE_HSF_MONITOR_LOG)){
			_queryDataForHsfMonitorLog(request,response);
		}else if ( type.equals(TYPE_SQLMAP)){
			_queryDataForSqlmap(request,response);
		}else if ( type.equals(TYPE_TRACKER)){
			_queryDataForMultiView(request,response);
		}else if ( type.equals(TYPE_VIEW) ){
			_queryDataForCustomViews(request, response);
		}else if ( type.equals(TYPE_CVIEW) ){
			_queryDataForCView(request, response);
		}else if ( type.equals(TYPE_CUSTOM) ){
			_queryDataForCustom(request, response);
		}
    	return null;
    }
	@RequestMapping("queryDataArea.htm")
    public String queryDataArea(final HttpServletRequest request, HttpServletResponse response) throws Exception{
		String type = request.getParameter("type");
		if ( type == null ){
			return null;
		}
		if ( type.equals(TYPE_ERROR) ){
		}else if ( type.equals(TYPE_MONITOR_LOG)){
		}else if ( type.equals(TYPE_HSF_MONITOR_LOG)){
		}else if ( type.equals(TYPE_SQLMAP)){
			_generateAreaForSqlmap(request,response);
		}else if ( type.equals(TYPE_TRACKER)){
		}
    	return null;
    }
	private void _generateAreaForSqlmap(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		//1.��ѯ����
		String appName = request.getParameter("appName");
		String keys = request.getParameter("keys");
		String sd = request.getParameter("startDate");
		String groupby = request.getParameter("groupby");
		String ed = request.getParameter("endDate");
		if ( StringUtils.isNotBlank(ed) && ed.equals("null") ){
			ed = "";
		}
		String sd2 = request.getParameter("startDate2");
		String ed2 = request.getParameter("endDate2");
		Date endDate =  new Date();
		Date startDate = null;
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			startDate = null;
			endDate = DateUtils.addDays(CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3),1);
			if ( groupby.equals("day") ){
				startDate = DateUtils.addDays(endDate,-1);
			}else if ( groupby.equals("week") ){
				startDate = DateUtils.addDays(endDate,-7);
			}
		}
		String[] decodedKeys = URLDecoder.decode(keys, "utf8").split("\\^");
		Map<Date, MonitorValue> results = monitorLogQueryService.newQueryHistoryData(appName, getKey(decodedKeys), startDate, endDate);
		//2.����ֲ����
		RtDistributeDO dis = _getDistributeResult(results);
		PrintWriter out = response.getWriter();
		String desc = "��Ӧʱ��ռ�ȷֲ�ͼ";
		if ( StringUtils.isNotBlank(sd2) && StringUtils.isNotBlank(ed2) && !sd2.equals("null") && !ed2.equals("null")){
			//�Ա�
			Map<Date, MonitorValue> results2 = _queryDataForMonitorLogDetail(request, response,sd2,ed2, false);
			RtDistributeDO dis2 = _getDistributeResult(results2);
			String json = DataBuilder.buildAreaJson(dis,dis2,
					buildDateStr(startDate,endDate)+desc+dis.getDesc(),
					buildDateStr(sd2,ed2)+desc+dis2.getDesc(),
					desc
					);
			outPut(out,json);
		}else{
			String json = DataBuilder.buildAreaJson(dis,buildDateStr(startDate,endDate)+desc+dis.getDesc(),desc);
			outPut(out,json);
		}
	}
	private RtDistributeDO _getDistributeResult(Map<Date, MonitorValue> results) {
		RtDistributeDO dis = rtAnalyseManager.getDistribute(results);
		return dis;
	}
	private String buildDateStr(Date begin,Date end){
		return CalendarUtil.toString(begin,CalendarUtil.DATE_FMT_0)+"~"+CalendarUtil.toString(end,CalendarUtil.DATE_FMT_0);
	}
	private String buildDateStr(String begin,String end){
		Pair<Date,Date> dd = getDateFromRequest(begin,end);
		return buildDateStr(dd.getLeft(),dd.getRight());
	}

	private void _queryDataForSqlmap(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String appName = request.getParameter("appName");
		String keys = request.getParameter("keys");
		String valueType = request.getParameter("valueType");
		String sd = request.getParameter("startDate");
		String groupby = request.getParameter("groupby");
		String ed = request.getParameter("endDate");
		if ( StringUtils.isNotBlank(ed) && ed.equals("null") ){
			ed = "";
		}
		String sd2 = request.getParameter("startDate2");
		String ed2 = request.getParameter("endDate2");
		Date endDate =  new Date();
		Date startDate = null;
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			startDate = null;
			endDate = DateUtils.addDays(CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3),1);
			if ( groupby.equals("day") ){
				startDate = DateUtils.addDays(endDate,-1);
			}else if ( groupby.equals("week") ){
				startDate = DateUtils.addDays(endDate,-7);
			}
		}
		String[] decodedKeys = URLDecoder.decode(keys, "utf8").split("\\^");
		Map<Date, MonitorValue> results = monitorLogQueryService.newQueryHistoryData(appName, getKey(decodedKeys), startDate, endDate);
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(sd2) && StringUtils.isNotBlank(ed2) && !sd2.equals("null") && !ed2.equals("null")){
			//1.��ȡ���Աȵ�����
			Map<Date, MonitorValue> results2 = _queryDataForMonitorLogDetail(request, response,sd2,ed2, false);
			//2.��ȡ�ڶ����͵�һ�����ߵ����ʱ���
			getDayDiff(sd2,sd);//
			//3.ƴ���Map��titleΪʱ���
			Map<String/*title*/,Map<Date, MonitorValue>> resultsMap = new LinkedHashMap<String/*title*/,Map<Date, MonitorValue>>();
			resultsMap.put(getKey(sd,ed), results);
			resultsMap.put(getKey(sd2,ed2), LineRetriver.dateAddDays(results2,-getDayDiff(sd,sd2)));//�ڶ�������ʱ�����
			//4.ƴjson���
			String str = DataBuilder.buildDataJsonForMonitorLogForCompare(valueType, resultsMap,decodedKeys);
			outPut(out,str);
		}else{
			String str = DataBuilder.buildDataJsonForMonitorLog(valueType, results,decodedKeys);
			outPut(out,str);
		}
	}
	private boolean isToday(Date d){
		Date now = new Date();
		return CalendarUtil.zerolizedTime(now).equals(CalendarUtil.zerolizedTime(d));
	}
	private void _queryDataForCustomViews(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String size = request.getParameter("gSize");
		if ( StringUtils.isBlank(size) || size.equals("null")){
			size = "media";
		}
		String uuid = request.getParameter("uuid");
		Map<SingleViewDO,List<LineDefDO>> alllines = new LinkedHashMap<SingleViewDO,List<LineDefDO>>();
		//1.��ȡ��������
		if ( StringUtils.isNotBlank(uuid) ){
			BaseViewDO view = ateyeViewManager.getView(uuid);
			if ( view.getType() == BaseViewDO.TYPE_SINGLE ){
				SingleViewDO sv = (SingleViewDO) view;
				alllines.put(sv,sv.getLines());
			}else if ( view.getType() == BaseViewDO.TYPE_MULTI){
				MultiViewDO mv = (MultiViewDO) view;
				List<String> singleViewUUids = mv.getSingleViewUUids();
				for ( String suuid:singleViewUUids ){
					BaseViewDO sview = ateyeViewManager.getView(suuid);
					if ( sview == null || sview.getType() != BaseViewDO.TYPE_SINGLE ){
						continue;
					}
					SingleViewDO sv = (SingleViewDO) sview;
					alllines.put(sv,sv.getLines());
				}
			}else if ( view.getType() == VirtualViewDO.TYPE){//��������Ϊ����ڵ�
				VirtualViewDO vv = (VirtualViewDO)view;
				alllines = vv.getAlllines();
			}
		}
		if ( alllines.isEmpty() ){
			return;
		}
		String wholeDay = request.getParameter("wholeDay");
		boolean isShowWholeDay = false;
		if ( StringUtils.isNotBlank(wholeDay) && !wholeDay.equals("null") ){
			isShowWholeDay = true;
		}
		
		int showHourNumber = 3;//Ĭ�������3Сʱ��
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		Date endDate =  new Date();
		Date startDate = null;
		if ( sd != null && sd.equals("null") ){
			sd = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);
		}
		if ( ed != null && ed.equals("null") ){
			ed = "";
		}
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			startDate = null;
			endDate = DateUtils.addDays(CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3),1);
			startDate = DateUtils.addDays(endDate,-1);
		}
		//1.����ǽ����Ҳ���չʾȫ�죬���չʾ���3Сʱ
		if ( !isShowWholeDay && isToday(startDate)){
			startDate = DateUtils.addHours(new Date(), -showHourNumber);
			endDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),1);
		}
		ConcDO chartDO = new ConcDO();
		GraphRetriverDO graphDO = new GraphRetriverDO();
		int cn=0;
		for ( Map.Entry<SingleViewDO,List<LineDefDO>> ent:alllines.entrySet() ){
			chartDO.addTask(new GraphRetriver(cn,
					monitorLogQueryService,
					monitorLogLineManager,
					ent,
					graphDO,
					startDate,
					endDate,
					isShowWholeDay
					));
			cn++;
		}
		chartDO.begin();
		chartDO.joinAll(10);
		//<ͼ,<��,List<ʱ��,��>>>
		Map<String,Map<String,LineObjDO>> results = graphDO.getGraph();
		//<ͼ,ͼ����>
		Map<String,String> chartTypes = graphDO.getChartTypes();

		PrintWriter out = response.getWriter();
		if ( results.size() > 1 ){
			String str = DataBuilder.buildDataJson(results,chartTypes,DataBuilder.graphSizeMap.get(size));
			outPut(out,str);
		}else{
			String str = DataBuilder.buildDataJson(results,chartTypes, DataBuilder.defaultSize);
			outPut(out,str);
		}
	}
	private void _queryDataForCustom(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//custom�����Ƕ��ŷָ�Ķ���ͼ
		List<String> params = new ArrayList<String>();
		int max = 200;
		for (int i=1;i<=max;++i ){
			String customParam = request.getParameter("customParam_"+i);
			if ( StringUtils.isNotBlank(customParam) ){
				String cp = Base64.decode(customParam);
				params.add(cp);
			}else{
				break;
			}
		}
		String jsonStr = AbstractGraphManager.printGraph(params);
		PrintWriter out = response.getWriter();
		outPut(out,jsonStr);
	}
	private void _queryDataForCView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//��һ����ȷ������
		Pair<Date,Date> se = getStartAndEnd(request);
		Date startDate = se.getLeft();
		Date endDate = se.getRight();
		//2.�ҵ���ͼ
		boolean isPreviewMode = false;
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) || uuid.equals("null") ){
			uuid = request.getParameter("puuid");
			if ( StringUtils.isBlank(uuid) || uuid.equals("null" )){
				return;
			}
			isPreviewMode = true;
		}
		String unitName = request.getParameter("unitName");
		if ( unitName.equals("null") ){
			unitName = null;
		}
		boolean isSpe = false;
		String spe = request.getParameter("spe");
		if ( "1".equals(spe) ){
			isSpe = true;
		}
		CViewDO cView = null;
		if ( isPreviewMode ){
			TairResult<CViewDO> rs = tairMemCache.getObject("_view_preview_uuid_"+uuid, CViewDO.class);
			if ( rs.isSuccess() ){
				cView = rs.getResult();
			}	
		}else{
			cView = ateyeCViewService.getCViewById(uuid);
		}
		if ( cView == null ){
			return;
		}
		ViewConfig ddc = new ViewConfig(cView.getDetail());
		if ( ddc == null || !ddc.isDecoded() ){
			return;
		}
		if ( isSpe ){
			ddc.convert2Spe();
		}
		//3.��ȡ��ͼ����Ⱦ
		String jsonStr = viewDataManager.fetchGraphData(uuid,ddc,unitName,startDate,endDate);
		PrintWriter out = response.getWriter();
		outPut(out,jsonStr);
	}	
	private Pair<Date,Date> getStartAndEnd(HttpServletRequest request){
		String wholeDay = request.getParameter("wholeDay");
		boolean isShowWholeDay = false;
		if ( StringUtils.isNotBlank(wholeDay) && !wholeDay.equals("null") ){
			isShowWholeDay = true;
		}
		int showHourNumber = 3;//Ĭ�������3Сʱ��
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		Date endDate =  new Date();
		Date startDate = null;
		if ( sd != null && sd.equals("null") ){
			sd = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);
		}
		if ( ed != null && ed.equals("null") ){
			ed = "";
		}
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			startDate = null;
			endDate = DateUtils.addSeconds(DateUtils.addDays(CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3),1),-1);
			startDate = DateUtils.addDays(endDate,-1);
		}
		//1.����ǽ����Ҳ���չʾȫ�죬���չʾ���3Сʱ
		if ( !isShowWholeDay && isToday(startDate)){
			startDate = DateUtils.addHours(new Date(), -showHourNumber);
			endDate = DateUtils.addSeconds(DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),1),-1);
		}	
		return Pair.of(startDate, endDate);
	}
	private void _queryDataForMultiView(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String app = request.getParameter("appName");
		String k1 = request.getParameter("k1");
		String k2 = request.getParameter("k2");
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		String valueType = request.getParameter("valueType");
		String wholeDay = request.getParameter("wholeDay");
		boolean isShowWholeDay = false;
		if ( !wholeDay.equals("null") ){
			isShowWholeDay = true;
		}
		int showHourNumber = 3;//Ĭ�������3Сʱ��
		k1 = UrlUtil.decodeUtf8(k1);
		if ( k2.equals("null") ){
			k2 = null;
		}
		k2 = UrlUtil.decodeUtf8(k2);
		Date endDate =  new Date();
		Date startDate = null;
		if ( sd != null && sd.equals("null") ){
			sd = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);
		}
		if ( ed != null && ed.equals("null") ){
			ed = "";
		}
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			startDate = null;
			endDate = DateUtils.addDays(CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3),1);
			startDate = DateUtils.addDays(endDate,-1);
		}
		//1.����ǽ����Ҳ���չʾȫ�죬���չʾ���3Сʱ
		if ( !isShowWholeDay && isToday(startDate)){
			startDate = DateUtils.addHours(new Date(), -showHourNumber);
			endDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()), 1);
		}
		//<ͼ,<����,List<��>>>
		Map<String,Map<String,LineObjDO>> results = new LinkedHashMap<String,Map<String,LineObjDO>>();
		SortedSet<MonitorLogNode> nodes1 = monitorLogQueryService.newQueryMonitorLogInfoOfApp(app,k1,startDate,startDate);
		if ( !nodes1.isEmpty() ){
			_addNodesResult(app,endDate, startDate, results, nodes1,valueType,k2);
		}
		PrintWriter out = response.getWriter();
		String str = DataBuilder.buildDataJson(results,DataBuilder.graphSizeMap.get("big"));
		outPut(out,str);
	}
	private void _addNodesResult(String app,Date endDate, Date startDate,
			Map<String, Map<String, LineObjDO>> results,
			SortedSet<MonitorLogNode> nodes1,String valueType,String k2) throws Exception {
		//���5��level2��ÿ��level���10����
		int maxLevel2=5;
		int maxLevel3=10;
		MonitorLogNode node = nodes1.iterator().next();
		//1.�ҵ�����Level2
		List<MonitorLogNode> level2s = new ArrayList<MonitorLogNode>(node.getChildren());
		if ( StringUtils.isNotBlank(k2) ){
			//1.1��ҪK2
			level2s = pickByK2(level2s,k2);
		}else{
			level2s = sortAndPickMaxN(level2s,maxLevel2,valueType);
		}
		if ( level2s == null ){
			return;
		}
		//2.����level2
		for ( MonitorLogNode n2:level2s){
			Map<String, LineObjDO> vvs = new HashMap<String,LineObjDO>();
			List<MonitorLogNode> level3s = new ArrayList<MonitorLogNode>(n2.getChildren());
			if ( level3s == null || level3s.isEmpty() ){
				continue;
			}
			level3s = sortAndPickMaxN(level3s, maxLevel3, valueType);
			for ( MonitorLogNode n3: level3s){
				String fullKey = n3.getFullKey();
				Map<Date, MonitorValue> value = monitorLogQueryService.newQueryHistoryData(app, 
						fullKey, startDate, endDate);
				vvs.put(n3.getSelfKey(), new LineObjDO(value,valueType));
			}
			results.put(node.getSelfKey()+"-"+n2.getSelfKey(), vvs);
		}
		//3.��ѡlevel1,��level2ʱ��level2����Ҳ��ͼ
		if ( StringUtils.isBlank(k2) ){
			Map<String, LineObjDO> vvs2 = new HashMap<String,LineObjDO>();
			for ( MonitorLogNode n2: level2s){
				String fullKey = n2.getFullKey();
	
				Map<Date, MonitorValue> value = monitorLogQueryService.newQueryHistoryData(app, 
						fullKey, startDate, endDate);
				vvs2.put(n2.getSelfKey(), new LineObjDO(value,valueType));
			}
			results.put(node.getSelfKey(), vvs2);
		}
	}
	private List<MonitorLogNode> pickByK2(List<MonitorLogNode> level2s, String k2) {
		for ( MonitorLogNode node:level2s ){
			if ( node.getSelfKey().equals(k2) ){
				return Arrays.asList(node);
			}
		}
		return null;
	}
	private List<MonitorLogNode> sortAndPickMaxN(List<MonitorLogNode> level2s, int maxLevel2,final String valueType) {
		Collections.sort(level2s, new Comparator<MonitorLogNode>(){
			@Override
			public int compare(MonitorLogNode o1, MonitorLogNode o2) {
				if ( valueType.equals("v1") ){
					return -(int)(o1.getValue1()-o2.getValue1());
				}else if ( valueType.equals("v2") ){
					return -(int)(o1.getValue2()-o2.getValue2());
				}else if ( valueType.equals("v1v2") ){
					return -(int)(o1.getV1v2()-o2.getV1v2());
				}else if ( valueType.equals("v2v1") ){
					return -(int)(o1.getV2v1()-o2.getV2v1());
				}
				return 0;
			}
		});
		return level2s.subList(0, Math.min(level2s.size(), maxLevel2) );
	}
	
	private String getKey(String[] decodedKeys) throws UnsupportedEncodingException{
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<decodedKeys.length; i++) {
			if(i>0){
				sb.append("" + (char)1);
			}
			sb.append(decodedKeys[i]);
		}
		String convertKeys = sb.toString();
		return convertKeys;
	}
	@RequestMapping("dumpMonitorLogDetail.htm")
	public String dumpMonitorLogDetail(final HttpServletRequest request, final HttpServletResponse response,ModelMap result) throws Exception {
		String day = request.getParameter("startDate");
		String end = request.getParameter("endDate");
		Map<Date, MonitorValue> results = _queryDataForMonitorLogDetail(request, response,day,end, false);
		String keys = SecurityUtil.escapeHtml(request.getParameter("keys"));
		String app = request.getParameter("appName");
		String valueType = SecurityUtil.escapeHtml(request.getParameter("valueType"));
		String[] decodedKeys = URLDecoder.decode(keys, "utf8").split("\\^");
		String keyDesc = "";
		for ( String d:decodedKeys ){
			keyDesc += d+"-";
		}
		response.setContentType("application/csv;charset=gb18030");
        response.setHeader("Content-Disposition","attachment; filename=\"" + app + "_"+valueType+"_KV_"+day+"~"+end + ".csv" + "\"");
		PrintWriter out = response.getWriter();
		out.printf("%s,valueType:%s,��%d����\n",keyDesc,valueType,results.size());
		Long total = 0l;
		for ( Map.Entry<Date, MonitorValue> ent:results.entrySet() ){
			String key = SecurityUtil.richtext(CalendarUtil.toString(ent.getKey(), CalendarUtil.TIME_PATTERN));
			if ( valueType.equals("v1") ){
				out.printf("%s,%d\n", key, ent.getValue().getValue1());
				total += ent.getValue().getValue1();
			}else if ( valueType.equals("v2") ){
				out.printf("%s,%d\n", key, ent.getValue().getValue2());
				total += ent.getValue().getValue2();
			}else if ( valueType.equals("v1v2") ){
				out.printf("%s,%f\n", key, ent.getValue().getV1v2());
			}else if ( valueType.equals("v2v1") ){
				out.printf("%s,%f\n", key, ent.getValue().getV2v1());
			}
		}
		if (valueType.equals("v1") || valueType.equals("v2")){
			out.printf("�����ܺ�:%d",total);
		}
		out.close();
		return null;
	}
	private void _queryDataForMonitorLog(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String keys = request.getParameter("keys");
		String[] decodedKeys = StringUtils.splitPreserveAllTokens(URLDecoder.decode(keys, "utf8"),'^');
		String valueType = request.getParameter("valueType");
		if ( decodedKeys.length == 6 ){
			valueType = "v1v2";//���⴦��by�س�,��������Key�����������ǿ�ƽ�valueType����Ϊv1v2
		}
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		Map<Date, MonitorValue> results = _queryDataForMonitorLogDetail(request, response,sd,ed,beta);
		//log.error("�����Ӳ鿴:"+JSON.toJSONString(results, SerializerFeature.PrettyFormat,SerializerFeature.WriteDateUseDateFormat));
		String sd2 = request.getParameter("startDate2");
		String ed2 = request.getParameter("endDate2");
		Map<String,Map<String,LineObjDO>> graphs = new LinkedHashMap<String,Map<String,LineObjDO>>();
		Map<String,String> chartTypes = new HashMap<String,String>();
		//1.build����ͼ
		Map<String,LineObjDO> normalG = new LinkedHashMap<String, LineObjDO>();
		Map<String,LineObjDO> columnG = new LinkedHashMap<String, LineObjDO>();
		graphs.put("", normalG);
		graphs.put("Сʱ�ۺ�ͼ", columnG);
		chartTypes.put("","spline");
		chartTypes.put("Сʱ�ۺ�ͼ","column");
		//1.1.���ӵ�һ��ͼ
		Map<Date,MonitorValue> aggHs = LineRetriver.aggDotOfHour(results);
		//log.error("�ۺϵ�Сʱ:"+JSON.toJSONString(aggHs, SerializerFeature.PrettyFormat,SerializerFeature.WriteDateUseDateFormat));
		if ( StringUtils.isNotBlank(sd2) && StringUtils.isNotBlank(ed2) && !sd2.equals("null") && !ed2.equals("null")){
			//1.��ȡ���Աȵ�����
			Map<Date, MonitorValue> results2 = _queryDataForMonitorLogDetail(request, response,sd2,ed2, beta);
			//2.��ȡ�ڶ����͵�һ�����ߵ����ʱ���
			getDayDiff(sd2,sd);//
			//3.ƴ���Map
			Map<Date, MonitorValue> secondV = LineRetriver.dateAddDays(results2,-getDayDiff(sd,sd2));
			Map<Date,MonitorValue> secondAggHs = LineRetriver.aggDotOfHour(secondV);
			String titleOne = getKey(sd,ed)+":"+DataBuilder.getLineName(decodedKeys)+"|"+valueType;
			String titleTwo = getKey(sd2,ed2)+":"+DataBuilder.getLineName(decodedKeys)+"|"+valueType;
			//��һ����
			normalG.put(titleOne,new LineObjDO(results,valueType));
			columnG.put(titleOne,new LineObjDO(aggHs,valueType));
			//�ڶ�����
			normalG.put(titleTwo,new LineObjDO(secondV,valueType));
			columnG.put(titleTwo,new LineObjDO(secondAggHs,valueType));
			//4.�ۼ�ֵ�Ա�
			if ( valueType.equals("v1") || valueType.equals("v2") ){
				Map<String,LineObjDO> accumG = new LinkedHashMap<String, LineObjDO>();//�ۼ�
				chartTypes.put("�ۻ�ͼ", "spline");
				graphs.put("�ۻ�ͼ", accumG);
				//������ͼ
				accumG.put(titleOne, new LineObjDO(DataBuilder.aggDots(results), valueType));
				accumG.put(titleTwo, new LineObjDO(DataBuilder.aggDots(secondV), valueType));
			}
			PrintWriter out = response.getWriter();
			String str = DataBuilder.buildDataJson(graphs,chartTypes, DataBuilder.defaultSize);
			outPut(out,str);

		}else{
			normalG.put(DataBuilder.getLineName(decodedKeys)+"|"+valueType,new LineObjDO(results,valueType));
			columnG.put(DataBuilder.getLineName(decodedKeys)+"|"+valueType,new LineObjDO(aggHs,valueType));
			//����
			PrintWriter out = response.getWriter();
			String str = DataBuilder.buildDataJson(graphs,chartTypes, DataBuilder.defaultSize);
			outPut(out,str);
		}
	}
	private void _queryDataForMonitorLogOfDay(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String keys = request.getParameter("keys");
		String[] decodedKeys = StringUtils.splitPreserveAllTokens(URLDecoder.decode(keys, "utf8"),'^');
		String valueType = request.getParameter("valueType");
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		Map<Date, MonitorValue> results = _queryDataForMonitorLogOfDay(request, response,sd,ed,beta);
		Map<String,Map<String,LineObjDO>> graphs = new LinkedHashMap<String,Map<String,LineObjDO>>();
		Map<String,String> chartTypes = new HashMap<String,String>();
		//1.build����ͼ
		Map<String,LineObjDO> normalG = new LinkedHashMap<String, LineObjDO>();
		Map<String,LineObjDO> columnG = new LinkedHashMap<String, LineObjDO>();
		graphs.put("", normalG);
		graphs.put("��״ͼ", columnG);
		chartTypes.put("","spline");
		chartTypes.put("��״ͼ","column");
		//1.2���Key��6����valueTypeǿ��Ϊv1v2
		if ( decodedKeys.length == 6){
			valueType = "v1v2";
		}
		normalG.put(DataBuilder.getLineName(decodedKeys)+"|"+valueType,new LineObjDO(results,valueType));
		columnG.put(DataBuilder.getLineName(decodedKeys)+"|"+valueType,new LineObjDO(results,valueType));
		//����
		PrintWriter out = response.getWriter();
		String str = DataBuilder.buildDataJson(graphs,chartTypes, DataBuilder.defaultSize);
		outPut(out,str);
	}
	/*
	 * sd:С��
	 * sd2:����
	 */
	private int getDayDiff(String sd, String sd2) {
		Date end = CalendarUtil.toDate(sd2, CalendarUtil.DATE_FMT_3);
		Date begin = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
		int intervalDays = CalendarUtil.getIntervalDays(begin, end);
		return intervalDays;
	}

	private String getKey(String sd,String ed){
		Pair<Date,Date> pp = getDateFromRequest(sd, ed);
		return CalendarUtil.toString(pp.getLeft(), CalendarUtil.DATE_FMT_0)
				+"~"
				+ CalendarUtil.toString(pp.getRight(), CalendarUtil.DATE_FMT_0);
	}
	private Pair<Date,Date> getDateFromRequest(String sd,String ed){
		Date endDate =  new Date();
		Date startDate = null;
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) 
			&&	!"null".equals(sd) && !"null".equals(ed)
				){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			//if ( groupby.equals("day") ){
				startDate = DateUtils.addDays(endDate,-1);
			//}else if ( groupby.equals("week") ){
			//	startDate = DateUtils.addDays(endDate,-7);
			//}else if ( groupby.equals("month") ){
			//	startDate = DateUtils.addDays(endDate,-31);
		   //}
		}
		return Pair.of(startDate, endDate);
	}
	private Map<Date, MonitorValue>  _queryDataForMonitorLogDetail(HttpServletRequest request, HttpServletResponse response, String sd, String ed, boolean beta) throws Exception {
		String appName = request.getParameter("appName");
		String appName2 = request.getParameter("appName2");
		String vt = request.getParameter("valueType");
		String vt2 = request.getParameter("valueType2");
		String keys = request.getParameter("keys");
		String groupby = request.getParameter("groupby");
		String mday = request.getParameter("mday");
		String mday2 = request.getParameter("mday2");
		int nday = 0;//����ƫ����
		int nday2 = 0;
		if ( StringUtils.isNotBlank(mday)  && !mday.equals("null") ){
			nday = Integer.valueOf(mday);
		}
		if ( StringUtils.isNotBlank(mday2)  && !mday2.equals("null") ){
			nday2 = Integer.valueOf(mday2);
		}
		Pair<Date,Date> dd = getDateFromRequest(sd,ed);
		Date startDate = dd.getLeft();
		Date endDate = dd.getRight();

		String kstr = URLDecoder.decode(keys, "utf8");
		String[] decodedKeys  = StringUtils.splitPreserveAllTokens(kstr, '^');

		if ( groupby.equals("day") || groupby.equals("week") ){
			return monitorLogLineManager.queryMonitorData(appName, appName2,vt,vt2, decodedKeys, startDate, endDate,nday,nday2,beta);
		}else if ( groupby.equals("month") ){
		}
		return null;
	}
	private Map<Date, MonitorValue>  _queryDataForMonitorLogOfDay(HttpServletRequest request, HttpServletResponse response, String sd, String ed, boolean beta) throws Exception {
		String appName = request.getParameter("appName");
		String keys = request.getParameter("keys");
		String appName2 = request.getParameter("appName2");
		String vt = request.getParameter("valueType");
		String vt2 = request.getParameter("valueType2");
		Pair<Date,Date> dd = getDateFromRequest(sd,ed);
		Date startDate = dd.getLeft();
		Date endDate = dd.getRight();
		String mday = request.getParameter("mday");
		String mday2 = request.getParameter("mday2");
		int nday = 0;//����ƫ����
		int nday2 = 0;
		if ( StringUtils.isNotBlank(mday)  && !mday.equals("null") ){
			nday = Integer.valueOf(mday);
		}
		if ( StringUtils.isNotBlank(mday2)  && !mday2.equals("null") ){
			nday2 = Integer.valueOf(mday2);
		}
		String kstr = URLDecoder.decode(keys, "utf8");
		String[] decodedKeys  = StringUtils.splitPreserveAllTokens(kstr, '^');
		
		Long td = endDate.getTime() - startDate.getTime();
		if ( td > 365*24*60*60*1000l ){// ����һ��
			startDate = DateUtils.addYears(endDate, -1);
		}
		return monitorLogLineManager.queryMonitorDataOfDay(appName, appName2,vt,vt2,decodedKeys, startDate, endDate,nday,nday2,beta);
	}
	public static void main(String[] args) {
		String bb = "abcd^ddd^";
		System.out.println(bb.split("^").length);
	}

	private void _queryDataForHsfMonitorLog(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String appName = request.getParameter("appName");
		String keys = request.getParameter("keys");
		String valueType = request.getParameter("valueType");
		String groupby = request.getParameter("groupby");
		String sd = request.getParameter("startDate");
		String ed = request.getParameter("endDate");
		String betaStr = SecurityUtil.escapeHtml(request.getParameter("beta"));
		//�ж��Ƿ�beta
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		Date endDate =  new Date();
		Date startDate = null;
		if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed) ){
			startDate = CalendarUtil.toDate(sd, CalendarUtil.DATE_FMT_3);
			endDate = CalendarUtil.toDate(ed, CalendarUtil.DATE_FMT_3);
		}else{
			if ( groupby.equals("day") ){
				startDate = DateUtils.addDays(endDate,-1);
			}else if ( groupby.equals("week") ){
				startDate = DateUtils.addDays(endDate,-7);
			}else if ( groupby.equals("month") ){
				startDate = DateUtils.addDays(endDate,-31);
			}
		}
		
		String[] decodedKeys = URLDecoder.decode(keys, "utf8").split("\\^");
		Map<Date, MonitorValue> results = monitorLogLineManager.queryHsfData(appName,decodedKeys,startDate,endDate,beta);
		String sd2 = request.getParameter("startDate2");
		String ed2 = request.getParameter("endDate2");
		HsfVO hsfV = new HsfVO();
		hsfV.setApp(appName);
		hsfV.setNode(new KeysDO(decodedKeys));
		hsfV.setVt(valueType);
		//1.build����ͼ
		Map<String,Map<String,LineObjDO>> graphs = new LinkedHashMap<String,Map<String,LineObjDO>>();
		Map<String,String> chartTypes = new HashMap<String,String>();
		Map<String,LineObjDO> normalG = new LinkedHashMap<String, LineObjDO>();
		Map<String,LineObjDO> columnG = new LinkedHashMap<String, LineObjDO>();
		graphs.put("", normalG);
		graphs.put("Сʱ�ۺ�ͼ", columnG);
		chartTypes.put("","spline");
		chartTypes.put("Сʱ�ۺ�ͼ","column");
		//1.1.���ӵ�һ��ͼ
		Map<Date,MonitorValue> aggHs = LineRetriver.aggDotOfHour(results);
		Pair<Date,Date> pp2 = this.getDateFromRequest(sd2, ed2);
		if ( StringUtils.isNotBlank(sd2) && StringUtils.isNotBlank(ed2) && !sd2.equals("null") && !ed2.equals("null")){
			//1.��ȡ���Աȵ�����
			Map<Date, MonitorValue> results2 = monitorLogLineManager.queryHsfData(appName, decodedKeys, pp2.getLeft(), pp2.getRight(), beta);
			//2.��ȡ�ڶ����͵�һ�����ߵ����ʱ���
			getDayDiff(sd2,sd);//
			//3.ƴ���Map
			Map<Date, MonitorValue> secondV = LineRetriver.dateAddDays(results2,-getDayDiff(sd,sd2));
			Map<Date,MonitorValue> secondAggHs = LineRetriver.aggDotOfHour(secondV);
			String titleOne = getKey(sd,ed)+":"+hsfV.getDescForGraph();
			String titleTwo = getKey(sd2,ed2)+":"+hsfV.getDescForGraph();
			//��һ����
			normalG.put(titleOne,new LineObjDO(results,valueType));
			columnG.put(titleOne,new LineObjDO(aggHs,valueType));
			//�ڶ�����
			normalG.put(titleTwo,new LineObjDO(secondV,valueType));
			columnG.put(titleTwo,new LineObjDO(secondAggHs,valueType));
			//4.�ۼ�ֵ�Ա�
			if ( valueType.equals("v1") || valueType.equals("v2") ){
				Map<String,LineObjDO> accumG = new LinkedHashMap<String, LineObjDO>();//�ۼ�
				chartTypes.put("�ۻ�ͼ", "spline");
				graphs.put("�ۻ�ͼ", accumG);
				//������ͼ
				accumG.put(titleOne, new LineObjDO(DataBuilder.aggDots(results), valueType));
				accumG.put(titleTwo, new LineObjDO(DataBuilder.aggDots(secondV), valueType));
			}
			String str = DataBuilder.buildDataJson(graphs,chartTypes, DataBuilder.defaultSize);
			outPut(response.getWriter(),str);

		}else{
			normalG.put(hsfV.getDescForGraph(),new LineObjDO(results,valueType));
			columnG.put(hsfV.getDescForGraph(),new LineObjDO(aggHs,valueType));
			String str = DataBuilder.buildDataJson(graphs,chartTypes, DataBuilder.defaultSize);
			outPut(response.getWriter(),str);
		}
	}
	private void _queryDataForError(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String appName = request.getParameter("appName");
		String md5 = request.getParameter("md5");
		String groupby = request.getParameter("groupby");
		String endTime = request.getParameter("endDate");
		String beginTime = request.getParameter("beginTime");
		if(StringUtils.isBlank(beginTime) || beginTime.equals("null")){
			beginTime = CalendarUtil.toString(CalendarUtil.zerolizedTime(new Date()),"yyyy-MM-dd HH:mm");
		}
		Date beginTimeStr =  CalendarUtil.toDate(UrlUtil.decode(beginTime), "yyyy-MM-dd HH:mm");
		if ( beginTimeStr == null ){
			beginTimeStr =  CalendarUtil.toDate(UrlUtil.decode(beginTime), "yyyy-MM-dd");
		}
		Date endTimeStr = null;
		if(StringUtils.isBlank(endTime) || endTime.equals("null")){
			endTimeStr = DateUtils.addDays(beginTimeStr, 1);
		}else{
			endTimeStr =  CalendarUtil.toDate(UrlUtil.decode(endTime), "yyyy-MM-dd");
		}
		int interDay =  CalendarUtil.getIntervalDays(beginTimeStr, endTimeStr) ;
		if ( interDay > 30 ){
			groupby = "day";
		}else if ( interDay > 7 ){
			groupby = "hour";
		}else{
			groupby = "min";
		}
		PrintWriter out = response.getWriter();
		List<GeneralErrorDetailStatDO> stats = null;
		if ( groupby.equals("min") ){
			stats = generalErrorLogSearchService.getErrorDetailStat(appName, md5, 
					beginTimeStr,
					endTimeStr,
				TimePeriodEnum.ONEM
				);
		}else if ( groupby.equals("day") ){
			stats = generalErrorLogSearchService.getErrorDetailStat(appName, md5, 
					beginTimeStr,
					endTimeStr,
				TimePeriodEnum.ONED
				);
		}else if ( groupby.equals("hour") ){
			stats = generalErrorLogSearchService.getErrorDetailStat(appName, md5, 
					beginTimeStr,
					endTimeStr,
				TimePeriodEnum.ONEH
				);
		}
		if ( stats == null ){
			return;
		}
		String str = DataBuilder.buildDataJsonForError(md5, stats);
		outPut(out,str);
	}
	


}
