package com.taobao.ateye.controller.download;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;

/**
 * Created by wanglin on 15/6/10.
 */
@Controller
@RequestMapping("/extra")
public class DownloadController {

    private static Logger logger = Logger.getLogger(DownloadController.class);

    @Autowired
    private UrlGenerator urlGenerator;

    @Autowired
    private OpsServic opsServic;

    public static final String _DOWNLOAD_MACHINE_LIST = "screen/extra/machineList2";
    public static final String _DOWNLOAD_FILE = "screen/extra/downloadFile";

    @RequestMapping("downloadMachineList.htm")
    public String downloadMachineList(final HttpServletRequest request, ModelMap result) throws Exception {
        String app = request.getParameter("app");
        List<MachineDO> machines = opsServic.getAllMachinesBelongToAnApp(app);
        result.put("machines", machines);
        result.put("app", app);
        return _DOWNLOAD_MACHINE_LIST;
    }

    @RequestMapping("downloadFile.htm")
    public String downloadFile(final HttpServletRequest request, ModelMap result) throws Exception {
        String app = request.getParameter("app");
        String machineName = request.getParameter("machineName");
        String ip = request.getParameter("ip");
        String port = request.getParameter("port");
        result.put("app", app);
        result.put("machineName", machineName);
        result.put("ip" , ip);
        result.put("port", port);
        return _DOWNLOAD_FILE;
    }

    @RequestMapping("download.do")
    public String downloadFile(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        String ip = request.getParameter("ip");
        String port = request.getParameter("port");
        String path = request.getParameter("path");
        String large = request.getParameter("large");
        String name = null;
        if(org.apache.commons.lang3.StringUtils.isNotBlank(path) && path.lastIndexOf("/") != -1) {
            name = path.substring(path.lastIndexOf("/") + 1);
        }
        final String f_name = name;

        Map<String, String> params = new HashMap<String, String>();
        params.put("type", "DOWNLOAD");
        params.put("path", path);
        params.put("large", large);

        String url = "";
        try {
            url = urlGenerator.getUrl(ip, port, params);
        } catch (Exception e1) {
            return null;
        }

        HttpClientUtil.processResult(url, new HttpClientUtil.CallBack() {

            private void outputErrorMsg(String errorMsg) {
                try {
                    response.setContentType("text/plain");
                    response.getWriter().println(errorMsg);
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public void doJob(HttpMethod httpMethod) {
                Header header = httpMethod.getResponseHeader("Content-Type");
                if(header != null) {
                    String contentType = header.getValue();
                    if(StringUtils.isBlank(contentType)) {
                        outputErrorMsg("Content-Type����Ϊ��");
                    } else {
                        if(contentType.contains("application/octet-stream")) { //�ɹ������˶�����������
                            InputStream inputStream = null;
                            OutputStream outputStream = null;
                            try {
                                response.setHeader("Content-Disposition", "attachment; filename=\"" + f_name + "\"");
                                response.setContentType("application/octet-stream");
                                inputStream = httpMethod.getResponseBodyAsStream();
                                outputStream = response.getOutputStream();
                                IOUtils.copy(inputStream, outputStream);
                            } catch(IOException e) {
                                logger.error("��ȡAgent���ض������������쳣", e);
                            } finally {
                                IOUtils.closeQuietly(inputStream);
                                IOUtils.closeQuietly(outputStream);
                            }
                        } else if(contentType.contains("text/plain")) {//agent�˷����˴�����ʾ��Ϣ
                            try {
                                String agentErrorMsg = httpMethod.getResponseBodyAsString();
                                outputErrorMsg(agentErrorMsg);
                            } catch (Exception e) {
                                outputErrorMsg("��ȡAgent����ErrorMsg�쳣:" + e.getMessage());
                            }
                        } else {//�쳣���
                            outputErrorMsg("Unknown content type: " + contentType);
                        }
                    }
                } else {
                    outputErrorMsg("Content-Type header not found!");
                }
            }

        });
        return null;
    }

}
