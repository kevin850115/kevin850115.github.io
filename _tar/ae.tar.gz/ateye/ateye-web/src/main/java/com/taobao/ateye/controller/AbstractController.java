package com.taobao.ateye.controller;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.changefree.ApproveManager;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.alarm.log.AlarmLogModelManager;
import com.taobao.ateye.app.AppModelManager;
import com.taobao.ateye.app.model.AppModelListDO;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.cache.UserCache;
import com.taobao.ateye.changelog.AppChangeLogService;
import com.taobao.ateye.chg.ChangeManager;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.config.app.impl.AppExtendManager;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.BizLineDAO;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dal.SceneCatDAO;
import com.taobao.ateye.dal.SceneEntryPointDAO;
import com.taobao.ateye.dal.SceneLevelDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.SceneEntryPoint;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.db.DbManager;
import com.taobao.ateye.db.TairModelManager;
import com.taobao.ateye.db.model.DbModelListDO;
import com.taobao.ateye.db.model.TairModelListDO;
import com.taobao.ateye.diamond.impl.AppDomainList;
import com.taobao.ateye.diamond.impl.AppStatusList;
import com.taobao.ateye.diamond.impl.AppTypeList;
import com.taobao.ateye.diamond.impl.GroupAppWhiteList;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.goc.GocFaultManager;
import com.taobao.ateye.goc.emg.GocEmgManager;
import com.taobao.ateye.kv.KvGraphManager;
import com.taobao.ateye.kv.KvGraphMonitorItemDO;
import com.taobao.ateye.realtime.RealTimeRecordManager;
import com.taobao.ateye.realtime.RealTimeRecordModelListDO;
import com.taobao.ateye.scene.manager.SceneEntryManager;
import com.taobao.ateye.scene.manager.SceneEntryModel;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.sim.SimModelManager;
import com.taobao.ateye.ssql.SSqlManager;
import com.taobao.ateye.ssql.SSqlModelListDO;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.ateye.util.MobileUtil;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.tracker.generalerror.service.GeneralErrorLogSearchService;

public abstract class AbstractController{
	
    protected Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    protected AppDAO appDAO;
    @Autowired
    protected MachineDAO machineDAO;
    @Autowired
    protected EnvironmentService environmentService;
	@Autowired
	protected KvGraphManager kvGraphManager;
	@Autowired
	protected AppExtendManager appExtendManager;
    @Autowired
    protected OpsServic opsServic;
    @Autowired
    protected AppChangeLogService appChangeLogService;
	@Autowired
	protected BizLineDAO bizLineDAO;
	@Autowired
	protected UserCache userCache;
	@Autowired
	protected SceneLevelDAO sceneLevelDAO;
	@Autowired
	protected SceneEntryPointDAO sceneEntryPointDAO;
	@Autowired
	protected SceneCatDAO sceneCatDAO;
	@Autowired
	protected AppModelManager appModelManager;
	@Autowired
	protected SceneEntryManager sceneEntryManager;
	@Autowired
	protected GeneralErrorLogSearchService generalErrorLogSearchService;
	@Autowired
	protected AteyeConfig ateyeConfig;
	@Autowired
	protected DbManager dbManager;
	@Autowired
	protected TairModelManager tairModelManger;
	@Autowired
	protected GroupAppWhiteList groupAppWhiteList;
	@Autowired
	protected ChangeManager changeManager;
	@Autowired
	protected SSqlManager ssqlManager;
	@Autowired
	protected GocFaultManager gocFaultManager;
	@Autowired
	protected GocEmgManager gocEmgManager;
	@Autowired
	protected RealTimeRecordManager realTimeRecordManager;
	@Autowired
	protected SimModelManager simModelManager;
	@Autowired
	protected AppTypeList appTypeList;
	@Autowired
	protected AppDomainList appDomainList;
	@Autowired
	protected AppStatusList appStatusList;
	@Autowired
	protected AlarmLogModelManager alarmLogModelManager;

	@Autowired
	protected ApproveManager approveManager;

	
    private static String KV_ITEM_TYPE = "KV";

    private static final String validUrls = "alibaba-inc.com,alitrip.net,alitrip.com,taobao.com,taobao.net,fliggy.com,taobao.org,fliggy.net";

    private static List<Pattern> validUrlPatterns = new ArrayList<Pattern>();

    static {
        String[] patternStrs = validUrls.split(",");

        for (String patternStr : patternStrs) {
            validUrlPatterns.add(Pattern.compile(".*(" + patternStr + "/){1}.*"));
        }

    }
    protected SceneEntryPoint getEntryPointByName(String name) throws DAOException{
    	List<SceneEntryPoint> entryPoints = sceneEntryPointDAO.getEntryPointByName(name, environmentService.getEnvironmentType().getEnv());
		if ( entryPoints.size() == 1) {
			return entryPoints.get(0);
		}else if ( entryPoints.size() > 1 ) {
			for (SceneEntryPoint sep:entryPoints ) {//����������ƽ̨����HSF֮��
				if ( StringUtils.isNotBlank(sep.getClientAppName()) ) {
					return sep;
				}
			}
		}
		return null;
    }
	protected void buildAppsInfos(ModelMap result, Set<String> ownApps,int bizId)
			throws Exception, DAOException {
		{
			Map<String, String> flts = new HashMap<String,String>();;
			flts.put("app", StringUtils.join(ownApps,","));
			AppModelListDO appList = appModelManager.queryAppList(flts);
			result.put("bizMap",getBizMap());
			result.put("appList",appList);
			result.put("appsCnt", appList.getRetList().size());
			result.put("serversCnt",appList.getServerCount());
			result.put("apps",appList.getTopNRetList(7));
			result.put("empIdMap",userCache.getEmpIdMap());
			//2.��ȡ������ĳ���
			SceneEntryModel model = sceneEntryManager.getEntryList(flts);
			result.put("hourStr",CalendarUtil.toString(new Date(), "HH:")+"00");
			result.put("entrys",model.getTopNRetList(10));
			result.put("entryCnt",model.getRetList().size());
			result.put("model",model);
			result.put("allCats",sceneCatDAO.getAllMap());
			result.put("allLevels", sceneLevelDAO.getAllMap());
			//3.��ҳչʾ��дģʽ
			result.put("fullShow", "false");
			//4.��ȡ�������DB
			DbModelListDO dbList = dbManager.queryDb(ownApps);
			result.put("dbList",dbList.getRetList());
			TairModelListDO tairList = tairModelManger.queryTair(ownApps);
			result.put("tairList",tairList.getGroups());
			//5.��ȡ��֧�ŵĳ����б�
			Map<String, String> sptFlts = new HashMap<String,String>();
			SceneEntryModel supportModel = sceneEntryManager.getAppSupportEntryList(ownApps,sptFlts);
			if ( supportModel != null){
				result.put("supportEntrys",supportModel.getTopNRetList(10));
				result.put("supportEntryCnt",supportModel.getRetList().size());
				result.put("supportModel",supportModel);
			}
		}
		//5.����б�
		{
			Map<String, String> flts = new HashMap<String,String>();;
			if ( bizId == -1 ){
				flts.put("app", StringUtils.join(ownApps,","));
			}else{
				flts.put("biz", String.valueOf(bizId));//ҵ���߰�ҵ����ά������,�ܹ���Ӧ���⣬����Ա����ϢҲ�����ȥ
			}
			ChangeModelListDO changeList = changeManager.queryChangeList(flts, CalendarUtil.zerolizedTime(new Date()), new Date());
			result.put("changes",changeList.getTopNRetList(7));
			result.put("changeCnt",changeList.getRetList().size());
			
			SSqlModelListDO sList = ssqlManager.querySSqlList(flts);
			if ( sList != null ){
				result.put("ssqlList", sList.getTopNRetList(7));
				result.put("slowSqlCnt",sList.getRetList().size());
			}
			
			RealTimeRecordModelListDO rtrList = realTimeRecordManager.queryRealTimeRecordList(flts, new Date());
			if ( rtrList != null ){
				result.put("rtrList",rtrList.getTopNRetList(10));
				result.put("rtrCnt",rtrList.getRetList().size());
			}
		}
		//6.�����б�
		/*
		{
			Map<String, String> flts = new HashMap<String,String>();;
			flts.put("app", StringUtils.join(ownApps,","));
			AlarmLogModelListDO alarmLogList = alarmLogModelManager.queryCurrentHourLogList(flts);
			if ( alarmLogList != null ){
				result.put("alarmLogList",alarmLogList.getTopNRetList(7));
				result.put("alarmLogCnt",alarmLogList.getRetList().size());
			}
		}
		*/
	}	
	protected List<List<KvGraphMonitorItemDO>> buildArr(Map<String, List<KvGraphMonitorItemDO>> items) {
		List<List<KvGraphMonitorItemDO>> ret = new ArrayList<List<KvGraphMonitorItemDO>>();
		Collection<List<KvGraphMonitorItemDO>> values = items.values();
		for(List<KvGraphMonitorItemDO> it:values ){
			ret.add(it);
		}
		return ret;
	}

	protected Date stringToDate(String start_time, String hhmm) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(StringUtils.isNotBlank(hhmm) ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd");
		Date dat = format.parse(start_time + (StringUtils.isNotBlank(hhmm) ? (" " + hhmm) : ""));
		return dat;
	}
	/*
	 * ������Ĭ�Ϸ���
	 */
	protected Set<String> getExtendNodeGroups(String app,List<MachineDO> machines){
		Set<String> ret = new HashSet<String>();
		if ( !groupAppWhiteList.isInWhiteList(app) ){
			return ret;
		}
		Set<String> grps = new HashSet<String>(); 
		for ( MachineDO md:machines ){
			if ( StringUtils.isNotBlank(md.getNodeGroup()) ){
				grps.add(md.getNodeGroup());
			}
		}
		for ( String grp:grps ){
			if ( grp.equals(app+"host") ){
				continue;
			}
			ret.add(app+":"+grp);
		}
		return ret;
	}	
    protected Map<Integer,BizLineDO> getBizMap() throws DAOException {
		List<BizLineDO> bizs = bizLineDAO.getAllBizLineList();
		Map<Integer,BizLineDO> ret = new HashMap<Integer,BizLineDO>();
		for ( BizLineDO bld:bizs ){
			ret.put(new Long(bld.getId()).intValue(), bld);
		}
		return ret;
	}
    protected List<Pair<Long,Integer>> formatToLong(List<Pair<String,Integer>> mm){
		List<Pair<Long, Integer>> ret = new ArrayList<Pair<Long,Integer>>();
		if(CollectionUtils.isEmpty(mm)){
			return ret;
		}
		for (Pair<String, Integer> ent:mm ){
			if (ent.getLeft()!=null){
				try{
					Long left = Long.valueOf(ent.getLeft());
					ret.add(Pair.of(left, ent.getRight()));
				}catch(Throwable t){
					;//
				}
			}
		}
		return ret;
	}
    protected List<Pair<Integer,Integer>> formatToInt(List<Pair<String,Integer>> mm){
		List<Pair<Integer, Integer>> ret = new ArrayList<Pair<Integer,Integer>>(); 
		if ( mm == null ){
			return ret;
		}
		for (Pair<String, Integer> ent:mm ){
			if ( ent.getLeft()!= null ){
				ret.add(Pair.of(Integer.valueOf(ent.getLeft()), ent.getRight()));
			}
		}
		return ret;
	}
    protected List<Pair<Integer,Integer>> formatToInt(List<Pair<String,Integer>> mm,Map<Integer,BizLineDO> allBiz){
    	List<Pair<Integer,Integer>> ret = formatToInt(mm);
    	Set<Integer> bizs = allBiz.keySet();
    	for (Pair<Integer,Integer> bp:ret ){
    		bizs.remove(bp.getKey());
    	}
    	for (Integer biz:bizs ){
    		ret.add(Pair.of(biz, -1));
    	}
		return ret;
	}
    protected Date getDay(final HttpServletRequest request,ModelMap result) throws ParseException{
		String day = request.getParameter("day");
		if ( day == null ){
			String formatToDay = DateFormatUtil.formatToDay(new Date());
			result.put("current",formatToDay);
			return DateFormatUtil.parseByDay(formatToDay);
		}
		result.put("current",day);
		return CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
	}
    protected Pair<Date,Date> getTimeRange(final HttpServletRequest request,ModelMap result) throws ParseException{
		String ed = request.getParameter("ed");
		String sd = request.getParameter("sd");
		Date sdObj = null;
		Date edObj = null;
		if ( StringUtils.isBlank(ed) && StringUtils.isBlank(sd) ){
			edObj = new Date();
			sdObj = DateUtils.addMinutes(edObj, -30);
		}else if ( StringUtils.isBlank(sd) && StringUtils.isNotBlank(ed)){
			edObj = DateFormatUtil.parseByMinute(ed);
			sdObj = DateUtils.addMinutes(edObj, -30);
		}else if ( StringUtils.isNotBlank(sd) && StringUtils.isBlank(ed)){
			sdObj = DateFormatUtil.parseByMinute(sd);
			edObj = DateUtils.addMinutes(sdObj, 30);
		}else if ( StringUtils.isNotBlank(sd) && StringUtils.isNotBlank(ed)){
			sdObj = DateFormatUtil.parseByMinute(sd);
			edObj = DateFormatUtil.parseByMinute(ed);
		}
		result.put("ed",DateFormatUtil.formatToMinute(edObj));
		result.put("sd",DateFormatUtil.formatToMinute(sdObj));
		return Pair.of(sdObj, edObj);
	}
    /*
     * ����ȡ��ǰ�û���Ȩ�޵�Ӧ��
     */
    protected Map<String, List<List<String>>> initBizMapOwned(ModelMap result) throws DAOException {
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return null;
        }
        List<AppDO> appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
        result.put("allApps", appDOList);
        return initBizMap(result, appDOList);
    }


    /**
     * Modified by dongbi for fix the security bug:
     * http://security.alibaba-inc.com/vul/status.htm?vulNumber=ALIBABA-2016-07160&lvf=56ce2c90-800e-47c8-8416-7a1b4ea85b45
     *
     * @param request
     * @param response
     * @return
     * @throws UnsupportedEncodingException
     */
    protected String getRedirectUrl(final HttpServletRequest request, final HttpServletResponse response) throws UnsupportedEncodingException {
        String returnUrl = request.getParameter("returnUrl");
        return "redirect:" + UrlUtil.decode(getValidReturnUrl(returnUrl));
    }
    protected String getRedirectUrl(final HttpServletRequest request) throws UnsupportedEncodingException {
        String returnUrl = request.getParameter("returnUrl");
        return "redirect:" + UrlUtil.decode(getValidReturnUrl(returnUrl));
    }

    protected void putV(String k, final HttpServletRequest request, ModelMap result) {
        String v = request.getParameter(k);
        if (StringUtil.isNotBlank(v)) {
            result.put(k, v);
        }
    }

    public void setIsMobile(final HttpServletRequest request, final ModelMap result) {
        result.put("_mobile_", MobileUtil.isMobile(request));
    }

    /*
     * ��ȡ����Ӧ��
     */
    protected String getKVItemType(String app) {
        return KV_ITEM_TYPE + "_" + app;
    }

    protected String getWholeUrl(HttpServletRequest request) {
        return getWholeUrl(request, "");
    }

    protected String getWholeUrl(HttpServletRequest request, String extraParam) {
        try {
        	if(StringUtils.isEmpty(request.getQueryString()) && StringUtils.isEmpty(extraParam)){
				return request.getRequestURL().toString()+"?";
			}
            return request.getRequestURL() + "?" + UrlUtil.encode(request.getQueryString() + extraParam);
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }

    protected Map<String, List<List<String>>> initBizMap(ModelMap result) {
        //1.����Ӧ��
        List<AppDO> allApps = Collections.EMPTY_LIST;
        try {
            allApps = appDAO.getAllAppAsList();
        } catch (DAOException e) {
            e.printStackTrace();
            return null;
        }
        Map<String, List<List<String>>> bizMap = initBizMap(result, allApps);
        //3.ÿ��Ӧ�÷��䲻ͬ��ɫ
        ColorUtil.assignColor(result, bizMap.keySet(), "biz");
        return bizMap;
    }
	  /*<ҵ��,[ [ Ӧ����,����] ] >*/
    /*
    public Map<String, List<List<String>>> initBizMap(ModelMap result, List<AppDO> appList) {
        Set<String> existApps = new HashSet<String>();
        for (AppDO appDO : appList) {
            existApps.add(appDO.getAppName());
        }
        result.put("existApps", existApps);//�Ѵ��ڵ�����Ӧ��
        Map<String, List<List<String>>> bizApps = appsManager.getSortedApps();
  

        List<List<String>> unknowns = bizApps.get("δ֪");
        if (!CollectionUtils.isEmpty(unknowns)) {
            for (List<String> app : unknowns) {
                app.set(1, "?");
            }
            bizApps.remove("δ֪");
            bizApps.put("δ֪", unknowns);
        }

        //�����Ӧ�ã�����ʾҵ����
        Iterator<Entry<String, List<List<String>>>> iterator = bizApps.entrySet().iterator();
        while (iterator.hasNext()) {
            Entry<String, List<List<String>>> ent = iterator.next();
            boolean hasOne = false;
            if (ent.getValue() != null) {
                for (List<String> appDesc : ent.getValue()) {
                    if (existApps.contains(appDesc.get(0))) {
                        hasOne = true;
                        break;
                    }
                }
            }
            if (!hasOne) {
                iterator.remove();
            }
        }
        result.put("bizMap", bizApps);//��ҵ����ά��������Ӧ���б�
        return bizApps;
    }
    */
    protected String getBizName(AppDO app,Map<Long, BizLineDO> allBizLineMap){
    	String productName = "δ֪";
    	Integer bizType = app.getBizType();
    	if ( bizType == null ){
    		return productName;
    	}
    	BizLineDO bizLineDO = allBizLineMap.get(bizType.longValue());
    	if (bizLineDO == null ){
    		return productName;
    	}
    	return bizLineDO.getName();
    }
	  /*<ҵ��,[ [ Ӧ����,����] ] >*/
    public Map<String, List<List<String>>> initBizMap(ModelMap result, List<AppDO> appList) {
        Set<String> existApps = new HashSet<String>();
        for (AppDO appDO : appList) {
            existApps.add(appDO.getAppName());
        }
        result.put("existApps", existApps);//�Ѵ��ڵ�����Ӧ��
        Map<String, List<List<String>>> bizApps = new HashMap<String,List<List<String>>>();
        try {
        	Map<Long, BizLineDO> allBizLineMap = bizLineDAO.getAllBizLineMap();
			List<AppDO> allAppAsList = appDAO.getAllAppAsList();
			for (AppDO app:allAppAsList) {
				String productName = getBizName(app,allBizLineMap);
				if ( StringUtils.isBlank(productName) ){
					productName = "δ֪";
				}
				List<List<String>> list = bizApps.get(productName);
				if ( list == null ){
					list = new ArrayList<List<String>>();
					bizApps.put(productName,list);
				}
				list.add(Arrays.asList(app.getAppName(),app.getAppAlias()));
			}
		} catch (DAOException e) {
			log.error("��ȡDAOʧ��",e);
			return bizApps;
		}
        result.put("bizMap", bizApps);//��ҵ����ά��������Ӧ���б�
        return bizApps;
    }

    /**
     * According to the security scan check,
     * only support patthens like  '*.alibaba-inc.com/*,
     * *.alitrip.net/*,
     * *.alitrip.com/*'
     *
     * @param returnUrl
     * @return
     */
    protected String getValidReturnUrl(String returnUrl) {

        if (StringUtils.isBlank(returnUrl))
            return returnUrl;

        for (Pattern pattern : validUrlPatterns) {
            Matcher matcher = pattern.matcher(returnUrl);

            if (matcher.matches())
                return returnUrl;
        }
        return "";
    }


}
