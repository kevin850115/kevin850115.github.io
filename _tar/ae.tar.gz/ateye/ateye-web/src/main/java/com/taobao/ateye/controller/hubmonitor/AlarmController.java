package com.taobao.ateye.controller.hubmonitor;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.alarm.n.manager.SyncHbaseAlarmManager;
import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.taobao.ateye.alarm.config.AbstractAlarmConfig;
import com.taobao.ateye.alarm.config.RuleTypeConstant;
import com.taobao.ateye.alarm.detector.AbstractAlarmRuleDetector;
import com.taobao.ateye.alarm.manager.AlarmGroupManager;
import com.taobao.ateye.alarm.manager.AlarmRuleManager;
import com.taobao.ateye.alarm.rule.RuleManager;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.UserDetailDAO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.dataobject.UserProfileDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.security.util.SecurityUtil;
import com.taobao.tracker.hbase.AlarmRuleDO;
import com.taobao.tracker.hbase.AlarmRuleLogDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.view.AlarmGroupDO;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/hubmonitor")
public class AlarmController extends AbstractController{
	private static final String ALARM_HISTORY_LOG = "screen/hubmonitor/alarmHistoryLog";
	private static final String ALARM_CONFIG_LIST = "screen/hubmonitor/alarmConfigList";
	private static final String APP_ALARM_CONFIG_LIST = "screen/hubmonitor/appAlarmConfigList";
	private static final String APP_ALARM_USER_LIST = "screen/hubmonitor/appAlarmUserList";

	@Autowired
	private HbaseReadService hbaseReadService;
	@Autowired
	private RuleManager ruleManager;
	@Autowired
	private UserDetailDAO userDetailDAO;
	@Autowired
	private AlarmRuleManager alarmRuleManager;
	@Autowired
	private AlarmGroupManager alarmGroupManager;

	@Autowired
	private SyncHbaseAlarmManager syncHbaseAlarmManager;

	//��ѯĳһӦ��ĳһ��ȫ���澯���ݵ�JSON���ݽӿ�
	@RequestMapping("getAlarmLog.htm")
	public void getAlarmLog(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String appName = request.getParameter("appName");
		String startDateStr = request.getParameter("startDate");
		PrintWriter out = response.getWriter();
		if(StringUtils.isBlank(appName)) {
			onError("appName is null", out);
			return;
		}
		Date startDate = null;
		try {
			startDate = DateUtils.parseDate(startDateStr, new String[] {"yyyy-MM-dd"});
		} catch(Exception ignore) {}
		if(startDate == null) {
			onError("invalid startDate:" + startDateStr, out);
			return;
		}
		try {
			List<AlarmRuleLogDO> alarmRuleLogDOList = hbaseReadService.getAlarmLogsByAppIgnoreEnv(appName, startDate);
			if(CollectionUtils.isEmpty(alarmRuleLogDOList)) {
				alarmRuleLogDOList = Lists.newArrayList();
			}
			String json = JSONObject.toJSONString(alarmRuleLogDOList);
			out.print(SecurityUtil.escapeJson(json));
		} catch(Exception e) {
			onError(e.getMessage(), out);
		}
	}

	private void onError(String errorMsg, PrintWriter out) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("error", errorMsg);
		out.print(SecurityUtil.escapeJson(jsonObject.toJSONString()));
	}
	
	@RequestMapping("alarmAllHistoryLog.htm")
    public String alarmAllHistoryLog(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, IOException {
	    UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String startDate = request.getParameter("startDate");
		Date startDateObj = new Date();
		if ( StringUtils.isNotBlank(startDate) ){
			startDateObj = CalendarUtil.toDate(startDate, "yyyy-MM-dd");
		}
		result.put("startDate",CalendarUtil.toString(startDateObj,"yyyy-MM-dd"));
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsOfDay(CalendarUtil.zerolizedTime(startDateObj));
		sortLogs(result, alarmLogs);
		return ALARM_HISTORY_LOG;
    }
	private void sortLogs(ModelMap result, List<AlarmRuleLogDO> alarmLogs) {
		if ( alarmLogs.isEmpty() ){
			return;
		}
		Map<String, List<AlarmRuleLogDO>> sortLogsByType = sortLogsByType(alarmLogs);
		result.put("mLogs", sortLogsByType);
		result.put("selectedTab",sortLogsByType.keySet().iterator().next());
	}	
	private Map<String,List<AlarmRuleLogDO>> sortLogsByType(List<AlarmRuleLogDO> alarmLogs) {
		Map<String,List<AlarmRuleLogDO>> ret = new TreeMap<String,List<AlarmRuleLogDO>>();
		for ( AlarmRuleLogDO rld:alarmLogs ){
			String type = RuleTypeConstant.getType(rld.getRuleType());
			List<AlarmRuleLogDO> list = ret.get(type);
			if ( list == null ){
				list = new ArrayList<AlarmRuleLogDO>();
				ret.put(type, list);
			}
			list.add(rld);
		}
		return ret;
	}
	@RequestMapping("alarmUserList.htm")
    public String alarmUserList(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
		Map<String, List<AlarmRuleDO>> allRulesGroupByUser = ruleManager.getAllRulesGroupByUser();
		result.put("rules",allRulesGroupByUser);
		Map<String,String> userNameUtf8 = new HashMap<String,String>();
    	for ( String user:allRulesGroupByUser.keySet() ){
    		if ( !userNameUtf8.containsKey(user) ){
	    		userNameUtf8.put(user, URLEncoder.encode(user, "utf-8"));
			}
    	}
    	result.put("returnUrl",super.getWholeUrl(request));
    	result.put("userNames", userNameUtf8);
    	Map<String, UserProfileDO> phoneMap = userDetailDAO.getPhoneMap();
    	result.put("phones", phoneMap);
    	Map<String, UserProfileDO> allMap = userDetailDAO.getAllMap();
    	result.put("nickMap", allMap);
		return APP_ALARM_USER_LIST;
	}
	@RequestMapping("alarmConfigList.htm")
    public String alarmConfigList(final HttpServletRequest request, ModelMap result) throws DAOException {
		 //����ҵ���ߵķ���
		Map<String, List<AlarmRuleDO>> allAlarmRules = hbaseReadService.getAllAlarmRules();
		/*<type,<app,List>>>*/
		Map<String,Map<String,List<AlarmRuleDO>>> types = new HashMap<String,Map<String,List<AlarmRuleDO>>>();
		for ( List<AlarmRuleDO> rules:allAlarmRules.values() ){
			for ( AlarmRuleDO rule:rules ){
				String type = RuleTypeConstant.getType(rule.getRuleType());
				Map<String, List<AlarmRuleDO>> map = types.get(type);
				if ( map == null ){
					map = new HashMap<String,List<AlarmRuleDO>>();
					types.put(type, map);
				}
				List<AlarmRuleDO> list = map.get(rule.getApp());
				if ( list == null ){
					list = new ArrayList<AlarmRuleDO>();
					map.put(rule.getApp(), list);
				}
				list.add(rule);
			}
		}
		Long tt = 0l;
		Map<String,Long> typeCounts = new HashMap<String,Long>();
		for ( String type:types.keySet() ){
			Map<String, List<AlarmRuleDO>> map = types.get(type);
			Long total = 0l;
			for ( List<AlarmRuleDO> rules:map.values() ){
				total += rules.size();
				tt += rules.size();
			}
			typeCounts.put(type, total);
		}
		result.put("typeCounts",typeCounts);
    	result.put("types", types);
    	result.put("total",tt);
    	super.initBizMap(result);
    	return ALARM_CONFIG_LIST;
    }	
	@RequestMapping("appAlarmConfigList.htm")
    public String appAlarmConfigList(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
		String app = request.getParameter("appName");
		if ( StringUtils.isEmpty(app) ){
			return null;
		}
		result.put("app",app);
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByApp(app);
		result.put("alarmGrps", alarmGroups);
		 //����ҵ���ߵķ���
		List<AlarmRuleDO> allAlarmRules = alarmRuleManager.getAllAlarmRulesOfApp(app);
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsOfDay(CalendarUtil.zerolizedTime(new Date()));
		result.put("todayLogs", format2CountMap(alarmLogs));

		String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),0));
		result.put("current",formatToDay);
		Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
		result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
    	result.put("rules", allAlarmRules);
    	Map<AlarmRuleDO,AbstractAlarmConfig> alarmConfigs = getAlarmConfigs(allAlarmRules);
    	result.put("rulesMap", alarmConfigs);
    	result.put("returnUrl",super.getWholeUrl(request));
    	return APP_ALARM_CONFIG_LIST;
    }	
	private Map<String,Integer> format2CountMap(List<AlarmRuleLogDO> alarmLogs) {
		Map<String,Integer> ret = new HashMap<String,Integer>();
		for ( AlarmRuleLogDO arl:alarmLogs ){
			String uuid = arl.getUuid();
			Integer cnt = ret.get(uuid);
			if ( cnt == null ){
				ret.put(uuid, 1);
			}else{
				ret.put(uuid, cnt+1);
			}
		}
		return ret;
	}

	@RequestMapping("bizAlarmConfigList.htm")
    public String bizAlarmConfigList(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
		String biz = request.getParameter("biz");
		if ( StringUtils.isEmpty(biz) ){
			return null;
		}
		result.put("biz",biz);
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByBiz(biz);
		result.put("alarmGrps", alarmGroups);
		 //����ҵ���ߵķ���
		List<AlarmRuleDO> allAlarmRules = alarmRuleManager.getAllAlarmRulesOfBiz(biz);
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsOfDay(CalendarUtil.zerolizedTime(new Date()));
		result.put("todayLogs", format2CountMap(alarmLogs));
		String formatToDay = DateFormatUtil.formatToDay(DateUtils.addDays(new Date(),0));
		result.put("current",formatToDay);
		Date dayObj = com.taobao.util.CalendarUtil.toDate(formatToDay, "yyyy-MM-dd");
		result.put("currentPlus1", com.taobao.util.CalendarUtil.toString(DateUtils.addDays(dayObj, 1), "yyyy-MM-dd"));
    	result.put("rules", allAlarmRules);
    	Map<AlarmRuleDO,AbstractAlarmConfig> alarmConfigs = getAlarmConfigs(allAlarmRules);
    	result.put("rulesMap", alarmConfigs);
    	result.put("returnUrl",super.getWholeUrl(request));
    	return APP_ALARM_CONFIG_LIST;
    }	
	private Map<AlarmRuleDO, AbstractAlarmConfig> getAlarmConfigs(
			List<AlarmRuleDO> allAlarmRules) {
		Map<AlarmRuleDO,AbstractAlarmConfig> ret = new HashMap<AlarmRuleDO,AbstractAlarmConfig>();
		for ( AlarmRuleDO ard:allAlarmRules ){
			AbstractAlarmRuleDetector detector = AbstractAlarmRuleDetector.getDetector(ard);
			if ( detector == null ){
				continue;
			}
			AbstractAlarmConfig config = detector.getAlarmConfig().fromJSON(ard.getRuleDesc());
			if ( config == null ){
				continue;
			}
			ret.put(ard, config);
		}
		return ret;
	}

	@RequestMapping("alarmAppHistoryLog.htm")
    public String alarmAppHistoryLog(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, IOException {
	    UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String app = request.getParameter("appName");
		String startDate = request.getParameter("startDate");
		if ( StringUtils.isEmpty(app) ){
			return null;
		}
		result.put("app",app);
		Date startDateObj = new Date();
		if ( StringUtils.isNotBlank(startDate) ){
			startDateObj = CalendarUtil.toDate(startDate, "yyyy-MM-dd");
		}
		result.put("startDate",CalendarUtil.toString(startDateObj,"yyyy-MM-dd"));
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsByApp(app, CalendarUtil.zerolizedTime(startDateObj));
		sortLogs(result, alarmLogs);

		return ALARM_HISTORY_LOG;
    }
	@RequestMapping("alarmHistoryLog.htm")
    public String alarmHistoryLog(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, IOException {
	    UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String uuid = request.getParameter("uuid");
		String app = request.getParameter("appName");
		String alarmTime = request.getParameter("alarmTime");
		String startDate = request.getParameter("startDate");
		if ( StringUtils.isEmpty(app) || StringUtils.isEmpty(uuid) ){
			return null;
		}
		result.put("app",app);
		result.put("uuid",uuid);
		Date startDateObj = new Date();
		if ( StringUtils.isNotBlank(startDate) ){
			startDateObj = CalendarUtil.toDate(startDate, "yyyy-MM-dd");
		}
		result.put("startDate",CalendarUtil.toString(startDateObj,"yyyy-MM-dd"));
		List<AlarmRuleLogDO> alarmLogs = hbaseReadService.getAlarmLogsByUuid(app, uuid, CalendarUtil.zerolizedTime(startDateObj));
		if ( StringUtils.isNotBlank(alarmTime) ){
			List<AlarmRuleLogDO> ruleLogs = filterLogByTime(alarmLogs,CalendarUtil.toDate(alarmTime, CalendarUtil.TIME_PATTERN));
			sortLogs(result, ruleLogs);
		}else{
			sortLogs(result, alarmLogs);
		}
		return ALARM_HISTORY_LOG;
    }
	/*
	 * Ѱ��alarmTimeǰ��30s��Χ�ڵĹ���
	 */
	private List<AlarmRuleLogDO> filterLogByTime(List<AlarmRuleLogDO> rules, Date alarmTime) {
		List<AlarmRuleLogDO> ret = new ArrayList<AlarmRuleLogDO>();
		for ( AlarmRuleLogDO rule:rules ){
			if ( Math.abs(rule.getDate().getTime()-alarmTime.getTime()) < 30*1000 ){
				ret.add(rule);
			}
		}
		return ret;
	}
	@RequestMapping("delAlarmRuleOfUser.htm")
    public String delAlarmRuleOfUser(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String user = request.getParameter("user");
		if ( StringUtils.isBlank(user) ){
			return "";
		}
		ruleManager.deleteAllRulesOfUser(user);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("delAlarmRule.htm")
    public String delAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String uuid = request.getParameter("uuid");
		hbaseReadService.deleteAlarmRule(app, uuid);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("pauseAlarmRule.htm")
    public String pauseAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String uuid = request.getParameter("uuid");
		AlarmRuleDO alarmRule = hbaseReadService.getAlarmRule(app, uuid);
		if ( alarmRule == null ){
			return "";
		}
		alarmRule.setIsOpen(false);
		hbaseReadService.addOrUpdateAlarmRule(alarmRule);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("pauseNHourAlarmRule.htm")
    public String pauseNHourAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String uuid = request.getParameter("uuid");
		String hourStr = request.getParameter("hour");
		Double hour = Double.valueOf(hourStr);
		AlarmRuleDO alarmRule = hbaseReadService.getAlarmRule(app, uuid);
		if ( alarmRule == null ){
			return "";
		}
		alarmRule.setReopenDate(DateUtils.addMinutes(new Date(), (int)(hour*60)));//�����´δ�ʱ��
		hbaseReadService.addOrUpdateAlarmRule(alarmRule);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("resumeAlarmRule.htm")
    public String resumeAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String uuid = request.getParameter("uuid");
		AlarmRuleDO alarmRule = hbaseReadService.getAlarmRule(app, uuid);
		if ( alarmRule == null ){
			return "";
		}
		alarmRule.setIsOpen(true);
		hbaseReadService.addOrUpdateAlarmRule(alarmRule);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("updateNotifier.htm")
    public String updateNotifier(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String uuid = request.getParameter("uuid");
		AlarmRuleDO alarmRule = hbaseReadService.getAlarmRule(app, uuid);
		if ( alarmRule == null ){
			return "";
		}
		String nicks = request.getParameter("nicks");
		AbstractAlarmRuleDetector detector = AbstractAlarmRuleDetector.getDetector(alarmRule);
		AbstractAlarmConfig config = detector.getAlarmConfig().fromJSON(alarmRule.getRuleDesc());
		config.setNotifyNicksByString(nicks);
		alarmRule.setRuleDesc(config.toJSON());
		hbaseReadService.addOrUpdateAlarmRule(alarmRule);
		return getRedirectUrl(request, response);
	}
	@RequestMapping("addAlarmRule.htm")
    public String addAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String vt = request.getParameter("valueType");
		String encodeKeys = request.getParameter("keys");
		String ruleType = request.getParameter("ruleType");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(ruleType) ){
			return "";
		}
		KeysDO keys = new KeysDO(encodeKeys);
		List<String> keys2 = keys.getKeys();
		AlarmRuleDO rule = new AlarmRuleDO();
		rule.setApp(app);
		rule.setIsOpen(true);
		rule.setK1("");
		rule.setK2("");
		rule.setK3("");
		rule.setK4("");
		rule.setK5("");
		rule.setK6("");
		rule.setIsGlobal(false);
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotBlank(uuid) ){
			rule.setUuid(uuid);
		}
		if ( keys2.size()>0 ){
			rule.setK1(keys2.get(0));
		}
		if ( keys2.size()>1 ){
			rule.setK2(keys2.get(1));
		}
		if ( keys2.size()>2 ){
			rule.setK3(keys2.get(2));
		}
		if ( keys2.size()>3 ){
			rule.setK4(keys2.get(3));
		}
		if ( keys2.size()>4 ){
			rule.setK5(keys2.get(4));
		}
		if ( keys2.size()>5 ){
			rule.setK6(keys2.get(5));
		}
		rule.setRuleType(ruleType);
		AbstractAlarmConfig alarmConfig = AlarmRuleManager.newAlarmConfig(ruleType);
		if ( alarmConfig == null ){
			log.error("û�������������:"+ruleType);
			return getRedirectUrl(request, response);
		}
		String ruleDesc = alarmConfig.getRuleDesc(request.getParameterMap());
		if ( StringUtils.isBlank(ruleDesc) ){
			return "";
		}
		rule.setRuleDesc(ruleDesc);
		rule.setType(vt);
		syncHbaseAlarmManager.sync2NewAlarm(rule,app,true,true);
		hbaseReadService.addOrUpdateAlarmRule(rule);
		return getRedirectUrl(request, response);
	}

	@RequestMapping("addGlobalAlarmRule.htm")
    public String addGlobalAlarmRule(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws UnsupportedEncodingException {
		String app = request.getParameter("appName");
		String ruleType = request.getParameter("ruleType");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(ruleType) ){
			return "";
		}
		AlarmRuleDO rule = new AlarmRuleDO();
		rule.setApp(app);
		rule.setIsOpen(true);
		rule.setK1("");
		rule.setK2("");
		rule.setK3("");
		rule.setK4("");
		rule.setK5("");
		rule.setK6("");
		rule.setIsGlobal(true);
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotBlank(uuid) ){
			rule.setUuid(uuid);
		}
		rule.setRuleType(ruleType);
		AbstractAlarmConfig alarmConfig = AlarmRuleManager.newAlarmConfig(ruleType);
		if ( alarmConfig == null ){
			log.error("û�������������:"+ruleType);
			return getRedirectUrl(request, response);
		}
		String ruleDesc = alarmConfig.getRuleDesc(request.getParameterMap());
		if ( StringUtils.isBlank(ruleDesc) ){
			return "";
		}
		rule.setRuleDesc(ruleDesc);
		rule.setType("v1v2");//д��
		syncHbaseAlarmManager.sync2NewAlarm(rule,app,true,true);
		hbaseReadService.addOrUpdateAlarmRule(rule);
		return getRedirectUrl(request, response);
	}
	public void setHbaseReadService(HbaseReadService hbaseReadService) {
		this.hbaseReadService = hbaseReadService;
	}
	public HbaseReadService getHbaseReadService() {
		return hbaseReadService;
	}
}
