package com.taobao.ateye.controller.alarm;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.alarm.n.manager.AlarmOprManager;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ateye.alarm.n.data.AlarmContext;
import com.taobao.ateye.alarm.n.enu.AppScopeEnum;
import com.taobao.ateye.alarm.n.enu.SubscriberEnu;
import com.taobao.ateye.alarm.n.manager.AlarmCacheManager;
import com.taobao.ateye.alarm.n.manager.AlarmDetectorManager;
import com.taobao.ateye.alarm.n.manager.AlarmManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.controller.alarm.data.AlarmAppScopeRelation;
import com.taobao.ateye.controller.alarm.data.AlarmSubRelation;
import com.taobao.ateye.dal.AlarmConfPersonalizedDAO;
import com.taobao.ateye.dal.AteyeAlarmConfDAO;
import com.taobao.ateye.dal.AteyeAlarmItemDAO;
import com.taobao.ateye.dal.AteyeAlarmItemRuleSingleDAO;
import com.taobao.ateye.dal.AteyeAlarmRecordDAO;
import com.taobao.ateye.dal.AteyeAlarmSubRelationDAO;
import com.taobao.ateye.dal.AteyeAlarmSubscriberDAO;
import com.taobao.ateye.dataobject.AlarmConfPersonalizedDO;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.dataobject.AteyeAlarmItemDO;
import com.taobao.ateye.dataobject.AteyeAlarmItemRuleSingleDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubRelationDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.util.CalendarUtil;

/**
 * Created by sunqiang on 2018/12/17.
 */
public abstract  class AbstractAlarmController extends AbstractController{
    @Autowired
    protected AlarmDetectorManager alarmDetectorManager;

    @Autowired
    protected AteyeAlarmRecordDAO recordDAO;

    @Autowired
    protected AteyeAlarmSubscriberDAO subscriberDAO;

    @Autowired
    protected AteyeAlarmConfDAO confDAO;

    @Autowired
    protected AteyeAlarmSubRelationDAO relationDAO;

    @Autowired
    protected AlarmManager alarmManager;

    @Autowired
    protected AteyeAlarmItemRuleSingleDAO alarmItemRuleSingleDAO;


    @Autowired
    protected AteyeAlarmItemDAO itemDAO;

    @Autowired
    protected AlarmConfPersonalizedDAO personalizedDAO;

    @Autowired
    protected AlarmCacheManager cacheManager;

    @Autowired
    protected AlarmOprManager alarmOprManager;
    protected Integer getBiz(HttpServletRequest request) throws DAOException {
        Map<String,BizLineDO> name2BizMap = bizLineDAO.getAllBizLineMapByName();

        String bizStr = request.getParameter("biz");
        Integer biz= null;
        if(StringUtils.isNotEmpty(bizStr)){
            if(NumberUtils.isNumber(bizStr)){
                biz = Integer.parseInt(bizStr);
            }else{
                BizLineDO bizLineDO = name2BizMap.get(bizStr);
                if(bizLineDO != null){
                    biz = (int)bizLineDO.getId();
                }
            }
        }
        return biz;
    }

    protected Set<Long> getConfIdByBiz(Integer biz ) throws DAOException {

        Set<Long>alarmConfIds = Sets.newHashSet();

        if(biz==null){
            for (Long bizId : bizLineDAO.getAllBizLineMap().keySet()) {
                alarmConfIds.addAll(cacheManager.getAlarmConfIds(bizId.intValue()));
            }
        }else{
            alarmConfIds.addAll(cacheManager.getAlarmConfIds(biz));
        }

        return alarmConfIds;
    }

    protected Set<Long> getConfIdByBizAndApp(Integer biz,String appName) throws DAOException {
        Set<Long> confIdsOfBiz = getConfIdByBiz(biz);
        Set<Long> confIdsOfApp = getConfIdbyAppName(appName);
        confIdsOfBiz.retainAll(confIdsOfApp);
        return confIdsOfBiz;
    }

    protected  Set<Long> getConfIdbyAppName(String appName){
        Set<Long> result = Sets.newHashSet();
        if(StringUtils.isNotEmpty(appName)){
            Set<Long> confIds  = cacheManager.getApp2ConfIdsMap().get(appName);
            if(confIds!=null){
                result.addAll(confIds);
            }
        }else{
            for (Set<Long> confIds : cacheManager.getApp2ConfIdsMap().values()) {
                result.addAll(confIds);
            }
        }
        return result;
    }


    protected List<AlarmAppScopeRelation> buildAppScopeConf(Long subId,Long confId) throws DAOException {
        Map<Integer,BizLineDO> bizMap = getBizMap();
        List<AlarmAppScopeRelation> appScopes = Lists.newArrayList();
        List<AteyeAlarmConfDO> confs = confDAO.selectAppScope();

        List<AteyeAlarmSubRelationDO> relations = relationDAO.selectAppScope(environmentService.getEnvironmentType().getEnv());
        Iterator<AteyeAlarmSubRelationDO> iterator = relations.iterator();
        while(iterator.hasNext()){
            AteyeAlarmSubRelationDO relation = iterator.next();
            if(subId!=null && relation.getSubId()!= subId){
                iterator.remove();//ֻ��һ��subId
            }
        }
        Map<Long,List<AteyeAlarmSubRelationDO>> confId2SubRelation = transferMap(relations);
        if ( confId != null && confId > 0 ){//ֻ��һ��confId
        	List<AteyeAlarmSubRelationDO> list = confId2SubRelation.get(confId);
        	confId2SubRelation = Maps.newHashMap(); 
        	confId2SubRelation.put(confId, list);
        }

        if(CollectionUtils.isNotEmpty(relations) && CollectionUtils.isNotEmpty(confs)){
            for (AteyeAlarmConfDO conf : confs) {
                List<AteyeAlarmSubRelationDO> subRelations = confId2SubRelation.get(conf.getId());
                if(CollectionUtils.isNotEmpty(subRelations)){
                    List<Long> subIds = Lists.transform(subRelations, new Function<AteyeAlarmSubRelationDO, Long>() {
                        @Nullable
                        @Override
                        public Long apply(@Nullable AteyeAlarmSubRelationDO input) {
                            return input.getSubId();
                        }
                    });
                    AlarmAppScopeRelation appScope = new AlarmAppScopeRelation();
                    List<AteyeAlarmItemRuleSingleDO> singleRuleSingleDOs = alarmItemRuleSingleDAO.selectByConfId(conf.getId());
                    if ( singleRuleSingleDOs != null && singleRuleSingleDOs.size() > 0 ){
                    	appScope.setRuleDO(singleRuleSingleDOs.iterator().next());
                    }
                    List<AlarmConfPersonalizedDO> personalizedDOS =personalizedDAO.selectByConfId(conf.getId());
                    if(CollectionUtils.isNotEmpty(personalizedDOS)){
                        appScope.setPerCount(personalizedDOS.size());
                    }
                    appScope.setConfDO(conf);
                    appScope.setSubStr(subStr(subscriberDAO.selectByIds(subIds)));
                    appScope.setRuleType(subRelations.get(0).getRuleType());
                    appScope.setAppScopeType(subRelations.get(0).getAppScopeType());
                    if(subRelations.get(0).getAppScopeType() == AppScopeEnum.BIZ.getValue() || subRelations.get(0).getAppScopeType() == AppScopeEnum.CORE_APP.getValue()){
                        BizLineDO lineDO = bizMap.get(Integer.valueOf(subRelations.get(0).getAppScopeValue()));
                        if(lineDO !=null){
                            appScope.setAppScopeValue(lineDO.getName());
                        }else{
                            appScope.setAppScopeValue(subRelations.get(0).getAppScopeValue());
                        }

                    }else{
                        appScope.setAppScopeValue(subRelations.get(0).getAppScopeValue());
                    }
                    int alarmCount = recordDAO.countRealByConfIdStartTime(conf.getId(),CalendarUtil.zerolizedTime(new Date()));
                    appScope.setAlarmCount(alarmCount);
                    appScope.setConfId(conf.getId());
                    appScope.setReopenDate(conf.getReopenDate());
                    appScope.setStatus(conf.getStatus());
                    appScope.setUuid(conf.getUuid());
                    appScopes.add(appScope);
                }
            }
        }
        return appScopes;
    }

    protected Map<Long,List<AteyeAlarmSubRelationDO>> transferMap(List<AteyeAlarmSubRelationDO> relations) {
        Map<Long,List<AteyeAlarmSubRelationDO>> maps = Maps.newHashMap();
        if(CollectionUtils.isNotEmpty(relations)){
            for (AteyeAlarmSubRelationDO relation : relations) {
                if(!maps.containsKey(relation.getAlarmConfId())){
                    maps.put(relation.getAlarmConfId(),Lists.<AteyeAlarmSubRelationDO>newArrayList());
                }
                maps.get(relation.getAlarmConfId()).add(relation);
            }
        }
        return maps;
    }

    protected void filterRelation(List<AlarmSubRelation> relations, String appName, Set<String> ruleTypes, Long alarmGroupIp) {
        if(CollectionUtils.isNotEmpty(relations)){
            Iterator<AlarmSubRelation> iterator= relations.iterator();
            while(iterator.hasNext()){
                AlarmSubRelation relation = iterator.next();
                if(StringUtils.isNotEmpty(appName)&& !appName.equalsIgnoreCase(relation.getApp())){
                    iterator.remove();
                }else if(!ruleTypes.contains(relation.getRuleType())){
                    iterator.remove();
                }else if(alarmGroupIp!=null && !relation.getSubIds().contains(alarmGroupIp)){
                    iterator.remove();
                }

            }
        }
    }

    protected String fetchAppScopeSubStr(long confId, String ruleTypeDetail) {
        return subStr(cacheManager.fetchAppScopeSubScribe(confId,ruleTypeDetail));
    }

    protected String subStr(List<AteyeAlarmSubscriberDO> subscriberDOS){
        if(CollectionUtils.isEmpty(subscriberDOS)){
            return "";
        }
        return Joiner.on(",").join(Lists.transform(subscriberDOS, new Function<AteyeAlarmSubscriberDO, String>() {
            @Nullable
            @Override
            public String apply(@Nullable AteyeAlarmSubscriberDO input) {
                if(input.getType() == SubscriberEnu.DINGGROUP.getValue()){
                    return "#"+input.getName();
                }
                return input.getName();
            }
        }));
    }

    protected String fetchSubName(Map<Long, Set<Long>> confId2SubIdsMap, long confId) {
        return subStr(cacheManager.fetchSimpleSubScribe(confId2SubIdsMap,confId));
    }

    protected String fomatName(AlarmContext alarmContext) {
        if(alarmContext.getConfDO().getIsAggr()==0){
            AteyeAlarmItemDO itemDO = alarmContext.getRuleContexts().get(0).getItemDO();
            if(!itemDO.getRuleType().startsWith("biz_")){
                String app = alarmContext.getRuleContexts().get(0).getItemDO().getApp();
                String app2 = alarmContext.getRuleContexts().get(0).getItemDO().getApp2();
                String type2 = alarmContext.getRuleContexts().get(0).getItemDO().getType2();
                String keys = Joiner.on(" ").join(new KeysDO(alarmContext.getRuleContexts().get(0).getItemDO()).getKeys());
                return app+" "+keys+(StringUtils.isNotEmpty(app2)?(" "+ app2):"")+(StringUtils.isNotEmpty(type2)?(" "+ type2):"");
            }else{
                return "[ȫ������]";
            }

        }else{
            return alarmContext.getConfDO().getName();
        }
    }

}
