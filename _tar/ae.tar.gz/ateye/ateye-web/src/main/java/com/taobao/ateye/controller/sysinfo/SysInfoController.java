package com.taobao.ateye.controller.sysinfo;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.OperateLogDAO;
import com.taobao.ateye.dataobject.OperateLogDO;
import com.taobao.ateye.query.OperateLogQuery;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.tracker.event.EventLogDO;
import com.taobao.tracker.hbase.HbaseReadService;

/**
 * 
 * @author gumo
 * 
 */
@Controller
@RequestMapping("/sys")
public class SysInfoController extends AbstractController{
    @Autowired
    OperateLogDAO operateLogDAO;
    @Autowired
    HbaseReadService hbaseReadService;
    
    @SuppressWarnings("unchecked")
    @RequestMapping("viewEventLog.htm")
    public final String viewEventLog(final HttpServletRequest request, final ModelMap result) throws Exception {
    	Pair<Date, Date> tr = super.getTimeRange(request, result);
    	List<EventLogDO> eventLogs = hbaseReadService.getEventLogs(tr.getLeft(),tr.getRight());
    	Collections.reverse(eventLogs);
    	result.put("eventLogs", eventLogs);
    	
        return "screen/viewEventLog";
    }

    @SuppressWarnings("unchecked")
    @RequestMapping("viewOperateLog.htm")
    public final String viewOperateLog(final HttpServletRequest request, final ModelMap result) throws Exception {
        OperateLogQuery queryDO = new OperateLogQuery();
        queryDO.setCurrentPage(1);
        if (!StringUtil.isBlank(request.getParameter("page"))) {
            int page = Integer.valueOf(request.getParameter("page"));
            if (page == 0)
                page = 1;
            queryDO.setCurrentPage(page);
        }
        /*
        queryDO.setCl(request.getParameter("cl"));
        queryDO.setLevel(request.getParameter("level"));
        queryDO.setMethod(request.getParameter("method"));
        queryDO.setOperater(request.getParameter("op"));
        queryDO.setServerId(request.getParameter("server_id"));
        */

        queryDO.setPageSize(50);
        List<OperateLogDO> logs = operateLogDAO.getOperateLogByQuery(queryDO);
        Integer count = operateLogDAO.getOperateLogCountByQuery(queryDO);
        queryDO.setTotalItem(count);
        result.put("page", queryDO.getCurrentPage());
        result.put("total", queryDO.getTotalPage());
        
        if ( queryDO.getCurrentPage() != 1){
	        String paras = "?";
	        paras += "page="+queryDO.getPreviousPage();
	        result.put("prev_url", paras);
        }
        if ( queryDO.getCurrentPage() != queryDO.getTotalPage() ){
	        String paras = "?";
	        paras += "page=" + queryDO.getNextPage();
	        result.put("next_url", paras);
        }
        result.put("logs", logs);
        return "screen/viewOperateLog";
    }

}
