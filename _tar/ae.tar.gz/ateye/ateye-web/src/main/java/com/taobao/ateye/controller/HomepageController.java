package com.taobao.ateye.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.platform.buc.sso.common.dto.SimpleSSOUser;
import com.taobao.ateye.alarm.log.AlarmLogGraphManager;
import com.taobao.ateye.alarm.log.AlarmLogGraphParam;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.authority.SSOThreadLocal;
import com.taobao.ateye.cache.AppCache;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.config.manager.ConfigManager;
import com.taobao.ateye.dal.SceneCatDAO;
import com.taobao.ateye.dal.SceneExtendDAO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.SceneCatDO;
import com.taobao.ateye.dataobject.SceneExtendDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.graph.base.GraphParamDO;
import com.taobao.ateye.scene.extend.SceneExtendTypeEnum;
import com.taobao.ateye.user.UserManager;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.tracker.hbase.AccessStat;
import com.taobao.tracker.hbase.CViewDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.hbase.service.AteyeCViewService;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.BaseViewDO;
import com.taobao.tracker.hbase.view.MultiViewDO;
import com.taobao.tracker.hbase.view.SingleViewDO;
import com.taobao.util.CalendarUtil;

/**
 * @author gumo
 */
@Controller
public class HomepageController extends AbstractController{
	@Autowired
	private HbaseReadService hbaseReadService;
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private AteyeConfig ateyeConfig;
	@Autowired
	private ConfigManager configManager;
	@Autowired
	private AteyeCViewService ateyeCViewService;
	@Autowired
	private SceneCatDAO sceneCatDAO;
	@Autowired
	private UserManager userManager;
	@Autowired
	private SceneExtendDAO sceneExtendDAO;
	
	private Set<String> getSceneTags(){
		Set<String> ret = new HashSet<String>();
		try {
			List<SceneExtendDO> exds = sceneExtendDAO.getAllSceneExtends();
			for ( SceneExtendDO exd:exds ){
				if (exd.getType().equals(SceneExtendTypeEnum.TAGS.name())) {
					ret.add(exd.getValue());
				}
			}
		} catch (DAOException e) {
		}
		return ret;
	}
	@RequestMapping("/check.htm")
	public String check(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		return "screen/check";
	}

	@RequestMapping("/index.htm")
	public String handleIndexRequest(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		String serverName = request.getServerName();
		if ( StringUtils.isNotBlank(serverName) &&
			( serverName.contains("safe.fliggy")
			|| serverName.contains("safe.trip")
				)	){
			return "redirect:index4.htm";
		}
		result.put("apps", getAccessStat());
		return "redirect:index2.htm";
	}
	@RequestMapping("/showData.htm")
	public String showData(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		String json = request.getParameter("json");
		json = UrlUtil.base64Decode(json);
		JSONObject obj = null;
		try{
			obj = JSON.parseObject(json);
			result.put("json",JSON.toJSONString(obj,true));
		}catch(Throwable t){
			result.put("json",json);
		}
		try{
			Map<String,String> subObjs = new HashMap<String,String>();
			if ( obj != null ){
				Set<Entry<String, Object>> entrySet = obj.entrySet();
				for ( Entry<String,Object> ent:entrySet ){
					String value = ent.getValue().toString();
					try{
						JSONObject subObj = JSON.parseObject(value);
						//1.gmtModified,��gmtCreate��ʱ����滻
						formatTimestamp("gmtModified",subObj);
						formatTimestamp("gmtCreate",subObj);
						if ( subObj != null ){
							subObjs.put(ent.getKey(), JSON.toJSONString(subObj, true));
						}
					}catch(Throwable t){
						
					}
				}
			}
			result.put("subObjs",subObjs);
		}catch(Throwable t){
			
		}
		return "screen/showData";
	}
	private void formatTimestamp(String key,JSONObject objs){
		try{
			Long mo= (Long) objs.get(key);
			if ( mo != null ){
				Date d = new Date(mo);
				objs.put(key, CalendarUtil.toString(d, "yyyy-MM-dd HH:mm:ss.SSS"));
			}
		}catch(Throwable t){
			
		}
		
	}
	@RequestMapping("/indexOld.htm")
	public String handleIndexOldRequest(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		result.put("apps", getAccessStat());
		return "screen/index";
	}
	private Set<String> getCoreSceneCat(){
		Set<String> ret = new HashSet<String>();
		if ( ateyeConfig.isDisableHbase() ){
			return ret;
		}
		
		String nt = configManager.get("safe.scene.core.cat");
		if ( StringUtils.isBlank(nt) ){
			return ret;
		}
		String[] pts = nt.split("\r\n");
		ret.addAll(Arrays.asList(pts));
		return ret;
	}
	private List<String> getSafeReleaseNotes(){
		List<String> ret = new ArrayList<String>();
		if ( ateyeConfig.isDisableHbase() ){
			return ret;
		}
		
		String nt = configManager.get("safe.release.note");
		if ( StringUtils.isBlank(nt) ){
			return ret;
		}
		String[] pts = nt.split("\r\n");
		return Arrays.asList(pts);
	}
	private String getNotice(){
		if ( ateyeConfig.isDisableHbase() ){
			return "";
		}
		
		String nt = configManager.get("homepage.notice");
		if ( StringUtils.isBlank(nt) ){
			return "";
		}
		
		return nt.replaceAll("\r\n", "<br>");
	}
	private List<AccessStat> getAccessStat(){
		if ( ateyeConfig.isDisableHbase() ){
			return Collections.EMPTY_LIST;
		}
		try{
			SimpleSSOUser user = SSOThreadLocal.get();
			if ( user == null ){
				return null;
			}
			List<AccessStat> mostAccessApps = hbaseReadService.getMostAccessApps(new Long(user.getId()), 15);
			if ( mostAccessApps.size()> 10 ){
				return mostAccessApps.subList(0, 9);
			}
			return mostAccessApps;
		}catch(Throwable t){
			return Collections.EMPTY_LIST;
		}
	}
	@RequestMapping("/index3.htm")
	public String handleIndex3Request(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws Exception {
		SimpleSSOUser user = SSOThreadLocal.get();
		if ( user != null ){
			String nk = user.getTbWW();
			if ( StringUtils.isBlank(nk) ){
				UserDO ur = (UserDO) MyThreadLocal.get();
				if (ur != null) {
					nk = ur.getNick();
				}
			}
			//1.��ȡ�������Ӧ��
			Set<String> ownApps = userManager.getOwnApps(nk);
			buildAppsInfos(result, ownApps,-1);
			//2.ͼ
			GraphParamDO gp = new GraphParamDO();
			gp.setName(AlarmLogGraphManager.ALARM_LOG_GRAPH);
			AlarmLogGraphParam param = new AlarmLogGraphParam();
			param.setOwner(nk);
			param.setEnd(new Date());
			param.setStart(DateUtils.addHours(new Date(),-1));
			param.setQueryType(AlarmLogGraphParam.QUERY_TYPE_OWNER);
			gp.setParam(param);
			result.put("customParam", gp.toCustomParam());
		}
		setIsMobile(request, result);
		return "screen/index3";
	}



	@RequestMapping("/index2.htm")
	public String handleIndex2Request(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException, ParseException {
		result.put("apps", getAccessStat());
		result.put("notice", getNotice());
		if ( !ateyeConfig.isDisableHbase() ){
			SimpleSSOUser user = SSOThreadLocal.get();
			if ( user != null ){
				String tbWW = user.getTbWW();
				if ( StringUtils.isBlank(tbWW) ){
					UserDO ur = (UserDO) MyThreadLocal.get();
					if (ur != null) {
						tbWW = ur.getNick();
					}
				}
				if ( StringUtils.isNotBlank(tbWW) ){
					List<BaseViewDO> listAllViewOfUser = ateyeViewService.listAllViewOfUser(tbWW);
					List<MultiViewDO> mviews = new ArrayList<MultiViewDO>();
					List<SingleViewDO> sviews = new ArrayList<SingleViewDO>();
					for ( BaseViewDO bv:listAllViewOfUser ){
						if ( bv.getType() == BaseViewDO.TYPE_MULTI ){
							mviews.add((MultiViewDO)bv);
						}
						if ( bv.getType() == BaseViewDO.TYPE_SINGLE){
							sviews.add((SingleViewDO)bv);
						}
					}
					result.put("mviews", mviews);
					result.put("sviews", sviews);
					
					List<CViewDO> userCViews = ateyeCViewService.getUserCViews(tbWW);
					result.put("cviews", userCViews);
				}
				//��ȡҵ����
				List<String> bizs= configManager.gets("user.biz");
				List<String> ownerBizs = new ArrayList<String>();
				if ( StringUtils.isNotBlank(tbWW) ){
					for ( String biz:bizs ){
						if ( biz.contains(tbWW)){
							String[] ps = biz.split(":");
							if ( ps.length >= 2 ){
								String view = configManager.get("bizview."+ps[0]);
								if ( StringUtils.isNotBlank(view) ){
									ownerBizs.add(ps[0]);
								}
							}
						}
					}
				}
				result.put("bizviews", ownerBizs);
			}
		}
		return "screen/index2";
	}
	@RequestMapping("/index4.htm")
	public String handleIndex4Request(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws Exception {
		SimpleSSOUser user = SSOThreadLocal.get();
		if ( user != null ){
			String nk = user.getTbWW();
			if ( StringUtils.isBlank(nk) ){
				UserDO ur = (UserDO) MyThreadLocal.get();
				if (ur != null) {
					nk = ur.getNick();
				}
			}
			//1.��ȡ�û�����ҵ����
			String empId = user.getEmpId();
			Long empIdL = -1L;
			try{
				empIdL = Long.parseLong(empId);
			}catch(Throwable t){
				
			}
			if ( empIdL > 0 ){
				Long bizId = AppCache.getUserBiz().get(empIdL);
				if ( bizId != null && bizId > 0 ){
					BizLineDO bizLineDO = AppCache.getBizs().get(bizId);
					result.put("bizLine",bizLineDO);
				}
			}
		}
		List<String> srns = getSafeReleaseNotes();
		result.put("rnotes",srns);
		setIsMobile(request, result);
		Set<String> sceneCatCn = getCoreSceneCat();
		List<SceneCatDO> allCats = sceneCatDAO.getAll();
		result.put("sCats",sceneCatCn);
		result.put("allCats", allCats);
		Set<String> sceneTags = getSceneTags();
		sceneTags.remove("core");//core��������;��ȡ����
		result.put("sceneTags",sceneTags);
		return "screen/index4";
	}

	@RequestMapping("/noPermission.htm")
	public String noPermissionRequest(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		return "screen/noPermission";
	}
	@RequestMapping("/err.htm")
	public String err(HttpServletRequest request, HttpServletResponse response, ModelMap result) throws ServletException, IOException {
		return "screen/err";
	}

	public void setHbaseReadService(HbaseReadService hbaseReadService) {
		this.hbaseReadService = hbaseReadService;
	}

	public HbaseReadService getHbaseReadService() {
		return hbaseReadService;
	}
}
