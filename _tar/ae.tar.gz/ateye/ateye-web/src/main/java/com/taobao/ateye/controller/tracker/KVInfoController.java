package com.taobao.ateye.controller.tracker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.report.model.KeysDO;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.ateye.util.DescUtils;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.tracker.hbase.CViewDO;
import com.taobao.tracker.hbase.service.AteyeCViewService;
import com.taobao.tracker.hbase.service.AteyeViewService;
import com.taobao.tracker.hbase.view.BaseViewDO;
import com.taobao.tracker.hbase.view.LineDefDO;
import com.taobao.tracker.hbase.view.MultiViewDO;
import com.taobao.tracker.hbase.view.SingleViewDO;
@SuppressWarnings("unchecked")
@Controller
@RequestMapping("/kv")
public class KVInfoController  extends AbstractController{
	private static final String VIEW = "screen/kv/view";
	private static final String VIEW_LIST = "screen/kv/viewList";
	private static final String CVIEW_LIST = "screen/kv/cviewList";
	private static Map<String,List<Pair<String,String>>> multiViewers = new HashMap<String,List<Pair<String,String>>>();
	static{
		multiViewers.put("tracker", Arrays.asList(
				Pair.of("#DEFAULT#Tracker�����߳�","v1v2"),
				Pair.of("#DEFAULT#Hbase�첽��������С","v1v2"),
				Pair.of("#DEFAULT#Hbase�첽�߳���","v1v2"),
				Pair.of("#RT#HbasePool","v1v2")
				));
		
	}
	@Autowired
	private AteyeViewService ateyeViewService;
	@Autowired
	private AteyeCViewService ateyeCViewService;
	@RequestMapping("viewList.htm")
	public String viewList(final HttpServletRequest request, ModelMap result) throws Exception {
		List<BaseViewDO> allViews = ateyeViewService.listAllViews();
		
    	result.put("returnUrl",super.getWholeUrl(request));

    	result.put("all",true);
		result.put("views",sortView(allViews));
		result.put("viewDesc",descBaseView(allViews));
		return VIEW_LIST;
	}
	@RequestMapping("cviewList.htm")
	public String cviewList(final HttpServletRequest request, ModelMap result) throws Exception {
    	result.put("returnUrl",super.getWholeUrl(request));

    	List<CViewDO> userCViews = ateyeCViewService.getAllCViews();
    	Collections.sort(userCViews, new Comparator<CViewDO>(){
			@Override
			public int compare(CViewDO arg0, CViewDO arg1) {
				long td = arg0.getGmtModified().getTime() - arg1.getGmtModified().getTime();
				if (td == 0l){
					return 0;
				}else if ( td<0l){
					return 1;
				}else{
					return -1;
				}
			}
    	});
		
		result.put("views",userCViews);
		return CVIEW_LIST;
	}
	private Map<BaseViewDO,String> descBaseView(List<BaseViewDO> bvs){
		Map<BaseViewDO,String> mm = new HashMap<BaseViewDO,String>();
		for ( BaseViewDO bv:bvs ){
			if ( bv.getType() == BaseViewDO.TYPE_SINGLE ){
				SingleViewDO sv = (SingleViewDO) bv;
				Set<Pair<String,String>> pp = getRelationFromLines(sv.getLines());
				StringBuilder sb = new StringBuilder();
				sb.append("����"+sv.getLines().size()+"������,����");
				for ( Pair<String,String> p:pp ){
					sb.append(p.getKey()+":"+p.getValue()+" | ");
				}
				mm.put(bv, sb.toString());
			}else{
				MultiViewDO mv = (MultiViewDO) bv;
				List<String> singleViewUUids = mv.getSingleViewUUids();
				StringBuilder sb = new StringBuilder();
				sb.append("����"+singleViewUUids.size()+"����һ��ͼ");
				mm.put(bv, sb.toString());
			}
		}
		return mm;
	}
	/* app:type */
	private Set<Pair<String,String>> getRelationFromLines(List<LineDefDO> lines){
		Set<Pair<String,String>> ret = new HashSet<Pair<String,String>>();
		for ( LineDefDO line:lines ){
			ret.add(Pair.of(line.getApp(),line.getType()));
		}
		return ret;
	}
	@RequestMapping("listAppViews.htm")
	public String listAppViews(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	result.put("returnUrl",super.getWholeUrl(request));
    	String app = request.getParameter("app");
    	String type = request.getParameter("type");
    	if ( StringUtils.isBlank(app) || StringUtils.isBlank(type) ){
    		return "";
    	}
		String nick = user.getNick();
		List<SingleViewDO> existViews = ateyeViewService.listSViewOfApp(app, type);
		List<BaseViewDO> evs = new ArrayList<BaseViewDO>();
		for ( SingleViewDO svd:existViews ){
			evs.add(svd);
		}
		result.put("views",existViews);
		result.put("nick",nick);
		List<BaseViewDO> myList = ateyeViewService.listAllViewOfUser(nick);
		Set<String> followedUUids = new HashSet<String>();
		for ( BaseViewDO bv:myList ){
			if ( !bv.getOwner().equals(nick) ){
				followedUUids.add(bv.getUuid());
			}
		}
		result.put("follows",followedUUids);
		result.put("viewDesc",descBaseView(evs));
		return VIEW_LIST;
	}
	@RequestMapping("listMViews.htm")
	public String listMViews(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	result.put("returnUrl",super.getWholeUrl(request));
    	String uuid = request.getParameter("uuid");
    	if ( StringUtils.isBlank(uuid) ){
    		return "";
    	}
		String nick = user.getNick();
		List<MultiViewDO> existViews = ateyeViewService.listMViewOfSView(uuid);
		List<BaseViewDO> evs = new ArrayList<BaseViewDO>();
		for ( MultiViewDO svd:existViews ){
			evs.add(svd);
		}
		result.put("views",existViews);
		result.put("nick",nick);
		List<BaseViewDO> myList = ateyeViewService.listAllViewOfUser(nick);
		Set<String> followedUUids = new HashSet<String>();
		for ( BaseViewDO bv:myList ){
			if ( !bv.getOwner().equals(nick) ){
				followedUUids.add(bv.getUuid());
			}
		}
		result.put("follows",followedUUids);
		result.put("viewDesc",descBaseView(evs));
		return VIEW_LIST;
	}	
	@RequestMapping("adjustMViewOrder.htm")
	public String adjustMViewOrder(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	result.put("returnUrl",super.getWholeUrl(request));
    	String uuid = request.getParameter("uuid");
    	if ( StringUtils.isBlank(uuid) ){
    		return "";
    	}
		String nick = user.getNick();
		BaseViewDO viewDO = ateyeViewService.getView(uuid);
		if ( viewDO == null || viewDO.getType() == BaseViewDO.TYPE_SINGLE ){
			return getRedirectUrl(request,response);
		}
		if ( !viewDO.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		result.put("nick",nick);
		MultiViewDO mv = (MultiViewDO)viewDO;
		List<String> singleViewUUids = mv.getSingleViewUUids();
		List<Pair<String,Integer>> resortUuids = new ArrayList<Pair<String,Integer>>();
		for ( String suuid:singleViewUUids ){
			String od = request.getParameter(suuid);
			if ( od == null ){
				resortUuids.add(Pair.of(suuid, 10000));
				continue;
			}
			try{
				int pi = Integer.parseInt(od);
				resortUuids.add(Pair.of(suuid, pi));
			}catch(Throwable t){
				resortUuids.add(Pair.of(suuid, 10000));
				continue;
			}
		}
		Collections.sort(resortUuids,new Comparator<Pair<String,Integer>>(){
			@Override
			public int compare(Pair<String, Integer> o1,
					Pair<String, Integer> o2) {
				return o1.getRight() - o2.getRight();
			}
		});
		List<String> newUuids = new ArrayList<String>();
		for ( Pair<String,Integer> pp:resortUuids ){
			newUuids.add(pp.getLeft());
		}
		mv.setSingleViewUUids(newUuids);
		ateyeViewService.addOrUpdateMultiView(uuid, mv);
		return "redirect:/hubmonitor/viewMultiDetail.htm?uuid="+uuid;
	}	
	@RequestMapping("etViewName.htm")
	public String etViewName(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	String uuid = request.getParameter("uuid");
    	if ( StringUtils.isBlank(uuid) ){
    		return "";
    	}
		String nn = request.getParameter("newName");
		if ( StringUtils.isBlank(nn) ){
			return "";
		}
		String nick = user.getNick();
		BaseViewDO viewDO = ateyeViewService.getView(uuid);
		if ( viewDO == null ){
			return getRedirectUrl(request,response);
		}
		if ( !viewDO.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		viewDO.setName(nn);
		if ( viewDO.getType() == BaseViewDO.TYPE_MULTI ){
			ateyeViewService.addOrUpdateMultiView(uuid, (MultiViewDO)viewDO);
		}else{
			ateyeViewService.addOrUpdateSingleView(uuid, (SingleViewDO)viewDO);
		}
		return getRedirectUrl(request,response);
	}	
	@RequestMapping("listUserViews.htm")
	public String listUserViews(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	result.put("returnUrl",super.getWholeUrl(request));

		String nick = user.getNick();
		List<BaseViewDO> existViews = ateyeViewService.listAllViewOfUser(nick);
		putV("valueType",request,result);
		putV("type",request,result);
		putV("keys",request,result);
		putV("app",request,result);
		putV("s_uuid",request,result);
		if ( StringUtils.isNotBlank(request.getParameter("keys")) ){
			result.put("keyDO", new KeysDO(request.getParameter("keys")));
		}
		result.put("views",sortView(existViews));
		result.put("nick",nick);
		List<BaseViewDO> myList = ateyeViewService.listAllViewOfUser(nick);
		Set<String> followedUUids = new HashSet<String>();
		for ( BaseViewDO bv:myList ){
			if ( !bv.getOwner().equals(nick) ){
				followedUUids.add(bv.getUuid());
			}
		}
		result.put("follows",followedUUids);
		result.put("viewDesc",descBaseView(existViews));

		return VIEW_LIST;
	}
	private List<BaseViewDO> sortView(List<BaseViewDO> views ){
		List<BaseViewDO> ret = new ArrayList<BaseViewDO>();
		List<BaseViewDO> mg = new ArrayList<BaseViewDO>();
		for ( BaseViewDO bv:views ){
			if ( bv.getType() == BaseViewDO.TYPE_MULTI ){
				mg.add(bv);
			}
		}
		ret.addAll(sortByName(mg));
		List<BaseViewDO> sg = new ArrayList<BaseViewDO>();
		for ( BaseViewDO bv:views ){
			if ( bv.getType() == BaseViewDO.TYPE_SINGLE){
				sg.add(bv);
			}
		}
		ret.addAll(sortByName(sg));
		return ret;
	}
	
	private List<? extends BaseViewDO> sortByName(List<BaseViewDO> mg) {
		Collections.sort(mg,new Comparator<BaseViewDO>(){
			@Override
			public int compare(BaseViewDO o1, BaseViewDO o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		return mg;
	}
	@RequestMapping("deleteView.htm")
	public String deleteView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isEmpty(uuid) ){
			return getRedirectUrl(request,response);
		}
		BaseViewDO viewDO = ateyeViewService.getView(uuid);
		if ( viewDO == null ){
			return getRedirectUrl(request,response);
		}
		if ( !viewDO.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		ateyeViewService.deleteView(uuid);
		return getRedirectUrl(request,response);
	}
	@RequestMapping("upViewType.htm")
	public String upViewType(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isEmpty(uuid) ){
			return getRedirectUrl(request,response);
		}
		String gType = request.getParameter("gtype");
		if ( StringUtils.isEmpty(gType) ){
			return getRedirectUrl(request,response);
		}
		BaseViewDO viewDO = ateyeViewService.getView(uuid);
		if ( viewDO == null ){
			return getRedirectUrl(request,response);
		}
		if ( !viewDO.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		if ( viewDO.getType() == BaseViewDO.TYPE_MULTI ){
			return getRedirectUrl(request,response);
		}
		SingleViewDO sv = (SingleViewDO)viewDO;
		List<LineDefDO> lines = sv.getLines();
		for ( LineDefDO line:lines ){
			line.setGraphType(Integer.valueOf(gType));
		}
		ateyeViewService.addOrUpdateSingleView(uuid, sv);
		return getRedirectUrl(request,response);
	}
	@RequestMapping("followView.htm")
	public String followView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotEmpty(uuid) ){
			ateyeViewService.userFollowView(nick, uuid);
		}
		return getRedirectUrl(request,response);
	}
	@RequestMapping("unfollowView.htm")
	public String unFollowView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isNotEmpty(uuid) ){
			ateyeViewService.userUnFollowView(nick, uuid);
		}
		return getRedirectUrl(request,response);
	}
	@RequestMapping("deleteLineOfView.htm")
	public String deleteLineOfView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isEmpty(uuid) ){
			return getRedirectUrl(request,response);
		}
		String uniqStr = request.getParameter("uniqStr");
		if ( StringUtils.isBlank(uniqStr) ){
			return getRedirectUrl(request,response);
		}
		BaseViewDO bview = ateyeViewService.getView(uuid);
		if ( !bview.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		if ( bview == null || bview.getType() != BaseViewDO.TYPE_SINGLE){
			return getRedirectUrl(request,response);
		}
		SingleViewDO sv = (SingleViewDO)bview;
		List<LineDefDO> lines = sv.getLines();
		for ( LineDefDO line:lines ){
			String md5sum = DescUtils.md5sum(line.toString());
			if ( md5sum.equals(uniqStr) ){
				lines.remove(line);
				break;
			}
		}
		sv.setLines(lines);
		sv.setGmtModified(new Date());
		ateyeViewService.addOrUpdateSingleView(uuid, sv);
		return getRedirectUrl(request,response);
	}
	@RequestMapping("deleteSViewOfMView.htm")
	public String deleteSViewOfMView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isEmpty(uuid) ){
			return getRedirectUrl(request,response);
		}
		String s_uuid = request.getParameter("s_uuid");
		if ( StringUtils.isEmpty(s_uuid) ){
			return getRedirectUrl(request,response);
		}
		BaseViewDO viewDO = ateyeViewService.getView(uuid);
		if ( viewDO == null || viewDO.getType() == BaseViewDO.TYPE_SINGLE ){
			return getRedirectUrl(request,response);
		}
		if ( !viewDO.getOwner().equals(nick) ){
			return getRedirectUrl(request,response);
		}
		MultiViewDO mv = (MultiViewDO) viewDO;
		List<String> singleViewUUids = mv.getSingleViewUUids();
		singleViewUUids.remove(s_uuid);
		mv.setGmtModified(new Date());
		ateyeViewService.addOrUpdateMultiView(uuid, mv);
		
		return getRedirectUrl(request,response);
	}
	@RequestMapping("add2MultiView.htm")
	public String add2MultiView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		String s_uuid = request.getParameter("s_uuid");
		String name = request.getParameter("name");
		if ( StringUtils.isBlank(s_uuid)){
			return "";
		}
		if ( StringUtils.isBlank(name) && StringUtils.isBlank(uuid)){
			return "";
		}
		MultiViewDO viewDO = null;
		if ( StringUtils.isNotBlank(uuid) ){
			BaseViewDO view = ateyeViewService.getView(uuid);
			if ( view != null && view.getType() == BaseViewDO.TYPE_MULTI){
				viewDO = (MultiViewDO)view;
			}
		}
		if ( viewDO == null ){
			viewDO = new MultiViewDO();
			viewDO.setGmtCreate(new Date());
			viewDO.setName(name);
			viewDO.setOwner(nick);
			viewDO.setType(BaseViewDO.TYPE_MULTI);
			viewDO.setSingleViewUUids(new ArrayList<String>());
		}
		viewDO.getSingleViewUUids().add(s_uuid);
		viewDO.setGmtModified(new Date());
		uuid = ateyeViewService.addOrUpdateMultiView(uuid, viewDO);
		return "redirect:/hubmonitor/viewMultiDetail.htm?uuid="+uuid;
	}
	@RequestMapping("add2SingleView.htm")
	public String add2SingleView(final HttpServletRequest request,final HttpServletResponse response, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		String name = request.getParameter("name");
		List<LineDefDO> lines = null;
		SingleViewDO sv = null;
		if ( StringUtils.isNotEmpty(uuid) ){
			BaseViewDO bview = ateyeViewService.getView(uuid);
			if ( !bview.getOwner().equals(nick) ){
				return getRedirectUrl(request,response);
			}
			if ( bview != null && bview.getType() == BaseViewDO.TYPE_SINGLE){
				sv = (SingleViewDO)bview;
				lines = sv.getLines();
			}
		}else{
			if ( StringUtils.isBlank(name) ){
				return getRedirectUrl(request,response);
			}
		}
		if ( lines == null ){
			lines = new ArrayList<LineDefDO>();
		}
		String vt = request.getParameter("valueType");
		String type = request.getParameter("type");
		String keys = request.getParameter("keys");
		String app = request.getParameter("app");
		String[] mdays = request.getParameterValues("mdays");
		String gtype = request.getParameter("gtype");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(vt) || StringUtils.isBlank(type) || StringUtils.isBlank(keys)
			|| StringUtils.isBlank(gtype) || mdays == null || mdays.length == 0){
			return getRedirectUrl(request,response);
		}
		KeysDO keysDO = new KeysDO(keys);
		
		for ( String mday:mdays ){
			LineDefDO ldf = new LineDefDO();
			ldf.setApp(app);
			List<String> keys2 = keysDO.getKeys();
			if ( keys2.size() > 0 ){
				ldf.setK1(keys2.get(0));
			}
			if ( keys2.size() > 1 ){
				ldf.setK2(keys2.get(1));
			}
			if ( keys2.size() > 2 ){
				ldf.setK3(keys2.get(2));
			}
			if ( keys2.size() > 3 ){
				ldf.setK4(keys2.get(3));
			}
			if ( keys2.size() > 4 ){
				ldf.setK5(keys2.get(4));
			}
			if ( keys2.size() > 5 ){
				ldf.setK6(keys2.get(5));
			}
			ldf.setMday(Integer.valueOf(mday));
			ldf.setType(type);
			ldf.setGraphType(Integer.valueOf(gtype));
			ldf.setValueType(vt);
			addLine(lines,ldf);
		}
		if ( sv == null ){
			sv = new SingleViewDO();
			sv.setGmtCreate(new Date());
			sv.setName(name);
			sv.setOwner(nick);
			sv.setType(SingleViewDO.TYPE_SINGLE);
			sv.setLines(lines);
		}
		sv.setGmtModified(new Date());
		uuid = ateyeViewService.addOrUpdateSingleView(uuid, sv);
		
		return "redirect:/hubmonitor/viewDetail.htm?uuid="+uuid;
	}
	private void addLine(List<LineDefDO> lines,LineDefDO line){
		for ( LineDefDO ld:lines ){
			if ( ld.toString().equals(line.toString()) ){
				return;
			}
		}
		lines.add(line);
	}

	@RequestMapping("view.htm")
	public String kvView(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String k1 = request.getParameter("k1");
		String vt = request.getParameter("valueType");
		if ( StringUtils.isBlank(app) || StringUtils.isBlank(k1) || StringUtils.isBlank(vt) ){
			return null;
		}
		result.put("k1s",request.getParameter("k1s"));
		result.put("k1",k1);
		result.put("k2",request.getParameter("k2"));
		result.put("k1str",UrlUtil.decodeUtf8(k1));
		result.put("valueType", vt);
		result.put("valueTypes",request.getParameter("valueTypes"));
		result.put("app",app);
		String startDateStr = request.getParameter("startDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		String k1s = request.getParameter("k1s");
		String valueTypes = request.getParameter("valueTypes");
		if ( StringUtils.isNotBlank(k1s) ){
			String[] k1Arr = k1s.split(",");
			String[] vtArr = valueTypes.split(",");
			if ( k1Arr.length != vtArr.length ){
				return null;
			}
			Map<String,String> k1Map = new HashMap<String,String>();
			for ( int i=0;i<k1Arr.length;++i ){
				k1Map.put(k1Arr[i],vtArr[i]);
			}
			result.put("k1Map",k1Map);
		}
		return VIEW;
	}
	@RequestMapping("multiView.htm")
	public String multiKvView(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String startDateStr = request.getParameter("startDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		startDateStr = DateFormatUtil.formatToDay(startDate);
		result.put("startDate", startDateStr);
		List<Pair<String, String>> list = multiViewers.get(app);
		if ( list == null ){
			return "";
		}
		String [] k1Arr = new String[list.size()];
		String [] vtArr = new String[list.size()];
		for ( int i=0;i<list.size();++i ){
			k1Arr[i] = list.get(i).getLeft();
			vtArr[i] = list.get(i).getRight();
		}
		String k1s = StringUtils.join(k1Arr,",");
		String valueTypes = StringUtils.join(vtArr,",");
		String k1encode = UrlUtil.encodeDouble(k1Arr[0]);
		return "redirect:/kv/view.htm?app="+app+"&k1s="+UrlUtil.encode(k1s)+"&valueTypes="+valueTypes+"&startDate="+startDateStr
		      + "&k1="+k1encode+"&valueType="+vtArr[0];
	}
}
