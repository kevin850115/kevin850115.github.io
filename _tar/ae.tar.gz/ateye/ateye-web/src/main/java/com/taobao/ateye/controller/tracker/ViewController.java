package com.taobao.ateye.controller.tracker;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.tair.TairCache.TairResult;
import com.taobao.ateye.tair.TairMemCache;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.ateye.view.config.AbstractTableUnitConfig;
import com.taobao.ateye.view.config.TimeTableUnitConfig;
import com.taobao.ateye.view.config.ViewConfig;
import com.taobao.ateye.view.manager.ViewDataManager;
import com.taobao.ateye.view.manager.ViewFormatConvertManager;
import com.taobao.ateye.view.model.CustomTableDataDO;
import com.taobao.tracker.hbase.CViewDO;
import com.taobao.tracker.hbase.service.AteyeCViewService;
@SuppressWarnings("unchecked")
@Controller
@RequestMapping("/view")
public class ViewController  extends AbstractController{
	private static final String VIEW_LIST = "screen/view/list";
	private static final String VIEW_UPDATE= "screen/view/update";
	private static final String VIEW_SHOW = "screen/view/show";
	@Autowired
	private AteyeCViewService ateyeCViewService;
	@Autowired
	private ViewDataManager viewDataManager;
	@Autowired
	private AteyeConfig ateyeConfig;
	@Autowired
	private ViewFormatConvertManager viewFormatConvertManager;
	@Resource
	private TairMemCache tairMemCache;

	@RequestMapping("list.htm")
	public String viewList(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	result.put("returnUrl",super.getWholeUrl(request));

		String nick = user.getNick();	
		 List<CViewDO> userCViews = ateyeCViewService.getUserCViews(nick);
		
		result.put("views",userCViews);
		return VIEW_LIST;
	}
	@RequestMapping("show.htm")
	public String show(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		boolean isPreviewMode = false;
		if ( StringUtils.isBlank(uuid) ){
			uuid = request.getParameter("puuid");
			if ( StringUtils.isBlank(uuid) ){
				return "";
			}
			isPreviewMode = true;
		}
		result.put("uuid", uuid);
		boolean isSpe = false;
		String spe = request.getParameter("spe");
		if ( "1".equals(spe) ){
			result.put("spe","1");
			isSpe = true;
		}
		if ( environmentService.isProduction() ){//����������չʾ�������
			result.put("showSPE",true);
		}
		String unitName = request.getParameter("unitName");
		CViewDO cView = null;
		if ( isPreviewMode ){
			TairResult<CViewDO> rs = tairMemCache.getObject("_view_preview_uuid_"+uuid, CViewDO.class);
			if ( rs.isSuccess() ){
				cView = rs.getResult();
			}
		}else{
			cView = ateyeCViewService.getCViewById(uuid);//dbֵ
		}
		if ( cView == null ){
			return "";
		}
		result.put("isPreviewMode",isPreviewMode);
		result.put("unitName",unitName);
		result.put("view", cView);
		String startDateStr = request.getParameter("startDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateFormatUtil.parseByDay(DateFormatUtil.formatToDay(new Date()));
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		result.put("returnUrl", super.getWholeUrl(request));
		putV("wholeDay", request, result);
		//2.��ȡTable����ʵʱ��Ⱦ
		ViewConfig vc = new ViewConfig(cView.getDetail());
		if ( vc == null || !vc.isDecoded() ){
			return "";
		}
		if ( isSpe ){
			vc.convert2Spe();
		}
		Map<TimeTableUnitConfig, CustomTableDataDO> tableDatas = viewDataManager.fetchTimeTableData(vc,unitName);
		result.put("timetables",tableDatas);
		Map<AbstractTableUnitConfig,CustomTableDataDO> subKTableDatas = viewDataManager.fetchCustomTableData(vc,unitName,startDate);
		result.put("customtables",subKTableDatas);

		result.put("layouts",vc.getUnits());
		result.put("domain", ateyeConfig.getAteyeDomain());
		boolean isOwn = false;
		if ( cView.getNick().equals(nick) ){
			isOwn = true;
		}
		result.put("isOwn",isOwn);
		if ( StringUtils.isNotBlank(unitName) ){
			result.put("tableSort", true);
		}
	
		return VIEW_SHOW;
	}	
	@RequestMapping("convert.htm")
	public String convert(final HttpServletRequest request, ModelMap result) throws Exception {
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) ){
			return "";
		}
		viewFormatConvertManager.formatOld2NewAndSave(uuid);
		return "redirect:/view/list.htm";
	}
	@RequestMapping("copy.htm")
	public String copy(final HttpServletRequest request, ModelMap result) throws Exception {
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) ){
			return "";
		}
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		String nick = user.getNick();
		CViewDO cView = ateyeCViewService.getCViewById(uuid);//dbֵ
		if ( cView == null ){
			return "";
		}
		String newUuid=UUID.randomUUID().toString();
		ateyeCViewService.updateCView(nick, newUuid, cView.getName(), cView.getDetail());
		return "redirect:/view/list.htm";
	}
	@RequestMapping("etViewName.htm")
	public String etViewName(final HttpServletRequest request, ModelMap result) throws Exception {
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) ){
			return "";
		}
		String nn = request.getParameter("newName");
		if ( StringUtils.isBlank(nn) ){
			return "";
		}
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		CViewDO cView = ateyeCViewService.getCViewById(uuid);//dbֵ
		if ( cView == null ){
			return "";
		}
		ateyeCViewService.updateCView(nick, uuid, nn, cView.getDetail());
		return getRedirectUrl(request);
	}
	@RequestMapping("update.htm")
	public String update(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		super.setIsMobile(request, result);
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) ){
			result.put("uuid", UUID.randomUUID().toString());
			result.put("create",true);
			return VIEW_UPDATE;
		}
		result.put("uuid", uuid);
		CViewDO cView = ateyeCViewService.getCViewById(uuid);//dbֵ
		String action = request.getParameter("action");
		if( StringUtils.isNotBlank(action) ){
			String name = request.getParameter("name");
			String desc = request.getParameter("desc");
			result.put("name",name);
			result.put("desc",desc);
		}else{
			if ( cView != null ){
				String name = cView.getName();
				String desc = cView.getDetail();
				result.put("name",name);
				result.put("desc",desc);
			}
		}
		if ( cView != null ){
			String viewNick = cView.getNick();
			if ( nick.equals(viewNick)){
				result.put("owner",true);
			}
		}
		return VIEW_UPDATE;
	}	
	@RequestMapping("doUpdate.htm")
	public String doUpdate(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		String name = request.getParameter("name");
		String desc = request.getParameter("desc");
		if ( StringUtils.isBlank(name) || StringUtils.isBlank(desc) || StringUtils.isBlank(uuid) ){
			result.put("msg","�������Ϊ��");
			return update(request,result);
		}
		String action = request.getParameter("action");
		if ( StringUtils.isBlank(action) ){
			result.put("msg","��������Ϊ��");
			return update(request,result);
		}
		if ( action.equals("�ύ") ){
			ViewConfig ddc = new ViewConfig(desc);
			if ( !ddc.isDecoded() ){
				result.put("msg","��ʽ����,�޷��ύ:"+ddc.getDecodeErrMsg());
				return update(request,result);
			}
			ateyeCViewService.updateCView(nick, uuid, name, desc);
			return "redirect:/view/list.htm";
		}else if ( action.equals("��ʽУ��") ){
			ViewConfig ddc = new ViewConfig(desc);
			if ( !ddc.isDecoded() ){
				result.put("msg","��ʽ����:"+ddc.getDecodeErrMsg());
				return update(request,result);
			}else{
				result.put("s_msg","��ʽУ��ͨ��!");
				return update(request,result);
			}
		}else if ( action.equals("Ԥ��") ){
			ViewConfig ddc = new ViewConfig(desc);
			if ( !ddc.isDecoded() ){
				result.put("msg","��ʽ����,�޷�Ԥ��:"+ddc.getDecodeErrMsg());
				return update(request,result);
			}	
			String pre_uuid = UUID.randomUUID().toString();
			CViewDO cv = new CViewDO();
			cv.setDetail(desc);
			cv.setGmtCreate(new Date());
			cv.setGmtModified(new Date());
			cv.setName(name);
			cv.setNick(nick);
			cv.setUuid(pre_uuid);
			tairMemCache.put("_view_preview_uuid_"+pre_uuid, cv);
			return "redirect:/view/show.htm?puuid="+pre_uuid;
		}
		return VIEW_UPDATE;
	}	
	@RequestMapping("doDel.htm")
	public String doDel(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String nick = user.getNick();
		String uuid = request.getParameter("uuid");
		if ( StringUtils.isBlank(uuid) ){
			return null;
		}
		ateyeCViewService.removeCView(nick, uuid);
		return "redirect:/view/list.htm";
	}	
}
