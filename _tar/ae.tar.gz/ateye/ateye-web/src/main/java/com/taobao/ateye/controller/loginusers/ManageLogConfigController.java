package com.taobao.ateye.controller.loginusers;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.service.EnvironmentService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.LogFilePathDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.LogFilePathDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.oplog.OpLogPolicyManager;
import com.taobao.ateye.tracker.TrackerInfoManager;
import com.taobao.ateye.tracker.TrackerTypeConstant;

@Controller
@RequestMapping("/manage/log")
public class ManageLogConfigController extends AbstractController{
	@Autowired
	private LogFilePathDAO logFilePathDAO;
	@Autowired
	OpLogPolicyManager opLogPolicyManager;
	@Autowired
	TrackerInfoManager trackerInfoManager;

	@Autowired
	private EnvironmentService environmentService;
	
    @RequestMapping("listTrackerLogs.htm") 
    public String listTrackerLogs(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	Map<String,AppDO> allAppMap = appDAO.getAllAppAsMap();
    	Map<Integer, Map<Long, List<LogFilePathDO>>> sorted = logFilePathDAO.getAllLogFilePathMap(environmentService.getEnvironmentType().getEnv());
    	result.put("types", sorted);
    	result.put("appMap", allAppMap);
    	result.put("typeMap", TrackerTypeConstant.typeDesc);
    	super.initBizMap(result);
    	return "/manage/log/listTrackerLogs";
    }
    
    @RequestMapping("auDelPolicy.htm") 
    public String auDelPolicy(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	String reserveMonth = request.getParameter("month");
    	if ( StringUtils.isBlank(app) || StringUtils.isBlank(reserveMonth) ){
    		return "";
    	}
    	opLogPolicyManager.addOrUpdateDelPolicy(app, Integer.valueOf(reserveMonth));
    	return "redirect:/manage/log/listHt.htm";
    }
}
