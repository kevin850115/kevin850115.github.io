package com.taobao.ateye.controller.scene;

import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.security.util.StringUtils;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.SceneCatDAO;
import com.taobao.ateye.dal.SceneEntryPointDAO;
import com.taobao.ateye.dal.SceneLevelDAO;
import com.taobao.ateye.dal.SceneRelationInfoDAO;
import com.taobao.ateye.dataobject.SceneCatDO;
import com.taobao.ateye.dataobject.SceneLevelDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.relation.manager.SceneManager;
import com.taobao.ateye.relation.model.RNode;
import com.taobao.ateye.relation.model.RNodeExtInfo;
import com.taobao.ateye.relation.model.RTree;
import com.taobao.ateye.relation.model.RTreeResult;
import com.taobao.ateye.relation.tree.node.NodeExtUtils;
import com.taobao.ateye.scene.DependencyType;
import com.taobao.ateye.scene.info.SceneInfoManager;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.security.util.SecurityUtil;
@Controller
@RequestMapping("/scene")
public class SceneController extends AbstractController{
	private static final String VIEW_SCENE = "screen/scene/viewScene";
	private static final String VIEW_SCENE_INTABLE = "screen/scene/viewSceneInTable";
	private static final String LEVEL_LIST = "screen/scene/levelList";
	private static final String CAT_LIST = "screen/scene/catList";
	
	@Autowired
	private SceneEntryPointDAO sceneEntryPointDAO;
	@Autowired
	private SceneLevelDAO sceneLevelDAO;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private SceneCatDAO sceneCatDAO;
	@Autowired
	private SceneManager sceneManager;
	@Autowired
	private SceneRelationInfoDAO sceneRelationInfoDAO;
	@Autowired
	private SceneInfoManager sceneInfoManager;


	@RequestMapping("catList.htm")
	public String catList(final HttpServletRequest request, final ModelMap result) throws Exception {
	
		List<SceneCatDO> all = sceneCatDAO.getAll();
		
		result.put("cats", all);
		
		return CAT_LIST;
    }
	@RequestMapping("levelList.htm")
	public String levelList(final HttpServletRequest request, final ModelMap result) throws Exception {
	
		List<SceneLevelDO> all = sceneLevelDAO.getAll();
		
		result.put("levels", all);
		
		return LEVEL_LIST;
    }

	@RequestMapping("viewSingleSceneAppRelation.htm")
	public String viewSceneAppRelation(final HttpServletRequest request, final ModelMap result) throws Exception {
		String sceneName = request.getParameter("sceneName");
		String entryPointType = request.getParameter("entryPointType");
		if ( StringUtils.isBlank(entryPointType) ){
			entryPointType = DependencyType.HSF_S.getType();
		}
		result.put("entryPointType", entryPointType);
		String clientAppName = request.getParameter("clientAppName");
		result.put("clientAppName", clientAppName);
		String type=request.getParameter("type");
		if (!"day".equals(type) ){
			type = "hour";
		}
		String day = request.getParameter("day");
		String ajaxUrl = "/monitor/querySingleSceneAppRelation.htm?sceneName="+sceneName+"&type="+type+"&entryPointType="+entryPointType+"&clientAppName="+clientAppName;
		if ( StringUtils.isNotBlank(day) ){
			ajaxUrl += "&day="+day;
		}else{
			day = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);	
		}
		Date dateObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		result.put("sceneName", sceneName);
		result.put("type", type);
		result.put("day", day);
		
		result.put("arrowLeft2Right","true");
		result.put("ajaxUrl",ajaxUrl);
		result.put("timeUrl", "/scene/viewSingleSceneAppRelation.htm?sceneName="+sceneName+"&entryPointType="+entryPointType+"&clientAppName="+clientAppName);
		result.put("sceneTitle", "�������:<font class='green fb'>"+sceneName+"</font>��<font class='red fb'>Ӧ��������</font>");
		result.put("addUrl", "/scene/viewSingleSceneServiceRelation.htm?sceneName="+sceneName+"&type="+type+"&day="+day+"&entryPointType="+entryPointType+"&clientAppName="+clientAppName);
		result.put("addUrlTxt", "�鿴����������");
		if ( "day".equals(type) ){
			result.put("dateStart",CalendarUtil.toString(dateObj,CalendarUtil.TIME_PATTERN));
			result.put("dateEnd",CalendarUtil.toString(DateUtils.addDays(dateObj,1),CalendarUtil.TIME_PATTERN));
		}else{
			result.put("dateStart",DateFormatUtil.formatToHour(new Date())+":00:00");
			result.put("dateEnd","now");
		}
		result.put("showAdvOpt","false");
		return VIEW_SCENE;
    }
	private String buildTreeInTable(RNode root) {
		String html="";
		List<RNode> childrens = root.getChildren();
		for (RNode rn:childrens ){
			html+="<tr>";
			html+="<td>"+rn.getShowName()+"</td>";
			html+="<td>";
			for (RNode c:rn.getChildren()){
				html+="<a class='f13 fb green' target='_blank' href='/scene/scene.htm?name='"+c.getUniqName()+"'>[��������]</a>";
				html+=c.getShowName();
				html+="<a class='f13' target='_blank' href='/scene/viewSingleSceneAppRelation.htm?sceneName="+c.getUniqName()+"&type=day&entryPointType="+c.getConsumerType()+"'>[Ӧ������]</a>";
				html+="<a class='f13' target='_blank' href='/scene/viewSingleSceneServiceRelation.htm?sceneName="+c.getUniqName()+"&type=day&entryPointType="+c.getConsumerType()+"'>[��������]</a>";
				RNodeExtInfo extInfo = c.getExtInfoShow();
				if ( extInfo != null ){
					html += "<font>"+extInfo.getSource()+"</font> | ";
					html += NodeExtUtils.buildStatHtml(extInfo);
				}
				html+="<br>";
			}
			html+="</td>";
			html+="</tr>";
		}
		return html;
	}
	@RequestMapping("viewSceneByAppNodeGroup.htm")
	public String viewSceneByAppNodeGroup(final HttpServletRequest request, final ModelMap result) throws Exception {
		String appNodeGroup = request.getParameter("appNodeGroup");
		String type=request.getParameter("type");
		if (!"day".equals(type) ){
			type = "hour";
		}
		String day = request.getParameter("day");
		String ajaxUrl = "/monitor/querySceneByAppNodeGroup.htm?appNodeGroup="+appNodeGroup+"&type="+type;
		if ( StringUtils.isNotBlank(day) ){
			ajaxUrl += "&day="+day;
		}else{
			day = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);	
		}
		Date dateObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		result.put("appNodeGroup", appNodeGroup);
		result.put("type", type);
		result.put("day", day);
		result.put("arrowLeft2Right","false");
		result.put("ajaxUrl",ajaxUrl);
		result.put("timeUrl", "/scene/viewSceneByAppNodeGroup.htm?appNodeGroup="+appNodeGroup);
		result.put("sceneTitle", "Ӧ�÷���<font class='green fb'>"+appNodeGroup+"</font>��֧�ŵ�ȫ������");
		result.put("time",DateFormatUtil.formatToHour(new Date()));
		if ( "day".equals(type) ){
			result.put("dateStart",CalendarUtil.toString(dateObj,CalendarUtil.TIME_PATTERN));
			result.put("dateEnd",CalendarUtil.toString(DateUtils.addDays(dateObj,1),CalendarUtil.TIME_PATTERN));
		}else{
			result.put("dateStart",DateFormatUtil.formatToHour(new Date())+":00:00");
			result.put("dateEnd","now");
		}
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		RTree tree = sceneManager.buildSceneByAppNodeGroup(appNodeGroup, type, dayObj);
		if ( tree != null ){
			result.put("treeTableHtml",buildTreeInTable(tree.getRoot()));
		}
		return VIEW_SCENE_INTABLE;
    }
	@RequestMapping("viewSceneByService.htm")
	public String viewSceneByService(final HttpServletRequest request, final ModelMap result) throws Exception {
		String service = request.getParameter("service");
		String type=request.getParameter("type");
		if (!"day".equals(type) ){
			type = "hour";
		}
		String day = request.getParameter("day");
		String ajaxUrl = "/monitor/querySceneByService.htm?service="+service+"&type="+type;
		if ( StringUtils.isNotBlank(day) ){
			ajaxUrl += "&day="+day;
		}else{
			day = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);	
		}
		Date dateObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		result.put("service", service);
		result.put("type", type);
		result.put("day", day);
		result.put("arrowLeft2Right","false");
		result.put("ajaxUrl",ajaxUrl);
		result.put("timeUrl", "/scene/viewSceneByService.htm?service="+service);
		result.put("sceneTitle", "����:<font class='green fb'>"+service+"</font>��֧�ŵ�ȫ������");
		result.put("time",DateFormatUtil.formatToHour(new Date()));
		if ( "day".equals(type) ){
			result.put("dateStart",CalendarUtil.toString(dateObj,CalendarUtil.TIME_PATTERN));
			result.put("dateEnd",CalendarUtil.toString(DateUtils.addDays(dateObj,1),CalendarUtil.TIME_PATTERN));
		}else{
			result.put("dateStart",DateFormatUtil.formatToHour(new Date())+":00:00");
			result.put("dateEnd","now");
		}
		Date dayObj = new Date();
		if ( StringUtils.isNotBlank(day) ){
			dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		}
		RTree tree = sceneManager.buildSceneByService(service, type, dayObj);
		if ( tree != null ){
			result.put("treeTableHtml",buildTreeInTable(tree.getRoot()));
		}
		return VIEW_SCENE_INTABLE;	
    }
	@RequestMapping("viewSingleSceneServiceRelation.htm")
	public String viewSceneServiceRelation(final HttpServletRequest request, final ModelMap result) throws Exception {
		String sceneName = request.getParameter("sceneName");
		String clientAppName = request.getParameter("clientAppName");
		String entryPointType = request.getParameter("entryPointType");
		if ( StringUtils.isBlank(entryPointType) ){
			entryPointType = DependencyType.HSF_S.getType();
		}
		String includeDAO = request.getParameter("includeDAO");
		String onlyMainPath = request.getParameter("onlyMainPath");
		result.put("entryPointType", entryPointType);
		String type=request.getParameter("type");
		if (!"day".equals(type) ){
			type = "hour";
		}
		if ( StringUtils.isNotBlank(includeDAO)){
			result.put("includeDAO","1");
		}
		if ( StringUtils.isNotBlank(onlyMainPath) ){
			result.put("onlyMainPath","1");
		}
		String inTable = request.getParameter("inTable");
		boolean isInTable = false;
		if ( StringUtils.isNotBlank(inTable) && "1".equals(inTable)) {
			isInTable = true;
		}else {
			inTable = "";
		}
		result.put("isInTable", isInTable);
		result.put("inTable", inTable);
		String day = request.getParameter("day");
		String ajaxUrl = "/monitor/querySingleSceneServiceRelation.htm?sceneName="+sceneName+"&type="+type+"&entryaPointType="+entryPointType+"&clientAppName="+clientAppName;
		if ( StringUtils.isNotBlank(day) ){
			ajaxUrl += "&day="+day;
		}else{
			day = CalendarUtil.toString(new Date(), CalendarUtil.DATE_FMT_3);	
		}
		String addUrl = "";
		if ( StringUtils.isNotBlank(includeDAO) ){
			addUrl += "&includeDAO=1";
		}
		if ( StringUtils.isNotBlank(onlyMainPath) ){
			addUrl += "&onlyMainPath=1";
		}
		ajaxUrl += addUrl;
		Date dateObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
		result.put("sceneName", sceneName);
		result.put("clientAppName",clientAppName);
		result.put("type", type);
		result.put("day", day);
		result.put("arrowLeft2Right","true");
		if ( isInTable ) {//���չʾ����Ҫ�첽����
			Date dayObj = new Date();
			if ( StringUtils.isNotBlank(day) ){
				dayObj = CalendarUtil.toDate(day, CalendarUtil.DATE_FMT_3);
			}
			RTreeResult tree = sceneManager.buildSingleSceneServiceRelation(sceneName,type,clientAppName,dayObj,entryPointType,
					StringUtils.isNotBlank(includeDAO),
					StringUtils.isNotBlank(onlyMainPath)
					);
			RTree tr = tree.getTree();
			result.put("treeTableHtml",buildTreeHtml(tr));
		}else {
			result.put("ajaxUrl",ajaxUrl);
		}
		result.put("timeUrl", "/scene/viewSingleSceneServiceRelation.htm?sceneName="+sceneName+"&entryPointType="+entryPointType+"&clientAppName="+clientAppName+addUrl+"&inTable="+inTable);
		result.put("sceneTitle", "�������:<font class='green fb'>"+sceneName+"</font>��<font class='fb red'>����������</font>");
		result.put("addUrl", "/scene/viewSingleSceneAppRelation.htm?sceneName="+sceneName+"&type="+type+"&day="+day+"&entryPointType="+entryPointType+"&clientAppName="+clientAppName+"&inTable="+inTable);
		result.put("addUrlTxt", "�鿴Ӧ��������");
		if ( "day".equals(type) ){
			result.put("dateStart",CalendarUtil.toString(dateObj,CalendarUtil.TIME_PATTERN));
			result.put("dateEnd",CalendarUtil.toString(DateUtils.addDays(dateObj,1),CalendarUtil.TIME_PATTERN));
		}else{
			result.put("dateStart",DateFormatUtil.formatToHour(new Date())+":00:00");
			result.put("dateEnd","now");
		}
		result.put("showAdvOpt","true");
		return VIEW_SCENE;
    }
	static class NodeS{
		/*
		 * RNodeӦ�ó��ֵ�����,��1��ʼ��
		 */
		public Map<Integer,RNode> nodeIdx = new HashMap<Integer,RNode>();//��ǰ��Ľڵ���
		public int currentIdx=1;
		public void add(RNode node) {
			nodeIdx.put(currentIdx, node);
			currentIdx += node.getLastNodeCount();
		}
		public RNode getNode(int j) {
			return nodeIdx.get(j);
		}
	}
	/*
	 * ��һ������ԭ��һ�����
	 */
	private String buildTreeHtml(RTree tr) {
		if ( tr == null || tr.getRoot() == null ) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		RNode root = tr.getRoot();
		int maxDepth = root.getDepth(1);
		/*<��1��ʼ,ÿ������>*/
		Map<Integer,NodeS> nodeOfDepths = new HashMap<Integer,NodeS>();
		fillNodeOfDepths(root,nodeOfDepths,1,maxDepth);
		sb.append("<tr>");
		for ( int i=1;i<=maxDepth;++i ) {
			sb.append("<td class='green f14 fb'>��"+ i +"��</td>");
		}
		sb.append("</tr>");
		//�������
		int totalCnt = root.getLastNodeCount();
		String tableHtml = buildChildHtml(root,nodeOfDepths,totalCnt,maxDepth);
		sb.append(tableHtml);
		return sb.toString();
	}
	private String buildChildHtml(RNode root,Map<Integer, NodeS> nodeOfDepths,int totalCnt,int totalDepth) {
		if ( nodeOfDepths == null ) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		int idx = 1;//idx��������js
		for (int i=1;i<=totalCnt;++i ) {
			sb.append("<tr>");
			for ( int j = 1; j<= totalDepth; ++j ) {
				idx ++;
				NodeS nodeS = nodeOfDepths.get(j);
				if ( nodeS == null ) {
					break;
				}
				RNode node = nodeS.getNode(i);
				if ( node == null ) {
					continue;
				}
				if ( "������".equals(node.getRelationInfoType() )){
					sb.append("<td rowspan="+node.getLastNodeCount()+" style='background-color:lightgray'>");
				}else {
					sb.append("<td rowspan="+node.getLastNodeCount()+">");
				}
				if (node.isEmptyNode() ) {
					;//do Nothing
				}else {
					sb.append("<span class='f16'>"+node.getShowNameWithUrl()+"</span>");
					//�����������
					RNodeExtInfo extInfo = node.getExtInfoShow();
					if ( extInfo != null ){
						//sb.append("<font>"+extInfo.getSource()+"</font>");
						sb.append("<br>");
						sb.append(NodeExtUtils.buildStatHtml(extInfo));
					}
					//HSF��ʱ
					String timeout = node.getHsfTimeoutDesc();
					if ( StringUtils.isNotBlank(timeout) ) {
						sb.append("<br><font class='red f13'>Hsf��ʱ����: "+timeout+"</font>");
					}
					//��ϵ����
					String relationUniqKey = node.getRelationUniqKey();
					if (StringUtils.isNotBlank(relationUniqKey) && node != root) {//ROOT�ڵ�Ͳ��������
						sb.append("<br><div><span class='f13 fi fl'>��������:</span>");
						sb.append(buildRelationDepType(idx,node.getSceneId(),node.getRelationInfoType(),node.getRelationUniqKey()));
						sb.append("</div>");
						sb.append("<div><span class='f13 fi fl'>������ע:</span>");
						sb.append(buildRelationDepDesc(idx,node.getSceneId(),node.getRelationInfoDesc(),node.getRelationUniqKey()));
						sb.append("</div>");
						String relationInfoEditor = node.getRelationInfoEditor();
						if ( StringUtils.isNotBlank(relationInfoEditor) ) {
							sb.append("<span class='f13 fi'>���༭��:"+relationInfoEditor+"</span>");
						}
					}
				}
				sb.append("</td>");
			}
			sb.append("</tr>");
		}
		return sb.toString();
	}
	private String buildRelationDepDesc(int idx,long sceneId,String depDesc,String uniqK) {
		String ret = "";
		ret += "<form class='form-inline f13 fi' style='margin:0px 0px 0px'>";
		ret += "<span class='w300' style='display:block' id='n_txt_"+idx+"'>"+(depDesc==null?"":depDesc)+"</span>";
		ret += "<span id='n_modify_"+idx+"' hidden>";
		ret += "<input id='n_ipt_"+idx+"' value='"+(depDesc==null?"":depDesc)+"' class='w300' required></input>";
		ret += "<input id='n_smt_"+idx+"' class='btn btn-success ml2' type='button' value='����' onclick=saveDesc("+sceneId+",'"+uniqK+"',"+idx+")></input>";
		ret += "<input id='n_cancel_"+idx+"' class='btn ml2' type='button' value='ȡ��' onclick=cancelDesc("+idx+")></input>";
		ret += "</span>";
		ret += "<a href='javascript:void(0)' id='n_edit_"+idx+"' onclick=openDesc4Save("+idx+")><i class='icon-edit'></i></a>";
		ret += "</form>";
		return ret;
	}
	private String buildRelationDepType(int idx,long sceneId,String depType,String uniqK) {
		String ret = "";
		ret += "<form class='form-inline f13 fi' style='margin:0px 0px 0px'>";
		ret += "<span id='l_txt_"+idx+"'>"+(depType==null?"":depType)+"</span>";
		ret += "<span id='l_modify_"+idx+"' hidden>";
		ret += "<select id='l_ipt_"+idx+"' class='w100 ml5'>";
		ret += "	<option value='δ����' "+ ("δ����".equals(depType)?"selected":"")+" >δ����</option>";
		ret += "	<option value='ǿ����' "+ ("ǿ����".equals(depType)?"selected":"")+" >ǿ����</option>";
		ret += "	<option value='������' "+ ("������".equals(depType)?"selected":"")+" >������</option>";
		ret += "</select>";
		ret += "<input id='l_smt_"+idx+"' class='btn btn-success ml2' type='button' value='����' onclick=saveDepType("+sceneId+",'"+uniqK+"',"+idx+")></input>";
		ret += "<input id='l_cancel_"+idx+"' class='btn ml2' type='button' value='ȡ��' onclick=cancelDepType("+idx+")></input>";
		ret += "</span>";
		ret += "<a href='javascript:void(0)' id='l_edit_"+idx+"' onclick=openDepType4Save("+idx+")><i class='icon-edit'></i></a>";
		ret += "</form>";
		return ret;
	}
	@RequestMapping("updateRelationDepTypeAjax.htm")
	public String updateRelationDepTypeAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}

		String nick = user.getNick();	
		String sceneId = request.getParameter("sceneId");
		String key = request.getParameter("key");
		String depType = request.getParameter("type");
		PrintWriter out = response.getWriter();
		if (StringUtils.isBlank(sceneId) || StringUtils.isBlank(key) || StringUtils.isBlank(depType) ) {
			return null;
		}
		Map<String,String> ret = new HashMap<String,String>();
		
		Pair<String, String> sceneInfo = sceneInfoManager.parseSceneInfoKeyOfBase64(key);
		if ( sceneInfo == null ) {
			return null;
		}
		int update = sceneRelationInfoDAO.updateDepType(Long.valueOf(sceneId),sceneInfo.getKey(),sceneInfo.getValue(),nick,depType);
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateRelationDescAjax.htm")
	public String updateRelationDescAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}

		String nick = user.getNick();	
		String sceneId = request.getParameter("sceneId");
		String key = request.getParameter("key");
		String desc = request.getParameter("desc");
		PrintWriter out = response.getWriter();
		if (StringUtils.isBlank(sceneId) || StringUtils.isBlank(key) || StringUtils.isBlank(desc) ) {
			return null;
		}
		Map<String,String> ret = new HashMap<String,String>();
		
		Pair<String, String> sceneInfo = sceneInfoManager.parseSceneInfoKeyOfBase64(key);
		if ( sceneInfo == null ) {
			return null;
		}
		int update = sceneRelationInfoDAO.updateDepDesc(Long.valueOf(sceneId),sceneInfo.getKey(),sceneInfo.getValue(),nick,desc);
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	
	/*
	 * ��һ�����ĸ����ڵ����
	 */
	private void fillNodeOfDepths(RNode father,Map<Integer, NodeS> nodeMap,int currentDepth,int maxDepth) {
		addRNode(nodeMap,currentDepth,father);
		if ( father.getChildren() == null || father.getChildren().size() == 0 ) {
			//������������
			for ( int i=currentDepth+1;i<=maxDepth;i++ ) {
				addRNode(nodeMap,i,RNode.newEmptyNode());
			}
		}
		for (RNode child:father.getChildren()) {
			fillNodeOfDepths(child, nodeMap, currentDepth+1,maxDepth);
		}
	}
	private void addRNode(Map<Integer, NodeS> nodeMap,int depth,RNode node) {
		NodeS list = nodeMap.get(depth);
		if ( list == null ) {
			list = new NodeS();
			nodeMap.put(depth, list);
		}
		list.add(node);
	}
	@RequestMapping("viewTest.htm")
	public String viewTest(final HttpServletRequest request, final ModelMap result) throws Exception {
		String ajaxUrl = "/monitor/queryTest.htm";
		
		result.put("arrowLeft2Right","true");
		result.put("ajaxUrl",ajaxUrl);
		
		return VIEW_SCENE;
    }
	@RequestMapping("addLevel.htm")
	public String addLevel(final HttpServletRequest request, final ModelMap result) throws Exception {
		String levelName = request.getParameter("levelName");
		String levelDesc = request.getParameter("levelDesc");
		if ( StringUtils.isNotBlank(levelName) && StringUtils.isNotBlank(levelDesc) ){
			SceneLevelDO sl = new SceneLevelDO();
			sl.setGmtCreate(new Date());
			sl.setGmtModified(new Date());
			sl.setLevelName(levelName);
			sl.setLevelDesc(levelDesc);
			sl.setEnv("");
			try{
				sceneLevelDAO.insert(sl);
			}catch(DAOException e){
				log.error("дDB�쳣",e);
			}
		}
		return "redirect:/scene/levelList.htm";
    }
	@RequestMapping("addCat.htm")
	public String addCat(final HttpServletRequest request, final ModelMap result) throws Exception {
		String name = request.getParameter("name");
		if ( StringUtils.isNotBlank(name) ){
			SceneCatDO sl = new SceneCatDO();
			sl.setGmtCreate(new Date());
			sl.setGmtModified(new Date());
			sl.setName(name);
			try{
				sceneCatDAO.insert(sl);
			}catch(DAOException e){
				log.error("дDB�쳣",e);
			}
		}
		return "redirect:/scene/catList.htm";
    }
	@RequestMapping("updateLevelAjax.htm")
	public String updateLevelAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String levelId = request.getParameter("levelId");
		String levelName = request.getParameter("levelName");
		PrintWriter out = response.getWriter();
		String levelDesc = request.getParameter("levelDesc");
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(levelId) && StringUtils.isNotBlank(levelName) ){
			update = sceneLevelDAO.updateLevelName(levelId,levelName);
		}else if ( StringUtils.isNotBlank(levelId) && StringUtils.isNotBlank(levelDesc) ){
			update = sceneLevelDAO.updateLevelDesc(levelId,levelDesc);
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("updateCatAjax.htm")
	public String updateCatAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		PrintWriter out = response.getWriter();
		Map<String,String> ret = new HashMap<String,String>();
		int update=0;
		if ( StringUtils.isNotBlank(id) && StringUtils.isNotBlank(name) ){
			update = sceneCatDAO.updateCatName(id,name);
		}
		ret.put("success", update>0?"true":"false");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
}
