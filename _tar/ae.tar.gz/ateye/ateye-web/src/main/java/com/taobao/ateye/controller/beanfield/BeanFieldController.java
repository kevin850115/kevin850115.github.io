package com.taobao.ateye.controller.beanfield;


import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.taobao.ateye.base.Pair;
import com.taobao.ateye.beanfield.BeanFieldCompare;
import com.taobao.ateye.changefree.CFType;
import com.taobao.ateye.changefree.ChangeFreeRS;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.SwitchBaseLineDAO;
import com.taobao.ateye.dataobject.*;
import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Maps;
import com.taobao.ateye.applog.AppLog;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.beanfield.BeanField;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.AppChangeMonitor;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.UserAuditService;
import com.taobao.ateye.switcher.app.AppPersistenceSwitchDO;
import com.taobao.ateye.switcher.app.AppPersistenceSwitchManager;
import com.taobao.ateye.useaudit.UserAuditHistoryManager;
import com.taobao.ateye.util.AgentVersionUtil;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;
import com.taobao.security.util.SecurityUtil;

@Controller
@RequestMapping("/beanfield")
public class BeanFieldController extends AbstractController
{
	private static Logger logger = Logger.getLogger("SwitchLogger");
	private ExecutorService exec = Executors.newCachedThreadPool();
	
	private static final String DIMENSION2="screen/beanfield/dimension2";
	private static final String ALL_FIELDS_OF_A_SINGLE_MACHINE2="screen/beanfield/allFieldsOfSingleMachine2";
	private static final String ALL_FIELDS_OF_AN_APP2="screen/beanfield/allFieldsOfAnApp2";
	public static final String BATCH_SET_RESULT2="screen/beanfield/batchSetResult2";
	private static final String DELETE_PERSIST2 ="screen/beanfield/deletePersist2";
	private static final String SWITCH_ERROR2="screen/beanfield/error2";

	@Autowired
	private AppPersistenceSwitchManager appPersistenceSwitchManager;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private AppService appService;
	@Autowired
	private UrlGenerator urlGenerator;
	@Autowired
	private UserAuditService userAuditService;
	@Autowired
	private AgentVersionUtil agentVersionUtil;
	@Autowired
	private UserAuditHistoryManager userAuditHistoryManager;

	@Autowired
	private AppDAO appDAO;

	@Autowired
	private SwitchBaseLineDAO switchBaseLineDAO;

	
    @RequestMapping("selectApp2.htm")
    public String selectApp2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/beanfield/beanfieldDimension2.htm");
    	result.put("level2","��̬����");
    	result.put("level2Url","/beanfield/selectApp2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
    private void _dimension(final HttpServletRequest request, ModelMap result) throws DAOException{
    	String app=request.getParameter("app");
    	List<MachineDO> machines=opsServic.getAllMachinesBelongToAnApp(app);

    	result.put("env",this.environmentService.getEnvironmentType().getEnv());

    	String refreshed = request.getParameter("refreshed");
    	if(StringUtils.isNotBlank(refreshed)){
    		result.put("refreshed",refreshed);
		}
    	result.put("machines", machines);
    	result.put("app", app);
		result.put("returnUrl",super.getWholeUrl(request));
		//���ڿ��ؿ��չ��ܣ�ֻ�ڻ�Ʊ��Ӧ��չʾ
		AppDO appDO = appDAO.getAppByName(app);
		if(appDO!=null && appDO.getBizType()==11){
			result.put("showSnapShot",true);
			SwitchBaseLineDO lineDO = switchBaseLineDAO.selectByAppId(appDO.getId(),environmentService.getEnvironmentType().getEnv());
			if(lineDO!=null){
				result.put("existSnapShot",true);
			}
		}
    }
    @RequestMapping("beanfieldDimension2.htm")
    public String dimension2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
    	_dimension(request, result);
    	return DIMENSION2;
    }

    @RequestMapping("compareBaseLine.htm")
	public String compareBaseLine(final HttpServletRequest request,final HttpServletResponse response,  ModelMap result) throws DAOException, UnsupportedEncodingException {
		String app=request.getParameter("app");
		String ip=request.getParameter("ip");
		String port = request.getParameter("port");
		result.put("app",app);
		result.put("ip",ip);
		result.put("port",port);
		result.put("machineName",request.getParameter("machineName"));
		AppDO appDO = appDAO.getAppByName(app);
		if(appDO == null){
			result.put("errorMsg", "�޷��鵽������Ϣ");
		}else{
			SwitchBaseLineDO switchBaseLineDO = switchBaseLineDAO.selectByAppId(appDO.getId(),environmentService.getEnvironmentType().getEnv());
			if(switchBaseLineDO==null){
				result.put("errorMsg", "�޷��鵽Ӧ�õĻ��ߣ����ֱ������");
			}else{
				Pair<Boolean,List<BeanField>> pair = getBeanField(ip,port,result);
				if(pair.getFirst()){
					List<BeanField> baseLineFiled = null;
					if(com.taobao.ateye.util.reflect.StringUtils.isNotEmpty(switchBaseLineDO.getSwitchInfo())){
						baseLineFiled = JSON.parseArray(switchBaseLineDO.getSwitchInfo(),BeanField.class);
					}
					if(CollectionUtils.isEmpty(pair.getSecond())){
						result.put("errorMsg", "��ǰ�����޿�����Ϣ");
					}else if(CollectionUtils.isEmpty(baseLineFiled)){
						result.put("errorMsg", "�����޿�����Ϣ");
					}else{
						int notEqual = 0;
						int allTotal = 0;
						List<BeanFieldCompare> compares = compare(pair.getSecond(),baseLineFiled);
						if(CollectionUtils.isNotEmpty(compares)){
							for (BeanFieldCompare compare : compares) {
								allTotal++;
								if (!compare.isEqual()){
									notEqual++;
								}
							}
						}
						result.put("desc","����"+allTotal+"�� ���Ա�"+(notEqual==0?",�޲�ͬ":",���ƣ�"+notEqual+"������ͬ"));
						Collections.sort(compares, new Comparator<BeanFieldCompare>() {
							@Override
							public int compare(BeanFieldCompare o1, BeanFieldCompare o2) {
								if(o1.isEqual() && !o2.isEqual()){
									return 1;
								}else if(!o1.isEqual() && o2.isEqual()){
									return -1;
								}else{
									return 0;
								}
							}
						});
						result.put("compares",compares);
					}

				}
			}
		}
		return "screen/beanfield/compareBaseLine";
	}

	private List<BeanFieldCompare> compare(List<BeanField> curBeanFields, List<BeanField> baseLineFileds) {
		List<BeanFieldCompare> compares = Lists.newArrayList();
		Map<String,BeanField> curMap = Maps.newHashMap();
		for (BeanField beanField : curBeanFields) {
			curMap.put(beanField.getBeanName()+"_"+beanField.getFieldName(),beanField);
		}
		Map<String,BeanField> baselineMap = Maps.newHashMap();
		for (BeanField beanField : baseLineFileds) {
			baselineMap.put(beanField.getBeanName()+"_"+beanField.getFieldName(),beanField);
		}
		for (BeanField curBeanField : curBeanFields) {
			BeanFieldCompare compare = new BeanFieldCompare();
			compare.setBeanField(curBeanField);
			BeanField baseLine = baselineMap.get(curBeanField.getBeanName()+"_"+curBeanField.getFieldName());
			if(baseLine!=null){
				compare.setBaseLineValue(baseLine.getCurrValue());
				if(curBeanField.getCurrValue()!=null){
					if(curBeanField.getCurrValue().equalsIgnoreCase(baseLine.getCurrValue())){
						compare.setEqual(true);
						compare.setDesc("��ͬ");
					}else{
						compare.setEqual(false);
						compare.setDesc("����ͬ");
					}

				}else if(curBeanField.getCurrValue() == null){
					if(baseLine.getCurrValue() == null){
						compare.setEqual(true);
						compare.setDesc("��ͬ");
					}else{
						compare.setEqual(false);
						compare.setDesc("����ͬ");
					}
				}
			}else{
				compare.setEqual(false);
				compare.setDesc("���߲����ڸò���");
			}
			compares.add(compare);
		}
		for (BeanField baseLineFiled : baseLineFileds) {
			String key  = baseLineFiled.getBeanName()+"_"+baseLineFiled.getFieldName();
			if(!curMap.containsKey(key)){
				BeanFieldCompare compare = new BeanFieldCompare();
				compare.setBeanField(baseLineFiled);
				compare.setBaseLineValue(baseLineFiled.getCurrValue());
				compare.getBeanField().setCurrValue(null);
				compare.setEqual(false);
				compare.setDesc("��ǰ���������ڸò���");
			}
		}
		return compares;

	}

	private Pair<Boolean,List<BeanField>> getBeanField(String ip, String port, ModelMap result){
		Map<String,String> params=new HashMap<String,String>();
		params.put("type", "SWITCH");
		params.put("action", "list");
		String url="";
		try {
			url = urlGenerator.getUrl(ip,port,params);
		} catch (Exception e1) {
			result.put("errorMsg", e1.getMessage());
			return new Pair<Boolean, List<BeanField>>(false,null);
		}
		List<BeanField> allFields = new ArrayList<BeanField>();
		try {
			String json = HttpClientUtil.getResult(url);
			JSONArray jsonArray = new JSONArray(json);
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(i);
				BeanField bf=BeanField.getBeanField(jsonObject);
				if(bf!=null)
					allFields.add(bf);
			}
		} catch (Exception e) {
			logger.error("��ȡ������Ϣ�쳣 ip:"+ip+" port:"+port+" params:"+params,e);
			result.put("errorMsg", e.getMessage());
			return new Pair<Boolean, List<BeanField>>(false,null);
		}
		return new Pair<Boolean, List<BeanField>>(true,allFields);
	}

    @RequestMapping("saveBaseLine.htm")
    public String saveBaseLine(final HttpServletRequest request,final HttpServletResponse response,  ModelMap result) throws DAOException, UnsupportedEncodingException {
		String app=request.getParameter("app");
		String ip=request.getParameter("ip");
		String port = request.getParameter("port");
		checkEnvIsMatch(ip,app);
		Pair<Boolean,List<BeanField>>  pair =  getBeanField(ip,port,result);
		if(pair.getFirst()){
			AppDO appDO = appDAO.getAppByName(app);
			if(appDO == null){
				result.put("errorMsg", "�޷��鵽������Ϣ");
			}else{
				switchBaseLineDAO.deleteByAppId(appDO.getId(),environmentService.getEnvironmentType().getEnv());
				SwitchBaseLineDO baseLineDO = new SwitchBaseLineDO();
				baseLineDO.setEnv(environmentService.getEnvironmentType().getEnv());
				baseLineDO.setAppId(appDO.getId());
				baseLineDO.setIp(ip);
				baseLineDO.setSwitchInfo(JSON.toJSONString(pair.getSecond()));
				switchBaseLineDAO.insert(baseLineDO);
			}
			result.put("errorMsg", "������߳ɹ�");
		}else{
			result.put("errorMsg", "��õ�ǰ��������ʧ��");
		}

		return getRedirectUrl(request, response);
	}

    @RequestMapping("queryRemoteBeanfield2.htm")
    public String queryRemoteBeanfield2(final HttpServletRequest request, ModelMap result) {
    	return _queryRemoteBeanfield(request, result,ALL_FIELDS_OF_A_SINGLE_MACHINE2);
    }
    
    private void checkEnvIsMatch(String ip,String app) {
    	boolean isMatch = environmentService.checkEnvMatch(app, ip);
    	if ( !isMatch ){
    		throw new RuntimeException("App��IP��ƥ��");
    	}
    }
    
    private String _queryRemoteBeanfield(final HttpServletRequest request, ModelMap result,String page){
      	UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
    	String app=request.getParameter("app");
    	String machineName=request.getParameter("machineName");
    	String ip=request.getParameter("ip");
    	String port = request.getParameter("port");
    	
    	checkEnvIsMatch(ip,app);
    	
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "SWITCH");
    	params.put("action", "list");
    	String url="";
		try {
			url = urlGenerator.getUrl(ip,port,params);
		} catch (Exception e1) {
			result.put("errorMsg", e1.getMessage());
			return page;
		}
		List<BeanField> allFields = new ArrayList<BeanField>();
		try {
			String json = HttpClientUtil.getResult(url);
			JSONArray jsonArray = new JSONArray(json);
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject=jsonArray.getJSONObject(i);
				BeanField bf=BeanField.getBeanField(jsonObject);
				if(bf!=null)
				allFields.add(bf);
			}
			List<List<BeanField>> fieldList = userAuditHistoryManager.sortSwitches(allFields, user.getNick(), app);
			result.put("fieldList", fieldList);
			if(fieldList.get(0).size() > 0) {
				result.put("hasRecentlyUsedSwitches", "true");
			}
			if(fieldList.get(1).size() > 0) {
				result.put("hasHeavilyUsedSwitches", "true");
			}
			if(fieldList.get(2).size() > 0) {
				result.put("hasOtherSwitches", "true");
			}
		} catch (Exception e) {
			logger.error("��ȡ������Ϣ�쳣 ip:"+ip+" port:"+port+" params:"+params,e);
			result.put("errorMsg", e.getMessage());
		}
		
		/**
		 * ��ȡateye�汾���鿴�Ƿ����1.0.3
		 */
		boolean isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
		result.put("isSupportNull", isSupportNull);
		
		result.put("app", app);
		result.put("machineName", machineName);
		result.put("ip", ip);
		result.put("port", port);
    	return page;
    }
    @RequestMapping("setBeanFieldAjax.htm")
	public String setRemoteBeanfieldByAjax(final HttpServletRequest request, HttpServletResponse response) throws JSONException, IOException {
    	UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
 		String appName = request.getParameter("app");
		String ip = request.getParameter("ip");
    	checkEnvIsMatch(ip,appName);

		String port = request.getParameter("port");
		String beanName = request.getParameter("beanName");
		String fieldName = request.getParameter("fieldName");
		String newValue = URLDecoder.decode(request.getParameter("newValue"), "UTF-8");
		String oldValue = URLDecoder.decode(request.getParameter("oldValue"), "UTF-8");
		String persist = request.getParameter("persist");
	 	int valueType = 0;
	    	String valueTypeString=request.getParameter("valueType");
	    	if(StringUtil.isNotBlank(valueTypeString)){
	    		try{
	    			valueType =Integer.valueOf(valueTypeString);
	    		}catch (NumberFormatException e) {}
	    	}
		
		boolean isSuccess=false;

		Map<String, String> params = new HashMap<String, String>();
		params.put("type", "SWITCH");
		params.put("action", "set");
		params.put("beanName", beanName);
		params.put("fieldName", fieldName);
		params.put("newValue", newValue);
		params.put("oldValue", oldValue);
		params.put("persist", persist);
		params.put("valueType", String.valueOf(valueType));
		
		PrintWriter out = response.getWriter();
		JSONObject returnJson = new JSONObject();// ����json��
		returnJson.put("SetSuccess", false);
		returnJson.put("PersistSuccess", false);
		returnJson.put("exception", "");

		returnJson.put("approvePass", true);

		String approve=request.getParameter("approve");
		if(StringUtil.isNotEmpty(approve) && "true".equalsIgnoreCase(approve)){
			ChangeFreeRS rs = approveManager.check(CFType.SWITCH,user.getEmpId()+"",appName,beanName,fieldName);
			if(!rs.isPass() && StringUtil.isNotEmpty(rs.getApproveUrl())){
				returnJson.put("approvePass",false);
				returnJson.put("approveUrl", rs.getApproveUrl());
				out.print(SecurityUtil.escapeJson(returnJson.toString()));
				return null;
			}
		}

		String url = "";
		Object exc = null;
		try {
			url = urlGenerator.getUrl(ip, port, params);
		} catch (Exception e1) {
			out.print(SecurityUtil.escapeJson(returnJson));
			return null;
		}

		try {
			String json = HttpClientUtil.getResult(url);
			JSONArray jsonArray = new JSONArray(json);
			JSONObject optResult = jsonArray.getJSONObject(0);
			returnJson.put("SetSuccess", optResult.opt("SetSuccess"));
			// ����Set�ɹ�
			if ("true".equalsIgnoreCase((String) optResult.opt("SetSuccess"))) {
				isSuccess=true;
				returnJson.put("PersistSuccess", optResult.opt("PersistSuccess"));
				// ���س־û�ʧ��
				if (!"true".equalsIgnoreCase((String) optResult.opt("PersistSuccess"))) {
					exc =  optResult.opt("PersistException");
				}else{
					newValue+="&persist=true";
				}
				
			}
			// ����Setʧ��
			else {
				exc = optResult.opt("SetException");
			}

			AppLog.log("���ÿ���",appName,beanName+":"+fieldName,"���ÿ��سɹ�,"+beanName+":"+fieldName+",ֵ:"+newValue);

			AppChangeLogVO changeLog = AppChangeMonitor.createSwitchChangeLog(beanName, fieldName, oldValue, newValue, user.getNick(), UUID.randomUUID().toString(), ip, appName);
			super.appChangeLogService.addOneChangeLog(changeLog);

		} catch (Exception e) {
			logger.error("���ÿ���ֵʱ�쳣ip:" + ip + " port:" + port + " params:" + params, e);
		}
		/**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,ip,UserAuditDO.SWITCH,beanName,fieldName,newValue+"&isSuccess="+isSuccess);
		userAuditService.addUserAuditLog(userAuditDO);
		if(exc != null)
			returnJson.put("exception", URLEncoder.encode(exc.toString(), "UTF-8"));
		out.print(SecurityUtil.escapeJson(returnJson.toString()));
		return null;
	}
	@RequestMapping("cleanDisapperPersistSwitchData.htm")
	public String cleanDisapperPersistSwitchData(final HttpServletRequest request, ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}

		String app = request.getParameter("app");
		String bean = request.getParameter("bean");
		String field = request.getParameter("field");

		this.appPersistenceSwitchManager.remove(app,bean,field);
		AppLog.log("���ÿ���",app,bean+":"+field,"�ɹ�ɾ�������ڵĳ־û�����ֵ,"+bean+":"+field);

		AppChangeLogVO changeLog = AppChangeMonitor.deleteSwitchPesist(bean, field, user.getNick(), UUID.randomUUID().toString(),app);
		super.appChangeLogService.addOneChangeLog(changeLog);

		return "redirect:/beanfield/listAllSwitchesOfAnApp2.htm?app=" + app;
	}

    @RequestMapping("listAllSwitchesOfAnApp2.htm")
    public String listAllSwitchesOfAnApp2(final HttpServletRequest request, ModelMap result) throws DAOException{
    	return _listAllSwitchesOfAnApp(request, result, ALL_FIELDS_OF_AN_APP2);
	}
    private String _listAllSwitchesOfAnApp(final HttpServletRequest request, ModelMap result,String page) throws DAOException
    {
    	UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
    	String app=request.getParameter("app");
    	List<MachineDO> machines=opsServic.getAllMachinesBelongToAnApp(app);
    	
    	//���Ի�ȡһ̨�����Ŀ����б�
    	List<BeanField> allFields=new ArrayList<BeanField>();
    	boolean isSupportNull = false;
    	for(MachineDO machine:machines)
    	{
    		String ip=machine.getIp();
    		String port=machine.getPort()+"";
        	Map<String,String> params=new HashMap<String,String>();
        	params.put("type", "SWITCH");
        	params.put("action", "list");
        	String url="";
			try {
				url = urlGenerator.getUrl(ip, port, params);
			} catch (Exception e1) {
				result.put("errorMsg", e1.getMessage());
				return page;
			}
        	
    		try {
    			String json= HttpClientUtil.getResult(url);
				JSONArray jsonArray=new JSONArray(json);
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject=jsonArray.getJSONObject(i);
					BeanField bf = BeanField.getBeanField(jsonObject);
					if(bf!=null)
					allFields.add(bf);
				}
				if(allFields.size()>0){
					/**
					 * ��ȡateye�汾���鿴�Ƿ����1.0.3
					 */
					isSupportNull = agentVersionUtil.appMeetTheVersion(ip, port, "1.0.3");
					break;
				}
    		} catch (Exception e) {
    			logger.error("��ȡ������Ϣʱ�쳣app:"+app, e);
    		}
    	}
    	if(allFields.size()>0)
    	{
    		List<List<BeanField>> fieldList = userAuditHistoryManager.sortSwitches(allFields, user.getNick(), app);
			result.put("fieldList", fieldList);
			if(fieldList.get(0).size() > 0) {
				result.put("hasRecentlyUsedSwitches", "true");
			}
			if(fieldList.get(1).size() > 0) {
				result.put("hasHeavilyUsedSwitches", "true");
			}
			if(fieldList.get(2).size() > 0) {
				result.put("hasOtherSwitches", "true");
			}
    		result.put("isSupportNull", isSupportNull);
    		try {
    			Map<String, AppPersistenceSwitchDO> psMap = appPersistenceSwitchManager.list(app);

				Map<String, AppPersistenceSwitchDO> disapperPersistSwitchList = Maps.newHashMap();

    			if (!psMap.isEmpty() ){
					disapperPersistSwitchList.putAll(psMap);
		    		Map<BeanField,AppPersistenceSwitchDO> persistenceMap = new HashMap<BeanField,AppPersistenceSwitchDO>();
		    		for ( List<BeanField> fl:fieldList ){
		    			for ( BeanField bf:fl ){
		    				String k = bf.getBeanName()+"_"+bf.getFieldName();
		    				if ( psMap.containsKey(k) ){
		    					persistenceMap.put(bf, psMap.get(k));
								disapperPersistSwitchList.remove(k);
		    				}
		    			}
		    		}
		    		result.put("pMap",persistenceMap);
		    		result.put("disapperPersistSwitchList",disapperPersistSwitchList);
    			}
    		} catch (IOException e) {
    			logger.error("��ȡ�־û������쳣",e);
    		}
    	}
    	else
    	{
    		result.put("errorMsg", "δ���Ӧ��"+app+"�µĻ����Ŀ����б�");
    	}
    	result.put("app", app);
    	return page;
    }
    @RequestMapping("deletePersist2.htm")
    public String deletePersist2(final HttpServletRequest request, ModelMap result) throws DAOException{
    	return _deletePersist(request, result, DELETE_PERSIST2);
    }
    public String _deletePersist(final HttpServletRequest request, ModelMap result,String page) throws DAOException
    {
    	final UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
    	final String app=request.getParameter("app");
    	final String beanName=request.getParameter("beanName");
    	final String fieldName=request.getParameter("fieldName");
    	if ( StringUtils.isBlank(beanName) || StringUtils.isBlank(fieldName) ){
	    	return page;
    	}
    	try {
			boolean remove = appPersistenceSwitchManager.remove(app, beanName,fieldName);
			result.put("success", remove);
			AppLog.log("���ÿ���",app,beanName+":"+fieldName,"�ɹ�ɾ���־û�����ֵ,"+beanName+":"+fieldName);

			AppChangeLogVO changeLog = AppChangeMonitor.deleteSwitchPesist(beanName, fieldName, user.getNick(), UUID.randomUUID().toString(),app);
			super.appChangeLogService.addOneChangeLog(changeLog);

		} catch (IOException e) {
			logger.error("ɾ���־û������쳣",e);
		}
		result.put("app", app);
    	return page;
    }
    @RequestMapping("setBeanFieldInBatchMode2.htm")
    public String setBeanFieldInBatchMode2(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	return _setBeanFieldInBatchMode(request,result,BATCH_SET_RESULT2);
    }
    private String _setBeanFieldInBatchMode(final HttpServletRequest request, ModelMap result, String page) throws DAOException, UnsupportedEncodingException{
    	final UserDO user = (UserDO) MyThreadLocal.get();
 		if (user == null) {
 			return "redirect:/noPermission.htm";
 		}
    	final String app=request.getParameter("app");
    	final String beanName=URLDecoder.decode(request.getParameter("beanName"),"UTF-8");
    	final String fieldName=request.getParameter("fieldName");
		final String newValue = URLDecoder.decode(request.getParameter("newValue"), "UTF-8");

    	String persist=request.getParameter("persist");
    	int valueType = 0;
    	String valueTypeString=request.getParameter("valueType");
    	if(StringUtil.isNotBlank(valueTypeString)){
    		try{
    			valueType =Integer.valueOf(valueTypeString);
    		}catch (NumberFormatException e) {}
    	}
    	
    	final Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "SWITCH");
    	params.put("action", "set");
    	params.put("beanName", beanName);
    	params.put("fieldName", fieldName);
    	params.put("newValue", newValue);
    	params.put("persist", "false");//���ڻ����ĳ־û�ǿ������Ϊfalse
    	params.put("valueType", String.valueOf(valueType));

		String approve=request.getParameter("approve");
		if(StringUtil.isNotEmpty(approve) && "true".equalsIgnoreCase(approve)){
			ChangeFreeRS rs = approveManager.check(CFType.SWITCH,user.getEmpId()+"",app,beanName,fieldName);
			if(!rs.isPass() && StringUtil.isNotEmpty(rs.getApproveUrl())){
				return "redirect:"+rs.getApproveUrl();
			}
		}

    	final Set<Map<String,String>> batchSetResults = Collections.synchronizedSet(new HashSet<Map<String,String>>());
    	List<MachineDO> machines=opsServic.getAllMachinesBelongToAnApp(app);
    	List<Future<?>> callList = new ArrayList<Future<?>>();
    	final AppDO appDO = appService.getAppByAppName(app);
    	//�������ø�Ӧ���µ�ȫ�������Ŀ���
    	for(final MachineDO machine:machines)
    	{
    		Future<?> fu = exec.submit(new Runnable()
    		{
    			public void run()
    			{
            			Map<String,String> singleResult=new HashMap<String,String>();
            	    		singleResult.put("machineName", machine.getMachineName());
            	    		singleResult.put("ip", machine.getIp());
            	    		
            	    		String ip=machine.getIp();
            	    		String port=machine.getPort()+"";
            	    		String url="";
            	    		String opValue=newValue;
            	    		boolean isSuccess=false;
    				try {
    					if(appDO != null) {
    						url = urlGenerator.getUrl(ip, port, params);
    					}else{
    						singleResult.put("SetSuccess", "false");
        					singleResult.put("SetException", "App of name:" + app + " doesn't exist");
        					batchSetResults.add(singleResult);
        	    			return;
    					}
    				} catch (Exception e1) {
    					singleResult.put("SetSuccess", "false");
    					singleResult.put("SetException", e1.getMessage());
    					batchSetResults.add(singleResult);
    	    			return;
    				}
    	    		try {
    	    			String json=HttpClientUtil.getResult(url);
    					JSONArray jsonArray=new JSONArray(json);
    					JSONObject optResult=jsonArray.getJSONObject(0);
    					
    					//���������Ϣ
    					singleResult.put("SetSuccess", (String)optResult.opt("SetSuccess"));
    					//����Set�ɹ�
    					if("true".equalsIgnoreCase((String)optResult.opt("SetSuccess")))
    					{
    						isSuccess=true;
    						
    						singleResult.put("PersistSuccess", (String)optResult.opt("PersistSuccess"));
    						//���س־û�ʧ��
    						if(!"true".equalsIgnoreCase((String)optResult.opt("PersistSuccess")))
    						{
    							singleResult.put("PersistException", (String)optResult.opt("PersistException"));
    						}else{
    							opValue=newValue+"&persist=true";
    						}
    					}
    					//����Setʧ��
    					else
    					{
    						singleResult.put("SetException", (String)optResult.opt("SetException"));
    					}
    	    		} catch (Exception e) {
    	    			logger.error("���ÿ���ֵʱ�쳣ip:"+ip+" port:"+port+" params:"+params, e);
    	    			singleResult.put("SetSuccess", "false");
    	    			singleResult.put("SetException", "�����쳣"+e.getMessage());
    	    		}
                    	    		batchSetResults.add(singleResult);
                    	    		/**
					 * ���� �����û������Ϣ
					 */
					UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),app,ip,UserAuditDO.SWITCH,beanName,fieldName,opValue+"&isSuccess="+isSuccess);
					userAuditService.addUserAuditLog(userAuditDO);
    			}
    		});
    		callList.add(fu);
    	}
    	//�ȴ��߳�ִ����ϣ����ÿ��ǳ�ʱ����ʱ������HttpClient�ĳ�ʱ��������֤
    	try
    	{
    		for(Future<?> f:callList)
        	{
        		f.get();//���Է���ֵ
        	}
    	}
    	catch(Exception e){}//������û��Interrupt��Runnableִ�еĴ���Ჶ���쳣
    	
    	result.put("batchSetResults", batchSetResults);
    	result.put("app", app);
    	result.put("persist", persist);
    	if ( persist != null && persist.equals("true") ){
	    	//������û���Ӧ�õĳ־û���������
	    	
	    	AppPersistenceSwitchDO sw = new AppPersistenceSwitchDO();
	    	sw.setBeanName(beanName);
	    	sw.setFieldName(fieldName);
	    	sw.setSwitchValue(newValue);
	    	sw.setValueType(valueType);
			try {
				boolean rs = appPersistenceSwitchManager.put(app, sw);
				if ( rs ){
					result.put("persistResult","true");
				}else{
					result.put("persistResult","false");
				}
			} catch (IOException e) {
				logger.error("�־û��쳣",e);
				result.put("persistResult","false");
			}
    	}

		AppChangeLogVO changeLog = AppChangeMonitor.createSwitchChangeLog(beanName, fieldName, "ateye:unknown", newValue, user.getNick(), UUID.randomUUID().toString(), "ȫ��������", app);
		super.appChangeLogService.addOneChangeLog(changeLog);
    	
    	return page;
    }
    @RequestMapping("switchError2.htm")
    public String switchError2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
    	String exception=request.getParameter("exception");
    	result.put("exception", exception);
    	return SWITCH_ERROR2;
    }
   
}
