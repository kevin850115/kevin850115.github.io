package com.taobao.ateye.controller.alarm.data;

import com.taobao.ateye.alarm.n.util.AlarmMonitorUtils;

import java.util.Date;

/**
 * Created by sunqiang on 2018/12/17.
 */
public class AlarmSubscriber {
    /**
     * ����
     */
    private long id;

    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ҵ����
     */
    private Integer biz;

    /**
     * ҵ����
     */
    private String bizName;


    /**
     * ������
     */
    private String operator;

    /**
     * ����,����,�绰
     */
    private Integer type;

    /**
     * ������token
     */
    private String value;

    /**
     * 0-��Ч 1-ɾ��
     */
    private int isDelete;

    /**
     * ����
     */
    private String env;

    private String name;

    /**
     * ��������
     */
    private int alarmCount;

    /**
     * ��������
     */
    private int ruleCount;

    public String alarmUrl(){
        return AlarmMonitorUtils.buildSubRealAlarm(id);
    }

    public int getAlarmCount() {
        return alarmCount;
    }

    public void setAlarmCount(int alarmCount) {
        this.alarmCount = alarmCount;
    }

    public int getRuleCount() {
        return ruleCount;
    }

    public void setRuleCount(int ruleCount) {
        this.ruleCount = ruleCount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getBiz() {
        return biz;
    }

    public void setBiz(Integer biz) {
        this.biz = biz;
    }

    public String getBizName() {
        return bizName;
    }

    public void setBizName(String bizName) {
        this.bizName = bizName;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
