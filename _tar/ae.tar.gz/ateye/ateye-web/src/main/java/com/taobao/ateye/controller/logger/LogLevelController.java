package com.taobao.ateye.controller.logger;


import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.AppChangeMonitor;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserAuditDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.log.LogVoBean;
import com.taobao.ateye.logger.LogDO;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.UserAuditService;
import com.taobao.ateye.useaudit.UserAuditHistoryManager;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.JsonUtils;
import com.taobao.ateye.util.UrlGenerator;

@Controller
@RequestMapping("/logLevel")
public class LogLevelController extends AbstractController{
	private static final Logger log = Logger.getLogger(LogLevelController.class);
	
	private static final String MACHINE2 = "screen/ateyeloggerlevel/machine2";
	private static final String LOGGER2 = "screen/ateyeloggerlevel/logger2";
	private static final String UPDATE2 = "screen/ateyeloggerlevel/update2";
	@Autowired
	private UserAuditService userAuditService;	
    @Autowired
    private OpsServic opsServic;
    @Autowired
    private UrlGenerator urlGenerator;
    @Autowired
    UserAuditHistoryManager userAuditHistoryManager;
    
    @RequestMapping("selectApp2.htm")
    public String selectApp2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/logLevel/queryAppMachinesList2.htm");
    	result.put("level2","��־�������");
    	result.put("level2Url","/logLevel/selectApp2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
    @RequestMapping("queryAppMachinesList2.htm")
    public String queryAppMachineList2(final HttpServletRequest request, ModelMap result){
    	return _queryAppMachineList(request, result, MACHINE2);
    }
    private String _queryAppMachineList(final HttpServletRequest request, ModelMap result,String page){
    	String app = request.getParameter("app");
    	List<MachineDO> machineLists=new ArrayList<MachineDO>();
    	if(StringUtils.isBlank(app)){
    		log.info("when request queryAppMachinesList , app is null");
    	}else{
    		if(StringUtil.isNotBlank(app)){
	    	 try {
				machineLists=opsServic.getAllMachinesBelongToAnApp(app);
			} catch (DAOException e) {
				log.info("getAllMachines is error",e);
			}
    		}
    	}

		result.put("env",this.environmentService.getEnvironmentType().getEnv());

		String refreshed = request.getParameter("refreshed");
		if(StringUtils.isNotBlank(refreshed)){
			result.put("refreshed",refreshed);
		}

    	result.put("appseleced", app);
    	result.put("machineList", machineLists);
    	return page;
    }
    @RequestMapping("queryRemoteLoggers2.htm")
    public String queryRemoteLoggers2(final HttpServletRequest request, ModelMap result){
    	return _queryRemoteLoggers(request, result, LOGGER2);
    }
    private String _queryRemoteLoggers(final HttpServletRequest request, ModelMap result,String page){
    	UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	String ip = request.getParameter("ip");
    	String port = request.getParameter("port");
    	String app = request.getParameter("app");
    	result.put("app",app);
    	List<LogDO> loggerslist=new ArrayList<LogDO>();
    	if(StringUtils.isBlank(ip) || StringUtils.isBlank(port)){
    		log.info("when request getAllLoggers , IP or port  is null");
    	}else{
    		Map<String,String> params=new HashMap<String, String>();
    		params.put("type", "LOGCONTROL");
    		params.put("operate", "getLoggers");
	    	String appUrl = "";
			try {
				appUrl = urlGenerator.getUrl(ip, port, params);
				String responseBody = HttpClientUtil.getResult(appUrl);
		    	if(StringUtils.isNotBlank(responseBody)){
			    	Object object = JsonUtils.jsonDecode(responseBody, LogDO.class, true);
			    	loggerslist = (List<LogDO>) object;
		    	}
			} catch (Exception e) {
				result.put("error", e.getMessage());
			}
			List<List<LogDO>> sortLoggers = userAuditHistoryManager.sortLoggers(loggerslist, user.getNick(), app);
	    	result.put("loggerLists", sortLoggers);
	    	if(sortLoggers.get(0).size() > 0) {
    			result.put("hasRecentlyUsed", "true");
    		}
    		if(sortLoggers.get(1).size() > 0) {
    			result.put("hasHeavilyUsed", "true");
    		}
    		if(sortLoggers.get(2).size() > 0) {
    			result.put("hasOther", "true");
    		}
    	}
		result.put("machineIp", ip);
		result.put("port", port);
    	return page;
    }
    @RequestMapping("updateLoggerLevel2.htm")
    public String updateLoggerLevel2(final HttpServletRequest request, ModelMap result){
    	return _updateLoggerLevel(request, result, UPDATE2);
    }
    private String _updateLoggerLevel(final HttpServletRequest request, ModelMap result,String page){
    	String name = request.getParameter("name");   //logger��name
    	String level = request.getParameter("level"); //logger��level
    	String logtype = request.getParameter("logtype"); //logger����־����
    	String IP = request.getParameter("ip");		 //�޸Ļ�����IP
    	String port = request.getParameter("port");
    	String app = request.getParameter("app");
    	result.put("logtype", logtype);
    	result.put("app", app);
		result.put("name", name);
		result.put("level", level);
		result.put("machineIp", IP);
		result.put("port", port);
    	return page;
    }
    @RequestMapping("updateLoggerLevel2Client2.htm")
    public String updateLoggerLevel2Client2(final HttpServletRequest request, ModelMap result) {
    	return _updateLoggerLevel2Client(request, result, LOGGER2);
    }
    private String _updateLoggerLevel2Client(final HttpServletRequest request, ModelMap result,String page) {
    	UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	String name = request.getParameter("name");  		//logger��name
    	String level = request.getParameter("level");		//logger��Ҫ�޸ĳɵ�level
    	String logtype = request.getParameter("logtype");   //logger����־����
    	String ip = request.getParameter("ip");
    	String app = request.getParameter("app");
    	result.put("app",app);
    	String port = request.getParameter("port");
    	Map<String,String> params=new HashMap<String, String>();
		params.put("type", "LOGCONTROL");
		params.put("operate", "modifyLogger");
		params.put("name", name);
		params.put("level", level);
		params.put("logtype", logtype);
		try{
			String appUrl = urlGenerator.getUrl(ip, port, params);
		   	String responseBody = HttpClientUtil.getResult(appUrl);
		   	if(null != responseBody){
		    	Object object=JsonUtils.jsonDecode(responseBody, LogVoBean.class, true);
		    	List<LogVoBean> loggerslist=(List<LogVoBean>) object;
		    	result.put("loggers", loggerslist);
		    	
		    	UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),app,ip,UserAuditDO.LOGLEVEL,name,logtype,level);
				userAuditService.addUserAuditLog(userAuditDO);
	    	}
		}catch(Exception e){
			result.put("error", e.getMessage());
		}
	   	result.put("machineIp", ip);
	   	result.put("port", port);

	   	AppChangeLogVO changeLog = AppChangeMonitor.createLoggerLevelChangeLog(name,level,UUID.randomUUID().toString(),user.getNick(),ip,app);
		super.appChangeLogService.addOneChangeLog(changeLog);

    	return _queryRemoteLoggers(request,result,page);
    }
}
