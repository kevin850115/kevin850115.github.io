package com.taobao.ateye.authority;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.util.AntUrlPathMatcher;
import org.springframework.security.web.util.UrlMatcher;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.buc.api.AccessControlService;
import com.alibaba.buc.api.PermissionService;
import com.alibaba.buc.api.check.CheckPermissionParam;
import com.alibaba.buc.api.check.CheckPermissionResult;
import com.alibaba.buc.api.condition.PageCondition;
import com.alibaba.buc.api.condition.PermissionDetailCondition;
import com.alibaba.buc.api.exception.BucException;
import com.alibaba.buc.api.model.Page;
import com.alibaba.buc.api.permission.GetPermissionParam;
import com.alibaba.buc.api.permission.PermissionResult;
import com.alibaba.buc.api.result.PermissionResultModel;
import com.alibaba.buc.sso.client.util.SimpleUserUtil;
import com.alibaba.common.lang.StringUtil;
import com.alibaba.platform.buc.sso.common.dto.SimpleSSOUser;
import com.mysql.jdbc.StringUtils;
import com.taobao.ateye.controller.loginusers.AclSyncUtil;
import com.taobao.ateye.dal.ResourceDAO;
import com.taobao.ateye.dal.RoleDAO;
import com.taobao.ateye.dal.UserDAO;
import com.taobao.ateye.dal.UserDetailDAO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.ResourceDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.monitor.TripMonitor;
import com.taobao.ateye.monitor.TripMonitorQps;
import com.taobao.ateye.scene.SceneContants;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.UserService;
import com.taobao.ateye.threadlocal.AteyeThreadLocal;
import com.taobao.ateye.util.MobileUtil;
import com.taobao.ateye.util.SystemUtil;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.tracker.log.kv.KvLog;

/**
 * Ateye��¼��Ȩ�޿���Filter
 *
 * @author guangu.lj
 */
public class AuthorityFilter implements Filter {
    private final static Logger logger = LoggerFactory.getLogger("securityLogger");
    
    private ScheduledExecutorService aclPermissionSyncScheduler = Executors
            .newSingleThreadScheduledExecutor();
    //����Ӧ��
    private static Set<String> virtualApps = new HashSet<String>();
    static{
        virtualApps.add("_DB_");
        virtualApps.add("_MSG_");
        virtualApps.add("_TAIR_");
        virtualApps.add("_ERROR_");
        virtualApps.add("_REALTIME_");
        virtualApps.add("_ERROR_DETAIL_");
    }

    /**
     * ����Ȩ�޹�����uri(�ų��б�)
     */
    private String[] excludeUris = {"/*.ateye",
            "/simple/day_sum_result.do",    //eagle eye,
            "/check.htm",
            "/index.htm",
            "/index2.htm",
            "/index3.htm",
            "/index4.htm",
            "/index/**",
            "/noPermission.htm",
            "/err.htm",
            "/showData.htm",
            "/status.taobao",
            "/audit/opHistory.htm",
            "/manage/role/resetRole.htm",//��ʱȨ�޻ָ���!
            "/static/**",
            "/*.ico",
            "/permissionApply/apply.htm",
    };


    private final static String USERID_DAILY = "111304818";     //ateye-acl

    static private Set<String> notMonitorURI = new HashSet<String>();
    static {
        notMonitorURI.add("/agent.ateye");
        notMonitorURI.add("/status.taobao");
        notMonitorURI.add("/static/js/My97DatePicker.html");
    }
    private WebApplicationContext applicationContext;
    private UserService userService;
    private RoleDAO ateyeRoleDAO;
    private UserDetailDAO userDetailDAO;
    private UserDAO userDAO;
    private ResourceDAO ateyeResourceDAO;
    private HbaseReadService hbaseReadService;
    private OpsServic opsServic;
    private UrlMatcher urlMatcher = new AntUrlPathMatcher();
    private String type;//��ǰ���� daily��pre��public
    private EnvironmentService environmentService;
    private TempRole tempRoleService;
    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    //private boolean useAclPermission = true;    //use acl permission validation or not;
    private static Map<String, PermissionResult> allPermissionMap = null;

    private AccessControlService aclAccessControlService = null; //provide the authentication
    private PermissionService aclPermissionService = null;

    @Override
    public void init(FilterConfig filterConfig) {
    	//1.����׼������spring���õ����ֶ���
        ServletContext sc = filterConfig.getServletContext();
        applicationContext = WebApplicationContextUtils
                .getWebApplicationContext(sc);
        userService = (UserService) applicationContext.getBean("userService");
        tempRoleService = (TempRole) applicationContext.getBean("tempRole");
        MyThreadLocal.tempRoleService = tempRoleService;
        ateyeRoleDAO = (RoleDAO) applicationContext.getBean("ateyeRoleDAO");
        userDetailDAO = (UserDetailDAO) applicationContext.getBean("userDetailDAO");
        userDAO = (UserDAO) applicationContext.getBean("ateyeUserDAO");
        ateyeResourceDAO = (ResourceDAO) applicationContext.getBean("ateyeResourceDAO");
        environmentService = (EnvironmentService) applicationContext.getBean("environmentService");
        opsServic = (OpsServic) applicationContext.getBean("opsServic");
        hbaseReadService = (HbaseReadService) applicationContext.getBean("hbaseReadService");
        aclAccessControlService = (AccessControlService) applicationContext.getBean("aclAccessControlService");
        aclPermissionService = (PermissionService) applicationContext.getBean("aclPermissionService");
        int envId = environmentService.getEnvironmentType().ordinal();
        switch (envId) {
            case 0: {
                type = "Daily����";
                break;
            }
            case 1: {
                type = "Ԥ������";
                break;
            }
            case 2: {
                type = "���ϻ���";
                break;
            }
            case 3: {
                type = "С��������";
                break;
            }
            default: {
                type = "";
                break;
            }
        }
        
        //����ͬ��aclȨ��
        initAclPermissionMap();

        aclPermissionSyncScheduler.scheduleAtFixedRate(new Runnable() {
            public void run() {
                try {
                    if (AclSyncUtil.IS_ACL_PERMISSION) {
                        initAclPermissionMap();
                    }
                } catch (Throwable t) {
                    logger.error("ACLͬ��Ȩ��ʧ��[BUC Exception]", t);
                }
            }
        }, 10L, 120L, TimeUnit.SECONDS);

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        boolean useAclPermissionInRequest = AclSyncUtil.USE_ACL_PERMISSION;
        if (!(request instanceof HttpServletRequest)
                || !(response instanceof HttpServletResponse)) {
            logger.error("AuthorityFilter just supports HTTP requests");
            chain.doFilter(request, response);
            return;
        }
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        //0.���ݷ������������ñ���
        AteyeThreadLocal.platform.set("Ateye");
        String requestURL = httpRequest.getRequestURL().toString();
        if ( requestURL != null && requestURL.contains("safe.fliggy") ){
        	httpRequest.setAttribute("f_domain", "safe.fliggy");
        	AteyeThreadLocal.platform.set("FliggySafe");
        }
        if ( requestURL != null && requestURL.contains("safe.trip") ){
        	httpRequest.setAttribute("f_domain", "safe.trip");
        	AteyeThreadLocal.platform.set("FliggySafe");
        }
        //1.��ȡ���ص�ַ������
        httpRequest.setAttribute("env_type", type);
        httpRequest.setAttribute("env_addr", SystemUtil.getIp());
        String uri = httpRequest.getRequestURI();
        if ("/".equals(uri)) {
            redirectStrategy.sendRedirect(httpRequest, httpResponse, "/index2.htm");
            return;
        }
        //2.��ȡ�û���Ϣ
		SimpleSSOUser ssoUser = null;
        try{
			ssoUser = SimpleUserUtil.findUser(httpRequest);
        }catch(Throwable t){
            logger.error("�����û�ʧ��",t);
        }
        if (ssoUser == null) {
            chain.doFilter(request, response);
            TripMonitor.qps("������֤�����", uri, "").record();
            return;
        }
        //3.��ȡ�û����� 
        String loginAteyeNick = ssoUser.getTbWW();//ʵ�ʵ�¼�û����ǳ�
        if (StringUtil.isBlank(loginAteyeNick)) {//ȡ����
            loginAteyeNick = ssoUser.getNickNameCn();
            if (StringUtil.isBlank(loginAteyeNick)) {//����ҲΪ�գ���ȡ��ʵ����
                loginAteyeNick = ssoUser.getLastName();
            }
        }
        //4.˳���¼һ���û���Ϣ��Ŀǰ��Email
        recordUserEmail(loginAteyeNick, ssoUser.getEmailAddr());
        //�����û��Ĺ��ţ����¼���ϵ
        recordUserExtend(loginAteyeNick,ssoUser);
        //5.ҳ��PV���ͳ��&&�û����ͳ��
        if (!notMonitorURI.contains(httpRequest.getRequestURI())) {
            TripMonitorQps qps = TripMonitor.qps("ҳ��PV", httpRequest.getRequestURI(), "");
            qps.record();
            KvLog.logDetail(qps, "ҳ�����","flt_user:"+loginAteyeNick,httpRequest.getParameterMap(),ssoUser);
        }
        TripMonitorQps qps = TripMonitor.qps("�û����ʴ���", ssoUser.getDepDesc()+"-"+loginAteyeNick, "");
        qps.record();
        KvLog.logDetail(qps, "�û����ʵĲ���ϸ��", "flt_dep:"+ssoUser.getDepDesc(),"flt_url:"+uri,request.getParameterMap(),ssoUser);
        boolean isMobile = MobileUtil.isMobile(httpRequest);
        if ( isMobile ){
	        TripMonitorQps qps2 = TripMonitor.qps("�û����ʴ���-Mobile", ssoUser.getDepDesc()+"-"+loginAteyeNick, "");
	        qps2.record();
	        KvLog.logDetail(qps2, "���߷��ʵĲ���ϸ��", "flt_dep:"+ssoUser.getDepDesc(),"flt_url:"+uri,request.getParameterMap(),ssoUser);
        }
        httpRequest.setAttribute("ateye_nick", loginAteyeNick);
        //6.��ȡ��ɫ���ݡ�������н�ɫ��������ʱΪ�л���Ľ�ɫ
        String tempRole = tempRoleService.getTempRole(loginAteyeNick);
        if (tempRole != null) {
            httpRequest.setAttribute("role_nick", tempRole);
            logger.warn(loginAteyeNick + "ʹ����ʱ����:" + tempRole);
        } else {
            httpRequest.setAttribute("role_nick", loginAteyeNick);
        }
        //���ڲ��Ի�����˵�������ǳ�Ϊadmin
        String roleAteyeNick = null;//����Ȩ��У����ǳ�
        if (environmentService.getEnvironmentType().ordinal() == 0 && userService.isDailyLoginNotCheck()) {
            roleAteyeNick = "admin";
        } else {
            roleAteyeNick = tempRole != null ? tempRole : loginAteyeNick;
        }
        //7.��ȡ�����û����ݣ�������ThreadLocal
        UserDO user = userService.getUserByNick(roleAteyeNick);
        /*
		 * ��userDO���õ�ThreadLocal��
		 */
        if (null != user) {
            user.setNick(loginAteyeNick);//�û����ǳ�Ϊ��ʵ��¼��Nick
            MyThreadLocal.set(user);
        }
        if (ssoUser != null) {
            SSOThreadLocal.set(ssoUser);
        }
        //8.��Ȩ����֤֮ǰ���ж�URL·��;����ǲ���Ȩ�޹�����uri���򲻽���Ȩ����֤
        for (String excludeUri : excludeUris) {
            if (urlMatcher.pathMatchesUrl(excludeUri, uri)) {
                chain.doFilter(request, response);
                return;
            }
        }
        //9.��ȡ�û���ɫ
        List<RoleDO> roleList = getUserRole(httpRequest, user);
        if (user == null || roleList == null || roleList.isEmpty()) {
			/*
			 * ��ʾͨ����arkȨ����֤�� ���ұ��ؿ��в����ڵ��û�.���߱����û�û���κ�Ȩ�޵��û�
			 * Ĭ�Ͼ���guestȨ��
			 */
            RoleDO guest = null;
            try {
                guest = ateyeRoleDAO.getRoleByName(RoleDO.ROLE_GUEST_NAME);
                roleList = new ArrayList<RoleDO>();
                roleList.add(guest);
                useAclPermissionInRequest = false;
            } catch (Exception e) {
                logger.error("��ȡ������guest��ɫ�Ľ�ɫʧ�ܡ�role_name:" + RoleDO.ROLE_GUEST_NAME, e);
            }
        }
        boolean isPassRolePermission = false;
        //10.��ʼ����Ȩ����֤
        if(isAdmin(roleList)) {//adminȫȨ
            isPassRolePermission = true;
        }
        else {
            //VALIDATION - CASE 2, acl validation
            if (useAclPermissionInRequest && this.isUseAclPermission(user.getNick())) {
                try {
                    Integer bucUserId = ssoUser.getId();
                    if ("admin".equals(roleAteyeNick)) {
                        bucUserId = Integer.parseInt(USERID_DAILY);
                    }
                    isPassRolePermission = checkPermissionByAcl(bucUserId, uri);
                } catch (BucException e) {
                    logger.error("ACL��ɫ��֤ʧ��[BUC Exception],user:" + user.getNick(), e);
                } catch (Throwable t) {
                    logger.error("ACL��ɫ��֤ʧ��,user:" + user.getNick(), t);
                }
            } else {//Ŀǰ�����·����֤,@�س� 2017.11��
                for (RoleDO role : roleList) {
                    List<ResourceDO> resources = null;
                    try {
                        resources = ateyeResourceDAO.getResourcesByRoleId(role.getId());
                    } catch (DAOException e) {
                        logger.error("��ȡ��Դʧ��", e);
                    }
                    if (resources == null || resources.isEmpty()) {
                        redirectStrategy.sendRedirect(httpRequest, httpResponse, "/noPermission.htm");
                        return;
                    }
                    for (ResourceDO res : resources) {
                        String path = res.getPath();
                        if (urlMatcher.pathMatchesUrl(path, uri)) {
                            isPassRolePermission = true;
                        }
                    }
                }
            }
        }
        if (!isPassRolePermission){
            redirectStrategy.sendRedirect(httpRequest, httpResponse, "/noPermission.htm");
            return;
        }
        //11.ҳ��Ȩ��ͨ�����ж��û��Ƿ���Ӧ��Ȩ��
		/*
		* �ж��Ƿ����Ӧ��Ȩ�ޡ���ֹ�����ƹ�Ȩ����֤���в�����
		* ͨ����ȡ�����е�app�������е������Ȩ����֤��
		*/
        String app = this.getAppname(request);
        recordAppPV(app);
        boolean isVirtualApp = isVirtualApp(app);
        // ip����
        String ip = getIpAddr(request);
        if ( !isVirtualApp && !checkPermision(app, ip, user)) {
            redirectStrategy.sendRedirect(httpRequest, httpResponse, "/noPermission.htm");
            return;
        }
        //12.���ڷ�����app���������¼���ʴ�������������ҳ����������ʵ�չʾ
        recordAppAccess(ssoUser, app);

        chain.doFilter(request, response);
        MyThreadLocal.remove();
        SSOThreadLocal.remove();
        return;
    }

    private List<RoleDO> getUserRole(HttpServletRequest httpRequest, UserDO user) {
		List<RoleDO> roleList = null;
        if (null != user) {
			/*
			 * ���ؿ��д��ڣ�ȡ���û��Ľ�ɫ�б�
			 */
            try {
                //�����û���½��Ϣ
                user.setLastLoginIp(AuthorityFilter.getIpAddr(httpRequest));
                user.setLastLoginTime(new Date());
                userService.updateUserLoginInfo(user);
                roleList = ateyeRoleDAO.getUserRoleList(user.getId());
            } catch (DAOException e) {
                logger.error("��ȡ��ɫʧ��", e);
            }
        }
		return roleList;
	}


    private boolean isVirtualApp(String app) {
        if ( app == null ){
            return false;
        }
        //�س� 2017.03.01.APP��_VIRTUAL_��ͷ����Ϊ������Ӧ��
        return  app.startsWith("_VIRTUAL_") 
        		|| app.startsWith("tframe_")
        		|| virtualApps.contains(app);
    }

    private boolean isAdmin(List<RoleDO> roles)
    {
        if(roles==null||roles.size()<1)
            return  false;

        for(RoleDO role:roles)
        {
            if("ROLE_ADMIN".equals(role.getName()))
                return true;
        }


        return false;
    }

    private String getAppname(ServletRequest request)
    {
        String app = request.getParameter("app");
        if (StringUtil.isBlank(app)) {
            app = request.getParameter("appName");
        }
        if ( StringUtil.isNotBlank(app) ){
            /*Ӧ�԰���@@@�����*/
            String[] split2 = app.split(SceneContants.KEY_INNER_STACK_SPLITTER_1);
            if ( split2.length >= 2 ){
                app = split2[0];
            }
			/*Ӧ�������������������htds:htds_corehost*/
            String[] split = app.split(":");
            if ( split.length == 2 ){
                return split[0];
            }
        }
        return app;
    }

    private String getIpAddr(ServletRequest request)
    {

        String ip = request.getParameter("ip");
        if (StringUtil.isBlank(ip)) {
            ip = request.getParameter("dns_ip");
        }

        return ip;
    }


    private void recordAppPV(String appname) {
        if (StringUtil.isBlank(appname)) {
            return;
        }
        TripMonitor.qps("Ӧ�÷���PV", appname, "").record();
    }



    private boolean isUseAclPermission(String userNickCn) {

        if (StringUtils.isNullOrEmpty(AclSyncUtil.TEST_USER_NICKS))
            return false;

        if ("*".equals(AclSyncUtil.TEST_USER_NICKS))
            return true;

        return AclSyncUtil.TEST_USER_NICKS.contains(userNickCn);

    }


    /**
     * whether user can validated by the specific url;
     *
     * @param ssoUser
     * @return
     */
    private boolean checkPermissionByAcl(Integer bucUserId, String url) throws BucException {


        //initAclPermissionMap();

        Set<Map.Entry<String, PermissionResult>> permissionSet = allPermissionMap.entrySet();

        for (Map.Entry<String, PermissionResult> entry : permissionSet) {

            if (urlMatcher.pathMatchesUrl(entry.getKey(), url)) {

                CheckPermissionParam checkPermParam = new CheckPermissionParam();
                checkPermParam.setUserId(bucUserId);
                checkPermParam.setPermissionNames(Arrays.asList(new String[]{entry.getValue().getPermissionName()}));
                List<CheckPermissionResult> checkResult = aclAccessControlService.checkPermissions(checkPermParam);

                if (checkResult == null || checkResult.size() < 1)
                    continue;

                if (checkResult.get(0).isAccessible())
                    return true;

            }

        }

        return false;
    }

    private void initAclPermissionMap() {
        try {
            PermissionDetailCondition permissionDetailCondition = new PermissionDetailCondition();
            PageCondition<PermissionDetailCondition> condition = new PageCondition<PermissionDetailCondition>();
            // ���ø�������Ҫ�Ĳ���
            permissionDetailCondition.setAppName("ateye");
            condition.setPage(1);
            condition.setSizePerPage(100);
            condition.setParam(permissionDetailCondition);
            //if (allPermissionMap == null) {
            allPermissionMap = new ConcurrentHashMap<String, PermissionResult>();
            Page<PermissionResultModel> allPermissionsModel = aclPermissionService.pagePermission(condition);
            List<PermissionResultModel> allPermissions = allPermissionsModel.getItems();
            for (PermissionResultModel pm : allPermissions) {
                GetPermissionParam getPermission = new GetPermissionParam();
                getPermission.setPermissionName(pm.getPermissionName());
                PermissionResult pr = aclPermissionService.getPermissionByName(getPermission);
                if (!StringUtil.isEmpty(pr.getPath()))
                    allPermissionMap.put(pr.getPath(), pr);
            }
        } catch (Exception e) {
            logger.error("ACLͬ��Ȩ��ʧ��[BUC Exception]", e);
        }
    }


    private void recordUserEmail(String loginAteyeNick, String emailAddr) {
        try {
            userDetailDAO.updateEmail(loginAteyeNick, emailAddr);
        } catch (Throwable e) {
            logger.error("��¼�û�Email�쳣", e);
        }
    }

    private void recordUserExtend(String loginAteyeNick, SimpleSSOUser ssoUser) {
        try {
            UserDO userDO = userDAO.getUserByNick(loginAteyeNick);
            if(userDO!=null && userDO.getEmpId()!=null &&
                    StringUtil.isNotEmpty(userDO.getEmailAddr()) &&
                    StringUtil.isNotEmpty(ssoUser.getCellphone()) &&
                    StringUtil.isNotEmpty(ssoUser.getLastName()) &&
                    StringUtil.isNotEmpty(ssoUser.getSupervisorEmpId()) &&
                    StringUtil.isNotEmpty(ssoUser.getDepDesc()) &&
                    StringUtil.isNotEmpty(ssoUser.getvSupervisorName())){
                return;
            }
            userDO = new UserDO();
            userDO.setNick(loginAteyeNick);
            userDO.setEmpId(Long.valueOf(ssoUser.getEmpId()));
            userDO.setEmailAddr(ssoUser.getEmailAddr());
            userDO.setPhone(ssoUser.getCellphone());
            userDO.setRealName(ssoUser.getLastName());
            userDO.setSupervisorEmpId(Long.valueOf(ssoUser.getSupervisorEmpId()));
            userDO.setSupervisorRealName(ssoUser.getSupervisorName());
            userDO.setDepDesc(ssoUser.getDepDesc());
            userDAO.updateUserExtendInfo(userDO);
        } catch (Throwable e) {
            logger.error("��¼�û���չ��Ϣ�쳣", e);
        }
    }

    private void recordAppAccess(SimpleSSOUser user, String app) {
        if (user == null || app == null || app.equals("")) {
            return;
        }
        try {
            hbaseReadService.addAccess(new Long(user.getId()), app);
        } catch (Throwable t) {
            logger.error("��¼access�쳣", t);
        }
    }

    @Override
    public void destroy() {
    }


    /**
     * ��ȡip��ַ
     */
    private static String getIpAddr(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /**
     * �����û��Ƿ����ĳ��Ӧ�û���ĳ��ip��Ȩ�ޡ�
     * app��ip������Ϊ�գ��ղ���У��
     * userΪ�գ�����鲻ͨ��
     *
     * @param app
     * @param ip
     * @param user
     */
    public boolean checkPermision(String appName, String ip, UserDO user) {
        //����app����ip�����ģ�����Ҫ����user��Ϣ
        if ((StringUtil.isNotBlank(appName) || StringUtil.isNotBlank(ip)) && user == null) {
            return false;
        }

        boolean allowIP = true, allowApp = true;

        //������ip������ͨ��ip��ȡapp��Ϣ������appName����
        if (StringUtil.isNotBlank(ip)) {
            try {
                MachineDO machine = opsServic.getMachineByIp(ip);
                if (machine != null) {
                    allowIP = opsServic.hasPermission(user.getId(), machine.getAppId());
                }
            } catch (Exception e) {
                allowIP = false;
            }
        }

        //������app����У��appȨ��
        if (StringUtil.isNotBlank(appName)) {
            try {
                allowApp = opsServic.hasPermission(user.getId(), appName);
            } catch (Exception e) {
                allowApp = false;
            }
        }
        return allowApp && allowIP;
    }
}
