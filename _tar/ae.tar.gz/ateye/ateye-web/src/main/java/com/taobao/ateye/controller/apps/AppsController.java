package com.taobao.ateye.controller.apps;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.diamond.impl.PlatformTrackerLogDiamond;
import com.taobao.ateye.util.DateFormatUtil;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.taobao.ateye.alarm.manager.AlarmEffectManager;
import com.taobao.ateye.beta.monitor.config.BetaMonitorUtils;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.config.app.AppConfigDO;
import com.taobao.ateye.config.app.impl.AppConfigManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.LogFilePathDAO;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.LogFilePathDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.diamond.impl.TframeAppWhiteList;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.kv.manager.KvDetectorManager;
import com.taobao.ateye.kv.manager.KvDetectorResultDO;
import com.taobao.ateye.score.health.HealthScoreManager;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.util.AgentVersionUtil;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("apps")
public class AppsController extends AbstractController
{
	private static final String APP_DETAIL = "screen/apps/detail";
	private static final String APP_DEBUG = "screen/apps/debug";
	
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	MachineDAO machineDAO;
	@Autowired
	private AppConfigManager appConfig;
	@Autowired
	private LogFilePathDAO logFilePathDAO;
	@Autowired
	private HealthScoreManager healthScoreManager;
	@Autowired
	private AppService appService;
	@Autowired
	private AteyeConfig ateyeConfig;
	@Autowired
	private AlarmEffectManager alarmEffectManager;
	@Autowired
	private OpsServic opsServic;
	@Autowired
	private KvDetectorManager kvDetectorManager;
	@Autowired
	private TframeAppWhiteList tframeAppWhiteList;
	@Autowired
	private HbaseReadService hbaseReadService;

	@Autowired
	private PlatformTrackerLogDiamond platformTrackerLogDiamond;
	
	@RequestMapping("debug.htm")
    public String appDebug(final HttpServletRequest request, ModelMap result) throws Exception {
		String app = request.getParameter("app");
		String threash = request.getParameter("threash");
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return null;
		}
		result.put("app",app);
		//1.���KV��ֹʱ��
		Set<String> ngName = opsServic.getNodeGroupsOfApp(appDO.getId());
		List<String> debugInfos = new ArrayList<String>();
		for (String ng:ngName ){
			Date latestEffectDate = alarmEffectManager.getLatestEffectDate(app, ng,  "/home/admin/logs/monitor/trip-monitor2.log");
			Date sceneLatestEffectDate = alarmEffectManager.getLatestEffectDate(app,ng, "/home/admin/logs/monitor/scene-trip-monitor2.log");
			debugInfos.add("NodeGroup:"+ng+",KV�ɼ���ֹ����:"+CalendarUtil.toString(latestEffectDate, CalendarUtil.TIME_PATTERN)
					+",SceneKV�ɼ���ֹ����:"+CalendarUtil.toString(sceneLatestEffectDate, CalendarUtil.TIME_PATTERN)
					);
		}
		//2.�����������ķ���
		List<LogFilePathDO> lfps = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(), environmentService.getEnvironmentType().getEnv());
		Map<String,Collection<String>> abandonLogs = new HashMap<String,Collection<String>>();
		for (LogFilePathDO lfp:lfps ){
			Set<Date> abandonLog = hbaseReadService.getAbandonLog(app, lfp.getFilePath(), DateUtils.addHours(new Date(), -1), new Date());
			if ( abandonLog != null && !abandonLog.isEmpty() ){
				List<String> dts = new ArrayList<String>();
				for (Date dt:abandonLog){
					dts.add(CalendarUtil.toString(dt, CalendarUtil.TIME_PATTERN));
				}
				Collections.sort(dts);
				abandonLogs.put(lfp.getFilePath(), dts);
			}
		}
		result.put("abandonLogs",abandonLogs);
		//3.���KV�춯
		Double tValue = 0.5;
		if ( StringUtils.isNotBlank(threash) ){
			tValue = Double.valueOf(threash);
		}
		Set<String> ngNameOfApp = opsServic.getNGNameOfApp(appDO);
		List<KvDetectorResultDO> results = new ArrayList<KvDetectorResultDO>();
		for (String ng:ngNameOfApp){
			List<KvDetectorResultDO> detectResult = kvDetectorManager.getDetectResult(ng,tValue);
			results.addAll(detectResult);
		}
		result.put("detectResults", results);
		result.put("infos",debugInfos);
		return APP_DEBUG;
    }
	@RequestMapping("detail.htm")
    public String appDetail(final HttpServletRequest request, ModelMap result) throws DAOException
    {
    	if(StringUtils.isNotEmpty(ateyeConfig.getNotice())){
			result.put("notice",ateyeConfig.getNotice());
		}
		String app = request.getParameter("app");
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return APP_DETAIL;
		}
		if(appDO.getId() > 0){
			app = app.toLowerCase();
		}
		if(platformTrackerLogDiamond.isExistConfig(app) && !environmentService.isDaily()){
			result.put("isPlatformApp", true);
		}
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appDO.getId(), environmentService.getEnvironmentType().ordinal());
		result.put("machines", machines);
		//������������������������չʾ
		result.put("extendApps", getExtendNodeGroups(app,machines));
		result.put("supportTframe", tframeAppWhiteList.getConfigObjs().contains(app));
		result.put("app", app);
		result.put("betaMonitor", BetaMonitorUtils.supportBetaMonintor(app));
		if(this.environmentService.isDaily()){
			result.put("sentinelUrl","http://sentinel.alibaba.net/#/dashboard/flow/" + app);
			result.put("dossUrl","http://doss.alibaba.net/admin/stable/stableIndex?app=" + app);
		}else if(this.environmentService.isPrepub()){
			result.put("sentinelUrl","http://sentinel.pre.alibaba-inc.com/#/dashboard/flow/" + app);
			result.put("dossUrl","http://pre.doss.alibaba-inc.com/admin/stable/stableIndex?app=" + app);
		}else{
			result.put("sentinelUrl","http://sentinel.alibaba-inc.com/#/dashboard/flow/" + app);
			result.put("dossUrl","http://doss.alibaba-inc.com/admin/stable/stableIndex?app=" + app);
		}
		AppConfigDO config = appConfig.getConfig(app);
		if ( config != null ){
			if ( appDO.getBu() != null && appDO.getBu().contains("����") ){
				String ateyeClientVersion = config.getAteyeClientVersion();
				if ( StringUtils.isNotBlank(ateyeClientVersion) ){
					if (AgentVersionUtil.compareByNumber(ateyeClientVersion,"2.2.0")<0){
						result.put("oldVersion",ateyeClientVersion);
						result.put("newVersion","2.2.3������");
						result.put("needUpdate",true);
					}
				}
			}
		}
    	return APP_DETAIL;
    }

	public String formatDouble(double d){
		String ss = String.valueOf(d);
		if ( ss.length() <=5 ){
			return ss;
		}
		return ss.substring(0,5);
	}

	@RequestMapping("listData.htm")
	@ResponseBody
	public String getAppsByBizType(@RequestParam("bizType") Integer bizType,
			@RequestParam(value="subBizType",required=false) Integer subBizType){
		List<AppDO> apps = this.appService.getAppByBizType(bizType, subBizType);
		return new Gson().toJson(apps);
	}
	@RequestMapping("listData2.htm")
	@ResponseBody
	public String getAppsByProductName(@RequestParam("productName") String productName) throws DAOException {
		List<AppDO> apps = appDAO.queryAppByProduct(productName);
		return new Gson().toJson(apps);
	}
	
}
