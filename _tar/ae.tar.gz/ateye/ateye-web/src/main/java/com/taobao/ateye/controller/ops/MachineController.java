package com.taobao.ateye.controller.ops;

import com.alibaba.security.SecurityUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.opsfree.OpsFree;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.OpsServic;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/machine")
public class MachineController extends AbstractController{
	private static Logger logger=Logger.getLogger(MachineController.class);
	
	private static final String OPS_LIST = "screen/ops/opsList";
	private static final String OPS_ADD = "screen/ops/opsAdd";
	private static final String OPS_SYNC_RESULT = "screen/ops/opsSyncResult";
	
	@Autowired
	private OpsServic opsServic;
	@Autowired
	private MachineDAO machineDAO;
	
	@Autowired
	private AppService appService;
	
	@Autowired
	private OpsFree opsfree;
	
    @RequestMapping("selectApp2.htm")
    public String selectApp2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/machine/opsList.htm");
    	result.put("level2","��������");
    	result.put("level2Url","/machine/selectApp2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
	@RequestMapping("opsList.htm")
	public String queryMachineAndAppList(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String appName = request.getParameter("app");
		result.put("app", appName);
		List<MachineDO> machines=new ArrayList<MachineDO>();
		Map<AppDO,List<MachineDO>> allMachines = new HashMap<AppDO, List<MachineDO>>();
		if(StringUtils.isNotBlank(appName)){
			 machines = opsServic.getAllMachinesBelongToAnApp(appName);
			AppDO appDO=appService.getAppByAppName(appName);
			allMachines.put(appDO, machines);
		}else{
		    allMachines = opsServic.getAllMachinesBelongToAUser(user.getId());
		}
		if(machines.size()==0){
			result.put("error", "û���ҵ���Ӧ�ù����Ļ���");
		}else{
			result.put("allMachines", allMachines);
		}

		result.put("env",this.environmentService.getEnvironmentType().getEnv());

		String refreshed = request.getParameter("refreshed");
		if(StringUtils.isNotBlank(refreshed)){
			result.put("refreshed",refreshed);
		}

		return OPS_LIST;
	}
	
	@RequestMapping("updateMachineDesc.htm")
	public String updateMachineDesc(final HttpServletRequest request,
			final HttpServletResponse response,ModelMap result) throws IOException, DAOException {
		String machineId = request.getParameter("machineId");
		String machineDesc = request.getParameter("machineDesc");
		String machinePort= request.getParameter("machinePort");
		this.opsServic.updateMachineDesc(Long.parseLong(machineId), machineDesc);
		if ( StringUtils.isNotBlank(machinePort)) {
			this.machineDAO.updateMachinePort(Long.parseLong(machineId), Integer.valueOf(machinePort) );
		}
		
		String appName = request.getParameter("appName");
		List<MachineDO> machines=new ArrayList<MachineDO>();
		Map<AppDO,List<MachineDO>> allMachines = new HashMap<AppDO, List<MachineDO>>();
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		if(StringUtils.isNotBlank(appName)){
			 machines = opsServic.getAllMachinesBelongToAnApp(appName);
			AppDO appDO=appService.getAppByAppName(appName);
			allMachines.put(appDO, machines);
		}else{
		    allMachines = opsServic.getAllMachinesBelongToAUser(user.getId());
		}
		if(machines.size()==0){
			result.put("error", "û���ҵ���Ӧ�ù����Ļ���");
		}else{
			result.put("allMachines", allMachines);
		}
		return "redirect:/machine/opsList.htm?app="+appName;
	}
	
	@RequestMapping("deleteOps.htm")
	public String deleteMachine(final HttpServletRequest request,
			final HttpServletResponse response,ModelMap result) throws IOException, DAOException {
		String dns_ip = request.getParameter("dns_ip");
		if (StringUtils.isNotBlank(dns_ip)) {
			opsServic.deleteMachineByIp(dns_ip);
		}
		String appName = request.getParameter("appName");
		result.put("app", appName);

		List<MachineDO> machines=new ArrayList<MachineDO>();
		Map<AppDO,List<MachineDO>> allMachines = new HashMap<AppDO, List<MachineDO>>();
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		if(StringUtils.isNotBlank(appName)){
			 machines = opsServic.getAllMachinesBelongToAnApp(appName);
			AppDO appDO=appService.getAppByAppName(appName);
			allMachines.put(appDO, machines);
		}else{
		    allMachines = opsServic.getAllMachinesBelongToAUser(user.getId());
		}
		if(machines.size()==0){
			result.put("error", "û���ҵ���Ӧ�ù����Ļ���");
			return OPS_LIST;
		}else{
			result.put("allMachines", allMachines);
			result.put("opMsg", "ɾ������"+dns_ip+"�ɹ�");
			return "redirect:/machine/opsList.htm?app="+appName;
		}
	}
	
	@RequestMapping("showOps.htm")
	public String showMachineAndApp(final HttpServletRequest request,ModelMap result) throws DAOException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
    	List<AppDO> appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
    	result.put("allApps", appDOList);
    	
		String app = request.getParameter("app");
		result.put("app",app);
		return OPS_ADD;
	}
	
	@RequestMapping("addOps.htm")
	public String addMachineAndApp(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result) throws IOException, DAOException {
		String nodename = request.getParameter("nodename");
		String dns_ip = request.getParameter("dns_ip");
		String appName = request.getParameter("appName");
		String portStr = request.getParameter("port");
		String desc = request.getParameter("desc");
		if(desc==null)
			desc = "";
		if(StringUtils.isBlank(nodename)||StringUtils.isBlank(dns_ip)||StringUtils.isBlank(appName)||StringUtils.isBlank(portStr)){
			return "redirect:/noPermission.htm";
		} else {
			nodename = nodename.trim();
			dns_ip = dns_ip.trim();
			appName = appName.trim();
			portStr = portStr.trim();
		}
		int port = 7001;
		try
		{
			port = Integer.parseInt(portStr);
		}
		catch(Exception e){}
		
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String oldAppName = opsServic.insertANewMachine(user.getId(), appName, nodename, dns_ip, port, desc);
		List<AppDO> appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
    	
		result.put("allApps", appDOList);
		if(oldAppName!=null) {
			result.put("opMsg", "����:"+dns_ip+"��Ӧ��:"+oldAppName+"���Ѿ����ڣ�����ɾ��������");
			return OPS_ADD;
		} else {
			result.put("opMsg", "����:"+dns_ip+"���ӳɹ�");
			return "redirect:/machine/opsList.htm?app="+appName;
		}
	}
	
	@RequestMapping("opsSync.htm")
	public String syncByOps(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String appName = request.getParameter("app");
		AppDO appDO=appService.getAppByAppName(appName);
		try {
			List<String> opResults = this.opsfree.synchronizedMachineInfoWithinAnApp(appDO);
			result.put("opResults",opResults);
		} catch (Throwable e) {
			logger.error("ͬ��Ӧ��:"+appName+"��Opsfree����ʱ�쳣", e);
			result.put("errorMsg", "ͬ��Ӧ��:"+appName+"��Opsfree����ʱ�쳣");
		}
		return OPS_SYNC_RESULT;
	}

	@RequestMapping("refresh.htm")
	public String refreshServers(HttpServletRequest request){
		String appName = request.getParameter("appName");
		String from = request.getHeader("Referer");

    	int refreshed = 1;
		try {
			this.opsServic.refreshMachineForTestEnv(appName);
			refreshed = 1;
		} catch (DAOException e) {
			logger.error("ͬ��Ӧ��:"+appName+"�Ĳ��Ի�����������ʱ�쳣", e);
			refreshed = 0;
		}

		if(from.indexOf("?") > -1){
			from = from + "&refreshed=" + refreshed;
		}else{
			from = from + "?refreshed=" + refreshed;
		}
		return "redirect:"+SecurityUtil.getSafeUrl(from);
	}
}
