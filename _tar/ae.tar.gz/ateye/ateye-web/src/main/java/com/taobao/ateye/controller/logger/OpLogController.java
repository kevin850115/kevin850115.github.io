package com.taobao.ateye.controller.logger;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.Maps;
import com.taobao.ateye.annotation.Switch;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.config.manager.ConfigManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.util.UrlUtil;
import com.taobao.tracker.log.TrackerLogConstants;
import com.taobao.tracker.log.TrackerMessageDO;
import com.taobao.tracker.search.OpLogSearchService;
import com.taobao.util.CalendarUtil;


@Controller
@RequestMapping("/log")
public class OpLogController extends AbstractController{
	private Logger logger = Logger.getLogger("OpLogger");
	private static final String QUERY_PAGE = "screen/opLog/query_Page";
	private static final String QUERY_DETAIL = "screen/opLog/opLogDetail";
	private static final String QUERY_DETAIL2 = "screen/opLog/logDetail";
	
	@Autowired
	private OpsServic opsServic;
	@Autowired
	private ConfigManager configManager;
	
	@Autowired
	private OpLogSearchService opLogSearchService;

	@RequestMapping("opLogTrackerQuery.htm")
	public final String queryLogForm(final HttpServletRequest request,
			ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		List<AppDO> appDOList = new ArrayList<AppDO>();
		try {
			appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
		} catch (DAOException e) {
			logger.info("get userApp failed ", e);
		}
		result.put("start_hhmm","00:00");
		result.put("end_hhmm","00:00");
		result.put("apps", appDOList);
		return QUERY_PAGE;
	}

	@RequestMapping("logDetail.htm")
	public final String logDetail(final HttpServletRequest request,
			ModelMap result) {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String app=request.getParameter("app");
		String id =request.getParameter("id").trim();
		String objId =request.getParameter("objId").trim();
		String objType =request.getParameter("objType").trim();
		String date =request.getParameter("date").trim();
		TrackerMessageDO trackerMessage = opLogSearchService.getTrackerMessageByUniqId(app, 
				Integer.valueOf(objType), 
				objId,
				CalendarUtil.toDate(date,"yyyy-MM-ddHH:mm:ss.SSS"), id);
		result.put("content",JSON.toJSONString(trackerMessage.getContext(),SerializerFeature.PrettyFormat,SerializerFeature.WriteDateUseDateFormat));

		String formatKeys = request.getParameter("formatKeys");
		String format = request.getParameter("format");
		if("1".equals(format)) {
			format = "commaText";
			formatKeys = "content";
		}else{
			format = "json";
		}

		if(StringUtils.isNotBlank(format) && StringUtils.isNotBlank(formatKeys)){
			String[] keys = formatKeys.split("\\,");
			Map<String,String> formatedContents = Maps.newHashMap();
			String formatedContent;
			for(String key : keys){
				formatedContent = (String)trackerMessage.getContext().get(key);
				if(StringUtils.isBlank(formatedContent)){
					formatedContent = "����Ϊ��(tracker)";
				}else{
					if("commaText".equals(format)){
						try {
							formatedContent = formatLogText(formatedContent);
						}catch(Exception e){
							logger.error("��־content���ݸ�ʽ���쳣,content=" + formatedContent,e);
							formatedContent = "���ݸ�ʽ��ʧ��";
						}
					}else if("json".equals(format)){
						try {
							formatedContent = formatJson(formatedContent);
						}catch(Exception e){
							logger.error("��־content���ݸ�ʽ���쳣,content=" + formatedContent,e);
							formatedContent = "���ݸ�ʽ��ʧ��";
						}
					}
				}
				formatedContents.put(key,formatedContent);
			}
			result.put("formated",formatedContents);
		}

		result.put("message",trackerMessage);
		
		return QUERY_DETAIL2;
	}

	public static String formatJson(String jsonStr) {
		if (null == jsonStr || "".equals(jsonStr))
			return "";
		StringBuilder sb = new StringBuilder();
		char last = '\0';
		char current = '\0';
		int indent = 0;
		boolean isInQuotationMarks = false;
		for (int i = 0; i < jsonStr.length(); i++) {
			last = current;
			current = jsonStr.charAt(i);
			switch (current) {
				case '"':
					if (last != '\\'){
						isInQuotationMarks = !isInQuotationMarks;
					}
					sb.append(current);
					break;
				case '{':
				case '[':
					sb.append(current);
					if (!isInQuotationMarks) {
						sb.append('\n');
						indent++;
						addIndentBlank(sb, indent);
					}
					break;
				case '}':
				case ']':
					if (!isInQuotationMarks) {
						sb.append('\n');
						indent--;
						addIndentBlank(sb, indent);
					}
					sb.append(current);
					break;
				case ',':
					sb.append(current);
					if (last != '\\' && !isInQuotationMarks) {
						sb.append('\n');
						addIndentBlank(sb, indent);
					}
					break;
				default:
					sb.append(current);
			}
		}

		return sb.toString();
	}

	/**
	 * ����space
	 */
	private static void addIndentBlank(StringBuilder sb, int indent) {
		for (int i = 0; i < indent; i++) {
			sb.append('\t');
		}
	}

	/**
	 *
	 * ��ʽ��traceLog��־����Ҫ���json �� javabean to string �ĸ�ʽ��
	 * @param logText
	 * @return
	 */
	public static String formatLogText(String logText) {
		if(StringUtils.isBlank(logText)){
			return null;
		}

		int level = 0;
		StringBuffer formatResult = new StringBuffer();
		for(int i=0;i<logText.length();i++){
			char c = logText.charAt(i);
			if(level>0&&'\n'==formatResult.charAt(formatResult.length()-1)){
				formatResult.append(StringUtils.repeat("\t",level));
			}
			switch (c) {
				case '{':
				case '[':
					formatResult.append(c+"\n");
					level++;
					break;
				case ',':
					formatResult.append(c+"\n");
					break;
				case '}':
				case ']':
					formatResult.append("\n");
					level--;
					formatResult.append(StringUtils.repeat("\t",level));
					formatResult.append(c);
					break;
				default:
					formatResult.append(c);
					break;
			}
		}

		return formatResult.toString();

	}

	@RequestMapping("opLogQuery.htm")
	public final String logQuery(final HttpServletRequest request,
			ModelMap result) throws UnsupportedEncodingException {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		List<AppDO> appDOList = new ArrayList<AppDO>();
		try {
			appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
		} catch (DAOException e) {
			logger.info("get userApp failed ", e);
		}
		String app = request.getParameter("app");
		String objType=request.getParameter("objType");
		if ( StringUtils.isNotBlank(objType)) {
			objType = objType.trim();
		}
		int type=Integer.parseInt(objType);
		Map<String, String> parmValue = new HashMap<String, String>();
		List<TrackerMessageDO> trackerMessageList=new ArrayList<TrackerMessageDO>();
		try{
			String indexId=request.getParameter("indexId");
			if ( StringUtils.isNotBlank(indexId) ){
				indexId = indexId.trim();
			}
			parmValue.put("app", app);
			parmValue.put("objType", objType);
			parmValue.put("indexId", indexId);
			String start_time = request.getParameter("start_time");
			String end_time = request.getParameter("end_time");
			String start_hhmm = request.getParameter("start_hhmm");
			String end_hhmm = request.getParameter("end_hhmm");
			if(!StringUtil.isBlank(start_time)&&!StringUtil.isBlank(end_time)){
				Date s_time=stringToDate(start_time,start_hhmm);
				Date e_time=stringToDate(end_time,end_hhmm);
				if(s_time.after(e_time)){
					result.put("error", "��ʼʱ�����С�ڽ���ʱ��");
					return QUERY_PAGE;
				}
				result.put("start_time",start_time);
				result.put("end_time",end_time);

				result.put("start_hhmm",start_hhmm);
				result.put("end_hhmm",end_hhmm);

				parmValue.put("start_time", start_time);
				parmValue.put("end_time", end_time);

				parmValue.put("start_hhmm", start_hhmm);
				parmValue.put("end_hhmm", end_hhmm);

				trackerMessageList = getMessages(app,type,indexId,s_time,e_time);
			}else{
				trackerMessageList = getMessages(app,type,indexId,null,null);
			}
		}
		catch(Exception e){
			logger.error("get log failure",e);
			result.put("error", "��ȡ��־��¼ʧ��");
		}
		//0.��������ɸѡ����һ�ι���
		filt(trackerMessageList,request,app);
		//1.�ҵ�����obj_�Ķ���
		Map<TrackerMessageDO, Map<String, String>> objs = extractObjs(trackerMessageList,"obj_",false);
		//2.�ҵ�����flt_�Ķ���
		Map<TrackerMessageDO, Map<String, String>> flts = extractObjs(trackerMessageList,"flt_",app.startsWith("_VIRTUAL_"));
		String showAllFlt = request.getParameter("showAllFlt");
		Map<String,List<Pair<String,Integer>>> fltIndexs = buildFltIndexs(flts,"true".equals(showAllFlt));
		if ( StringUtils.isNotBlank(request.getParameter("fltk")) ){
			result.put("fltk",request.getParameter("fltk"));
		}
		if ( StringUtils.isNotBlank(request.getParameter("fltv")) ){
			result.put("fltv",request.getParameter("fltv"));
		}
		if ( type == 9527 ){//���KVLog��һ������
			fltBaseType(objs);
		}
		result.put("objs", objs);
		result.put("fltMap", flts);
		result.put("fltIndexs", fltIndexs);
		result.put("apps", appDOList);
		result.put("queryParm", parmValue);
		result.put("queryUrl", buildQueryUrl(parmValue));
		result.put("messageList", trackerMessageList);
		result.put("showAllFlt", showAllFlt);
		return QUERY_PAGE;
	}

	private List<TrackerMessageDO> getMessages(String app,int type, String indexId,Date s_time,Date e_time){
		if ( !app.startsWith("_VIRTUAL_") || isSceneApp(app)){
			return getRealAppMessages(app,type,indexId,s_time,e_time);
		}else{
			List<TrackerMessageDO> ret = new ArrayList<TrackerMessageDO>();
			String vApp = app.substring("_VIRTUAL_".length());
			String key = "oplog.virtual."+vApp.toLowerCase();
			List<String> realApps = configManager.gets(key);
			for ( String appDesc:realApps ){
				String[] ps = appDesc.split(":");
				if ( ps.length != 2 ){
					continue;
				}
				try{
					List<TrackerMessageDO> msgs = getRealAppMessages(ps[0],Integer.valueOf(ps[1]),indexId,s_time,e_time); 
					if ( msgs != null ){
						ret.addAll(msgs);
					}
				}catch(Throwable t){
				}
			}
			sortByDate(ret);
			return ret;
		}
	}

	private boolean isSceneApp(String app){
		if(app != null && app.indexOf("SCENE") > -1){
			return true;
		}
		return false;
	}
	private void sortByDate(List<TrackerMessageDO> ret) {
		Collections.sort(ret, new Comparator<TrackerMessageDO>(){
			@Override
			public int compare(TrackerMessageDO arg0, TrackerMessageDO arg1) {
				return arg0.getLogTime().compareTo(arg1.getLogTime());
			}
		});
	}

	private List<TrackerMessageDO> getRealAppMessages(String app,int type, String indexId,Date s_time,Date e_time){
		if ( s_time == null && e_time == null ){
			List<TrackerMessageDO> trackerMessageList=opLogSearchService.findById(app, type, indexId);
			if ( trackerMessageList == null || trackerMessageList.isEmpty() ){
				trackerMessageList=opLogSearchService.findByIndex(app, type, indexId);
			}
			return trackerMessageList;
		}else{
			List<TrackerMessageDO> trackerMessageList=opLogSearchService.findById(app, type, indexId,s_time,e_time);//��չ1��
			if ( trackerMessageList == null || trackerMessageList.isEmpty() ){
				trackerMessageList=opLogSearchService.findByIndex(app, type, indexId,s_time,e_time);
			}
			return trackerMessageList;
		}
	}


	private void fltBaseType(Map<TrackerMessageDO, Map<String, String>> objs) {
		Iterator<Entry<TrackerMessageDO, Map<String, String>>> iterator = objs.entrySet().iterator();
		while ( iterator.hasNext() ){
			Entry<TrackerMessageDO, Map<String, String>> ent = iterator.next();
			Iterator<Entry<String, String>> itr2 = ent.getValue().entrySet().iterator();
			while ( itr2.hasNext() ){
				Entry<String, String> ent2= itr2.next();
				if ( ent2.getKey().startsWith("String") 
					|| ent2.getKey().startsWith("Integer")	
					|| ent2.getKey().startsWith("Long")	
					){
					itr2.remove();
					continue;
				}
			}
		}
	}

	private void filt(List<TrackerMessageDO> trackerMessageList, HttpServletRequest request,String appName) {
		if ( StringUtils.isBlank(request.getParameter("fltk"))  
		  || StringUtils.isBlank(request.getParameter("fltv")) ){
			//����Ҫɸѡ
			return ;
		}
		String fltk = request.getParameter("fltk");
		String fltv = request.getParameter("fltv");
		Map<TrackerMessageDO, Map<String, String>> flts = extractObjs(trackerMessageList,"flt_",appName.startsWith("_VIRTUAL_"));
		Iterator<TrackerMessageDO> iterator = trackerMessageList.iterator();
		while ( iterator.hasNext() ){
			TrackerMessageDO next = iterator.next();
			Map<String, String> fltMap = flts.get(next);
			if ( fltMap != null && fltMap.get(fltk)!=null && fltMap.get(fltk).equals(fltv)){
				//���Ϲ�������������
			}else{
				iterator.remove();
			}
		}
	}

	private String buildQueryUrl(Map<String, String> parmValue) throws UnsupportedEncodingException {
		StringBuilder sb = new StringBuilder();
		sb.append("/log/opLogQuery.htm?");
		for (Map.Entry<String, String> ent:parmValue.entrySet() ){
			if ( ent.getValue() != null ){
				sb.append(ent.getKey()).append("=").append(UrlUtil.encode(ent.getValue())).append("&");
			}
		}
		return sb.toString();
	}

	/*
	 * <��������,List<Pair<����ֵ�����ִ���>>>
	 */
	private Map<String, List<Pair<String, Integer>>> buildFltIndexs(
			Map<TrackerMessageDO, Map<String, String>> flts,boolean showAll ) {
		Map<String,Map<String,Integer>> ret = new TreeMap<String,Map<String,Integer>>();
		for ( Map.Entry<TrackerMessageDO, Map<String,String>> ent:flts.entrySet() ){
			Map<String, String> mmm = ent.getValue();
			for (Map.Entry<String, String> ent2:mmm.entrySet() ){
				String type = ent2.getKey();
				String value = ent2.getValue();
				Map<String, Integer> list = ret.get(type);
				if ( list == null ){
					list = new TreeMap<String,Integer>();
					ret.put(type,list);
				}
				Integer ivn = list.get(value);
				if ( ivn == null ){
					list.put(value, 1);
				}else{
					list.put(value, ivn+1);
				}
			}
		}
		Map<String, List<Pair<String, Integer>>> ret2 = new TreeMap<String,List<Pair<String,Integer>>>();
		for (Map.Entry<String, Map<String,Integer>> ent:ret.entrySet() ){
			ret2.put(ent.getKey(), sortByCnt(ent.getValue(),showAll));
		}
		return ret2;
	}

	private List<Pair<String, Integer>> sortByCnt(Map<String, Integer> value,boolean showAll) {
		int total = 0;
		List<Pair<String,Integer>> ret =  new ArrayList<Pair<String,Integer>>();
		for (Map.Entry<String, Integer> ent:value.entrySet() ){
			ret.add(Pair.of(ent.getKey(), ent.getValue()));
			total += ent.getValue();
		}
		ret.add(Pair.of("[ȫ��]", total));
		Collections.sort(ret, new Comparator<Pair<String,Integer>>(){
			@Override
			public int compare(Pair<String, Integer> arg0,
					Pair<String, Integer> arg1) {
				return arg1.getRight()-arg0.getRight();
			}
		}
		);
		if ( !showAll ){
			if ( ret.size() > 11 ){
				ret = ret.subList(0, 11);
			}
		}
		return ret;
	}

	private Map<TrackerMessageDO, Map<String, String>> extractObjs(
			List<TrackerMessageDO> trackerMessageList,String mark,boolean isVirtualApp) {
		Map<TrackerMessageDO,Map<String,String>> objs = new HashMap<TrackerMessageDO,Map<String,String>>();
		for (TrackerMessageDO tm:trackerMessageList ){
			Map<String, Object> context = tm.getContext();
			if ( context == null ){
				continue;
			}
			Map<String, String> objsMap = new HashMap<String,String>();
			for ( Map.Entry<String, Object> ent:context.entrySet() ){
				if ( ent.getKey().startsWith(mark) ){
					objsMap.put(ent.getKey().substring(mark.length()), ent.getValue().toString());
				}
			}
			//���������Ӧ�ã���app:type��Ϊһ��filter
			if ( isVirtualApp ){
				objsMap.put("_REAL_APP_", tm.getAppName()+"-"+tm.getObjType());
			}
			objs.put(tm, objsMap);
		}
		return objs;
	}
	
	@RequestMapping("logQueryDetail.htm")
	public String queryLogDetail(final HttpServletRequest request, ModelMap result){
		String msg=request.getParameter("msg");
		//msg = msg.replaceAll(, "<br/>").replaceAll("\n", "<br/>");
		String[] splits = msg.split(TrackerLogConstants.SEP_CHAR);
    	result.put("message", splits);
		return QUERY_DETAIL;
		
	}

	
}
