package com.taobao.ateye.controller.rep;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.report.generator.*;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.tracker.hbase.DocumentDO;
import com.taobao.tracker.hbase.HbaseReadService;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/rep")
public class ReportController extends AbstractController{
	
	private static final String LIST_ALL= "screen/rep/listAll";
	private static final String REP_LIST = "screen/rep/repList";
	private static final String DETAIL_EXCEPTION= "screen/rep/exceptionDetail";
	private static final String DETAIL_SQLMAP= "screen/rep/sqlmapDetail";
	private static final String DETAIL_KV= "screen/rep/kvDetail";
	private static final String DETAIL_TRACKER = "screen/rep/trackerDetail";
	private static final String EMAIL = "screen/email";
	private static final String PERSIST_SWITCH_CHECK = "screen/rep/persistSwitchCheck";

	@Autowired
	ExceptionReportGenerator exceptionGenerator;
	@Autowired
	SqlmapReportGenerator sqlmapGenerator;
	@Autowired
	KVReportGenerator kvReportGenerator;
	@Autowired
	TrackerReportGenerator trackerReportGenerator;
	@Autowired
	HbaseReadService hbaseReadService;
	@Autowired
	PersistSwitchCheckReportGenerator persistSwitchCheckReportGenerator;

	@RequestMapping("repList.htm")
	public String repList(final HttpServletRequest request, ModelMap result) throws Exception {
		String app= request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app",app);
		result.put("startDate", CalendarUtil.toString(DateUtils.addDays(
				CalendarUtil.zerolizedTime(new Date()), -1), CalendarUtil.TIME_PATTERN));
		return REP_LIST;
	}
	@RequestMapping("generateReport.htm")
	public String generateReport(final HttpServletRequest request, ModelMap result) throws Exception {
		String type= request.getParameter("report");
		if ( StringUtils.isBlank(type) ){
			return "";
		}
		String app= request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app",app);
		String startDateStr = request.getParameter("startDate");
		if ( StringUtils.isEmpty(startDateStr) ){
			return "";
		}
		Date startDate = DateFormatUtil.parseByDay(startDateStr);
		if ( type.equals("exception") ){
			exceptionGenerator.generateReport(app, startDate);
			return "redirect:/rep/exceptions.htm?app="+app+"&startDate="+startDateStr;
		}else if (type.equals("sqlmap") ){
			sqlmapGenerator.generateReport(app, startDate);
			return "redirect:/rep/sqlmap.htm?app="+app+"&startDate="+startDateStr;
		}else if ( type.equals("kv")){
			kvReportGenerator.generateReport(app, startDate);
			return "redirect:/rep/kv.htm?app="+app+"&startDate="+startDateStr;
		}else if ( type.equals("tracker")){
			trackerReportGenerator.generateReport(app, startDate);
			return "redirect:/rep/tracker.htm?app="+app+"&startDate="+startDateStr;
		}else if( "persistSwitchCheck".equals(type)){
			persistSwitchCheckReportGenerator.generateReport(app,startDate);
			return "redirect:/rep/persistSwitchCheck.htm?app=" + app + "&startDate="+startDateStr;
		}
		return "";

	}
	@RequestMapping("exceptions.htm")
	public String exceptions(final HttpServletRequest request, ModelMap result) throws Exception {
		return _commonReport(request, result, exceptionGenerator, DETAIL_EXCEPTION);
	}
	@RequestMapping("sqlmap.htm")
	public String sqlmap(final HttpServletRequest request, ModelMap result) throws Exception {
		return _commonReport(request, result, sqlmapGenerator , DETAIL_SQLMAP);
	}
	@RequestMapping("kv.htm")
	public String kv(final HttpServletRequest request, ModelMap result) throws Exception {
		return _commonReport(request, result, kvReportGenerator , DETAIL_KV);
	}
	@RequestMapping("tracker.htm")
	public String tracker(final HttpServletRequest request, ModelMap result) throws Exception {
		return _commonReport(request, result, trackerReportGenerator , DETAIL_TRACKER);
	}

	@RequestMapping("persistSwitchCheck.htm")
	public String persistSwitchCheck(final HttpServletRequest request, ModelMap result) throws Exception {
		return _commonReport(request, result, persistSwitchCheckReportGenerator , PERSIST_SWITCH_CHECK);
	}

	public String _commonReport(final HttpServletRequest request, ModelMap result,AbstractGenerator generator,String html) throws Exception {
		UserDO userDO = MyThreadLocal.get();
		if ( userDO == null ){
			return "";
		}
		String app= request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		String nick = request.getParameter("nick");
		if ( StringUtils.isBlank(nick) ){
			nick = userDO.getNick();
		}
		result.put("app",app);
		result.put("nick",nick);
		String startDateStr = request.getParameter("startDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = CalendarUtil.zerolizedTime(new Date());
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		result.put("startDateObj",startDate);
		
		String preview = request.getParameter("preview");
		String receivers = request.getParameter("receivers");
		if ( StringUtils.isNotBlank(preview) ){
			String ctx = generator.previewReport(app, startDate,userDO.getNick());
			result.put("ctx",ctx);
			return EMAIL;
		}
		if ( !StringUtils.isBlank(receivers)) {
			String[] rs = receivers.split(",");
			Map<String,String> nickMap = new HashMap<String,String>();
			for ( String em:rs ){
				nickMap.put(nick, em);
			}
			Map<String, Object> reportResultMap = generator.sendEmail(app, startDate, nickMap);
			result.putAll(reportResultMap);
			result.put("msg", "�ʼ��ɹ�����");
		}else{
			Map<String, Object> reportResultMap = generator.getReport(app,startDate);
			if ( reportResultMap != null ){
				result.putAll(reportResultMap);
			}
		}
		return html;
	}
	@RequestMapping("listAll.htm")
	public String listAll(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		initBizMap(result);
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = CalendarUtil.zerolizedTime(new Date());
		}
		result.put("startDate", DateFormatUtil.formatToDay(startDate));
		
		List<DocumentDO> documents = hbaseReadService.getDocuments(startDate);
		Map<String,Map<String,DocumentDO>> typeApps = new HashMap<String,Map<String,DocumentDO>>();
		for ( DocumentDO doc:documents ){
			Map<String,DocumentDO> apps = typeApps.get(doc.getType());
			if ( apps == null ){
				apps = new HashMap<String,DocumentDO>();
				typeApps.put(doc.getType(), apps);
			}
			apps.put(doc.getApp(),doc);
		}
		result.put("docs",typeApps);
		return LIST_ALL;
	}
}
