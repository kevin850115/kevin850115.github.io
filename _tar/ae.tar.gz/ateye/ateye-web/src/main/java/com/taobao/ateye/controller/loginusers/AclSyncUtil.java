package com.taobao.ateye.controller.loginusers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.buc.api.EnhancedUserQueryService;
import com.alibaba.buc.api.PermissionService;
import com.alibaba.buc.api.exception.BucException;
import com.alibaba.buc.api.grant.GrantRolesToUserParam;
import com.alibaba.buc.api.model.enhanced.EnhancedUser;
import com.alibaba.buc.api.param.Action;
import com.alibaba.buc.api.param.RiskLevel;
import com.alibaba.buc.api.permission.CreatePermissionParam;
import com.alibaba.buc.api.permission.GetPermissionParam;
import com.alibaba.buc.api.permission.UpdatePermissionParam;
import com.alibaba.buc.api.role.AddPermissionsToRoleParam;
import com.alibaba.buc.api.role.CreateRoleParam;
import com.alibaba.buc.api.role.GetRoleParam;
import com.alibaba.buc.api.role.RoleResult;
import com.alibaba.buc.api.role.UpdateRoleParam;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.taobao.ateye.annotation.AteyeInvoker;
import com.taobao.ateye.annotation.Switch;
import com.taobao.ateye.dataobject.PermissionApplyDO;
import com.taobao.ateye.dataobject.ResourceDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.PermissionApplyService;
import com.taobao.ateye.service.ResourceService;
import com.taobao.ateye.service.RoleService;
import com.taobao.ateye.util.Ateye;

/**
 * Created by wangj.w on 2015/9/23.
 */
@Service
public class AclSyncUtil {

    private static Logger logger = Logger.getLogger("AclSyncConfig");

    @Autowired
    private ResourceService ateyeResourceService;

    @Autowired
    private PermissionService aclPermissionService;

    @Autowired
    private EnhancedUserQueryService enhancedUserQueryService;

    @Autowired
    private com.alibaba.buc.api.RoleService aclRoleService;

    @Autowired
    private PermissionApplyService permissionApplyService;

    @Autowired
    private com.alibaba.buc.api.GrantService aclGrantService;

    @Autowired
    protected EnvironmentService environmentService;

    @Autowired
    private RoleService roleService;

    @Switch(description = "�Ƿ�ʹ��ACLȨ��")
    public static boolean USE_ACL_PERMISSION = true;


    @Switch(description = "�Ƿ�ͬ��ACLȨ��")
    public static boolean IS_ACL_PERMISSION = false;


    @Switch(description = "�û������б�")
    public static String TEST_USER_NICKS = "*";
    //public static String TEST_USER_NICKS = "���,����,·��,����,����,ɽ��";
    
    @Switch(description = "����ǩԼ����ָ��hscf")
    public static boolean CUSTOMER_SIGN_RETURN_TO_HSCF = true;
    
    @Switch(description = "׷�Ӽ��ܲ���������ǩԼ����ָ��hscf")
    public static boolean ADD_ENCODED_PARAS_TO_CUSTOMER_SIGN_RETURN = true;
    
    @Switch(description = "����ǩԼ����ָ��hscf base server name")
    public static String CUSTOMER_SIGN_RETURN_BASE_HSCF = "http://hotel.alitrip.com/hscf";

    private static List<String> ownedUserIdsDaily = Lists.asList("85459", new String[]{"27413", "111156207"});   //qinchong, shizhang, dongbi


    private static List<String> ownedUserIdsProd = Lists.asList("85459", new String[]{"27413", "590755"});


    private final static String USERID_DAILY = "111304818";     //ateye-acl
    private final static String USERID_PRODUCTION = "700374";   //ateye-acl


    public final static String[] sysAdminResource = new String[]{"ȫ��"};

    @AteyeInvoker(description = "��ȡUCID", paraDesc = "nickCn")
    public void getUcIdByNick(String nickCn) {

        try {

            EnhancedUser user = enhancedUserQueryService.getUserByNickNameCn(nickCn); //?should be sso userId

            Ateye.out.println(JSON.toJSONString(user));

        } catch (Throwable e) {
            Ateye.out.println(e.getStackTrace());
        }
    }


    @AteyeInvoker(description = "ͬ��acl��ɫ��Ȩ", paraDesc = "applyId")
    public void grantUserAclRolePermission(final int id) throws BucException {
        PermissionApplyDO applyDO = permissionApplyService.getApplyById(id);

        String nickname = applyDO.getNick();
        String roleIds = applyDO.getRoleIds();

        String[] roleIdList = roleIds.split(",");

        List<String> roleNames = new ArrayList<String>();
        for (String roleId : roleIdList) {
            RoleDO role = roleService.getRoleById(Long.parseLong(roleId));

            if (role != null)
                roleNames.add(role.getName());
        }

        aclGrantService.grantRolesToUser(createGrantRolesToUserParam(nickname, roleNames));

        logger.debug(String.format("Successfully grant acl rolenames[%s] to user: %s", StringUtils.join(roleNames, ","),nickname));

    }


    @AteyeInvoker(description = "ͬ��acl��ɫ��Ȩ", paraDesc = "userNickCN&roleNames[sperate by ,]")
    public void grantUserAclRolePermission(final String userNickCn, final String roleNames) throws Exception {

        String[] roleNameArray = roleNames.split(",");

        List<String> roleNameList = Arrays.asList(roleNameArray);

        grantUserAclRolePermission(userNickCn, roleNameList);


    }
    public void grantUserAclRolePermission(final String userNickCn, final List<String> roleNameList) throws Exception {


        aclGrantService.grantRolesToUser(createGrantRolesToUserParam(userNickCn, roleNameList));

        logger.debug(String.format("Successfully grant acl rolenames[%s] to user: %s", StringUtils.join(roleNameList, ","),userNickCn));

    }

    public void syncResourceRoles(String resourceName, String[] roleIds, String userId) {


        syncPermission(resourceName, userId);


        for (String roleId : roleIds) {


            RoleDO role = roleService.getRoleById(Long.parseLong(roleId));

            CreateRoleParam roleParam = createRoleParam(role, userId);
            try {
                if (aclRoleService.getRole(new GetRoleParam(role.getName())) == null) {
                    aclRoleService.createRole(roleParam);
                } else {
                    aclRoleService.updateRole(createUpdateRoleParam(role, userId));
                }

                grantAclPermissionToRole(role);


            } catch (BucException e) {

                logger.error("Error[BUC Exception] occurs when create or update role with name:" + role.getName(), e);

                throw new RuntimeException("Error[BUC Exception] occurs when create or update role with name:" + role.getName(), e);
            } catch (Throwable t) {

                logger.error("Error occurs when create or update role with name:" + role.getName(), t);
                throw new RuntimeException("Error occurs when create or update role with name:" + role.getName(), t);
            }
        }

    }

    public void grantAclPermissionToRole(RoleDO role) {
        List<ResourceDO> resourceDOList = role.getResourceList();
        try {
            RoleResult aclResult = aclRoleService.getRole(new GetRoleParam(role.getName()));
            if (aclResult != null && !StringUtils.isEmpty(aclResult.getName())) {
                aclRoleService.addPermissionsToRole(createRolePermisionParam(role));
            }

        } catch (BucException e) {
            logger.error("Error occurs when grant acl permission to role with name:" + role.getName(), e);
        }

    }


    public void syncPermission(String resourceName, String userId) {


        ResourceDO resourceDO = ateyeResourceService.getResourceByName(resourceName);
        try {

            GetPermissionParam getPermission = new GetPermissionParam();
            getPermission.setPermissionName(getAclPermissionName(resourceDO.getName()));
            if (aclPermissionService.getPermissionByName(getPermission) != null) {

                UpdatePermissionParam updatePermissionParam = createUpdatePermisionParam(resourceDO, userId);
                aclPermissionService.updatePermission(updatePermissionParam);

                logger.info("update permission:" + updatePermissionParam.getName());
            } else {
                CreatePermissionParam createPermissionParam = createPermisionParam(resourceDO, userId);
                aclPermissionService.createPermission(createPermissionParam);
                logger.info("Create permission:" + createPermissionParam.getName());
            }
        } catch (BucException e) {
            logger.error("Error occurs when query or create permission with name:" + resourceDO.getName(), e);
        }


    }


    public AddPermissionsToRoleParam createRolePermisionParam(RoleDO roleDO) {

        AddPermissionsToRoleParam roleParam = new AddPermissionsToRoleParam();
        roleParam.setAppName("ateye");
        roleParam.setRoleName(roleDO.getName());
        roleParam.setApplyUserId(Integer.parseInt(getAteyeActUserId()));
        roleParam.setPrincipalUserId(Integer.parseInt(getAteyeActUserId()));
        List<ResourceDO> resourceRoleList = ateyeResourceService.getResourcesByRoleId(roleDO.getId());

        List<String> permissionNames = Lists.transform(resourceRoleList, new Function<ResourceDO, String>() {
            @Nullable
            @Override
            public String apply(ResourceDO input) {
                return getAclPermissionName(((ResourceDO) input).getName());
            }
        });

        roleParam.setPermissionNames(permissionNames);

        //roleParam.setApplyUserId();
        //roleParam.setFlow();
        //roleParam.setPrincipalUserId();

        return roleParam;
    }

    public UpdateRoleParam createUpdateRoleParam(final RoleDO role, final String userId) {
        UpdateRoleParam roleParam = new UpdateRoleParam();
        roleParam.setAppName("ateye");
        roleParam.setUserId(Integer.parseInt(getAteyeActUserId()));
        roleParam.setName(role.getName());
        roleParam.setTitle(role.getDescription());
        roleParam.setApproverUserIds(getAteyeAclOwnerIds());
        roleParam.setCreatorUserId(userId);
        roleParam.setOwnerUserId(userId);
        return roleParam;
    }


    public CreateRoleParam createRoleParam(final RoleDO role, final String userId) {
        CreateRoleParam roleParam = new CreateRoleParam();
        roleParam.setAppName("ateye");
        roleParam.setUserId(Integer.parseInt(getAteyeActUserId()));
        roleParam.setName(role.getName());
        roleParam.setTitle(role.getDescription());
        roleParam.setApproverUserIds(getAteyeAclOwnerIds());
        roleParam.setCreatorUserId(userId);
        roleParam.setOwnerUserId(userId);
        return roleParam;
    }

    // ����Ȩ�޽��з���, Permission(path)
    public CreatePermissionParam createPermisionParam(final ResourceDO resourceDO, String userId) {

        CreatePermissionParam permissionParam = new CreatePermissionParam();

        // ����param
        permissionParam.setAppName("ateye");
        permissionParam.setName(getAclPermissionName(resourceDO.getName()));
        permissionParam.setTitle("ateye_" + resourceDO.getName());
        permissionParam.setDescription("ateye_" + resourceDO.getName());
        permissionParam.setInfo("ateye_" + resourceDO.getName());
        permissionParam.setUserId(getAteyeActUserId());

        if (isSysAdminPermission(resourceDO.getName())) {
            permissionParam.setRiskLevel(RiskLevel.H);
            permissionParam.setFeature("ϵͳ����");
            permissionParam.setPath(resourceDO.getPath());
        } else {
            permissionParam.setRiskLevel(RiskLevel.M);
            permissionParam.setFeature("Ӧ��ά��");
            permissionParam.setPath(resourceDO.getPath());
        }
        permissionParam.setOwnerUserId(userId);

        permissionParam.setAnonymous(false);
        permissionParam.setActive(true);
        permissionParam.setCreatorUserId(userId);
        permissionParam.setApproverUserIds(getAteyeAclOwnerIds());

        //permissionParam.setOrgIds(ownerUserIds);
        //permissionParam.setRiskThreshold("�������ͨ����7�챻��˲�ͨ��");

        return permissionParam;
    }


    // ����Ȩ�޽��з���, Permission(path)
    public UpdatePermissionParam createUpdatePermisionParam(final ResourceDO resourceDO, String userId) {

        UpdatePermissionParam permissionParam = new UpdatePermissionParam();

        // ����param
        permissionParam.setAppName("ateye");
        permissionParam.setName(getAclPermissionName(resourceDO.getName()));
        permissionParam.setTitle("ateye_" + resourceDO.getName());
        permissionParam.setDescription("ateye_" + resourceDO.getName());
        permissionParam.setInfo("ateye_" + resourceDO.getName());
        permissionParam.setUserId(getAteyeActUserId());

        if (isSysAdminPermission(resourceDO.getName())) {
            permissionParam.setRiskLevel(RiskLevel.H);
            permissionParam.setFeature("ϵͳ����");
            permissionParam.setPath(resourceDO.getPath());
        } else {
            permissionParam.setRiskLevel(RiskLevel.M);
            permissionParam.setFeature("Ӧ��ά��");
            permissionParam.setPath(resourceDO.getPath());
        }
        permissionParam.setOwnerUserId(userId);

        permissionParam.setAnonymous(false);
        permissionParam.setActive(true);
        permissionParam.setCreatorUserId(userId);
        permissionParam.setApproverUserIds(getAteyeAclOwnerIds());


        return permissionParam;
    }

    private String getAclPermissionName(String resourceName) {

        ResourceDO resourceDO = ateyeResourceService.getResourceByName(resourceName);

        String resourceEnName = resourceDO.getPath().replace("/", "").replace("*", "");
        resourceEnName = resourceEnName.isEmpty() ? "all" : resourceEnName;
        return "acl_ateye_" + resourceEnName;
    }


    public GrantRolesToUserParam createGrantRolesToUserParam(String userNick, List<String> roleNames) {
        GrantRolesToUserParam rolePermission = new GrantRolesToUserParam();

        //rolePermission.setPrincipalUserId();
        rolePermission.setAppName("ateye");

        rolePermission.setRoleNames(roleNames);


        try {
            rolePermission.setUserId(enhancedUserQueryService.getUserByNickNameCn(userNick).getId());
        } catch (Throwable e) {
            logger.error("Error occurs when grant acl role to user:" + userNick, e);
        }
        rolePermission.setPrincipalUserId(Integer.parseInt(getAteyeActUserId()));
        rolePermission.setAction(Action.Grant);

        return rolePermission;
    }


    public String getAteyeActUserId() {
        return environmentService.isDaily() ? USERID_DAILY : USERID_PRODUCTION;
    }


    public boolean isSysAdminPermission(String resoureName) {
        for (String resource : AclSyncUtil.sysAdminResource)
            if (resource.equals(resoureName))
                return true;

        return false;
    }


    public List<String> getAteyeAclOwnerIds() {
        return environmentService.isDaily() ? ownedUserIdsDaily : ownedUserIdsProd;
    }

}
