package com.taobao.ateye.controller.alarm.data;

import com.taobao.ateye.dataobject.AlarmConfPersonalizedDO;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;

/**
 * Created by sunqiang on 2019/1/28.
 */
public class AlarmPersonalized {
    private AlarmConfPersonalizedDO personalizedDO;
    private AteyeAlarmRecordDO recordDO;
    private AteyeAlarmConfDO confDO;
    private AteyeAlarmSubscriberDO subscriberDO;

    public AteyeAlarmSubscriberDO getSubscriberDO() {
        return subscriberDO;
    }

    public void setSubscriberDO(AteyeAlarmSubscriberDO subscriberDO) {
        this.subscriberDO = subscriberDO;
    }

    public AlarmConfPersonalizedDO getPersonalizedDO() {
        return personalizedDO;
    }

    public void setPersonalizedDO(AlarmConfPersonalizedDO personalizedDO) {
        this.personalizedDO = personalizedDO;
    }

    public AteyeAlarmRecordDO getRecordDO() {
        return recordDO;
    }

    public void setRecordDO(AteyeAlarmRecordDO recordDO) {
        this.recordDO = recordDO;
    }

    public AteyeAlarmConfDO getConfDO() {
        return confDO;
    }

    public void setConfDO(AteyeAlarmConfDO confDO) {
        this.confDO = confDO;
    }
}
