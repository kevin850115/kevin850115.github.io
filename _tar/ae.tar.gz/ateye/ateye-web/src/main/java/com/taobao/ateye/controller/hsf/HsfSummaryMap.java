package com.taobao.ateye.controller.hsf;

import java.util.HashMap;

public class HsfSummaryMap extends HashMap<String,HsfSummaryDO>{
	private static final long serialVersionUID = -2735458960685839188L;
	private HsfSummaryDO newHsfSummaryDO(String key){
		HsfSummaryDO hsfSummaryDO = get(key);
		if ( hsfSummaryDO == null ){
			hsfSummaryDO = new HsfSummaryDO();
			put(key,hsfSummaryDO);
		}
		return hsfSummaryDO;
	}
	public void addServiceInvokeCount(String key,String service,long count){
		newHsfSummaryDO(key).addServiceInvokeCount(service, count);
	}
	public void addMethodInvokeCount(String key,String service,long count){
		newHsfSummaryDO(key).addMethodInvokeCount(service, count);
	}
	public void addTotalInvokeCount(String key,long totalInvokeCount) {
		newHsfSummaryDO(key).addTotalInvokeCount(totalInvokeCount);
	}
}
