package com.taobao.ateye.controller.cron;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SchedulerDO {
	private String schedulerName;
	private Boolean started;
	private List<TriggerDO> triggerInfoList;
	private Map<String,TriggerDO> triggerInfoMap = new HashMap<String,TriggerDO>();;
	public String getSchedulerName() {
		return schedulerName;
	}
	public void setSchedulerName(String schedulerName) {
		this.schedulerName = schedulerName;
	}
	public Boolean getStarted() {
		return started;
	}
	public void setStarted(Boolean started) {
		this.started = started;
	}
	public List<TriggerDO> getTriggerInfoList() {
		return triggerInfoList;
	}
	public void setTriggerInfoList(List<TriggerDO> triggerInfoList) {
		this.triggerInfoList = triggerInfoList;
		setTriggerInfoMap(new HashMap<String,TriggerDO>());
		for ( TriggerDO td:triggerInfoList ){
			getTriggerInfoMap().put(td.getTriggerName(), td);
		}
	}
	public void setTriggerInfoMap(Map<String,TriggerDO> triggerInfoMap) {
		this.triggerInfoMap = triggerInfoMap;
	}
	public Map<String,TriggerDO> getTriggerInfoMap() {
		return triggerInfoMap;
	} 
}
