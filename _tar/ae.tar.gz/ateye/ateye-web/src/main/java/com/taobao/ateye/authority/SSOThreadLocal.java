package com.taobao.ateye.authority;

import com.alibaba.platform.buc.sso.common.dto.SimpleSSOUser;

public class SSOThreadLocal {
	
	private static final ThreadLocal<SimpleSSOUser> tl = new ThreadLocal<SimpleSSOUser>();
	
	public static void set(SimpleSSOUser value){
		tl.set(value);
	}
	
	public static SimpleSSOUser get(){
		return tl.get();
	}
	
	public static void remove(){
		tl.remove();
	}
}
