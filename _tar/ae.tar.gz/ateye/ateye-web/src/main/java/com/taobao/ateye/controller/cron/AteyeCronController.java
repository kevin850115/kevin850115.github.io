package com.taobao.ateye.controller.cron;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.cron.AppCronManager;
import com.taobao.ateye.cron.AppCronManager.AppCronJsonDO;
import com.taobao.ateye.cron.AppCronManager.RunningAppCronJsonDO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.UserAuditDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.operate.OperateLogger;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.service.UserAuditService;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;

@Controller
@RequestMapping("/appcron")
public class AteyeCronController extends AbstractController {

	private static final Logger logger = Logger.getLogger("QuartzLogger");

	@Autowired
	private OpsServic opsServic;
	@Autowired
	AppCronManager appCronManager;
	@Autowired
	OperateLogger operateLogger;
	@Autowired
	private UserAuditService userAuditService;
	@Autowired
	private UrlGenerator urlGenerator;

    @RequestMapping("selectApp2.htm")
    public String selectApp2(final HttpServletRequest request, ModelMap result) throws DAOException
    {
        //����ҵ���ߵķ���
    	result.put("to", "/appcron/appcronlist2.htm");
    	result.put("level2","ʱ��������");
    	result.put("level2Url","/appcron/selectApp2.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
    } 
	@RequestMapping("appcronlist2.htm")
	public final String viewList2(@RequestParam(value = "app", required = false) String appName,
			final HttpServletRequest request, final ModelMap result) throws Exception {
		return _viewList(appName, request, result, "screen/cron/appCronList2");
	}
	private final String _viewList(@RequestParam(value = "appName", required = false) String appName,
			final HttpServletRequest request, final ModelMap result,String page) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		List<AppDO> appDOList = opsServic.getAllAppsBelongToAUser(user.getId());
		result.put("apps", appDOList);
		if (StringUtils.isNotBlank(appName)) {
			List<MachineDO> machineList = opsServic.getAllMachinesBelongToAnApp(appName);
			if(machineList != null && machineList.size() > 0){
				result.put("machines", machineList);
				result.put("appName", appName);
			}
		}
		return page;
	}

	@RequestMapping("appcronview2.htm")
	public final String viewCron2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		return _viewCron(appName, dns_ip, request, result,"screen/cron/appCronView_new2");
	}
	private final String _viewCron(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			final HttpServletRequest request, final ModelMap result,String page)
			throws Exception {
		try {
			JSONArray _objs = appCronManager.getAllCronsFromServer(dns_ip);
			if (_objs == null || _objs.isEmpty()) {
				result.put("error", "��ȡʱ�����ʧ��");
				return viewList2(appName, request, result);
			}
			Map<String, AppCronJsonDO> crons = AppCronManager.stripAllCrons(_objs);
			List<RunningAppCronJsonDO> runnings = AppCronManager.stripRunningCrons(_objs);
			//����һ��Map���ڴ洢ÿ��schedule��trigger�ĸ���
			Map<String,Integer> keyValue=new HashMap<String,Integer>();
			for(String key:crons.keySet()){
				String[] subKeys=key.split("\\.");
				Integer count=keyValue.get(subKeys[0]);
				if(count==null)
					keyValue.put(subKeys[0], 1);
				else
					keyValue.put(subKeys[0], ++count);

			}
			result.put("crons", crons);
			result.put("runnings", runnings);
			result.put("keyValue", keyValue);
			boolean supportNewQuartzProtocol = appCronManager.supportNewQuartzProtocol(dns_ip);
			//��ȡ�־û���ֵ����
			Map<String, SchedulerDO> pData = getSchedulerPersistDataOfAMachine(dns_ip);
			result.put("pData", pData);
			if(supportNewQuartzProtocol){
				return page;
			}else{
				return "screen/cron/appCronView";
			}
		} catch(Exception e) {
			logger.error("��ȡScheduler�����쳣", e);
			//���ϲ��׳��쳣
			throw new RuntimeException(e);
		}
	}
	@RequestMapping("removePersist.htm")
	public String removeSchedulerPersistData(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws Exception {
		String ip = request.getParameter("ip");
		String appName = request.getParameter("appName");
		MachineDO machine = machineDAO.getMachineByIp(ip);
		String schedulerName = request.getParameter("schedulerName");
		Map<String, String> params = new HashMap<String, String>();
		params.put("type", "QUARTZ");
		params.put("action", "removePersistInfo");
		params.put("schedulerName", schedulerName);
		String url = urlGenerator.getUrl(machine.getIp(), machine.getPort()
				+ "", params);
		String removeStatus = HttpClientUtil.getResult(url);
		if (removeStatus != null && removeStatus.startsWith("OK")) {
			params.put("action", "getPersistInfo");
			url = urlGenerator.getUrl(machine.getIp(), machine.getPort() + "",
					params);
			HttpClientUtil.getResult(url);
		}
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+ip;
	}
	public static void main(String[] args) {
		String b = "{\"timeTaskScheduler\":{\"schedulerName\":\"timeTaskScheduler\",\"started\":false,\"triggerInfoList\":[{\"cronExpression\":\"0 0 0 * * ?\",\"started\":false,\"triggerGroup\":\"DEFAULT\",\"triggerName\":         \"opsFileProcessTrigger\"},{\"cronExpression\":\"0 40 10 ? * MON-FRI\",\"started\":true,\"triggerGroup\":\"DEFAULT\",\"triggerName\":\"dingcanTaskTrigger\"},{\"cronExpression\":\"0 0 12 * * ?\",\"started\":true,\"triggerGroup\":\"DEFAULT\",\"triggerName\":\"sendEmailProcessTrigger\"}]}}";
	}
	private Map<String,SchedulerDO> getSchedulerPersistDataOfAMachine(String ip) throws Exception {
		MachineDO machine = machineDAO.getMachineByIp(ip);
		Map<String, String> params = new HashMap<String, String>();
		params.put("type", "QUARTZ");
		params.put("action", "getPersistInfo");
		String url = urlGenerator.getUrl(machine.getIp(), machine.getPort()
				+ "", params);
		String json = HttpClientUtil.getResult(url);
		Map<String,SchedulerDO> ret = new HashMap<String,SchedulerDO>();
		if (json != null && !json.startsWith("Error")) {
			JSONObject obj = JSON.parseObject(json);
			for(String k:obj.keySet() ){
				Object object = obj.get(k);
				SchedulerDO pdo = JSON.parseObject(object.toString(),SchedulerDO.class);
				ret.put(k,pdo);
			}
		}
		return ret;
	}
	@RequestMapping("apptriggercron2.htm")
	public final String triggerCron2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("group") String group,
			@RequestParam("trigger") String trigger,
			@RequestParam("fname") String fname,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.triggerCron(dns_ip, group, trigger,fname);
		   /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,trigger,"triggerCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	
	@RequestMapping("apppausecron2.htm")
	public final String pauseCron2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("group") String group,
			@RequestParam("trigger") String trigger,
			@RequestParam("fname") String fname,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.pauseCron(dns_ip, group, trigger,fname);
		   /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,trigger,"pauseCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	@RequestMapping("appresumecron2.htm")
	public final String resumeCron2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("group") String group,
			@RequestParam("trigger") String trigger,
			@RequestParam("fname") String fname,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.resumeCron(dns_ip, group, trigger,fname);
		 /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,trigger,"resumeCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	@RequestMapping("appsetnewCronexp2.htm")
    public final String setNewCronExp2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip, @RequestParam("group") String group,
            @RequestParam("trigger") String trigger, @RequestParam("newCronExp") String newCronExp,
            @RequestParam("fname") String fname,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.setNewCronExp(dns_ip, group, trigger, newCronExp,fname);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,trigger,"newCronExp:"+newCronExp+","+rs);
		userAuditService.addUserAuditLog(userAuditDO);
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
	
	@RequestMapping("appPersist2.htm")
    public final String persist2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip, @RequestParam("group") String group,
            @RequestParam("trigger") String trigger,
            @RequestParam("fname") String fname,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.setPersist(dns_ip, group, trigger,fname);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,trigger,"PersistCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
	@RequestMapping("appstartScheduler2.htm")
    public final String startScheduler2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
            @RequestParam("fname") String fname,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.startScheduler(dns_ip,fname);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,"","startScheduler:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
	@RequestMapping("appstopScheduler2.htm")
    public final String stopScheduler2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
            @RequestParam("fname") String fname,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.stopScheduler(dns_ip,fname);
        
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,fname,"","stopScheduler:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }

	@RequestMapping("invokeTrigger2.htm")
	public final String invokeTrigger_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("schedulerName") String schedulerName,
			@RequestParam("triggerGroup") String triggerGroup,
			@RequestParam("triggerName") String triggerName,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.invokeTrigger_new(dns_ip, schedulerName, triggerGroup, triggerName);
		   /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,triggerName,"triggerCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	@RequestMapping("stopTrigger2.htm")
	public final String stopTrigger_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("schedulerName") String schedulerName,
			@RequestParam("triggerGroup") String triggerGroup,
			@RequestParam("triggerName") String triggerName,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.stopTrigger_new(dns_ip, schedulerName, triggerGroup, triggerName);
		   /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,triggerName,"pauseCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	@RequestMapping("startTrigger2.htm")
	public final String startTrigger_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("schedulerName") String schedulerName,
			@RequestParam("triggerGroup") String triggerGroup,
			@RequestParam("triggerName") String triggerName,
			final HttpServletRequest request, final ModelMap result)
			throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
		String rs = appCronManager.startTrigger_new(dns_ip, schedulerName, triggerGroup, triggerName);
		 /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,triggerName,"resumeCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

	}
	@RequestMapping("updateCronExpression2.htm")
    public final String setCronExpression_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip
			, @RequestParam("schedulerName") String schedulerName, @RequestParam("triggerGroup") String triggerGroup,
            @RequestParam("triggerName") String triggerName, @RequestParam("newCronExpression") String newCronExpression,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.setCronExpression_new(dns_ip, schedulerName, triggerGroup, triggerName, newCronExpression);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,triggerName,"newCronExp:"+newCronExpression+","+rs);
		userAuditService.addUserAuditLog(userAuditDO);
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
	@RequestMapping("persist2.htm")
    public final String persist_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
            @RequestParam("schedulerName") String schedulerName,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.persist_new(dns_ip, schedulerName);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,"","PersistCron:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
	@RequestMapping("startScheduler2.htm")
    public final String startScheduler_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
            @RequestParam("schedulerName") String schedulerName,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.startScheduler_new(dns_ip,schedulerName);
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick(),appName,dns_ip,UserAuditDO.SCHEDULE,schedulerName,"","startScheduler:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }	
	@RequestMapping("stopScheduler2.htm")
    public final String stopScheduler_new2(@RequestParam("appName") String appName,
			@RequestParam("dns_ip") String dns_ip,
			@RequestParam("schedulerName") String schedulerName,
            final HttpServletRequest request, final ModelMap result) throws Exception {
		UserDO user = (UserDO) MyThreadLocal.get();
		if (user == null) {
			return "redirect:/noPermission.htm";
		}
        String rs = appCronManager.stopScheduler_new(dns_ip, schedulerName);
        
        /**
		 * ���� �����û������Ϣ
		 */
		UserAuditDO userAuditDO = new UserAuditDO(user.getNick() ,appName, dns_ip, UserAuditDO.SCHEDULE, schedulerName, "", "stopScheduler:"+rs);
		userAuditService.addUserAuditLog(userAuditDO);
		
        result.put("info", rs);
		return "redirect:/appcron/appcronview2.htm?appName="+appName+"&dns_ip="+dns_ip;

    }
}
