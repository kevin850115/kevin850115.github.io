package com.taobao.ateye.controller.monitor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;

import javax.servlet.http.HttpServletRequest;

import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.tracker.ext.*;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.dubbo.common.json.JSON;
import com.google.common.collect.Maps;
import com.taobao.ateye.alarm.config.RuleTypeConstant;
import com.taobao.ateye.alarm.manager.AlarmGroupManager;
import com.taobao.ateye.alarm.manager.AlarmRuleManager;
import com.taobao.ateye.alarm.n.data.AlarmNewRuleVO;
import com.taobao.ateye.alarm.n.manager.AlarmSwitchManager;
import com.taobao.ateye.base.EnvIdType;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.config.blacklist.ErrorLogMd5BlackListManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.error.ErrorManager;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.hsf.monitor.HsfMonitorType;
import com.taobao.ateye.monitor.MonitorItemDO;
import com.taobao.ateye.monitor.TimePeriodUtils;
import com.taobao.ateye.scene.SceneContants;
import com.taobao.ateye.scene.common.StackInfo;
import com.taobao.ateye.scene.common.StackInfoUtil;
import com.taobao.ateye.util.ColorUtil;
import com.taobao.ateye.util.DescUtils;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;
import com.taobao.tracker.except.ExceptionTypeConstant;
import com.taobao.tracker.generalerror.domain.GeneralErrorDO;
import com.taobao.tracker.generalerror.domain.GeneralErrorDetailDO;
import com.taobao.tracker.generalerror.domain.TimePeriodEnum;
import com.taobao.tracker.generalerror.service.GeneralErrorLogSearchService;
import com.taobao.tracker.hbase.AlarmRuleDO;
import com.taobao.tracker.hbase.view.AlarmGroupDO;
import com.taobao.tracker.service.monitor.MonitorLogNode;
import com.taobao.tracker.service.monitor.MonitorLogQueryService;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/monitor")
public class GeneralMonitor extends AbstractController{

	private static final String OVERVIEW = "screen/monitor/overview";
	private static final String DETAIL = "screen/monitor/detail";
	private static final String TYPE_OVERVIEW = "screen/monitor/type_overview";
	private static final String EXCEPT_LIST = "screen/monitor/except_list";
	private static final String MEM_WATCH = "screen/monitor/mem_watch";
	private static final String EXCEPT_INFO = "screen/monitor/except_info";
	private static final String HSF_EXCEPT_INFO = "screen/monitor/hsf_except_info";

	public static Integer CMP_BY_TIMES=0;
	public static Integer CMP_BY_RT=1;
	public static Integer CMP_BY_RATE=3;
	public static Map<HsfMonitorType,Integer> cmpMethodMap = new HashMap<HsfMonitorType,Integer>();

	static {
		cmpMethodMap.put(HsfMonitorType.CONSUMER_EXCEPTION, CMP_BY_TIMES);
		cmpMethodMap.put(HsfMonitorType.CONSUMER_RT, CMP_BY_RT);
		cmpMethodMap.put(HsfMonitorType.CONSUMER_TIMES, CMP_BY_TIMES);
		cmpMethodMap.put(HsfMonitorType.CONSUMER_TIMEOUT, CMP_BY_TIMES);
		cmpMethodMap.put(HsfMonitorType.PROVIDER_RT, CMP_BY_RT);
		cmpMethodMap.put(HsfMonitorType.PROVIDER_TIMES, CMP_BY_TIMES);
		cmpMethodMap.put(HsfMonitorType.PROVIDER_EXCEPTION, CMP_BY_TIMES);
	}
		
	@Autowired
	private UrlGenerator  urlGenerator;	
	@Autowired
	private GeneralErrorLogSearchService generalErrorLogSearchService;
	@Autowired
	private ErrorLogMd5BlackListManager errorLogMd5BlackListManager;
	@Autowired
	private MonitorLogQueryService monitorLogQueryService;
	@Autowired
	private AlarmRuleManager alarmRuleManager;
	@Autowired
	private ErrorManager errorManager;
	@Autowired
	private AlarmGroupManager alarmGroupManager;

	@Autowired
	private AlarmSwitchManager alarmSwitchManager;

	@Autowired
	private GeneralExExtendManager generalExExtendManager;

	@Autowired
	private AteyeConfig ateyeConfig;

	private void fillAllQueryTypes(List<String> queryTypes){
		queryTypes.add("error");
		queryTypes.add("exception");
		/*
		for ( HsfMonitorType type:HsfMonitorType.values() ){
			queryTypes.add(type.name());
		}
		*/
	}
	@RequestMapping("memwatchList.htm")
	public String hsfMonitorLogList(final HttpServletRequest request, ModelMap result) throws Exception {
    	result.put("to", "/monitor/memwatch.htm");
    	result.put("level2","�������");
    	result.put("level2Url","/memwatch.htm/memwatchList.htm");
        if ( initBizMapOwned(result) == null ){
			return "redirect:/noPermission.htm";
        }
        return "screen/common/commonSelectApp";
	}
	
	@RequestMapping("memwatch.htm")
    public String memWatch(final HttpServletRequest request, ModelMap result) throws DAOException {
		String app=request.getParameter("app");
		result.put("app", app);
		String serverId =request.getParameter("id");
		String type =request.getParameter("type");
		AppDO appDO = appDAO.getAppByName(app);
		if ( appDO == null ){
			return MEM_WATCH;
		}
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appDO.getId()	, environmentService.getEnvironmentType().ordinal());
		result.put("servers",machines);
		if ( StringUtils.isBlank(serverId) ){
			return MEM_WATCH;
		}
		MachineDO m = machineDAO.getMachineByid(Long.valueOf(serverId));
		
		Map<String, MemWatchDO> qResults = getMemoryStat(m,"quicklist");
		result.put("qResults",qResults);
		if ( type != null && type.equals("real") ){
			//�ճ�������ʵʱ��Ԥ��ͬʱִ��
			Map<String, MemWatchDO> results = getMemoryStat(m,"list");
			result.put("results",results);
		}
		return MEM_WATCH;
	}
	private Map<String, MemWatchDO> getMemoryStat(MachineDO m,String action) {
		Map<String,MemWatchDO> results = new HashMap<String,MemWatchDO>();
    	Map<String,String> params=new HashMap<String,String>();
    	params.put("type", "MEMWATCH");
    	params.put("action", action);
    	String url="";
		try {
			url = urlGenerator.getUrl(m.getIp(),String.valueOf(m.getPort()), params);
		} catch (Exception e1) {
			log.error("��ȡUrlʧ��",e1);
		}
		try {
			String json=HttpClientUtil.getResult(url);
			if ( json == null || json.length() == 0 || json.equals("null") ){
				return results;
			}
			Map<String,Map<String,Map<String,Long>>> watch = new HashMap<String,Map<String,Map<String,Long>>>();
			watch = JSON.parse(json, watch.getClass());
			results.put(m.getIp(), new MemWatchDO(watch));
		} catch (Exception e) {
			log.error("��ȡ�ڴ�����ʧ��",e);
			return results;
		}
		return results;
	}
	public static class MemWatchDO{
		
		public String getTotalBytes(){
			Long total = 0l;
			for ( Map<String,MemWatchDODetail> ent:map.values() ){
				for ( MemWatchDODetail dd:ent.values() ){
					total += dd.getTotal();
				}
			}
			return DescUtils.descBytes(total);
		}
		
		public MemWatchDO(Map<String,Map<String,Map<String,Long>>> m){
			for ( String k1:m.keySet() ){
				HashMap<String, MemWatchDODetail> mm1 = new HashMap<String,MemWatchDODetail>();
				for ( String k2:m.get(k1).keySet() ){
					Map<String, Long> mm = m.get(k1).get(k2);
					if ( mm == null || mm.size() == 0 ){
						continue;
					}
					MemWatchDODetail d = new MemWatchDODetail();
					Long ave = mm.get("ave");
					if ( ave != null ){
						d.setAve(ave);
					}
					Long total = mm.get("total");
					if ( total != null ){
						d.setTotal(total);
					}
					Long size = mm.get("size");
					if ( size != null ){
						d.setSize(size);
					}
					mm1.put(k2, d);
				}
				map.put(k1, mm1);
			}
		}
		
		private Map<String,Map<String,MemWatchDODetail>> map = new HashMap<String,Map<String,MemWatchDODetail>>();

		public void setMap(Map<String,Map<String,MemWatchDODetail>> map) {
			this.map = map;
		}

		public Map<String,Map<String,MemWatchDODetail>> getMap() {
			return map;
		}
	}
	public static class MemWatchDODetail{
		private long total;
		private long size;
		private long ave;
		public void setTotal(long total) {
			this.total = total;
		}
		public long getTotal() {
			return total;
		}
		public String getTotalStr() {
			return DescUtils.descBytes(total);
		}
		public void setSize(long size) {
			this.size = size;
		}
		public long getSize() {
			return size;
		}
		public void setAve(long ave) {
			this.ave = ave;
		}
		public long getAve() {
			return ave;
		}
		public String getAveStr() {
			return DescUtils.descBytes(ave);
		}
		
	}

	@RequestMapping("exceptionList.htm")
    public String exceptionList(final HttpServletRequest request, ModelMap result) throws Exception {
		String alarm = request.getParameter("alarm");
		String tab = request.getParameter("tab");
		if ( StringUtils.isNotBlank(alarm) ){
			result.put("selectedTab","f_alarm");
		}else{
			if ( StringUtils.isNotBlank(tab) && tab.equals("hour")){
				result.put("selectedTab","f_hour");
			}else{
				result.put("selectedTab","f_min");
			}
		}
		//1.��ȡ����
		String app= request.getParameter("app");
		if ( StringUtils.isEmpty(app) ){
			 //����ҵ���ߵķ���
	    	result.put("to", "/monitor/exceptionList.htm");
	    	result.put("level2","[����]ʵʱ�쳣");
	    	result.put("level2Url","/monitor/exceptionList.htm");
	        if ( initBizMapOwned(result) == null ){
				return "redirect:/noPermission.htm";
	        }
	        return "screen/common/commonSelectApp";
		}
		String realApp = GeneralExExtendManager.stripRealApp(app);
		
		String period = request.getParameter("period");
		if ( StringUtils.isBlank(period)){
			period = TimePeriodEnum.ONEM.name();
		}
		TimePeriodEnum periodEnum = TimePeriodEnum.valueOf(period);
		//2.ʱ�䷶Χ
		getTime(request, result, periodEnum);
		//3.����
		Date start = new Date();
		//�ж��Ƿ�beta
		String betaStr= request.getParameter("beta");
		boolean beta = false;
		if(StringUtils.isNotEmpty(betaStr)){
			beta = Boolean.parseBoolean(betaStr);
		}
		//1.��������
		Map<String, Map<String, Long>> showMap = generalErrorLogSearchService.getExceptionTypeStat(app, 
				new Date[]{DateUtils.addMinutes(start, -20),start,},
				TimePeriodEnum.ONEM,beta?EnvIdType.BETA.getEnvId():"");
		result.put("minMap", showMap);
		//2.Сʱ����
		Map<String, Map<String, Long>> hourShowMap = generalErrorLogSearchService.getExceptionTypeStat(app, 
				new Date[]{CalendarUtil.zerolizedTime(start),start},
				TimePeriodEnum.ONEH,beta?EnvIdType.BETA.getEnvId():"");
		result.put("hourMap", hourShowMap);
		//3.������
		Map<String, Map<String, Long>> dayShowMap = generalErrorLogSearchService.getExceptionTypeStat(app, 
				new Date[]{DateUtils.addDays(start, -20),start},
				TimePeriodEnum.ONED,beta?EnvIdType.BETA.getEnvId():"");
		result.put("dayMap", dayShowMap);
		
		Map<String,String> ss = new LinkedHashMap<String,String>();
		ss.putAll(ExceptionTypeConstant.typeMap);
		ss.put(ExceptionTypeConstant.DEFAULT_TYPE,"Default");
		result.put("allTypes",ss);
		result.put("app",app);
		//4.����
		if(alarmSwitchManager.isNew(app)){
			result.put("newAlarm",true);
			List<AlarmNewRuleVO> rules = alarmRuleManager.getNewGlobalAlarmRulesOfType(realApp, RuleTypeConstant.GLOBAL_EXCEPTION_TYPE_INCR);
			if ( rules != null ){
				result.put("rules",rules);
			}
		}else{
			List<AlarmRuleDO> rules = alarmRuleManager.getGlobalAlarmRulesOfType(realApp, RuleTypeConstant.GLOBAL_EXCEPTION_TYPE_INCR);
			if ( rules != null ){
				result.put("rules",rules);
				result.put("ruleObjs", alarmRuleManager.getRuleObj(rules));
			}
		}
		AppDO apps = appDAO.getAppByName(realApp);
		result.put("admins",apps.getAdministrators());
		result.put("returnUrl", super.getWholeUrl(request,"&alarm=1"));
		List<AlarmGroupDO> alarmGroups = alarmGroupManager.getAlarmGroupsByApp(realApp);
		result.put("alarmGrps", alarmGroups);
		boolean isScene = !realApp.equals(app);
		result.put("isScene",isScene);
		if ( isScene ){
			StackInfo si = StackInfoUtil.parseStackInfo(app);
			result.put("sceneStackInfo",si);
		}
		//5.��ȡ����б�
		Map<String, String> flts = new HashMap<String,String>();
		flts.put("app", stripRealAppFromNG(realApp));
		ChangeModelListDO changeList = changeManager.queryChangeList(flts, DateUtils.addHours(new Date(), -3), new Date());
		result.put("changes",changeList.getRetList());
		result.put("changeCnt",changeList.getRetList().size());
		result.put("empIdMap",userCache.getEmpIdMap());

        return EXCEPT_LIST;
    }
	private static String stripRealAppFromNG(String app){
		if ( app.contains(":") ){
			return app.split(":")[0];
		}
		return app;
	}
	@RequestMapping("exceptionInfo.htm")
    public String exceptionInfo(final HttpServletRequest request, ModelMap result) throws DAOException {
		//1.��ȡ����
		String app= request.getParameter("app");
		String period = request.getParameter("period");
		if ( StringUtils.isBlank(period)){
			period = TimePeriodEnum.ONEM.name();
		}
		TimePeriodEnum periodEnum = TimePeriodEnum.valueOf(period);
		String type = request.getParameter("type");
		result.put("period",period);
		
		//2.ʱ�䷶Χ
		Date begin = getTime(request, result, periodEnum);
		result.put("type",type);
		
		//<md5,number>
		Map<String, Long> listMap = generalErrorLogSearchService.getExceptionTypeInfo(app, type, begin, periodEnum);
		if ( listMap.isEmpty() ){
	        return EXCEPT_INFO;
		}
		listMap = GeneralExExtendManager.sortMapByValue(listMap);
		String realApp = GeneralExExtendManager.stripRealApp(app);
		//<md5,desc>
		Map<String,String> descMap = new HashMap<String,String>();
		int maxDetails = 20;
		int count = 0;
		ExContext exContext = new ExContext();
		int parseCount = 0;
		for ( Map.Entry<String, Long> ent:listMap.entrySet() ){
			if ( ++count  > maxDetails ){
				break;
			}
			GeneralErrorDetailDO errorDetail = generalErrorLogSearchService.getErrorDetail(realApp, ent.getKey());
			if ( errorDetail != null ){
				String wholeLine = errorDetail.getWholeLine();
				ExDO exDO = new ExDO();
				exDO.setApp(app);
				exDO.setType(type);
				if(parseCount++ < ateyeConfig.getParseExDetailCountPerTime()){
					generalExExtendManager.processor(wholeLine,exContext,ent.getValue(),exDO);
				}
				descMap.put(ent.getKey(), getAbbrLine(wholeLine));
			}
		}
		//result.put("extendMaps",exContext.getAppMap());

		Map<String,String> ip2Apps = Maps.newHashMap();
		if(exContext.getMethodMap()!=null) {
			for (Map.Entry<String, GeneralExtendInfo> entry : exContext.getMethodMap().entrySet()) {
				if (entry.getValue().getIps2Num() != null) {
					for (Map.Entry<String, Long> ip2Num : entry.getValue().getIps2Num().entrySet()) {
						MachineDO machineDO = machineDAO.getMachineByIp(ip2Num.getKey());
						if (machineDO != null) {
							AppDO appDO = appDAO.getAppById(machineDO.getAppId());
							if (appDO != null) {
								ip2Apps.put(ip2Num.getKey(), appDO.getAppName());
							} else {
								ip2Apps.put(ip2Num.getKey(), "unknow");
							}
						} else {
							ip2Apps.put(ip2Num.getKey(), "unknow");
						}
					}
				}
			}
		}
		result.put("ip2Apps",ip2Apps);
//                MachineDO machineDO = machineDAO.getMachineByIp(ip);
//                if(machineDO != null){
//                    AppDO appDO = appDAO.getAppById(machineDO.getAppId());
//                    if (appDO != null) {
//                        appName=appDO.getAppName();
//                    }
//                }
//                if(!exContext.getAppMap().containsKey(appName)){
//                    exContext.getAppMap().put(appName,new GeneralExtendInfo());
//                }
//                exContext.getAppMap().get(appName).add(ip,times);

		result.put("methodMaps",exContext.getMethodMap());
		result.put("labelInfo",GeneralExExtendManager.label(type));
		result.put("exceptions",listMap);
		result.put("details",descMap);
		result.put("app",app);
		result.put("realApp",realApp);
		boolean isScene = !realApp.equals(app);
		result.put("isScene",isScene);
		if ( isScene ){
			StackInfo si = StackInfoUtil.parseStackInfo(app);
			result.put("sceneStackInfo",si);
		}
		
        return EXCEPT_INFO;
    }
	@RequestMapping("hsfExceptionInfo.htm")
    public String hsfExceptionInfo(final HttpServletRequest request, ModelMap result) {
		//1.��ȡ����
		String app= request.getParameter("app");
		result.put("app",app);
		String period = request.getParameter("period");
		if ( StringUtils.isBlank(period)){
			period = TimePeriodEnum.ONEM.name();
		}
		TimePeriodEnum periodEnum = TimePeriodEnum.valueOf(period);
		result.put("period",period);
		String service = request.getParameter("service");
		String method = request.getParameter("method");
		if ( StringUtils.isBlank(service) || StringUtils.isBlank(method) ){
			return HSF_EXCEPT_INFO;
		}
		//1.1.��method����Ĳ���ȥ��
		//����query~G --> query
		String methodPrefix="";
		int startPos = method.indexOf("~");
		if ( startPos != -1 ){
			methodPrefix = method.substring(0,startPos);
			result.put("methodPrefix", methodPrefix);
		}
		result.put("service",service);
		result.put("method", method);
		String type = request.getParameter("type");

		//2.ȷ��ʱ�䷶Χ����ȡͳ������
		Pair<Date, Date> timeRange = getTimeRange(request,result,periodEnum);
		Map<String,Map<String,Long>> allTypeCountMap = new HashMap<String,Map<String,Long>>();
		//<md5,number>
		queryExceptionInfo(app, period, service, method, timeRange, allTypeCountMap);
		if	( StringUtils.isNotBlank(methodPrefix)  ){
			//2.1.��methodPrefix��ѯһ�Σ��п���hsf.log����־��ķ����ǲ����������͵�
			queryExceptionInfo(app, period, service, methodPrefix, timeRange, allTypeCountMap);
		}
		if ( allTypeCountMap == null || allTypeCountMap.isEmpty() ){
	        return HSF_EXCEPT_INFO;
		}
		//3.����С����
		Map<String,Map<String,Long>> sortedListMap = new HashMap<String,Map<String,Long>>();
		for (String t:allTypeCountMap.keySet() ){
			sortedListMap.put(t, GeneralExExtendManager.sortMapByValue(allTypeCountMap.get(t)));
		}
		//4.�����ͣ�ÿ������ȡn������ֵ��Ϊ��Ʒ <md5,desc>
		Map<String,String> descMap = new HashMap<String,String>();
		for (String t:sortedListMap.keySet()){
			Map<String, Long> listMap = sortedListMap.get(t);
			int maxDetails = 15;
			int count = 0;
			for ( Map.Entry<String, Long> ent:listMap.entrySet() ){
				if ( ++count  > maxDetails ){
					break;
				}
				GeneralErrorDetailDO errorDetail = generalErrorLogSearchService.getErrorDetail(app, ent.getKey());
				if ( errorDetail != null ){
					descMap.put(ent.getKey(), getAbbrLine(errorDetail.getWholeLine()));
				}
			}
		}
		//5.����Ĭ��ѡ�е�Tab
		if ( StringUtils.isBlank(type) || !sortedListMap.keySet().contains(type) ){
			type = sortedListMap.keySet().iterator().next();
		}
		result.put("select_type",type);
		result.put("exceptionMap",sortedListMap);
		result.put("details",descMap);
		result.put("app",app);
		
        return HSF_EXCEPT_INFO;
    }
	private void queryExceptionInfo(String app, String period, String service,
			String method, Pair<Date, Date> timeRange,
			Map<String, Map<String, Long>> allTypeCountMap) {
		if ( period.equals(TimePeriodEnum.ONED.name() ) ){
			Map<String,Map<String,Long>> typeCountMap = generalErrorLogSearchService.getDailyHsfExceptionTypeInfo(app, service, method, timeRange.getLeft());
			if ( !typeCountMap.isEmpty() ){
				allTypeCountMap.putAll(typeCountMap);
			}
		}else if (  period.equals(TimePeriodEnum.ONEM.name() )){
			Map<String,Map<String,Long>> typeCountMap = generalErrorLogSearchService.getMinHsfExceptionTypeInfo(app, service, method, timeRange.getLeft(), timeRange.getRight());
			if ( !typeCountMap.isEmpty() ){
				allTypeCountMap.putAll(typeCountMap);
			}
		}
	}

	private String getAbbrLine(String wholeLine){
		String bb = "";
		String[] split = wholeLine.split("\n");
		int len = split.length>5?5:split.length;
		for ( int i= 0;i<len;++i ){
			split[i] = split[i].replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
			boolean matches = split[i].contains("Exception");
			if ( matches ){
				bb += "<cite><b><big>"+split[i]+"</big></b></cite>";
			}else{
				bb += split[i];
			}
			bb += "<br>";
		}
		bb+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;...........................";
		return bb;
		
	}
	
	private Date getTime(final HttpServletRequest request, ModelMap result,
			TimePeriodEnum periodEnum) {
		String beginTime = request.getParameter("beginTime");

		if(StringUtils.isBlank(beginTime) ){
			beginTime = CalendarUtil.toString(new Date(),"yyyy-MM-dd HH:mm");
		}
		result.put("beginTimeStr", beginTime);
		Date beginTimeStr =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd HH:mm");
		String[] timePeriod = TimePeriodUtils.getTimePeriod(periodEnum, beginTimeStr);
		result.put("beginTime", timePeriod[0].substring(11));
		result.put("endTime", timePeriod[1].substring(11));
		return beginTimeStr;
	}
	private Pair<Date,Date> getTimeRange(final HttpServletRequest request, ModelMap result,
			TimePeriodEnum periodEnum) {
		String beginTime = request.getParameter("beginTime");
		if(StringUtils.isBlank(beginTime) ){
			beginTime = CalendarUtil.toString(new Date(),"yyyy-MM-dd HH:mm");
		}
		Date beginTimeObj =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd HH:mm");
		if ( beginTimeObj == null ){
			beginTimeObj =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd");
		}
		String[] timePeriod = TimePeriodUtils.getTimePeriod(periodEnum, beginTimeObj);
		String endTime = request.getParameter("endTime");
		if(StringUtils.isBlank(endTime) ){
			endTime = timePeriod[1];
		}
		Date endTimeObj =  CalendarUtil.toDate(endTime, "yyyy-MM-dd HH:mm");
		result.put("beginTimeObj", beginTimeObj);
		result.put("endTimeObj", endTimeObj);
		result.put("beginTimeStr", beginTime);
		result.put("endTimeStr", endTime);
		return Pair.of(beginTimeObj, endTimeObj);
	}
    private void  _getViews(final HttpServletRequest request, ModelMap result,List<String> queryTypes,int limit,String[] appNameArray) {
    
		String day = request.getParameter("day");
		String min = request.getParameter("min");
		String beginTime = null;
		String period = request.getParameter("period");
		if ( StringUtils.isBlank(period)){
			period = TimePeriodEnum.ONEH.name();
		}
		
		result.put("appNameArray", appNameArray);
		if(StringUtils.isBlank(day) ){
			beginTime = CalendarUtil.toString(new Date(),"yyyy-MM-dd HH:mm");
		}else{
			beginTime = day + " " + min;
			Date date = CalendarUtil.toDate(beginTime, "yyyy-MM-dd HH:mm");
			if ( date == null ){
				return;
			}
		}
		result.put("beginTimeStr", beginTime);//����ʱ���
		result.put("day",beginTime.substring(0,10));//��
		result.put("min",beginTime.substring(11));//����
		Date beginTimeStr =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd HH:mm");
		TimePeriodEnum periodEnum = TimePeriodEnum.valueOf(period);
		String[] timePeriod = TimePeriodUtils.getTimePeriod(periodEnum, beginTimeStr);
		result.put("beginTime", timePeriod[0]);//ʱ�䷶Χ
		result.put("endTime", timePeriod[1]);//ʱ�䷶Χ
		Date timeStart = CalendarUtil.toDate(timePeriod[0],"yyyy-MM-dd HH:mm");
		
		//4.���ݵ�ǰֵ�ҵ�ǰһ��ʱ����ֵ��������ͬ��
		//<md5,ͳ��ֵ>
		int timeDiff = TimePeriodUtils.getTimePeriodDiffInMinutes(periodEnum);
		Date prevTime = DateUtils.addMinutes(beginTimeStr, -timeDiff);
		if ( queryTypes.contains("error") ){
			List<GeneralErrorDO> errorList = errorManager.getErrorList(appNameArray,
					beginTimeStr,
					periodEnum,
					limit);
			result.put("errorList", errorList);
			Map<String,Long> prevErrorStat = getErrorStat(prevTime, periodEnum, errorList);
			//2.���Ա�
			calculateTrend(errorList, prevErrorStat ,timeStart, timeDiff);
		}
		if ( queryTypes.contains("exception") ){
			List<GeneralErrorDO> exceptionList = errorManager.getExceptionList(appNameArray,
					beginTimeStr,
					periodEnum,
					limit);
			result.put("exceptionList", exceptionList);
			Map<String,Long> prevErrorStat = getErrorStat(prevTime, periodEnum, exceptionList);
			calculateTrend(exceptionList, prevErrorStat,timeStart, timeDiff );
		}
		result.put("period", period);
    }


	@RequestMapping("overview.htm")
    public String overview(final HttpServletRequest request, ModelMap result) throws DAOException {
		String app = request.getParameter("app");
		String appNames = request.getParameter("appNames");
		String biz = request.getParameter("biz");
		if ( StringUtils.isEmpty(app) && StringUtils.isEmpty(appNames) && StringUtils.isEmpty(biz)){
			 //����ҵ���ߵķ���
	    	result.put("to", "/monitor/overview.htm");
	    	result.put("level2","[����]ʵʱ�쳣");
	    	result.put("level2Url","/monitor/overview.htm");
	        if ( initBizMapOwned(result) == null ){
				return "redirect:/noPermission.htm";
	        }
	        return "screen/common/commonSelectApp";
		}
		List<String> queryTypes = new ArrayList<String>();
		fillAllQueryTypes(queryTypes);
		//1.��ȡ����
		if ( StringUtils.isNotBlank(app) ){
			appNames=app;
		}
		//2.ʱ�䷶Χ
		String[] appNameArray = null;
		if ( appNames != null ){
			appNameArray = appNames.split(",");
			result.put("appNames",appNames);
		}
		int size = 10;
		//3.�����biz
		if ( StringUtils.isNotBlank(biz) ){
			List<AppDO> apps = appDAO.queryAppByBizType(biz);
			appNameArray = new String[apps.size()];
			int idx =0;
			for ( AppDO appDO:apps ){
				appNameArray[idx++] = appDO.getAppName();
			}
			result.put("bizName", biz);
			result.put("biz",biz);
			size = 20;
		}
		//4.������ɫ
		ColorUtil.assignColor(result, Arrays.asList(appNameArray), "app");
		Long tic = System.currentTimeMillis();
		_getViews(request, result,queryTypes,size,appNameArray);
		result.put("used",System.currentTimeMillis()-tic);
		
        return OVERVIEW;
    }
	private void calculateTrend(List<GeneralErrorDO> errors,Map<String,Long> prevCounts,Date timeStart,int timeDiff ){
		long timePassedInMs = (new Date()).getTime()-timeStart.getTime();
		float timePercent = (float)timePassedInMs/(timeDiff*60*1000);
		if ( timePercent > 1 ){
			timePercent = 1.0f;
		}
		for ( GeneralErrorDO error:errors ){
			Long prevCount = prevCounts.get(error.getMd5());
			Float prevCountUnify = prevCount*timePercent;
			Long currentCount = error.getCount();
			if ( currentCount > prevCountUnify ){
				error.setDirection(1);
				if ( prevCountUnify.equals(0.0f) ){
					error.setTrend("100");
				}else{
					Float incr = (currentCount-prevCountUnify)/prevCountUnify;
					if ( incr > 100 ){
						incr = 100f;
					}
					error.setTrend(String.format("%.0f",incr*100));
				}
			}else{
				error.setDirection(-1);
				if ( prevCountUnify.equals(0.0f) ){
					error.setTrend("???");
				}else{
					Float decr = (prevCountUnify-currentCount)/prevCountUnify;
					if ( decr > 100 ){
						decr = 100f;
					}
					error.setTrend(String.format("%.0f",decr*100));
				}
			}
		}
	}

	private Map<String,Long> getErrorStat(Date beginTime,TimePeriodEnum period,List<GeneralErrorDO> errors ){
		Map<String,Long> ret = new HashMap<String,Long>();
		/*app->List<md5>*/
		Map<String,List<String>> md5s = new HashMap<String,List<String>>();
		for ( GeneralErrorDO error:errors ){
			if ( !md5s.containsKey(error.getApp()) ){
				md5s.put(error.getApp(), new ArrayList<String>());
			}
			md5s.get(error.getApp()).add(error.getMd5());
		}
		for ( Map.Entry<String, List<String>> ent:md5s.entrySet() ){
			ret.putAll( generalErrorLogSearchService.getErrorStat(ent.getKey(), ent.getValue(), beginTime, period) );
		}
		return ret;
	}
	@RequestMapping("type_overview.htm")
    public String typeOverView(final HttpServletRequest request, ModelMap result) throws NumberFormatException, DAOException {
		String type= request.getParameter("type");
		result.put("type", type);
		List<String> queryTypes = new ArrayList<String>();
		queryTypes.add(type);
		result.put("desc", getTypeDesc(type));
		//1.��ȡ����
		String appNames = request.getParameter("appNames");
		String app = request.getParameter("app");
		if ( StringUtils.isNotBlank(app) ){
			appNames=app;
		}
		String biz = request.getParameter("biz");

		//2.ʱ�䷶Χ
		String[] appNameArray = null;
		if ( appNames != null ){
			appNameArray = appNames.split(",");
			result.put("appNames",appNames);
		}
		int size = 1000;
		//3.�����biz
		if ( StringUtils.isNotBlank(biz) ){
			List<AppDO> apps = appDAO.queryAppByBizType(biz);
			appNameArray = new String[apps.size()];
			int idx =0;
			for ( AppDO appDO:apps ){
				appNameArray[idx++] = appDO.getAppName();
			}
			result.put("bizName", biz);
			result.put("biz",biz);
			size = 200;
		}
		//4.������ɫ
		ColorUtil.assignColor(result, Arrays.asList(appNameArray), "app");
		Long tic = System.currentTimeMillis();
		_getViews(request, result,queryTypes,size,appNameArray);		
		result.put("used",System.currentTimeMillis()-tic);
		
        return TYPE_OVERVIEW;
    }
	private String getTypeDesc(String type) {
		if ( type.equals("error") ){
			return "��־����";
		}else if ( type.equals("exception") ){
			return "��־�쳣Exception";
		}
		return "";
	}

	@RequestMapping("detail.htm")
    public String detail(final HttpServletRequest request, ModelMap result) {
		String appName = request.getParameter("appName");
		String md5 = request.getParameter("md5");
		String endTime = request.getParameter("endDate");
		String beginTime = request.getParameter("beginTime");
		if(StringUtils.isBlank(beginTime) || beginTime.equals("null")){
			beginTime = CalendarUtil.toString(CalendarUtil.zerolizedTime(new Date()),"yyyy-MM-dd HH:mm");
		}
		Date beginTimeStr =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd HH:mm");
		if ( beginTimeStr == null ){
			beginTimeStr =  CalendarUtil.toDate(beginTime, "yyyy-MM-dd");
		}
		Date endTimeStr = null;
		if(StringUtils.isBlank(endTime) || endTime.equals("null")){
			endTimeStr = DateUtils.addDays(beginTimeStr, 1);
		}else{
			endTimeStr =  CalendarUtil.toDate(endTime, "yyyy-MM-dd");
		}
		result.put("bt",CalendarUtil.toString(beginTimeStr, CalendarUtil.DATE_FMT_3));
		result.put("et",CalendarUtil.toString(endTimeStr, CalendarUtil.DATE_FMT_3));
		GeneralErrorDetailDO detail = generalErrorLogSearchService.getErrorDetail(appName, md5);
				
		result.put("appName", appName);
		result.put("md5", md5);
		String groupby = request.getParameter("groupby");
		result.put("groupby", groupby);
		result.put("logContent", formatLog(detail.getLogContent()));
	
    	result.put("returnUrl",super.getWholeUrl(request));
		result.put("blacked",errorLogMd5BlackListManager.isInBlackList(md5));
		
		Map<String, MonitorItemDO> scenes = buildSceneDetail(appName,md5,beginTimeStr);
		if ( scenes != null ){
			result.put("scenes", scenes);
		}
		Map<String, MonitorItemDO> ips = buildIpDetail(appName,md5,beginTimeStr);
		if ( ips != null ){
			result.put("ips", ips);
		}

		result.put("type", detail.getType());
		result.put("detail", detail);
        return DETAIL;
    }
	/*
	 * <����+stack,���ֵ>
	 */
	private Map<String,MonitorItemDO> buildSceneDetail(String appName, String md5,
			Date beginTimeStr) {
		try {
			SortedSet<MonitorLogNode> nodes = monitorLogQueryService.newQueryMonitorLogInfoOfApp("_ERROR_DETAIL_", "#DEFAULT#|"+md5, beginTimeStr, beginTimeStr);
			if (nodes == null || nodes.isEmpty()){
				return null;
			}
			Map<String,MonitorItemDO> ret = new HashMap<String,MonitorItemDO>();
			for ( MonitorLogNode mln:nodes ){
				SortedSet<MonitorLogNode> children = mln.getChildren();
				for (MonitorLogNode cld:children ){
					ret.put(cld.getSelfKey(), new MonitorItemDO(cld,"v2"));
				}
			}
			return ret;
		} catch (Exception e) {
		}
		return null;
	}
	/*
	 * <IP,���ֵ>
	 */
	private Map<String,MonitorItemDO> buildIpDetail(String appName, String md5,
			Date beginTimeStr) {
		try {
			SortedSet<MonitorLogNode> nodes = monitorLogQueryService.newQueryMonitorLogInfoOfApp("_ERROR_DETAIL_", "#DEFAULT#|IP|"+md5, beginTimeStr, beginTimeStr);
			if (nodes == null || nodes.isEmpty()){
				return null;
			}
			Map<String,MonitorItemDO> ret = new HashMap<String,MonitorItemDO>();
			for ( MonitorLogNode mln:nodes ){
				SortedSet<MonitorLogNode> children = mln.getChildren();
				for (MonitorLogNode cld:children ){
					ret.put(cld.getSelfKey(), new MonitorItemDO(cld,"v2"));
				}
			}
			return ret;
		} catch (Exception e) {
		}
		return null;
	}
	private String formatLog(String log){
		//���ж��Ƿ�����쳣��ջ
		if ( !log.contains(" at ") || !log.contains("Exception") ){
			return log;
		}
		return StringUtils.trimToNull(log.replaceAll(" at ", "\n\t at "));
	}
	
	private String[] getTimeRange(int range) {
		String[] timeRange = new String[2];
		GregorianCalendar calender = new GregorianCalendar();
		int minute = calender.get(Calendar.MINUTE);
		int division = minute / range;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		calender.set(Calendar.MINUTE, division * range);
		timeRange[0] = format.format(calender.getTime());
		calender.add(Calendar.MINUTE, range);
		timeRange[1] = format.format(calender.getTime());
		return timeRange;
	}
	public static void main(String[] args) {
		GeneralMonitor gm = new GeneralMonitor();
		System.out.println(gm.getTimeRange(30)[0]);
		System.out.println(gm.getTimeRange(30)[1]);
		String b = gm.formatLog("��ȡtripp act order �쳣 java.lang.reflect.UndeclaredThrowableException: null at $Proxy121.findSubActivityById(Unknown Source) ~[na:na] at com.taobao.ato.order.manager.impl.TrippManagerImpl.getActInfoByOrderId(TrippManagerImpl.java:208) ~[ato-biz-3.0.7-SNAPSHOT.jar:na] at com.taobao.ato.trip.service.impl.TripAtoQueryServiceImpl._commonSingleOrderQuery(TripAtoQueryServiceImpl.java:190) [ato-trip-biz-3.0.7-SNAPSHOT.jar:na] at com.taobao.ato.trip.service.impl.TripAtoQueryServiceImpl.getOrderById(TripAtoQueryServiceImpl.java:151) [ato-trip-biz-3.0.7-SNAPSHOT.jar:na] at sun.reflect.GeneratedMethodAccessor409.invoke(Unknown Source) ~[na:na] at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25) ~[na:1.6.0_32] at java.lang.reflect.Method.invoke(Method.java:597) ~[na:1.6.0_32] at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:307) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:182) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:149) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint.proceed(MethodInvocationProceedingJoinPoint.java:77) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at com.taobao.ato.trip.common.aspect.TripServiceAspect._proceed(TripServiceAspect.java:55) [ato-trip-biz-3.0.7-SNAPSHOT.jar:na] at com.taobao.ato.trip.common.aspect.TripServiceAspect.doTracerControl(TripServiceAspect.java:39) [ato-trip-biz-3.0.7-SNAPSHOT.jar:na] at sun.reflect.GeneratedMethodAccessor310.invoke(Unknown Source) ~[na:na] at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25) ~[na:1.6.0_32] at java.lang.reflect.Method.invoke(Method.java:597) ~[na:1.6.0_32] at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethodWithGivenArgs(AbstractAspectJAdvice.java:627) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethod(AbstractAspectJAdvice.java:616) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.aspectj.AspectJAroundAdvice.invoke(AspectJAroundAdvice.java:64) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:171) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.interceptor.ExposeInvocationInterceptor.invoke(ExposeInvocationInterceptor.java:89) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:171) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at org.springframework.aop.framework.JdkDynamicAopProxy.invoke(JdkDynamicAopProxy.java:204) [tmp3002357677492534561spring-2.5.6.jar:2.5.6] at $Proxy178.getOrderById(Unknown Source) [na:na] at sun.reflect.GeneratedMethodAccessor408.invoke(Unknown Source) ~[na:na] at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25) ~[na:1.6.0_32] at java.lang.reflect.Method.invoke(Method.java:597) ~[na:1.6.0_32] at com.taobao.hsf.rpc.tbremoting.provider.ProviderProcessor.handleRequest0(ProviderProcessor.java:474) [hsf.service.rpc.tbremoting-1.8.0.8.jar.plugin:na] at com.taobao.hsf.rpc.tbremoting.provider.ProviderProcessor.handleRequest(ProviderProcessor.java:272) [hsf.service.rpc.tbremoting-1.8.0.8.jar.plugin:na] at com.taobao.hsf.rpc.tbremoting.provider.ProviderProcessor.handleRequest(ProviderProcessor.java:61) [hsf.service.rpc.tbremoting-1.8.0.8.jar.plugin:na] at com.taobao.remoting.impl.DefaultMsgListener$1.run(DefaultMsgListener.java:98) [network.core-1.2.9.jar:na] at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:886) [na:1.6.0_32] at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:908) [na:1.6.0_32] at java.lang.Thread.run(Thread.java:662) [na:1.6.0_32] Caused by: com.taobao.hsf.exception.HSFServiceAddressNotFoundException: HSFServiceAddressNotFoundException-[HSF-Consumer] δ�ҵ���Ҫ���õķ����Ŀ���ַ at com.taobao.hsf.rpc.common.RPCProtocolTemplateComponent.invoke0(RPCProtocolTemplateComponent.java:565) ~[na:na] at com.taobao.hsf.rpc.common.RPCProtocolTemplateComponent.invokeWithMethodObject(RPCProtocolTemplateComponent.java:187) ~[na:na] at com.taobao.hsf.process.component.ProcessComponent$HSFServiceProxy.invoke(ProcessComponent.java:183) ~[na:na] ... 34 common frames omitted ");
		System.out.println(b);
		String method="query~GT";
		int startPos = method.indexOf("~");
		if ( startPos != -1 ){
			method = method.substring(0,startPos);
		}
		System.out.println(method);
	}
	
}
