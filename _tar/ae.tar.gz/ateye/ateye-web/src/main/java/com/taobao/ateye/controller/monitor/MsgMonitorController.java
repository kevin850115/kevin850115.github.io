package com.taobao.ateye.controller.monitor;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.monitor.AggrMsgStatMonitorDO;
import com.taobao.ateye.tracker.TrackerInfoManager;

@Controller
@RequestMapping("/monitor")
public class MsgMonitorController extends AbstractController{

	private static final String STAT_MONITOR = "screen/monitor/msg_stat";

	@Autowired
	private TrackerInfoManager trackerInfoManager;

	@RequestMapping("msgStat.htm")
	public String msgStat(final HttpServletRequest request, ModelMap result) throws Exception {
		Date startDate = getDay(request,result);
		String app=request.getParameter("app");
		String biz=request.getParameter("biz");
		if ( StringUtils.isBlank(app) && StringUtils.isBlank(biz)){
			return "";
		}
		result.put("app", app);
		Set<String> needApps = new HashSet<String>();
		//���ҵ��������
		if ( StringUtils.isNotBlank(biz) ){
			List<AppDO> apps = appDAO.queryAppByBizType(biz);
			result.put("bizName", biz);
			result.put("biz",biz);
			for ( AppDO a:apps ){
				needApps.add(a.getAppName());
			}
		}else{
			needApps.add(app);
		}
		AggrMsgStatMonitorDO msgStat = trackerInfoManager.getMsgStatOfApp(needApps, startDate);
		result.put("msgStat",msgStat);
		return STAT_MONITOR;
	}	
}
