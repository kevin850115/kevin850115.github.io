package com.taobao.ateye.controller.scene;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.alarm.log.AlarmLogGraphManager;
import com.taobao.ateye.alarm.log.AlarmLogGraphParam;
import com.taobao.ateye.cache.AppCache;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.goc.GocFaultModelDO;
import com.taobao.ateye.goc.GocFaultModelListDO;
import com.taobao.ateye.graph.base.GraphParamDO;
import com.taobao.util.CalendarUtil;
@Controller
@RequestMapping("/scene")
public class SceneBizController extends AbstractController{
	private static final String BIZ = "screen/scene/biz";

	@RequestMapping("biz.htm")
	public String biz(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<Integer, BizLineDO> bizMap = getBizMap();
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz) ){
			return "";
		}
		Integer nBiz = Integer.valueOf(biz);
		BizLineDO bizLineDO = bizMap.get(nBiz);
		if ( bizLineDO == null ){
			return "";
		}
		result.put("bizDO",bizLineDO);
		result.put("biz", biz);
		Set<String> appList = AppCache.getBizApps().get(nBiz);
		super.buildAppsInfos(result, appList, nBiz);
		
		//ҵ���߹���
		Map<String, String> flts = new HashMap<String,String>();
		flts.put("biz", biz);
		GocFaultModelListDO gocFaultList = gocFaultManager.queryGocFaultList(flts);
		if ( gocFaultList != null && gocFaultList.getRetList().size() > 0 ){
			GocFaultModelDO latestFault = gocFaultList.getRetList().get(0);
			result.put("faultCnt", gocFaultList.getRetList().size());
			result.put("latestFault", latestFault);
			result.put("latestFaultPassDay", CalendarUtil.getIntervalDays(latestFault.getGocFaultDO().getHappenTime(),new Date()));
		}
		//2.ͼ
		GraphParamDO gp = new GraphParamDO();
		gp.setName(AlarmLogGraphManager.ALARM_LOG_GRAPH);
		AlarmLogGraphParam param = new AlarmLogGraphParam();
		param.setBiz(biz);
		param.setEnd(new Date());
		param.setStart(DateUtils.addHours(new Date(),-1));
		param.setQueryType(AlarmLogGraphParam.QUERY_TYPE_BIZ);
		gp.setParam(param);
		result.put("customParam", gp.toCustomParam());
		
		super.setIsMobile(request, result);
	
		return BIZ;
	}
	
}
