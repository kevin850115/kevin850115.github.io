package com.taobao.ateye.controller.loginusers;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ateye.config.app.AppConfigDO;
import com.taobao.ateye.config.app.AppInfoDO;
import com.taobao.ateye.config.app.impl.AppConfigManager;
import com.taobao.ateye.config.app.impl.AppInfoManager;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.LogFilePathDAO;
import com.taobao.ateye.dal.RoleDAO;
import com.taobao.ateye.dal.UserAndAppDAO;
import com.taobao.ateye.dal.UserDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.LogFilePathDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserAndAppDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.diamond.impl.AppSubBizList;
import com.taobao.ateye.diamond.impl.AppTypeList;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.manager.impl.MiscellaneousManager;
import com.taobao.ateye.multithread.AbstractMultiThreadBatchTask;
import com.taobao.ateye.multithread.IBatchTask;
import com.taobao.ateye.operate.OperateLogger;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.LogFilePathService;
import com.taobao.ateye.service.OpsServic;
import com.taobao.ateye.tracker.TrackerTaskManager;
import com.taobao.ateye.update.AbstractUpdate;
import com.taobao.ateye.update.UpdateInterface;
import com.taobao.ateye.update.UpdateManager;
import com.taobao.ateye.util.BizUtil;
import com.taobao.ateye.util.HttpClientUtil;
import com.taobao.ateye.util.UrlGenerator;
import com.taobao.ateye.version.manager.AteyeVersionManager;

@Controller
@RequestMapping("/manage/app")
public class ManageAppController extends AbstractController{
    @Autowired
    OperateLogger operateLogger;
    @Autowired
    private OpsServic opsServic;
    @Autowired
    private AppService appService;
	@Autowired
	private RoleDAO ateyeRoleDAO;
    @Autowired
    private AppInfoManager appInfoManager;
	@Autowired
	private UrlGenerator urlGenerator;
	@Autowired
	private LogFilePathDAO logFilePathDAO;
	@Autowired
	private LogFilePathService logFilePathService;
	@Autowired
	private AppDAO appDAO;
    @Autowired
    private UserAndAppDAO userAndAppDAO;
    @Autowired
    private UserDAO userDAO;
    @Autowired
    private AppConfigManager appConfigManager;
    @Autowired
    private AteyeVersionManager ateyeVersionManager;
    @Autowired
    private UpdateManager updateManager;
    @Autowired
    private AppSubBizList appSubBizList;
    @Autowired
    private AppTypeList appTypeList;

    @Autowired
    private EnvironmentService environmentService;

    @Autowired
    private TrackerTaskManager trackerTaskManager;
	
    private void init(Map<String, Object> result) throws DAOException {
        List<AppDO> apps = opsServic.getAllApps();
    	result.put("apps",apps);
    }
    @RequestMapping("addAppLogFiles.htm") 
    public String addAppLogFiles(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	String file = request.getParameter("file");
    	String version = request.getParameter("version");
    	
    	logFilePathService.saveLogFilePathDO(app,file,version);
		return listAppLogFiles(request, result);
    }
    @RequestMapping("deleteAppLogFiles.htm") 
    public String deleteAppLogFiles(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	_deleteAppLogFiles(request,result);
		return listAppLogFiles(request, result);
    	
    }
    private void _deleteAppLogFiles(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	AppDO appDO = appDAO.getAppByName(app);
    	String file = request.getParameter("file");
		try{
			List<LogFilePathDO> logFiles = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(),environmentService.getEnvironmentType().getEnv());
			for ( LogFilePathDO p:logFiles ){
				if ( p.getFilePath().equals(file) ){
					long id = p.getId();
					logFilePathDAO.deleteLogFilePathDO(id);
					break;
				}
			}
		}catch(Throwable t){
			log.error("�쳣",t);
		}
    }
    @RequestMapping("deleteAppUser2.htm")
    public final String deleteApp2(final HttpServletRequest request,
            final ModelMap result) throws DAOException, UnsupportedEncodingException {
    	String appName = request.getParameter("app");
    	String[] userIds = request.getParameterValues("users");
    	String userId=request.getParameter("user");
    	if ( userId == null && ( userIds == null || userIds.length == 0) ){
    		return null;
    	}
        AppDO appDO = appDAO.getAppByName(appName);
        if ( appDO == null ){
            return null;
        }
        if ( userIds != null ){
	        for ( String uId :userIds ){
		        userAndAppDAO.deleteUserAndAppInfoByUserIdAndAppId(Long.valueOf(uId), appDO.getId());
	        }
        }
        if ( userId != null ){
	        userAndAppDAO.deleteUserAndAppInfoByUserIdAndAppId(Long.valueOf(userId), appDO.getId());
        }
        return "redirect:/manage/app/userAdmin.htm?app="+appName;
        	
    }
    @RequestMapping("deleteAppLogFiles2.htm") 
    public String deleteAppLogFiles2(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	_deleteAppLogFiles(request,result);
		return "redirect:/tracker/detail.htm?app="+app;
    }
   
   @RequestMapping("config.htm")
   public String config(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
	   String app = request.getParameter("app");
	   if ( StringUtils.isBlank(app) ){
		   return "";
	   }
	   //1.��DB��ȡ��Ϣ
	   AppDO appDO = appDAO.getAppByName(app);
	   if ( appDO == null ){
		   return "";
	   }
	   if (!environmentService.isDaily() ){
		   ateyeVersionManager.saveAppVersion(app);
	   }
	   result.put("app",app);
	   result.put("appDO",appDO);
	   //2.��Hbase�ж�ȡ��Ϣ
	   AppConfigDO config = appConfigManager.getConfig(app);
	   result.put("configs",config);
	   if ( StringUtils.isNotBlank( config.getAteyeClientVersion() ) ){
		   Map<UpdateInterface, Boolean> updateSt = updateManager.getUpdateStatus(app, config.getAteyeClientVersion());
		   result.put("uds", updateSt);
	   }
	   result.put("appTypes", appTypeList.getAppTypes());

	   return "manage/app/config";
   }
   @RequestMapping("configUd.htm")
   public String configUd(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
	   String app = request.getParameter("app");
	   if ( StringUtils.isBlank(app) ){
		   return "";
	   }
	   AppDO appDO = appDAO.getAppByName(app);
	   if ( appDO == null ){
		   return "";
	   }
	   String ud = request.getParameter("ud");
	   UpdateInterface ui = AbstractUpdate.allUpdateTasks.get(ud);
	   if ( ui != null ){
		   ui.update(app);
	   }
	   return "redirect:/manage/app/config.htm?app="+app;
   }
   @RequestMapping("updateConfig.htm")
   public String updateConfig(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
	   String app = request.getParameter("app");
	   if ( StringUtils.isBlank(app) ){
		   return "";
	   }
	   AppDO appDO = appDAO.getAppByName(app);
	   if ( appDO == null ){
		   return "";
	   }
	   //addAoneId
	   addAoneId(app,request.getParameter("aoneAppID"));

	   result.put("app",app);
	   Map<String,String> uu = new HashMap<String,String>();
	   fillMap(request,uu,AppConfigManager.CONFIG_CLOSE_ALL_ALARM);
	   fillMap(request,uu,AppConfigManager.CONFIG_CLOSE_SMS_ALARM);
	   fillMap(request,uu,AppConfigManager.CONFIG_CLOSE_DAILY_EMAIL);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_EXCEPTION);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_HSF);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_KV);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_OPLOG);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_TDDLSTAT);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_NOTIFY_META);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_TAIRSTAT);
	   //fillMap(request,uu,AppConfigManager.CONFIG_APP_TYPE);
	   //fillMap(request,uu,AppConfigManager.CONFIG_SUB_BIZ);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_SCENE);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_SCENE_OPLOG);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_SCENE_DEBUG_LOG);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_APP_CONFIG_LOG);
	   fillMap(request,uu,AppConfigManager.CONFIG_OPEN_TDDL_SLOW_SQL);
	   appConfigManager.saveConfig(app, uu);
	   if(!environmentService.isProduction()){
			//�����ճ���Ԥ������������䶨ʱ����رյģ�������Ҫͨ������
		   try{
			   trackerTaskManager.adjustTask2();
		   }catch (Exception e){
		   	log.error("������������쳣" ,e);
		   }

	   }
	   return "redirect:/manage/app/config.htm?app="+app;
   }

	private void addAoneId(String appName, String aoneAppID) throws DAOException {
    	if(StringUtils.isNotEmpty(aoneAppID) && NumberUtils.isNumber(aoneAppID)){
			AppDO appDO = appDAO.getAppByName(appName);
			if(appDO !=null){
				int aoneAppId = appDO.getAoneAppId();
				if(aoneAppId == -1){
					appDO.setAoneAppId(Integer.parseInt(aoneAppID));
					appDAO.updateAppTag(appDO.getId(),appDO.getAppTag());
				}
			}
		}

	}

	private void fillMap(final HttpServletRequest req,Map<String,String> uu,String k){
	   uu.put(k, req.getParameter(k));
   }
    @RequestMapping("userAdmin.htm")
    public String userAdmin(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	if ( StringUtils.isBlank(app) ){
    		return "";
    	}
    	AppDO appDO = appDAO.getAppByName(app);
    	if ( appDO == null ){
    		return "";
    	}
    	result.put("app",app);
        Map<String,String> userNameUtf8 = new HashMap<String,String>();
    	List<UserAndAppDO> ups = userAndAppDAO.getInfoByAppId(appDO.getId());
    	List<UserDO> users = new ArrayList<UserDO>();
        for ( UserAndAppDO uaa:ups ){
        	Long userId = uaa.getUserId();
        	UserDO user = userDAO.getUserById(userId);
        	if ( user != null ){
        	    if ( !userNameUtf8.containsKey(user.getNick()) ){
                    userNameUtf8.put(user.getNick(), URLEncoder.encode(user.getNick(), "utf-8"));
                }
				List<RoleDO> userRoles =  ateyeRoleDAO.getUserRoleList(userId);
				user.setRoleList(userRoles);
        	    users.add(user);
        	}
        }
        result.put("users",users);

        result.put("userNames",userNameUtf8);

    	return "manage/app/userAdmin";
    	
    }
    @RequestMapping("listAppLogFiles.htm") 
    public String listAppLogFiles(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException{
    	String app = request.getParameter("app");
    	if ( StringUtils.isEmpty(app) ){
	    	initBizMap(result);
	    	return "manage/app/listApps";
    	}
    	result.put("app", app);
    	AppDO appDO = appDAO.getAppByName(app);
    	if ( appDO == null ){
	    	return "manage/app/listAppLogFiles";
    	}
    	List<MachineDO> allMachines = machineDAO.getMachinesOfAnApp(appDO.getId(), environmentService.getEnvironmentType().ordinal());
    	final List<MachineDO> machines = pickRandom5(allMachines);
    	final Map<String,Map<String,Integer>> ret = new ConcurrentHashMap<String,Map<String,Integer>>();
    	final Map<String,Map<String,String>> retModified = new ConcurrentHashMap<String,Map<String,String>>();
    	final Map<String,Set<Integer>> fileTypes = new ConcurrentHashMap<String,Set<Integer>>();
    	int threadNumber = machines.size();
    	IBatchTask bt = new AbstractMultiThreadBatchTask<MachineDO>(threadNumber) {
			@Override
			protected void doSingleWork(MachineDO m) {
				Map<String,Integer> files = getFileList(m);
	    		if ( files == null ){
	    			return;
	    		}
	    		Map<String, String> fileModified = getFileModified(m);
	    		String key = m.getIp();
				if ( StringUtils.isNotBlank(m.getDesc())){
					key = m.getIp()+"("+m.getDesc()+")";
				}
	    		ret.put(key, files);
    			retModified.put(key,fileModified);
    			
	    		for ( Map.Entry<String, Integer> f:files.entrySet() ){
	    			Set<Integer> types = fileTypes.get(f.getKey());
	    			if ( types == null ){
	    				types = new HashSet<Integer>();
	    			}
	    			types.add(f.getValue());
	    			fileTypes.put(f.getKey(), types);
	    		}
			}
			@Override
			protected List<MachineDO> getObjects() {
				return machines;
			}
    	};
    	bt.doWork();
    	
    	result.put("fileTypes",fileTypes);
    	List<String> files = new ArrayList<String>();
    	files.addAll(Arrays.asList(MiscellaneousManager.DetectedFiles));
    	files.addAll(Arrays.asList(MiscellaneousManager.DetectedFilesAndVersion));
    	result.put("results",ret);
    	result.put("files",files);
    	result.put("modified",retModified);
    	//��ѯ��Ӧ�õ�ǰ�Ѿ����õĲɼ���־
    	List<LogFilePathDO> allLogFiles = logFilePathDAO.getAllLogFilePathDOsInAnApp(appDO.getId(),environmentService.getEnvironmentType().getEnv());
    	Set<String> collectedFiles = new HashSet<String>();
    	for ( LogFilePathDO fp:allLogFiles ){
    		collectedFiles.add(fp.getFilePath());
    	}
    	result.put("cfiles",collectedFiles);
    	
    	return "manage/app/listAppLogFiles";
    }
    private List<MachineDO> pickRandom5(List<MachineDO> allMachines) {
    	List<Integer> rlist = pickRandom5(allMachines.size());
    	List<MachineDO> ret = new ArrayList<MachineDO>();
    	for ( Integer r:rlist ){
    		ret.add(allMachines.get(r));
    	}
		return ret;
	}
    private static List<Integer> pickRandom5(Integer total){
    	Set<Integer> ss = new HashSet<Integer>();
    	if ( total <=5 ){
    		for ( int i=0;i<total;++i ){
    			ss.add(i);
    		}
    	}else{
	    	while ( ss.size() < 5 ){
	    		ss.add((int)(Math.random()*(total-1)));
	    	}
    	}
    	return new ArrayList<Integer>(ss);
    }
    public static void main(String[] args) {
		System.out.println(ManageAppController.pickRandom5(19));
	}
	private Map<String,Integer> getFileList(MachineDO machine){
    	Map<String, String> params = new HashMap<String, String>();
		params.put("type", "MISCELLANEOUS");
		params.put("action", "logFile");
		
		String url = "";
		try {
			url = urlGenerator.getUrl(machine.getIp(), String.valueOf(machine.getPort()), params);
		} catch (Exception e1) {
			return null;
		}

		try {
			String json = HttpClientUtil.getResult(url);
			if ( StringUtils.isBlank(json) ){
				log.error("��ȡ�ļ��б�Ϊ��,ip:"+machine.getIp());
				return null;
			}
			Map map = JSON.parseObject(json, Map.class);
			if ( map.containsKey("errorMsg") ){
				return null;
			}
			return map;
		} catch (Exception e) {
			log.error("getError",e);
			return null;
		}
    }
    private Map<String,String> getFileModified(MachineDO machine){
    	Map<String, String> params = new HashMap<String, String>();
		params.put("type", "MISCELLANEOUS");
		params.put("action", "logFileModified");
		
		String url = "";
		try {
			url = urlGenerator.getUrl(machine.getIp(), String.valueOf(machine.getPort()), params);
		} catch (Exception e1) {
			return null;
		}

		try {
			String json = HttpClientUtil.getResult(url);
			Map map = JSON.parseObject(json, Map.class);
			if ( map.containsKey("errorMsg") ){
				return null;
			}
			return map;
		} catch (Exception e) {
			log.error("getError",e);
			return null;
		}
    }
    @RequestMapping("addApp2.htm")
    public final String addApp2( final HttpServletRequest request,final HttpServletResponse response,final ModelMap result) throws DAOException, UnsupportedEncodingException {
    	String newAppName = request.getParameter("newApp");
    	String administrators = request.getParameter("admins"); 
    	if(StringUtils.isBlank(newAppName)){
        	result.put("error", "Ӧ�õ����ֲ���Ϊ��");
        	return "manage/app/addApp2";
        }
    	//Daily������������Ӧ�ã�Ԥ�������ϻ�����Ҫ��Armoryϵͳ�м��Ҫ���ӵ�Ӧ�����Ƿ���online����
    	//���������ΪӦ�����Ϸ���������Ϊ�Ƿ�����ֹ����
    	AppDO appDO1 = appService.getAppByAppName(newAppName);
        if(appDO1 != null){
        	result.put("error", "�������Ӧ���Ѿ����ڣ������ظ�����");
        }else{
        	AppDO appDO = new AppDO();
            appDO.setAppName(newAppName);
            appDO.setAdministrators(administrators);
            appDO.setContextRoot("/");
            boolean ok = appService.saveAppDO(appDO);
            if(ok) {
            	result.put("error", "����Ӧ�óɹ�");
            }else{
            	result.put("error", "����Ӧ��ʧ��");
            }
        }
		String returnUrl = request.getParameter("returnUrl");
    	String redirectUrl = super.getRedirectUrl(request, response);
    	if ( StringUtils.isBlank(returnUrl)) {
	        return "redirect:/apps/detail.htm?app="+newAppName;
    	}else{
    		return redirectUrl;
    	}

    }  
    @RequestMapping("updateAppAdminInfo.htm")
    public final String updateAppAdminInfo( @RequestParam(value = "appId_4adminInfoUpdate", required = true) Long appId
    		, @RequestParam(value = "administrators_update", required = true) String administrators
    		, final HttpServletRequest request, final ModelMap result) throws DAOException {
        boolean ok = appService.updateAppAdminInfo(appId, administrators);
        if(ok){
        	result.put("error", "����Ӧ�ù���Ա�ɹ�");
        }else{
        	result.put("error", "����Ӧ�ù���Աʧ��");
        }
        this.init(result);
        return "manage/app/queryApp";
    }
    @RequestMapping("updateAdmin.htm")
    public final String updateAdmin(final HttpServletRequest request, final ModelMap result) throws DAOException {
    	String app = request.getParameter("app");
    	if ( StringUtils.isBlank(app) ){
    		return "";
    	}
    	result.put("app",app);
    	String doUpdate = request.getParameter("doUpdate");
		AppDO appDO = appDAO.getAppByName(app);
    	if ( StringUtils.isEmpty(doUpdate) ){//���鿴
    		result.put("admins",appDO.getAdministrators());
    		return "manage/app/updateAdmin";
    	}
    	String admins = request.getParameter("admins");
    	if ( StringUtils.isBlank(admins) ){
        	result.put("error", "����Ϊ��");
	        return "manage/app/updateAdmin";
    	}
    	result.put("admins",appDO.getAdministrators());
    	String[] adminStr = admins.split(",");
    	if ( adminStr.length >  10 ){
    		result.put("error","����Ա���ܳ���10��");
    		return "manage/app/updateAdmin";
    	}
        boolean ok = appService.updateAppAdminInfo(appDO.getId(), admins);
        if(ok){
        	result.put("error", "����Ӧ�ù���Ա�ɹ�");
        }else{
        	result.put("error", "����Ӧ�ù���Աʧ��");
        }
		appDO = appDAO.getAppByName(app);
    	result.put("admins",appDO.getAdministrators());
    	

        return "manage/app/updateAdmin";
    }

	@RequestMapping("updateDingDingTokens.htm")
	public final String updateDingDingTokens(final HttpServletRequest request, final ModelMap result) throws DAOException {
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		result.put("app",app);
		String doUpdate = request.getParameter("doUpdate");
		AppDO appDO = appDAO.getAppByName(app);
		if ( StringUtils.isEmpty(doUpdate) ){//���鿴
			result.put("tokens",appDO.getDingDingTokens());
			return "manage/app/updateDingDingTokens";
		}
		String tokens = request.getParameter("tokens");

		result.put("tokens",appDO.getDingDingTokens());

		if(StringUtils.isNotBlank(tokens)) {
			String[] tokenTerms = tokens.split(",");
			if (tokenTerms.length > 10) {
				result.put("error", "����Ⱥ���ܳ���10��");
				return "manage/app/updateDingDingTokens";
			}
		}else{
			tokens = "";
		}

		boolean ok = appService.updateAppDingDingTokens(appDO.getId(), tokens);
		if(ok){
			result.put("error", "����Ӧ�ö���ȺToken�ɹ�");
		}else{
			result.put("error", "����Ӧ�ö���ȺTokenʧ��");
		}
		appDO = appDAO.getAppByName(app);
		result.put("tokens",appDO.getDingDingTokens());
		return "manage/app/updateDingDingTokens";
	}

    @RequestMapping("upAppPublishStatus.htm")
    public final String updateAppPublishStatus( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
        String appId = request.getParameter("id");
        String publishStatus = request.getParameter("publishStatus");
        if (StringUtils.isBlank(publishStatus)) {
            return getRedirectUrl(request, response);
        }
        AppDO app = appDAO.getAppById(Long.valueOf(appId));
        if (app != null) {
            JSONObject json = null;
            String appTag = app.getAppTag();
            if (!StringUtils.isEmpty(appTag)) {
                json = JSONObject.parseObject(appTag);
            } else {
                json = new JSONObject();
            }
            json.put("publishStatus", publishStatus);
            appDAO.updateAppTag(Long.valueOf(appId), json.toJSONString());
        }
        return getRedirectUrl(request, response);
    }   
    @RequestMapping("upAppType.htm")
    public final String updateAppType( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
        String appId = request.getParameter("id");
        String appType = request.getParameter("appType");
        if (StringUtils.isBlank(appType)) {
            return getRedirectUrl(request, response);
        }
        AppDO app = appDAO.getAppById(Long.valueOf(appId));
        if (app != null) {
            JSONObject json = null;
            String appTag = app.getAppTag();
            if (!StringUtils.isEmpty(appTag)) {
                json = JSONObject.parseObject(appTag);
            } else {
                json = new JSONObject();
            }
            json.put("type", appType);
            appDAO.updateAppTag(Long.valueOf(appId), json.toJSONString());
        }
        return getRedirectUrl(request, response);
    }   
    @RequestMapping("upAppDeleteStatus.htm")
    public final String updateOfflineStatus( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
        String appId = request.getParameter("id");
        String deleteStatus = request.getParameter("deleteStatus");
        if (StringUtils.isBlank(deleteStatus)) {
            return getRedirectUrl(request, response);
        }
        AppDO app = appDAO.getAppById(Long.valueOf(appId));
        if (app != null) {
            JSONObject json = null;
            String appTag = app.getAppTag();
            if (!StringUtils.isEmpty(appTag)) {
                json = JSONObject.parseObject(appTag);
            } else {
                json = new JSONObject();
            }
            json.put("deleteStatus", deleteStatus);
            appDAO.updateAppTag(Long.valueOf(appId), json.toJSONString());
        }
        return getRedirectUrl(request, response);
    }     
    @RequestMapping("upAppAlias.htm")
    public final String updateAlias( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
        String appId = request.getParameter("id");
        String cnName = request.getParameter("cnName");
        if(StringUtils.isBlank(cnName)){
            return getRedirectUrl(request, response);
        }
        appDAO.updateAppAlias(Long.valueOf(appId), cnName);
        return getRedirectUrl(request, response);
    }    
    @RequestMapping("upBizType.htm")
    public final String updateBizType( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
    	String appId = request.getParameter("id");
    	String bizType = request.getParameter("bizType");
    	if(StringUtils.isBlank(bizType)){
    		return getRedirectUrl(request, response);
        }
    	appDAO.updateAppBizType(Long.valueOf(appId), Integer.valueOf(bizType));
		return getRedirectUrl(request, response);
    }     
    @RequestMapping("upSubBizType.htm")
    public final String updateSubBizType( final HttpServletRequest request,final HttpServletResponse response, final ModelMap result) throws DAOException, UnsupportedEncodingException {
    	String appId = request.getParameter("id");
    	String subBizType = request.getParameter("subBizType");
    	if(StringUtils.isBlank(subBizType)){
    		return getRedirectUrl(request, response);
        }
    	appDAO.updateAppSubBizType(Long.valueOf(appId), Integer.valueOf(subBizType));
		return getRedirectUrl(request, response);
    }     
  
    @RequestMapping("updateAppContextRoot.htm")
    public final String updateAppContextRoot( @RequestParam(value = "appId_4contextRootUpdate", required = true) Long appId
    		, @RequestParam(value = "context_root_update", required = true) String contextRoot
    		,final HttpServletRequest request, final ModelMap result) throws DAOException {
        boolean ok = appService.updateAppContextRoot(appId, contextRoot);
        if(ok){
        	result.put("error", "����Ӧ��ContextRoot�ɹ�");
        }else{
        	result.put("error", "����Ӧ��ContextRootʧ��");
        }
        this.init(result);
        return "manage/app/queryApp";
    }

    @RequestMapping("queryApp.htm")
    public final String queryApp(final HttpServletRequest request, final ModelMap result) throws DAOException {
    	List<AppInfoDO> allApps = appInfoManager.getAllApps();
		result.put("returnUrl", super.getWholeUrl(request));
		Map<String, AppConfigDO> allConfigs = appConfigManager.getAllConfig();
		result.put("cfgs",allConfigs);
		int machineCount = 0;
    	for ( AppInfoDO appInfo:allApps ){
			List<MachineDO> machineDOs = appInfo.getMachines();
			if (!CollectionUtils.isEmpty(machineDOs)) {
				machineCount += machineDOs.size();
			}
    	}
    	Map<Long, BizLineDO> allBizLineMap = bizLineDAO.getAllBizLineMap();
    	//����ÿ��ҵ���ߵĻ�����
    	List<String> products = BizUtil.getProducts();
    	result.put("products",products);
    	Map<String,Integer> productCounts = new HashMap<String,Integer>();
    	for ( AppInfoDO appInfo:allApps ){
    		String productName = getBizName(appInfo.getAppDO(),allBizLineMap);
    		int size = appInfo.getMachines().size();
    		Integer cnt = productCounts.get(productName);
    		if ( cnt == null ){
    			productCounts.put(productName, size);
    		}else{
    			productCounts.put(productName, cnt + size);
    		}
    	}
    	result.put("productCnts",productCounts);
    	String selectedPrd = request.getParameter("prd");
    	if ( StringUtils.isNotBlank(selectedPrd) ){
	    	result.put("apps",fltByProductName(allApps,selectedPrd,allBizLineMap));
	    	result.put("totalMachines",productCounts.get(selectedPrd));
    	}else{
	    	result.put("totalMachines",machineCount);
	    	result.put("apps",allApps);
    	}
    	result.put("selectedPrd",selectedPrd);
        return "manage/app/queryApp";
    }
	private List<AppInfoDO> fltByProductName(List<AppInfoDO> allApps, String selectedPrd,Map<Long, BizLineDO> allBiz) {
		List<AppInfoDO> ret = new ArrayList<AppInfoDO>();
		for ( AppInfoDO ap:allApps ){
			String bizName = getBizName(ap.getAppDO(), allBiz);
			if ( selectedPrd.equals(bizName)){
				ret.add(ap);
			}
		}
		return ret;
	}
	@RequestMapping("deleteApp.htm")
    public final String deleteApp(final HttpServletRequest request, final ModelMap result) throws DAOException {
    	String appName = request.getParameter("appName");
    	if ( StringUtils.isBlank(appName) ){
	        return queryApp(request, result);
    	}
        boolean flag = appService.deleteAppDOByAppName(appName);
        if (!flag) {
            result.put("error", "ɾ��Ӧ��ʧ��");
            operateLogger.logError("ɾ��Ӧ��ʧ��", -1, appName);
        } else {
            result.put("info", "ɾ��Ӧ�óɹ�");
            operateLogger.logInfo("ɾ��Ӧ�óɹ�", -1, appName);
        }
        return queryApp(request, result);
    }
}
