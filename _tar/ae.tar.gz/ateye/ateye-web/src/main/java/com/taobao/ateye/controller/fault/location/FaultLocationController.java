package com.taobao.ateye.controller.fault.location;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ateye.alarm.log.AlarmLogModelListDO;
import com.taobao.ateye.base.Pair;
import com.taobao.ateye.chg.ChangeModelListDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.*;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.GocEmgExtendDO;
import com.taobao.ateye.dataobject.GocEmgMessageDO;
import com.taobao.ateye.dataobject.SceneEntryPoint;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.fault.location.*;
import com.taobao.ateye.fault.location.manager.AlarmLogFaultManager;
import com.taobao.ateye.fault.location.manager.ChangeFreeFaultManager;
import com.taobao.ateye.fault.location.manager.ExceptionLocationManager;
import com.taobao.ateye.fault.location.manager.data.FaultLocation;
import com.taobao.ateye.fault.location.manager.data.NodeGroup;
import com.taobao.ateye.goc.emg.GocEmgExtendTypeEnum;
import com.taobao.ateye.hsf.manager.NodeGroupManager;
import com.taobao.ateye.monitor.data.DataBuilder;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.ateye.util.reflect.BooleanUtils;
import com.taobao.ateye.util.reflect.StringUtils;
import com.taobao.tracker.except.ExceptionTypeConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by sunqiang on 2019/5/27.
 */
@Controller
@RequestMapping("/fault")
public class FaultLocationController extends AbstractController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String location = "screen/fault/location";

    @Autowired
    private GocEmgExtendDAO gocEmgExtendDAO;

    @Autowired
    private ChangeFreeFaultManager changeFreeFaultManager;

    @Autowired
    private GocEmgMessageDAO emgMessageDAO;

    @Autowired
    private SceneEntryPointDAO sceneEntryPointDAO;

    @Autowired
    private NodeGroupManager nodeGroupManager;

    @Autowired
    private AlarmLogFaultManager alarmLogFaultManager;

    @RequestMapping("location.htm")
    public String location(final HttpServletRequest request, final ModelMap result) throws Exception {

        String type = request.getParameter("type");

        String faultTime = request.getParameter("faultTime");
        if(StringUtils.isEmpty(faultTime)){
            Date s_time = null;
            String start_time = request.getParameter("start_time");
            String start_hhmm = request.getParameter("start_hhmm");
            if(!StringUtil.isBlank(start_time) && !StringUtil.isBlank(start_hhmm)
                    ){//�������򸲸�ԭ��ʱ��
                s_time=stringToDate(start_time,start_hhmm);
            }
            if(s_time != null){
                faultTime = CalendarUtil.formatDate(s_time,CalendarUtil.TIME_PATTERN_SESSION);
            }
        }
        String app = "Unknow";
        LocationDimension dimension = LocationDimension.singleApp;
        List<SceneEntryPoint> entrys = Lists.newArrayList();
        if("goc".equals(type)){
            dimension = LocationDimension.scene;
            String adKey = request.getParameter("adKey");
            String statusCode = request.getParameter("statusCode");
            GocEmgMessageDO gocEmgMessageDO = emgMessageDAO.getByUk(adKey,statusCode);
            result.put("gocEmgMessageDO",gocEmgMessageDO);

            if(StringUtils.isEmpty(faultTime)){
                faultTime = CalendarUtil.formatDate(gocEmgMessageDO.getMsgCreateTime(),CalendarUtil.TIME_PATTERN_SESSION);;
            }
            app = gocEmgMessageDO.getAppName();
            List<GocEmgExtendDO> extendDOS = gocEmgExtendDAO.getByAlarmIdAndType(gocEmgMessageDO.getAlarmId(), GocEmgExtendTypeEnum.APP.name());
            if(CollectionUtils.isNotEmpty(extendDOS)){
                app = extendDOS.get(0).getValue();
            }
            List<GocEmgExtendDO> sceneExtends = gocEmgExtendDAO.getByAlarmIdAndType(gocEmgMessageDO.getAlarmId(), GocEmgExtendTypeEnum.SCENE.name());
            if(CollectionUtils.isNotEmpty(sceneExtends)){
                for (GocEmgExtendDO sceneExtend : sceneExtends) {
                    String sceneName = sceneExtend.getValue();
                    List<SceneEntryPoint> scenes = sceneEntryPointDAO.getEntryPointByName(sceneName,environmentService.getEnvironmentType().getEnv());
                    if(CollectionUtils.isNotEmpty(scenes)){
                        for (SceneEntryPoint scene : scenes) {
                            entrys.add(scene);
                        }

                    }

                }
            }
        }else if("scene".equals(type)){
            dimension = LocationDimension.scene;
            String entryPointId = request.getParameter("entryPointId");
            SceneEntryPoint sceneEntryPoint = sceneEntryPointDAO.getEntryPointById(Long.parseLong(entryPointId));
            if(sceneEntryPoint !=null){
                entrys.add(sceneEntryPoint);
            }

        }else{
            app = request.getParameter("app");
            if(BooleanUtils.toBoolean(request.getParameter("hasRelation"))){
                dimension = LocationDimension.realtionApp;
            }else{
                dimension = LocationDimension.singleApp;
            }
        }
        if(StringUtils.isEmpty(faultTime)){
            faultTime = CalendarUtil.formatDate(new Date(),CalendarUtil.TIME_PATTERN_SESSION);;
        }
        Date faultDate = CalendarUtil.toDate(faultTime,CalendarUtil.TIME_PATTERN_SESSION);
        result.put("faultDate",CalendarUtil.formatDate(faultDate,CalendarUtil.TIME_PATTERN));
        result.put("start_time", com.taobao.util.CalendarUtil.toString(faultDate, com.taobao.util.CalendarUtil.DATE_FMT_3));
        result.put("start_hhmm", com.taobao.util.CalendarUtil.toString(faultDate, "HH:mm"));

        List<FaultLocation> faultLocations = Lists.newArrayList();
        List<String> totalCustomeParams  = new ArrayList<String>();
        Set<String> kvGraphTitles = Sets.newLinkedHashSet();
        AtomicInteger atomicInteger = new AtomicInteger(0);
        List<FaultGraphDO> faultGraphs = Lists.newArrayList();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(faultDate);
        calendar.add(Calendar.HOUR_OF_DAY,-3);
        Date startDate = calendar.getTime();
        calendar.setTime(faultDate);
        calendar.add(Calendar.HOUR_OF_DAY,1);
        Date endDate = calendar.getTime();
        if(endDate.after(new Date())){
            endDate = new Date();
        }
        //���쳡�������������
        ContextDO contextDO = new ContextDO();
        if(CollectionUtils.isNotEmpty(entrys)){
            {
                for (SceneEntryPoint entry : entrys) {
                    AbstractGraphFaultManager sceneFL = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.SCENE_MONITOR);
                    Map<String,GraphMonitorItemDO> items = sceneFL.abnormalGraph(entry.getId(),faultDate,contextDO);
                    faultLocations.addAll(sceneFL.fetchFL(items));
                    List<String> customeParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(items),DataBuilder.graphSizeMap.get("xxs"),startDate,endDate);
                    totalCustomeParams.addAll(customeParams);
//                    List<String> customeBigParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(items),DataBuilder.defaultSize);
                    kvGraphTitles.addAll(items.keySet());
                    faultGraphs.add(new FaultGraphDO(buildSceneName(entry),atomicInteger,items.keySet()));
                }
            }
        }
        String rawApp = "";
        if(app != null){
            List<NodeGroup> nodeGroups = nodeGroupManager.transferNodeGroup(app);
            if(nodeGroups.size() >0){
                rawApp = nodeGroups.get(0).getAppName();
            }
            if(dimension == LocationDimension.realtionApp){
                nodeGroups = nodeGroupManager.relationGroup(app, AbstractFaultManager.RELATION_LEVEL);
            }else if(dimension == LocationDimension.scene){
                if(CollectionUtils.isNotEmpty(entrys)){
                    Set<String> apps = (Set<String>) contextDO.getContext().get(ContextDO.SCENE_RELATION_APP);
                    if(CollectionUtils.isNotEmpty(apps)){
                        nodeGroups = Lists.newArrayList();
                        for (String s : apps) {
                            nodeGroups.addAll(nodeGroupManager.transferNodeGroup(s));
                        }
                    }
                }else{
                    nodeGroups = nodeGroupManager.relationGroup(app, AbstractFaultManager.RELATION_LEVEL);
                }
            }
            filter(nodeGroups,rawApp);
            logger.error("locationNodeGroup:"+ JSON.toJSONString(nodeGroups));
            String relationDecWithUrl = buildAppRelationWithURL(nodeGroups);
            result.put("app",app);
            result.put("relationDecWithUrl",relationDecWithUrl);
            //������ù�ϵ
            String relationDec = buildAppRelation(nodeGroups);
            result.put("relationDec",relationDec);
            //���
            ChangeModelListDO changeList = changeFreeFaultManager.locationChange(nodeGroups,faultDate);
            faultLocations.addAll(changeFreeFaultManager.fetchFL(changeList,faultDate));
            result.put("changes",changeList.getTopNRetList(20));
            result.put("changeCnt",changeList.getRetList().size());
            //����
            AlarmLogModelListDO alarmLogList = alarmLogFaultManager.locationAlarmLog(nodeGroups,faultDate);
            result.put("alarmLogList",alarmLogList.getTopNRetList(20));

            //�����쳣ϵͳ���ָ��
            buildSystemMonitor(nodeGroups,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultLocations,result,faultGraphs);
            //����������
            Set<String> tvNodeGroups = AbstractFaultManager.getTrackerViewNodeGroup(nodeGroups);
            for (String tvNodeGroup : tvNodeGroups) {
                Set<String> titles = Sets.newLinkedHashSet();

                buildProvider(tvNodeGroup,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultGraphs,titles);
                buildConsumer(tvNodeGroup,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultGraphs,titles);
                buildMeta(tvNodeGroup,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultGraphs,titles);
                buildNotify(tvNodeGroup,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultGraphs,titles);

                if(CollectionUtils.isNotEmpty(titles)){
                    faultGraphs.add(new FaultGraphDO("<span class=\"label label-success mb5 f14\">�������:</span>"+relationDecWithUrl,atomicInteger,titles));
                }
            }
            //�����쳣
            buildException(nodeGroups,faultDate,contextDO,startDate,endDate,relationDecWithUrl,atomicInteger,totalCustomeParams,faultLocations,result);
        }
        result.put("ateyeDomain",ateyeConfig.getAteyeDomain());
        result.put("customParams", totalCustomeParams);
        result.put("faultGraphs", faultGraphs);
        result.put("fullShow",true);

        if(CollectionUtils.isNotEmpty(faultLocations)){
            result.put("faultLocations", faultLocations);
        }
        result.put("type",type);
        result.put("entryPointId",request.getParameter("entryPointId"));
        result.put("hasRelation",request.getParameter("hasRelation"));
        result.put("app",request.getParameter("app"));
        result.put("adKey",request.getParameter("adKey"));
        result.put("statusCode",request.getParameter("statusCode"));
        return location;
    }

    private void buildException(List<NodeGroup> nodeGroups, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultLocation> faultLocations, ModelMap result) {
        //3.��ȡ�쳣�б�
        Map<String,String> ss = new LinkedHashMap<String,String>();
        ss.putAll(ExceptionTypeConstant.typeMap);
        ss.put(ExceptionTypeConstant.DEFAULT_TYPE,"Default");
        result.put("allTypes",ss);
        ExceptionLocationManager exceptionMo = (ExceptionLocationManager) AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.EXCEPTION_MONITOR);
        Map<String/*group*/,Pair<Map<String,String>,Map<String, Map<String, Long>>>> group2Exceptions = exceptionMo.exception(nodeGroups,faultDate);
        result.put("group2Exceptions", group2Exceptions);
    }

    private void buildSystemMonitor(List<NodeGroup> nodeGroups, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultLocation> faultLocations, ModelMap result, List<FaultGraphDO> faultGraphs) throws Exception {
        AbstractGraphFaultManager systemFL = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.SYSTEM_MONITOR);
        Map<String,GraphMonitorItemDO> graphItems = systemFL.abnormalGraph(nodeGroups,faultDate,contextDO);
        if ( graphItems != null ){
            faultLocations.addAll(systemFL.fetchFL(graphItems));

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(graphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate);
            if ( kvParams != null && !kvParams.isEmpty() ){
                result.put("systemGraphCount",kvParams.size());
                faultGraphs.add(new FaultGraphDO("<span class=\"label label-success mb5 f14\">ϵͳ���:</span>"+relationDecWithUrl,atomicInteger,graphItems.keySet()));
                totalCustomeParams.addAll(kvParams);
            }
        }
    }

    private void buildConsumer(String tvNodeGroup, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultGraphDO> faultGraphs, Set<String> titles) throws Exception {
        //����ϵͳ��consumer������
        AbstractGraphFaultManager consumerFlowFL = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.CONSUMER_MONITOR);
        Map<String,GraphMonitorItemDO> cGraphItems = consumerFlowFL.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( cGraphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(cGraphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"consumer������");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|consumer����");
                totalCustomeParams.addAll(kvParams);
            }
        }
    }

    private void buildProvider(String tvNodeGroup, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultGraphDO> faultGraphs, Set<String> titles) throws Exception {
        //����ϵͳ��provider������
        AbstractGraphFaultManager providerFlowFL = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.PROVIDER_MONITOR);
        Map<String,GraphMonitorItemDO> graphItems = providerFlowFL.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( graphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(graphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"provider����");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|provider������");
                totalCustomeParams.addAll(kvParams);
            }
        }
    }

    private void buildMeta(String tvNodeGroup, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultGraphDO> faultGraphs, Set<String> titles) throws Exception {
        //����ϵͳ��meta����������
        AbstractGraphFaultManager pMeta = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.META_P);
        Map<String,GraphMonitorItemDO> graphItems = pMeta.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( graphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(graphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"meta����������");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|meta����������");
                totalCustomeParams.addAll(kvParams);
            }
        }

        //����ϵͳ��meta����������
        AbstractGraphFaultManager cMeta = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.META_C);
        Map<String,GraphMonitorItemDO> cGraphItems = cMeta.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( cGraphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(cGraphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"meta����������");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|meta����������");
                totalCustomeParams.addAll(kvParams);
            }
        }
    }


    private void buildNotify(String tvNodeGroup, Date faultDate, ContextDO contextDO, Date startDate, Date endDate, String relationDecWithUrl, AtomicInteger atomicInteger, List<String> totalCustomeParams, List<FaultGraphDO> faultGraphs, Set<String> titles) throws Exception {

        //����ϵͳ��meta����������
        AbstractGraphFaultManager pMeta = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.Notify_P);
        Map<String,GraphMonitorItemDO> graphItems = pMeta.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( graphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(graphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"notify����������");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|notify����������");
                totalCustomeParams.addAll(kvParams);
            }
        }

        //����ϵͳ��meta����������
        AbstractGraphFaultManager cMeta = AbstractGraphFaultManager.graphFaultManagerMap.get(AbstractGraphFaultManager.Notify_C);
        Map<String,GraphMonitorItemDO> cGraphItems = cMeta.abnormalGraph(tvNodeGroup,faultDate,contextDO);
        if ( cGraphItems != null ){

            List<String> kvParams = kvGraphManager.buildParam(AbstractGraphFaultManager.convert(cGraphItems), DataBuilder.graphSizeMap.get("xxs"),startDate,endDate,true,"notify����������");
            if ( kvParams != null && !kvParams.isEmpty() ){
                titles.add(tvNodeGroup+"|notify����������");
                totalCustomeParams.addAll(kvParams);
            }
        }
    }

    private void filter(List<NodeGroup> nodeGroups, String rawApp) throws DAOException {
        //1��ɾ����spe����
        Iterator<NodeGroup> iterator = nodeGroups.iterator();
        Set<String> apps = Sets.newHashSet();
        while (iterator.hasNext()){
            NodeGroup nodeGroup = iterator.next();
            if(nodeGroup.getNodeGroup().endsWith("_spe")){
                iterator.remove();
            }
            apps.add(nodeGroup.getAppName());
        }
        //2.��Ӧ��������5��ʱ�򣬸���bizѡ�������
        if(apps.size() > 5){
            //���base app��ҵ����
            AppDO appDO = appDAO.getAppByName(rawApp);
            if(appDO == null){
                return;
            }
            Integer biz = appDO.getBizType();
            if(biz != null){
                Iterator<NodeGroup> iter = nodeGroups.iterator();
                while (iter.hasNext()){
                    NodeGroup nodeGroup = iter.next();
                    AppDO reApp = appDAO.getAppByName(nodeGroup.getAppName());
                    if(reApp.getBizType()==null){
                        iter.remove();
                    }else if(reApp.getBizType().intValue() != biz){
                        iter.remove();
                    }
                }
            }
        }
    }

    private String buildSceneName(SceneEntryPoint entry){
       return "<span class=\"label label-success mb5 f14\">�������:</span><a href=\"https://safe.trip.taobao.org/scene/scene.htm?spm=0.0.0.0.2oC8Rf&id="+entry.getId()+"\">"+entry.getName()+"</a>" ;
    }
    private String buildAppRelationWithURL(List<NodeGroup> nodeGroups) {
        Set<String> apps = Sets.newHashSet();
        for (NodeGroup nodeGroup : nodeGroups) {
            apps.add(nodeGroup.getAppName());
        }
        StringBuilder sb = new StringBuilder();
        for (String app : apps) {
            sb.append("<a href=\"https://safe.trip.taobao.org/scene/app.htm?app="+app+"\">"+app+",</a>");
        }
        return sb.toString();
    }

    private String buildAppRelation(List<NodeGroup> nodeGroups) {
        Set<String> apps = Sets.newHashSet();
        for (NodeGroup nodeGroup : nodeGroups) {
            apps.add(nodeGroup.getAppName());
        }

        return Joiner.on(",").join(apps);
    }

    private String buildRelation(List<NodeGroup> nodeGroups, int relationLevel) {
        Map<Integer,Set<String>> map = Maps.newHashMap();
        for (NodeGroup nodeGroup : nodeGroups) {
            if(!map.containsKey(nodeGroup.getLevel())){
                map.put(nodeGroup.getLevel(), Sets.<String>newHashSet());
            }
            map.get(nodeGroup.getLevel()).add(nodeGroup.getNodeGroup());
        }
        StringBuilder sb = new StringBuilder();
        for(int i = -relationLevel;i<=relationLevel;i++){
            Set<String> curGroups = map.get(i);
            if(CollectionUtils.isNotEmpty(curGroups)){
                sb.append(Joiner.on(",").join(curGroups)).append("->");
            }
        }
        if(sb.length() > 0){
            return sb.substring(0,sb.length()-2);
        }
        return sb.toString();
    }

    public enum LocationDimension{
        scene,realtionApp,singleApp
    }
}
