package com.taobao.ateye.controller.scene;

import java.io.PrintWriter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.dal.GocEmgMessageDAO;
import com.taobao.ateye.dataobject.GocEmgMessageDO;
import com.taobao.ateye.goc.emg.GocEmgExtendModel;
import com.taobao.ateye.util.CalendarUtil;
import com.taobao.ateye.util.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.goc.GocFaultModelListDO;
import com.taobao.ateye.goc.emg.GocEmgExtendManager;
import com.taobao.ateye.goc.emg.GocEmgModelListDO;
import com.taobao.security.util.SecurityUtil;
@Controller
@RequestMapping("/scene")
public class SceneGocController extends AbstractController{
	private static final String GOC_FAULT_LIST = "screen/scene/gocFaultList";
	private static final String GOC_EMG_LIST = "screen/scene/gocEmgList";
	private static final String GOC_MSG_LIST = "screen/scene/gocMsgList";


	@Autowired
	private GocEmgExtendManager gocEmgExtendManager;

	@Autowired
	private GocEmgMessageDAO gocEmgMessageDAO;

	@RequestMapping("gocMsgList.htm")
	public String gocMsgList(final HttpServletRequest request, final ModelMap result) throws Exception {

		String fltMonth= request.getParameter("fltMonth");
		if ( StringUtils.isNotBlank(fltMonth) ){
			result.put("fltMonth",fltMonth);
		}else{
			fltMonth = CalendarUtil.formatDate(new Date(),"yyyy-MM");
			result.put("fltMonth",fltMonth);
		}
		Calendar calendar = Calendar.getInstance();
		Date statDate = CalendarUtil.toDate(fltMonth,"yyyy-MM");
		calendar.setTime(statDate);
		calendar.add(Calendar.MONTH,1);
		Date endDate = calendar.getTime();

		List<GocEmgMessageDO> gocMsgs = gocEmgMessageDAO.getByDate(statDate,endDate);
		if(CollectionUtils.isNotEmpty(gocMsgs)){
			Collections.sort(gocMsgs, new Comparator<GocEmgMessageDO>() {
				@Override
				public int compare(GocEmgMessageDO o1, GocEmgMessageDO o2) {
					if(o1.getMsgCreateTime().after(o2.getMsgCreateTime())){
						return -1;
					}else if(o1.getMsgCreateTime().before(o2.getMsgCreateTime())){
						return 1;
					}
					return 0;
				}
			});
		}
		//����������չ
		Map<String, GocEmgExtendModel> allExtendMap = gocEmgExtendManager.getAllExtendMap();

		result.put("allExtendMap", allExtendMap);
		result.put("gocMsgs", gocMsgs);
		return GOC_MSG_LIST;

	}

	@RequestMapping("emgList.htm")
	public String emgList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();

		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltApp = request.getParameter("fltApp");
		if ( StringUtils.isNotBlank(fltApp) ){
			flts.put("app", fltApp);
			result.put("fltApp",fltApp);
		}
		String fltScene = request.getParameter("fltScene");
		if ( StringUtils.isNotBlank(fltScene) ){
			flts.put("scene", fltScene);
			result.put("fltScene",fltScene);
		}
		String fltHasScene = request.getParameter("fltHasScene");
		if ( StringUtils.isNotBlank(fltHasScene) ){
			flts.put("hasScene", fltHasScene);
			result.put("fltHasScene",fltHasScene);
		}
		String fltNamePath = request.getParameter("fltNamePath");
		if ( StringUtils.isNotBlank(fltNamePath) ){
			flts.put("namepath", fltNamePath);
			result.put("fltNamePath",fltNamePath);
		}
		String alarmId = request.getParameter("alarmId");
		if ( StringUtils.isNotBlank(alarmId) ){
			flts.put("alarmId", alarmId);
			result.put("alarmId",alarmId);
		}
		GocEmgModelListDO gocList = gocEmgManager.queryGocEmgList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = gocList.getFltMap();
		result.put("levelFlt", fltMap.get("level"));
		result.put("appFlt", fltMap.get("app"));
		result.put("sceneFlt", fltMap.get("scene"));
		result.put("hasSceneFlt", fltMap.get("hasScene"));
		result.put("namepathFlt", fltMap.get("namepath"));
		result.put("bizMap",getBizMap());
		result.put("gocEmgList",gocList.getRetList());
		result.put("fullShow", "true");
		return GOC_EMG_LIST; 
		
	}
	@RequestMapping("updateGocEmgAppAjax.htm")
	public String updateSceneDescAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String alarmId = request.getParameter("alarmId");
		String app = request.getParameter("value");
		PrintWriter out = response.getWriter();
		Map<String,String> ret = new HashMap<String,String>();
		if ( StringUtils.isNotBlank(alarmId) && StringUtils.isNotBlank(app) ){
			 gocEmgExtendManager.updateApp(alarmId, app);
		}
		ret.put("success", "true");
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }
	@RequestMapping("removeGocEmgSceneAjax.htm")
	public String removeGocEmgSceneAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String alarmId = request.getParameter("alarmId");
		String scene = request.getParameter("scene");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(alarmId) && StringUtils.isNotBlank(scene) ){
			boolean isSucc = gocEmgExtendManager.removeScene(alarmId, scene);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
	}
	@RequestMapping("addGocEmgSceneAjax.htm")
	public String addGocEmgSceneAjax(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String alarmId = request.getParameter("alarmId");
		String scene = request.getParameter("scene");
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(alarmId) && StringUtils.isNotBlank(scene) ){
			boolean isSucc = gocEmgExtendManager.addScene(alarmId, scene);
			ret.put("success", isSucc?"true":"false");
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
	}

	@RequestMapping("faultList.htm")
	public String faultList(final HttpServletRequest request, final ModelMap result) throws Exception {
		Map<String, String> flts = new HashMap<String,String>();

		String fltBiz = request.getParameter("fltBiz");
		if ( StringUtils.isNotBlank(fltBiz) ){
			flts.put("biz", fltBiz);
			result.put("fltBiz",fltBiz);
		}
		String fltLevel= request.getParameter("fltLevel");
		if ( StringUtils.isNotBlank(fltLevel) ){
			flts.put("level", fltLevel);
			result.put("fltLevel",fltLevel);
		}
		String fltSource= request.getParameter("fltSource");
		if ( StringUtils.isNotBlank(fltSource) ){
			flts.put("source", fltSource);
			result.put("fltSource",fltSource);
		}
		String fltMonth= request.getParameter("fltMonth");
		if ( StringUtils.isNotBlank(fltMonth) ){
			flts.put("month", fltMonth);
			result.put("fltMonth",fltMonth);
		}
		String fltBu= request.getParameter("fltBu");
		if ( StringUtils.isNotBlank(fltBu) ){
			flts.put("bu", fltBu);
			result.put("fltBu",fltBu);
		}
		GocFaultModelListDO gocList = gocFaultManager.queryGocFaultList(flts);
		
		Map<String, List<Pair<String, Integer>>> fltMap = gocList.getFltMap();
		result.put("bizFlt", formatToInt(fltMap.get("biz"),getBizMap()));
		result.put("sourceFlt", fltMap.get("source"));
		result.put("levelFlt", fltMap.get("level"));
		result.put("monthFlt", fltMap.get("month"));
		result.put("buFlt", fltMap.get("bu"));
		result.put("bizMap",getBizMap());
		result.put("ownerFlt",userCache.getNickMap().keySet());
		result.put("gocFaultList",gocList.getRetList());
		result.put("empIdMap",userCache.getEmpIdMap());
		result.put("fullShow", "true");
		return GOC_FAULT_LIST; 
		
	}
	
}
