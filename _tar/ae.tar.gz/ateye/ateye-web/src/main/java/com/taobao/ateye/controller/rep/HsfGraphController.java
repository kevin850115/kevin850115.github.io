package com.taobao.ateye.controller.rep;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taobao.ateye.config.app.AppConfig;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.graphviz.GrahvizManager;
import com.taobao.ateye.hsf.relation.HsfRelationManager;
import com.taobao.ateye.util.DateFormatUtil;
import com.taobao.util.CalendarUtil;

@Controller
@RequestMapping("/hsfgraph")
public class HsfGraphController extends AbstractController{
	
	@Autowired
	private GrahvizManager grahvizManager;
	@Autowired
	private HsfRelationManager hsfRelationManager;
	private static final String LIST_ALL= "screen/hsfgraph/listAll";
	private static final String LIST_ALL2= "screen/hsfgraph/listAll2";
	private static final String APP_LIST= "screen/hsfgraph/appList";
	private static final String GENERATE_STAT = "screen/hsfgraph/generateStat";
	
	@RequestMapping("appList.htm")
    public String appList(final HttpServletRequest request, ModelMap result) throws DAOException {
	  	result.put("to", "/hsfgraph/graphApp.htm");
    	result.put("level2","HSF��ϵ");
    	result.put("level2Url","/hsfgraph/appList.htm");
    	Map<String, List<List<String>>> bizMap= initBizMapOwned(result);
        if ( bizMap == null ){
			return "redirect:/noPermission.htm";
        }
        return APP_LIST;
    }	
	@RequestMapping("generateStat.htm")
	public String generateStat(final HttpServletRequest request, ModelMap result) throws Exception {
		String day = request.getParameter("day");
		Date startDate = null;
		if(StringUtils.isNotBlank(day)) {
			startDate = DateFormatUtil.parseByDay(day);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),0);
			String sd = CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3);
			result.put("current",sd);
			return GENERATE_STAT;
		}
		String sd = CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3);
		result.put("current",sd);
		hsfRelationManager.generateHsfRelation(startDate);
		result.put("result","HSFͳ���������ɳɹ�:"+sd);
		return GENERATE_STAT;
		
	}
	@RequestMapping("generate.htm")
	public String generate(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String homepage = request.getParameter("homepage");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),0);
		}
		String sd = CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3);
		result.put("startDate",sd);
		hsfRelationManager.generateHsfRelation(startDate);
		if ( homepage == null ){
			return "redirect:/hsfgraph/graphAll.htm?startDate="+sd;
		}else{
			return "redirect:/index.htm";
		}
		
	}
	@RequestMapping("graphBiz.htm")
	public String graphBiz(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String biz = request.getParameter("biz");
		if ( StringUtils.isBlank(biz) ){
			return "";
		}
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),-1);
		}
		result.put("startDate",CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3));
		List<List<String>> appList = AppConfig.groupApps().get(biz);
		String[] apps = new String[appList.size()];
		for (int i=0;i<appList.size();++i ){
			apps[i] = appList.get(i).get(0);
		}
		result.put("biz",biz);
		result.put("gtxt", grahvizManager.getHsfServiceRelationOfApps(startDate, apps,biz,isUseNewGraph(request)));
		
		return useTemplate(request);
	}
	@RequestMapping("graphAll.htm")
	public String graphAll(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),-1);
		}
		result.put("startDate",CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3));

		result.put("gtxt", grahvizManager.getHsfServiceRelation(startDate,isUseNewGraph(request)));
		result.put("all", 1);
		return useTemplate(request);
	}
	@RequestMapping("graphApp.htm")
	public String graphApp(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String app = request.getParameter("app");
		if ( StringUtils.isBlank(app) ){
			return "";
		}
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),-1);
		}
		result.put("app",app);
		result.put("startDate",CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3));
		
		result.put("gtxt", grahvizManager.getHsfServiceRelationOfApp(startDate, app,isUseNewGraph(request)));
		
		return useTemplate(request);
	}
	private boolean isUseNewGraph(HttpServletRequest request){
		String newJs = request.getParameter("new");
		if ( StringUtils.isNotBlank(newJs) && newJs.equals("1") ){
			return true;
		}
		return false;
	}
	private String useTemplate(HttpServletRequest request){
		String newJs = request.getParameter("new");
		if ( StringUtils.isNotBlank(newJs) && newJs.equals("1") ){
			return LIST_ALL2;
		}
		return LIST_ALL;
	}
	@RequestMapping("graphApps.htm")
	public String graphApps(final HttpServletRequest request, ModelMap result) throws Exception {
		String startDateStr = request.getParameter("startDate");
		String apps = request.getParameter("apps");
		if ( StringUtils.isBlank(apps) ){
			return "";
		}
		String[] appArrs = apps.split(",");
		Date startDate = null;
		if(StringUtils.isNotBlank(startDateStr)) {
			startDate = DateFormatUtil.parseByDay(startDateStr);
		} else {
			startDate = DateUtils.addDays(CalendarUtil.zerolizedTime(new Date()),-1);
		}
		result.put("apps",apps);
		result.put("startDate",CalendarUtil.toString(startDate, CalendarUtil.DATE_FMT_3));
		result.put("gtxt", grahvizManager.getHsfServiceRelationOfApps(startDate, appArrs,"��ѡӦ��",isUseNewGraph(request)));
		
		return useTemplate(request);
	}
}
