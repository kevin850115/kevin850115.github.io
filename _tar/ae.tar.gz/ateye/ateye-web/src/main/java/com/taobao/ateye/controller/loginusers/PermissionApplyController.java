package com.taobao.ateye.controller.loginusers;

import java.util.*;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.buc.api.EnhancedUserQueryService;
import com.alibaba.buc.api.exception.BucException;
import com.alibaba.buc.api.grant.GrantRolesToUserParam;
import com.alibaba.buc.api.param.Action;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.taobao.ateye.service.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.common.lang.StringUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.config.AteyeConfig;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.PermissionApplyDO;
import com.taobao.ateye.dataobject.RoleDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.notify.NotifyService;
import com.taobao.ateye.permission.PermissionManager;
import com.taobao.ateye.user.UserNameConverter;

/**
 * Ȩ������
 *
 * @author guangu.lj
 * @verion 0.1.0
 */
@Controller
public class PermissionApplyController {
    private static Logger logger = Logger.getLogger("PermissionApplyLogger");

    @Autowired
    private RoleService roleService;
    @Autowired
    private UserService userService;
    @Autowired
    private PermissionManager permissionManager;
    @Autowired
    private NotifyService notifyService;
    @Autowired
    private AteyeConfig ateyeConfig;
    @Autowired
    private EnhancedUserQueryService enhancedUserQueryService;

    @Autowired
    protected EnvironmentService environmentService;
    @Autowired
    private com.alibaba.buc.api.GrantService aclGrantService;

    @Autowired
    private AclSyncUtil aclSyncUtil;



    /**
     * @return the userService
     */
    public UserService getUserService() {
        return userService;
    }

    /**
     * @param userService the userService to set
     */
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Autowired
    private OpsServic opsServic;
    @Autowired
    private PermissionApplyService permissionApplyService;

    @RequestMapping("/permissionApply/apply.htm")
    public String permissionApply(HttpServletRequest request, final ModelMap result) {
        try {
            String nick = (String) request.getAttribute("ateye_nick");
            if (StringUtils.isBlank(nick)) {
                return "redirect:/noPermission.htm";
            }

            // ��ʼ��ҳ������
            List<RoleDO> list = roleService.getAllRoleList();
            List<AppDO> apps = opsServic.getAllApps();
            result.put("nick", nick);
            result.put("apps", apps);
            result.put("allRoles", list);

            UserDO user = (UserDO) MyThreadLocal.get();
            if (user != null) {
                List<RoleDO> userRoleList = roleService.getUserRoleList(user.getId());
                user.setRoleList(userRoleList);
                result.put("user", user);
                List<AppDO> userapps = this.opsServic.getAllAppsBelongToAUser(user.getId());
                result.put("userapps", userapps);
            }
        } catch (Exception e) {
            result.put("error", "ϵͳ�쳣������ϵ����Ա");
            logger.error("����Ȩ������Ҳ�쳣 ", e);
        }
        return "screen/permissionApply";
    }

    @RequestMapping("/permissionApply/save.htm")
    public String applySave(HttpServletRequest request, final PermissionApplyDO apply, @RequestParam(value = "roleId", required = false) String[] roles, @RequestParam(value = "roleapp", required = false) String[] apps, final ModelMap result) {
        try {
            String nick = (String) request.getAttribute("ateye_nick");
            if (StringUtils.isBlank(nick)) {
                return "redirect:/noPermission.htm";
            }

            // ������ɫ����
            StringBuffer roleIds = new StringBuffer();
            if (roles != null && roles.length > 0) {
                for (int i = 0; i < roles.length; i++) {
                    roleIds.append(roles[i]);
                    if (i != roles.length - 1) {
                        roleIds.append(",");
                    }
                }
                apply.setRoleIds(roleIds.toString());
            } else {// ��ɫֵ����Ϊ��
                result.put("error", "����ʧ�ܣ�������ָ��һ��������ɫ��");
                return permissionApply(request, result);
            }

            // ����Ӧ��
            StringBuffer appNames = new StringBuffer();
            if (apps != null && apps.length > 0) {
                for (int i = 0; i < apps.length; i++) {
                    appNames.append(apps[i]);
                    if (i != apps.length - 1) {
                        appNames.append(",");
                    }
                }
            } else {
                result.put("error", "����ʧ�ܣ�������Ӧ��ѡ��һ��Ӧ��");
                return permissionApply(request, result);
            }
            apply.setAppNames(appNames.toString());

            // �����ǳƣ�״̬λ0 δ����
            apply.setNick(nick);
            apply.setStatus(0);

            // ְλУ��
            String title = apply.getTitle();
            int titleLength = title.length();
            if (titleLength < 1 || titleLength > 50) {
                result.put("error", "����ʧ�ܣ�ְλ������1-50֮�䡣");
                return permissionApply(request, result);
            }

            int rLength = apply.getReason().length();
            if (rLength > 250) {
                result.put("error", "����ʧ��, �������ɳ���ҪС��250��");
                return permissionApply(request, result);
            }
            // ���������¼
            int applyId = permissionApplyService.insertApply(apply);

            if (-1 != applyId) {// ����ɹ�
                result.put("info", "����ɹ���ϵͳ����Ա���ڶ�ʱ���ڽ��и�Ȩ�޵�����������");
                logger.info("�����¼��" + apply.toString());
            } else {
                result.put("error", "Ȩ������ʧ��");
                logger.error("����Ȩ�ޱ��浽����ʱ������apply����Ϊ��" + apply.toString());
            }
            // ����������Ϣ
            String snsTitle = "���µ�Ȩ����Ҫ����";
            String ip = "http://" + ateyeConfig.getAteyeDomain() + "/manager/permissionApply/applyDetail.htm?id=" + applyId;
            String content = "�û� " + nick + "��ateye�Ͻ�����Ȩ������,�������url�鿴:\n";
            content = content + "<a href=\"" + ip + "\">" + ip + "</a>";
            String wangWangs = ateyeConfig.getSnsReciver();
            if (StringUtil.isBlank(wangWangs)) {
                result.put("error", "����֪ͨ��Ϊ�գ�����Ҫ֪ͨAteyeϵͳ����Ա���и�Ȩ�޵�����");
                return permissionApply(request, result);
            }
            String[] wangWangArray = wangWangs.split(",");

            for (String wangwang : wangWangArray) {
                Boolean WangWangResult = notifyService.sendWangWang(wangwang, snsTitle, content);
                if (WangWangResult) {
                    logger.info("��Ϣ�ɹ����͵��˹���Ա" + wangwang + "��\n��Ϣ���ݣ�" + content);
                } else {
                    logger.error("��Ϣ����������Աʱ������" + wangwang + "��\n��Ϣ���ݣ�" + content);
                }
            }

        } catch (Exception e) {
            result.put("error", "Ȩ������ʧ��,ϵͳ�쳣");
            logger.error("����Ȩ�ޱ��浽����ʱ������apply����Ϊ��" + apply, e);
        }
        return permissionApply(request, result);
    }

    @RequestMapping("/manager/permissionApply/applysList.htm")
    public String applysList(final ModelMap result) throws Exception {

        // ��ʼ��ҳ������
        List<PermissionApplyDO> list = permissionApplyService.getNotApproveApplys();
        result.put("applyList", list);
        Set<String> nicks = new HashSet<String>();
        for (PermissionApplyDO a : list) {
            nicks.add(a.getNick());
        }
        Map<String, String> users = UserNameConverter.convert(nicks);
        result.put("userNames", users);
        return "screen/permissionApply/applysList";

    }

    @RequestMapping("/manager/permissionApply/applyDetail.htm")
    public String applyDetail(@RequestParam("id") final int id, final ModelMap result) throws Exception {

        // ��ʼ��ҳ������
        PermissionApplyDO apply = permissionApplyService.getApplyById(id);
        StringBuffer roles = new StringBuffer();
        String roleIds = apply.getRoleIds();
        String[] ids = roleIds.split(",");
        int length = ids.length;
        if (length > 0) {
            for (int i = 0; i < length; i++) {
                long roleId = Long.valueOf(ids[i]);
                RoleDO role = roleService.getRoleById(roleId);
                roles.append(role.getDescription());
                if (i != (length - 1)) {
                    roles.append(",");
                }
            }
        }
        result.put("nn", UserNameConverter.convert(apply.getNick()));

        result.put("roles", roles.toString());
        result.put("apply", apply);
        return "screen/permissionApply/applyDetail";
    }

    @RequestMapping("/manager/permissionApply/applyApprove.htm")
    public String applyApprove(@RequestParam("id") final int id, @RequestParam("status") final int status, final ModelMap result) throws Exception {

        if (status != 1 && status != 2) {
            result.put("error", "����ʧ�ܣ������Ƿ�");
            return applysList(result);
        }

        // ���������¼��
        if (status == 2) {
            permissionApplyService.approveApply(id, PermissionApplyDO.STATUS_REJECT);
            result.put("info", "�����ɹ�");
            return applysList(result);
        }

        try {
            //����acl��ɫ��url����Ȩ��
            aclSyncUtil.grantUserAclRolePermission(id);

        } catch (Exception e) {
            result.put("error", "Ȩ������ʧ��,aclͬ�������쳣");
            logger.error("Ȩ������ʧ��,aclͬ������ʱ������apply id��" + id, e);
        }

        permissionManager.approve(id);

        return applysList(result);
    }

    /**
     * @return the ateyeRoleService
     */
    public RoleService getAteyeRoleService() {
        return roleService;
    }

    /**
     * @param ateyeRoleService the ateyeRoleService to set
     */
    public void setAteyeRoleService(RoleService ateyeRoleService) {
        this.roleService = ateyeRoleService;
    }

    /**
     * @return the opsServic
     */
    public OpsServic getOpsServic() {
        return opsServic;
    }

    /**
     * @param opsServic the opsServic to set
     */
    public void setOpsServic(OpsServic opsServic) {
        this.opsServic = opsServic;
    }

    /**
     * @return the permissionApplyService
     */
    public PermissionApplyService getPermissionApplyService() {
        return permissionApplyService;
    }

    /**
     * @param permissionApplyService the permissionApplyService to set
     */
    public void setPermissionApplyService(PermissionApplyService permissionApplyService) {
        this.permissionApplyService = permissionApplyService;
    }

    /**
     * @return the notifyService
     */
    public NotifyService getNotifyService() {
        return notifyService;
    }

    /**
     * @param notifyService the notifyService to set
     */
    public void setNotifyService(NotifyService notifyService) {
        this.notifyService = notifyService;
    }

    /**
     * @return the ateyeConfig
     */
    public AteyeConfig getAteyeConfig() {
        return ateyeConfig;
    }

    /**
     * @param ateyeConfig the ateyeConfig to set
     */
    public void setAteyeConfig(AteyeConfig ateyeConfig) {
        this.ateyeConfig = ateyeConfig;
    }
}
