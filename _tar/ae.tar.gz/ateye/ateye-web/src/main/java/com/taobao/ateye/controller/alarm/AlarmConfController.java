package com.taobao.ateye.controller.alarm;

import java.io.PrintWriter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.taobao.ateye.alarm.n.enu.StatusEnu;
import com.taobao.ateye.dal.*;
import com.taobao.ateye.dataobject.*;
import com.taobao.ateye.util.CalendarUtil;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.Lists;
import com.taobao.ateye.alarm.n.enu.SubscriberEnu;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.alarm.data.AlarmSubscriber;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.security.util.SecurityUtil;

/**
 * Created by sunqiang on 2018/12/17.
 */
@Controller
@RequestMapping("/alarm")
public class AlarmConfController extends AbstractAlarmController {
    private static final String ALARM_SUB_LIST = "screen/alarm/subConf";

    @Autowired
    private AteyeAlarmSubscriberDAO subscriberDAO;
    @Autowired
    private UserDAO userDAO;

    @Autowired
    private AteyeAlarmRecordDAO recordDAO;

    @Autowired
    private AlarmGroupDAO alarmGroupDAO;

    @RequestMapping("subConf.htm")
    public String subConf(final HttpServletRequest request, ModelMap result) throws DAOException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        if(StringUtils.isEmpty(type)){
            type = SubscriberEnu.DINGGROUP.getValue()+"";
        }
        List<AteyeAlarmSubscriberDO> alarmSubscribers = null;

        Integer biz = getBiz(request);
        alarmSubscribers = subscriberDAO.select(biz,name,StringUtils.isNotEmpty(type)?Integer.parseInt(type):null);

        validSubScriber(alarmSubscribers);
        Map<Integer,BizLineDO> bizMap= getBizMap();

        result.put("biz",biz);
        result.put("name",name);
        result.put("type",type);
        result.put("groups", convert(alarmSubscribers,bizMap));
        result.put("nick", user.getNick());
        result.put("bizMap", bizMap);
        result.put("subTypeMap", SubscriberEnu.getSubTypeMap());
        return ALARM_SUB_LIST;
    }

    private List<AlarmSubscriber> convert(List<AteyeAlarmSubscriberDO> alarmSubscribers, Map<Integer, BizLineDO> bizMap) throws DAOException {
        List<AlarmSubscriber> result = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(alarmSubscribers)){
            for (AteyeAlarmSubscriberDO alarmSubscriber : alarmSubscribers) {
                AlarmSubscriber sub = new AlarmSubscriber();
                //���챨����
                int count = recordDAO.countRealBySubIdStartTime(alarmSubscriber.getId(), CalendarUtil.zerolizedTime(new Date()));
                sub.setAlarmCount(count);
                //��������
                List<AteyeAlarmSubRelationDO> rules = relationDAO.selectAppScopeBySubId(alarmSubscriber.getId(),environmentService.getEnvironmentType().getEnv());
                if(CollectionUtils.isNotEmpty(rules)){
                    Iterator<AteyeAlarmSubRelationDO> iterator = rules.iterator();
                    while(iterator.hasNext()){
                        AteyeAlarmSubRelationDO subRelationDO = iterator.next();
                        AteyeAlarmConfDO confDO = confDAO.selectById(subRelationDO.getAlarmConfId());
                        if(confDO == null){
                            iterator.remove();
                        }
                        if(confDO.getStatus()== StatusEnu.DELETE.getValue()){
                            iterator.remove();
                        }
                    }
                    sub.setRuleCount(rules.size());
                }

                sub.setId(alarmSubscriber.getId());
                sub.setEnv(environmentService.getEnvironmentType().getEnv());
                sub.setValue(alarmSubscriber.getValue());
                sub.setIsDelete(alarmSubscriber.getIsDelete());
                sub.setName(alarmSubscriber.getName());
                sub.setOperator(alarmSubscriber.getOperator());
                sub.setGmtCreate(alarmSubscriber.getGmtCreate());
                sub.setGmtModified(alarmSubscriber.getGmtModified());
                sub.setType(alarmSubscriber.getType());
                if(alarmSubscriber.getBiz()>0){
                    BizLineDO bizLineDO = bizMap.get(alarmSubscriber.getBiz());
                    if(bizLineDO!=null){
                        sub.setBizName(bizLineDO.getName());
                        sub.setBiz(alarmSubscriber.getBiz());
                    }

                }else if(alarmSubscriber.getType()==SubscriberEnu.HUAMING.getValue()){
//                    UserDO userDO = userDAO.getUserByNick(alarmSubscriber.getName());

                }
                result.add(sub);
            }
        }
        return result;
    }

    @RequestMapping("updateSubConf.htm")
    public String updateSubConf(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
        Map<String,String> ret = new HashMap<String,String>();
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String value = request.getParameter("value");

        if ( StringUtils.isNotEmpty(id) && StringUtils.isNotBlank(value) ){
            int update = subscriberDAO.updateValue(Long.parseLong(id),value);
            ret.put("success", update>0?"true":"false");
        }else{
            ret.put("success", "false");
        }
        String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
        out.print(SecurityUtil.escapeJson(json));
        return null;
    }
	@RequestMapping("updateAlarmGroupBizById.htm")
	public String updateAlarmGroupBizById(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String bizId = request.getParameter("bizId");//ҵ����ID
		Map<String,String> ret = new HashMap<String,String>();
		PrintWriter out = response.getWriter();
		if ( StringUtils.isNotBlank(id) && StringUtils.isNotBlank(bizId) ){
			Long biz = Long.valueOf(bizId);
			BizLineDO bizLineDO = bizLineDAO.getAllBizLineMap().get(biz);
			if ( bizLineDO == null ){
				ret.put("success", "false");
			}else{
				int update = subscriberDAO.updateBiz(Long.valueOf(id), bizLineDO.getId());
				ret.put("success", update>0?"true":"false");
			}
		}else{
			ret.put("success", "false");
		}
		String json = JSON.toJSONString(ret, SerializerFeature.BrowserCompatible);
		out.print(SecurityUtil.escapeJson(json));
		return null;
    }

    @RequestMapping("removeSubConf.htm")
    public String removeSubConf(final HttpServletRequest request, ModelMap result) throws DAOException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        Long id = Long.parseLong(request.getParameter("id"));
        AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.selectById(id);
        if(subscriberDO!=null){
            AteyeAlarmSubscriberDO existDelete = subscriberDAO.getByUk(subscriberDO.getName(),environmentService.getEnvironmentType().getEnv(),1);
            if(existDelete !=null){
                //�˴�Ϊ�˷�ֹһ�����ƶ��ɾ����Ϊ�˱���Ψһ����������һ������
                subscriberDAO.updateName(existDelete.getId(),existDelete.getName()+"_"+ RandomUtils.nextInt(0,100));
            }
        }
        subscriberDAO.updateStatus(id,1);
        String biz = request.getParameter("biz");
        return "redirect:/alarm/subConf.htm?biz="+biz;
    }

    @RequestMapping("addSubConf.htm")
    public String addSubConf(final HttpServletRequest request, ModelMap result) throws DAOException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        Integer type = SubscriberEnu.DINGGROUP.getValue();
        String name = request.getParameter("name");
        String value = request.getParameter("value");
        Integer biz = Integer.parseInt(request.getParameter("biz"));
        AteyeAlarmSubscriberDO sub = new AteyeAlarmSubscriberDO();
        sub.setName(name);
        sub.setEnv(environmentService.getEnvironmentType().getEnv());
        sub.setOperator(user.getNick());
        sub.setValue(value);
        sub.setType(type);
        if(SubscriberEnu.HUAMING.getValue()!=type){
            sub.setBiz(biz);
        }
        addOldGroup(biz,name,value,user.getNick());
        subscriberDAO.insert(sub);
        return "redirect:/alarm/subConf.htm";
    }

    public void addOldGroup(Integer biz,String name,String dingdingToken,String nick){
        try{
            AteyeAlarmGroupDO group = new AteyeAlarmGroupDO();
            group.setBiz(biz);
            group.setName(name);
            group.setOperator(nick);
            group.setToken(dingdingToken);

            alarmGroupDAO.insert(group);
        }catch(Throwable t){

        }
    }

    private void validSubScriber(List<AteyeAlarmSubscriberDO> alarmSubscribers) {
        Iterator<AteyeAlarmSubscriberDO> iterator =  alarmSubscribers.iterator();
        while(iterator.hasNext()){
            AteyeAlarmSubscriberDO sub = iterator.next();
            if(sub.getIsDelete() == 1){
                iterator.remove();
            }
        }
    }
}
