package com.taobao.ateye.controller.alarm;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.common.collect.Lists;
import com.taobao.ateye.alarm.n.enu.AppScopeEnum;
import com.taobao.ateye.alarm.n.enu.RuleTypeMergeEnum;
import com.taobao.ateye.alarm.n.enu.StatusEnu;
import com.taobao.ateye.alarm.n.manager.AlarmRuleContextManager;
import com.taobao.ateye.alarm.n.util.ExtendUUIDUtil;
import com.taobao.ateye.authority.MyThreadLocal;
import com.taobao.ateye.controller.alarm.data.AlarmAppScopeRelation;
import com.taobao.ateye.controller.alarm.data.AlarmPersonalized;
import com.taobao.ateye.dal.AlarmConfPersonalizedDAO;
import com.taobao.ateye.dal.AteyeAlarmRecordDAO;
import com.taobao.ateye.dal.AteyeAlarmSubscriberDAO;
import com.taobao.ateye.dataobject.AlarmConfPersonalizedDO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.dataobject.AteyeAlarmRecordDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubRelationDO;
import com.taobao.ateye.dataobject.AteyeAlarmSubscriberDO;
import com.taobao.ateye.dataobject.BizLineDO;
import com.taobao.ateye.dataobject.UserDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.util.CollectionUtils;
import com.taobao.ateye.util.reflect.NumberUtils;
import com.taobao.ateye.util.reflect.StringUtils;

/**
 * Created by sunqiang on 2019/1/28.
 */
@Controller
@RequestMapping("/alarm")
public class AlarmConfPersonalizedController  extends AbstractAlarmController {

    @Autowired
    private AteyeAlarmRecordDAO recordDAO;

    @Autowired
    private AteyeAlarmSubscriberDAO subscriberDAO;

    @Autowired
    private AlarmConfPersonalizedDAO personalizedDAO;

    private static final String ALARM_PERSONALIZED_LIST = "screen/alarm/personalizedList";

    @RequestMapping("personalizedList.htm")
    public String detail(final HttpServletRequest request, ModelMap result) throws DAOException, UnsupportedEncodingException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        if(!AlarmRuleContextManager.PERONALIZED_ALARM_ON){
            result.put("errorMsg", "���Ի��������ÿ��عر���");
            return ALARM_PERSONALIZED_LIST;
        }
        String recordId = request.getParameter("recordId");
        String extendUUID = request.getParameter("extendUUID");
        String exTypes = request.getParameter("exTypes");
        String confId = request.getParameter("confId");
        String detail = request.getParameter("detail");
        if(StringUtils.isNotEmpty(detail)){
            detail = URLDecoder.decode(detail,"utf8");
        }
        result.put("detail",detail);
        if(StringUtils.isNotEmpty(recordId) && NumberUtils.isNumber(recordId)){
            AteyeAlarmRecordDO recordDO = recordDAO.selectById(Long.parseLong(recordId));
            if(recordDO != null){
                AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.selectById(recordDO.getSubId());
                AteyeAlarmConfDO confDO = confDAO.selectById(recordDO.getAlarmConfId());
                if(StringUtils.isEmpty(confId) && confDO != null){
                    confId = confDO.getId()+"";
                }
//                List<AteyeAlarmItemRuleSingleDO> singleDOS = alarmItemRuleSingleDAO.selectByConfId(confDO.getId());
//                if(CollectionUtils.isNotEmpty(singleDOS)){
//                    BigDecimal threshold = alarmItemRuleSingleDAO.selectByConfId(confDO.getId()).get(0).getThreshold();
//                    result.put("threshold",threshold);
//                }
                result.put("record",recordDO);
                result.put("confDO",confDO);
//                result.put("hourStart",confDO.getHourStart()==null?"0":confDO.getHourStart()+"");
//                result.put("hourEnd",confDO.getHourEnd()==null?"24":confDO.getHourEnd()+"");
                result.put("subscriberDO",subscriberDO);
                AppDO appDO = appDAO.getAppByName(recordDO.getApp());
                if(appDO != null){
                    Map<Long,BizLineDO>bizLineDOMap= bizLineDAO.getAllBizLineMap();
                    result.put("bizLineDO",bizLineDOMap.get(appDO.getBizType()));
                }
            }

        }
        //��ȡȫ�ֹ���
        if(StringUtils.isNotEmpty(confId)){
        	List<AteyeAlarmSubRelationDO> relations = relationDAO.getValidByConfId(Long.parseLong(confId), environmentService.getEnvironmentType().getEnv());
        	if ( relations != null && relations.size() >= 1){
        		AteyeAlarmSubRelationDO ateyeAlarmSubRelationDO = relations.get(0);
        		long subId = ateyeAlarmSubRelationDO.getSubId();
        		 //2.�������Ĺ�ϵ
                List<AlarmAppScopeRelation> scorpRelations = buildAppScopeConf(subId,Long.parseLong(confId));
                if (scorpRelations.size()>0){
	                result.put("rule", scorpRelations.iterator().next());
                }
		        //1.�������Ĺ�ϵ
		        AteyeAlarmSubscriberDO subscriberDO = subscriberDAO.selectById(subId);
		        if(subscriberDO==null){
		            result.put("subName", "");
		        }else{
		            result.put("subName", subscriberDO.getName());
		        }
		        //3.��ȡҵ����
		        if (subscriberDO != null ){
		        	Integer biz = subscriberDO.getBiz();
		        	BizLineDO bizLineDO = bizLineDAO.getAllBizLineMap().get(Long.valueOf(biz));
		        	if ( bizLineDO != null ){
		        		result.put("bizLineDO", bizLineDO);
		        	}
		        }
        	}
        }
        result.put("ruleMergeGroupMap", RuleTypeMergeEnum.getGroupMap());
        result.put("ruleMergeMap", RuleTypeMergeEnum.getMap());
        result.put("name2GroupMap", RuleTypeMergeEnum.getName2GroupMap());
        result.put("appScopeMap",AppScopeEnum.getMap());
        //��ȡ���Ի�����
        List<AlarmConfPersonalizedDO> personalizeds ;
        if(StringUtils.isNotEmpty(confId)){
            personalizeds = personalizedDAO.selectByConfId(Long.parseLong(confId));
        }else{
            personalizeds = personalizedDAO.selectAll(environmentService.getEnvironmentType().getEnv());
        }
        List<AlarmPersonalized> personalizedVOs = Lists.newArrayList();

        if(CollectionUtils.isNotEmpty(personalizeds)){
            for (AlarmConfPersonalizedDO personalized : personalizeds) {
                AlarmPersonalized data = new AlarmPersonalized();
                data.setPersonalizedDO(personalized);
                data.setConfDO(confDAO.selectById(personalized.getSourceConfId()));
                data.setRecordDO(recordDAO.selectById(personalized.getRecordId()));
                data.setSubscriberDO(subscriberDAO.selectById(personalized.getSubId()));
                personalizedVOs.add(data);
            }

        }
        //��ѯ�Ƿ��д��ڵ�����
        List<AlarmConfPersonalizedDO> personals = personalizedDAO.selectByExtendUUID(extendUUID);
        result.put("perConf",personals.size()>0?personals.get(0):null);
        result.put("existConf",personals.size()>0?true:false);

        if(environmentService.isProduction()){
            result.put("returnUrl","http://safe.trip.taobao.org/alarm/personalizedList.htm?confId="+confId);
        }else if(environmentService.isPrepub()){
            result.put("returnUrl","http://pre-safe.trip.taobao.org/alarm/personalizedList.htm?confId="+confId);
        }else{
            result.put("returnUrl","http://ateye.trip.daily.taobao.net/alarm/personalizedList.htm?confId="+confId);
        }

        result.put("perDatas",personalizedVOs);
        result.put("recordId",recordId);
        result.put("extendUUID",extendUUID);
        result.put("exTypes",exTypes);
        return ALARM_PERSONALIZED_LIST;
    }

    @RequestMapping("addPersionalized.htm")
    public String addPersionalized(final HttpServletRequest request, final HttpServletResponse response, ModelMap result) throws DAOException, UnsupportedEncodingException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        String id = request.getParameter("id");
        AlarmConfPersonalizedDO personalizedDO = new AlarmConfPersonalizedDO();
        if(StringUtils.isNotEmpty(id)){
            personalizedDO = personalizedDAO.selectById(Long.parseLong(id));
            if(personalizedDO==null){
                personalizedDO = new AlarmConfPersonalizedDO();
            }
        }
        personalizedDO.setApp(request.getParameter("app"));
        personalizedDO.setEnv(environmentService.getEnvironmentType().getEnv());
        String recordId = request.getParameter("recordId");
        personalizedDO.setRecordId(Long.parseLong(recordId));
        personalizedDO.setRemark(request.getParameter("remark"));
        String extendUUID = request.getParameter("extendUUID");
        personalizedDO.setSourceExtendUUID(extendUUID);
        personalizedDO.setSourceUUID(ExtendUUIDUtil.parseUUID(extendUUID));
        String exTypes = request.getParameter("exTypes");
        personalizedDO.setExTypes(exTypes);
        String subId = request.getParameter("subId");
        personalizedDO.setSubId(Long.parseLong(subId));
        String confId = request.getParameter("confId");
        personalizedDO.setSourceConfId(Long.parseLong(confId));
        String operType = request.getParameter("operType");
        if("valid".equalsIgnoreCase(operType)){
            personalizedDO.setSourceStatus(StatusEnu.VALID.getValue());
        }else if("pause".equalsIgnoreCase(operType)){
            personalizedDO.setSourceStatus(StatusEnu.PAUSE.getValue());
        }else if("pauseNHour".equalsIgnoreCase(operType)){
            String hourStr = request.getParameter("hour");
            int hour = Integer.parseInt(hourStr);
            personalizedDO.setSourceReopenDate(DateUtils.addMinutes(new Date(), (hour*60)));
        }
        String start = request.getParameter("hStart");
        String end = request.getParameter("hEnd");
        Integer startI =null;
        Integer endI = null;
        if ( org.apache.commons.lang3.StringUtils.isNotBlank(start)&&!"-1".equalsIgnoreCase(start) ){
            startI = Integer.valueOf(start);
        }
        if ( org.apache.commons.lang3.StringUtils.isNotBlank(end) &&!"-1".equalsIgnoreCase(end) ){
            endI = Integer.valueOf(end);
        }
        personalizedDO.setSourceHourStart(startI);
        personalizedDO.setSourceHourEnd(endI);

        String threshold = request.getParameter("threshold");
        if(StringUtils.isNotEmpty(threshold)){
            personalizedDO.setThreshold(new BigDecimal(threshold));
        }
        personalizedDO.setOperator(user.getNick());
        personalizedDO.setDetail(request.getParameter("detail"));
        List<AlarmConfPersonalizedDO> existsConfs = personalizedDAO.selectByExtendUUID(personalizedDO.getSourceExtendUUID());
        if(CollectionUtils.isNotEmpty(existsConfs) && StringUtils.isEmpty(id)){
            result.put("errorMsg", "�Ѵ�������������");
        }else{
            if(StringUtils.isNotEmpty(id)){
                personalizedDO.setId(Long.parseLong(id));
                personalizedDAO.update(personalizedDO);
                result.put("errorMsg", "���³ɹ�");
            }else{
                personalizedDAO.insert(personalizedDO);
                result.put("errorMsg", "���ӳɹ�");
            }


        }

        return getRedirectUrl(request, response);
    }


    @RequestMapping("deletePersionalized.htm")
    public String deletePersionalized(final HttpServletRequest request,  final HttpServletResponse response,ModelMap result) throws DAOException, UnsupportedEncodingException {
        result.put("errorMsg", request.getParameter("errorMsg"));
        UserDO user = (UserDO) MyThreadLocal.get();
        if (user == null) {
            return "redirect:/noPermission.htm";
        }
        String id = request.getParameter("id");
        if(StringUtils.isNotEmpty(id)){
            personalizedDAO.deleteById(Long.parseLong(id));
        }
        result.put("errorMsg", "ɾ���ɹ�");
        return getRedirectUrl(request, response);
    }

}
