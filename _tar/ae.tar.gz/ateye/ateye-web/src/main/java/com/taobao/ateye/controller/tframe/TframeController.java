package com.taobao.ateye.controller.tframe;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.fliggy.tframe.cmd.model.TframeDescDO;
import com.fliggy.tframe.cmd.model.TframeDescDO._APMDescDO;
import com.fliggy.tframe.cmd.model.TframeDescDO._PMDescDO;
import com.taobao.ateye.controller.AbstractController;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.dataobject.MachineDO;
import com.taobao.ateye.diamond.impl.TframeAppWhiteList;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.tframe.manager.TframeManager;
import com.taobao.ateye.tframe.manager.TframeTraceDO;
import com.taobao.ateye.tframe.manager.TframeTraceDO.TframeLogsDO;

@Controller
@RequestMapping("/tframe")
public class TframeController extends AbstractController{
	@Autowired
	private TframeManager tframeManager;
	@Autowired
	private MachineDAO machineDAO;
	@Autowired
	private AppDAO appDAO;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private TframeAppWhiteList tframeAppWhiteList;

	@RequestMapping("info.htm")
	public String info(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		String appName = request.getParameter("app");
		if ( StringUtils.isBlank(appName) ){
			return "";
		}
		result.put("app",appName);
		AppDO appDO = appDAO.getAppByName(appName);
		if ( appDO == null ){
			return "";
		}
		List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appDO.getId(), environmentService.getEnvironmentType().ordinal());
		result.put("machines",machines);
		String machineIdStr = request.getParameter("machine_id");
		if ( StringUtils.isBlank(machineIdStr) ){
			return "screen/tframe/info";
		}
		MachineDO machine = machineDAO.getMachineByid(Long.valueOf(machineIdStr));
		if ( machine == null ){
			return "screen/tframe/info";
		}

		TframeDescDO tframeDesc = tframeManager.getTframeDesc(machine.getIp(), machine.getPort());
		Map<String,Map<String,String>> graphs = new TreeMap<String,Map<String,String>>();
		Map<String, _APMDescDO> processes = tframeDesc.getProcesses();
		for (Map.Entry<String, _APMDescDO> ent:processes.entrySet() ){
			Map<String, String> map = graphs.get(ent.getKey());
			if ( map == null ){
				map = new TreeMap<String,String>();
				graphs.put(ent.getKey(), map);
			}
			Map<String, _PMDescDO> pms = ent.getValue().getPms();
			for ( Map.Entry<String, _PMDescDO> ent2:pms.entrySet() ){
				String desc = tframeManager.buildGraph(ent2.getValue());
				map.put(ent2.getKey(), desc);
			}
		}
		tframeManager.saveTframeDesc(appName, tframeDesc);
		result.put("graphs",graphs);
		

		return "screen/tframe/info";
	}
	@RequestMapping("trace.htm")
	public String trace(final HttpServletRequest request,
			final HttpServletResponse response, ModelMap result)
			throws IOException, DAOException {
		Set<String> allApps = tframeAppWhiteList.getConfigObjs();
		result.put("allApps",allApps);
		
		String appName = request.getParameter("app");
		if ( StringUtils.isBlank(appName) ){
			return "screen/tframe/trace";
		}
		result.put("app", appName);
		String id = request.getParameter("id");
		if ( StringUtils.isBlank(id) ){
			return "screen/tframe/trace";
		}
		result.put("id",id);
		AppDO appDO = appDAO.getAppByName(appName);
		if ( appDO == null ){
			return "";
		}
		TframeDescDO tDesc = tframeManager.getTframeDesc(appName);
		if ( tDesc == null ){
			List<MachineDO> machines = machineDAO.getMachinesOfAnApp(appDO.getId(), environmentService.getEnvironmentType().ordinal());
			for ( MachineDO machine:machines ){
				tDesc = tframeManager.getTframeDesc(machine.getIp(), machine.getPort());
				if ( tDesc != null ){
					tframeManager.saveTframeDesc(appName, tDesc);
					break;
				}
			}
		}
		if ( tDesc == null ){
			return "";
		}
		TframeTraceDO trace = tframeManager.getTraceByOrderId(appName, id);
		Map<String,Map<String,String>> graphs = new TreeMap<String,Map<String,String>>();
		Map<String, _APMDescDO> processes = tDesc.getProcesses();
		for (Map.Entry<String, _APMDescDO> ent:processes.entrySet() ){
			String pm = ent.getKey();
			Map<String, TframeLogsDO> logs = trace.getLogs(pm);
			if ( logs == null ){
				continue;
			}
			Map<String, String> map = graphs.get(ent.getKey());
			if ( map == null ){
				map = new TreeMap<String,String>();
				graphs.put(ent.getKey(), map);
			}
			Map<String, _PMDescDO> pms = ent.getValue().getPms();
			for ( Map.Entry<String, _PMDescDO> ent2:pms.entrySet() ){
				String desc = tframeManager.buildGraph(appName,id,ent2.getKey(),ent2.getValue(),logs);
				map.put(ent2.getKey(), desc);
			}
		}
		result.put("graphs",graphs);
		result.put("trace",JSON.toJSONString(trace, true));
		result.put("traceObj",trace);

		return "screen/tframe/trace";
	}

}
