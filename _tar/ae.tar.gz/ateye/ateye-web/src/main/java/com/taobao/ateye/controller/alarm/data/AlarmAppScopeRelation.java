package com.taobao.ateye.controller.alarm.data;

import java.util.Date;

import com.taobao.ateye.alarm.n.enu.AppScopeEnum;
import com.taobao.ateye.alarm.n.enu.RuleTypeMergeEnum;
import com.taobao.ateye.alarm.n.util.AlarmMonitorUtils;
import com.taobao.ateye.dataobject.AteyeAlarmConfDO;
import com.taobao.ateye.dataobject.AteyeAlarmItemRuleSingleDO;
import com.taobao.ateye.util.DescUtils;

/**
 * Created by sunqiang on 2018/12/18.
 */
public class AlarmAppScopeRelation {
	
	
	private AteyeAlarmItemRuleSingleDO ruleDO;
	private AteyeAlarmConfDO confDO; 
    /**
     * ����
     */
    private long confId;
    /**
     * ����ʱ��
     */
    private Date gmtCreate;

    /**
     * �޸�ʱ��
     */
    private Date gmtModified;

    /**
     * ��������
     */
    private String name;

    /**
     * 0-��Ч,1-��ͣ 2-�߼�ɾ��
     */
    private int status;

    /**
     * �����м���ͣһ��ʱ��
     */
    private Date reopenDate;

    /**
     * Ψһ��ʾ
     */
    private String uuid;

    /**
     * ������ ������Ÿ���
     */
    private String subStr;

    /**
     * Ȧ��Ӧ�õ�����,ҵ����,ĳ����,ownerӦ��,appps
     */
    private Integer appScopeType;

    /**
     * Ȧ��Ӧ�õ�ֵ
     */
    private String appScopeValue;

    /**
     * ҵ������
     */
    private String ruleType;

    /**
     * ���챨����
     */
    private int alarmCount;

    /**
     * ���Ի�����
     */
    private int perCount;
    
    public String descTime(){
    	if ( confDO != null ){
    		return confDO.getHourStart() + "�� ~ "+confDO.getHourEnd()+"��";
    	}
    	return "--";
    }
    
    public String descRuleType(){
    	String ret = "";
    	if ( ruleDO != null ){
    		if ( RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_HSF.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_SENTINEL.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_DAO.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.GLOBAL_EXCEPTION_TYPE_BASE.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_HSF.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_SENTINEL.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_DAO.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.BETA_GLOBAL_EXCEPTION_TYPE_BASE.getName().equals(ruleType) ||
                    RuleTypeMergeEnum.EXCEPTION_TYPE_INCR_HIGH_CRITICAL.getName().equals(ruleType)){
    			int nTimes = ruleDO.getRelativeDayTimes().intValue();
    			return "��ÿСʱ���ֵ��쳣��������ǰ3��ÿСʱ��ֵ��<font class='green fb'>"+nTimes+"��</font>ʱ";
    		}else if (RuleTypeMergeEnum.HSF_EXCEPTION.getName().equals(ruleType) || RuleTypeMergeEnum.BETA_HSF_EXCEPTION.getName().equals(ruleType)){
    			int nTimes = ruleDO.getContinuousTime().intValue();
    			float pc = ruleDO.getThreshold().floatValue();
    			return "������<font class='green fb'>"+nTimes+"����</font>�쳣��������<font class='green fb'>"+DescUtils.percent(pc)+"</font>ʱ";
    		}else if (RuleTypeMergeEnum.HSF_TIMEOUT.getName().equals(ruleType) || RuleTypeMergeEnum.BETA_HSF_TIMEOUT.getName().equals(ruleType)){
    			int nTimes = ruleDO.getContinuousTime().intValue();
    			float pc = ruleDO.getThreshold().floatValue();
    			return "������<font class='green fb'>"+nTimes+"����</font>��ʱ��������<font class='green fb'>"+DescUtils.percent(pc)+"</font>ʱ";
    		}else{
    			return "--";
    		}
    	}
    	return ret;
    }
    public String descAppScope(){
    	String ret = "";
    	if ( AppScopeEnum.BIZ.getValue() == appScopeType ){
    		return "ҵ����:<font class='green fb'>"+appScopeValue+"</font>";
    	}
        if ( AppScopeEnum.CORE_APP.getValue() == appScopeType ){
            return "ҵ����:<font class='green fb'>"+appScopeValue+"</font>�ĺ���Ӧ��";
        }
    	if ( AppScopeEnum.SOME_ONE_OWNER.getValue() == appScopeType ){
    		return "<font class='green fb'>"+appScopeValue+"</font>���������Ӧ��";
    	}
    	if ( AppScopeEnum.APPS.getValue() == appScopeType ){
    		return appScopeValue;
    	}
    	return ret;
    }

    public int getAlarmCount() {
        return alarmCount;
    }

    public void setAlarmCount(int alarmCount) {
        this.alarmCount = alarmCount;
    }

    public String alarmUrl(){
        return AlarmMonitorUtils.buildConfRealAlarm(confId);
    }

    public long getConfId() {
        return confId;
    }

    public void setConfId(long confId) {
        this.confId = confId;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getReopenDate() {
        return reopenDate;
    }

    public void setReopenDate(Date reopenDate) {
        this.reopenDate = reopenDate;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getSubStr() {
        return subStr;
    }

    public void setSubStr(String subStr) {
        this.subStr = subStr;
    }

    public Integer getAppScopeType() {
        return appScopeType;
    }

    public void setAppScopeType(Integer appScopeType) {
        this.appScopeType = appScopeType;
    }

    public String getAppScopeValue() {
        return appScopeValue;
    }

    public void setAppScopeValue(String appScopeValue) {
        this.appScopeValue = appScopeValue;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

	public AteyeAlarmConfDO getConfDO() {
		return confDO;
	}

	public void setConfDO(AteyeAlarmConfDO confDO) {
		this.confDO = confDO;
	}

	public AteyeAlarmItemRuleSingleDO getRuleDO() {
		return ruleDO;
	}

	public void setRuleDO(AteyeAlarmItemRuleSingleDO ruleDO) {
		this.ruleDO = ruleDO;
	}

    public int getPerCount() {
        return perCount;
    }

    public void setPerCount(int perCount) {
        this.perCount = perCount;
    }
}
