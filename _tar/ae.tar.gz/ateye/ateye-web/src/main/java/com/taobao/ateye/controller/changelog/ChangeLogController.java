package com.taobao.ateye.controller.changelog;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.taobao.ateye.changelog.AppChangeLogConstants;
import com.taobao.ateye.changelog.AppChangeLogVO;
import com.taobao.ateye.changelog.ChangeLogManager;
import com.taobao.ateye.config.app.AppConfig;
import com.taobao.ateye.config.app.AppDescDO;
import com.taobao.ateye.dal.AppChangeLogDAO;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dataobject.AppChangeLogDO;
import com.taobao.ateye.dataobject.AppDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.query.AppChangeLogQuery;
import com.taobao.ateye.service.AppService;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.impl.AppChangeLogServiceImpl.ChangeLogVOAdapter;
import com.taobao.ateye.util.BizUtil;


@Controller
@RequestMapping("changelog")
public class ChangeLogController {
	private static final String LIST_CHANGELOG = "screen/changelog/list";
	private Logger log = LoggerFactory.getLogger(ChangeLogController.class);
	@Autowired
	private AppChangeLogDAO appChangeLogDAO;
	@Autowired
	private AppService appService;
	@Autowired
	private EnvironmentService environmentService;
	@Autowired
	private AppDAO appDAO;
	@Autowired
	private ChangeLogManager changeLogManager;
	
	@RequestMapping("list.htm")
	public String list(@RequestParam(value="productName",required=false) String productName, 
			@RequestParam(value="appName",required=false) String appName,
			@RequestParam(value="changeType",required=false) Integer changeType, 
			@RequestParam(value="start",required=false) String start, 
			@RequestParam(value="end",required=false) String end,
			ModelMap result) throws DAOException{
		if(StringUtils.isNotBlank(appName)){
			AppDescDO appDescDO = AppConfig.getAppDesc().get(appName);
			if(appDescDO != null){
				productName = appDescDO.getProductName();
			}
		}
		Date startDate = null;
		Date endDate = null;
		if(StringUtils.isNotBlank(start)){
			try {
				startDate = DateUtils.parseDate(start, "yyyy-MM-dd");
			} catch (ParseException e) {
				log.error("��ʼ���ڸ�ʽ����ȷ{}",start);
			}
		}else{
			startDate = DateUtils.ceiling(new Date(), Calendar.DATE);
			startDate = DateUtils.addDays(startDate, -1);
		}
		if(StringUtils.isNotBlank(end)){
			try {
				endDate = DateUtils.parseDate(end, "yyyy-MM-dd");
			} catch (ParseException e) {
				log.error("�������ڸ�ʽ����ȷ{}",end);
			}
		}else{
			endDate = DateUtils.addDays(startDate, 1);
		}
		result.addAttribute("start", DateFormatUtils.format(startDate, "yyyy-MM-dd"));
		result.addAttribute("end", DateFormatUtils.format(endDate, "yyyy-MM-dd"));
		result.addAttribute("selectedProductName", productName);
		result.addAttribute("selectedAppName", appName);
		result.addAttribute("selectedChangeType", changeType);
		
		AppChangeLogQuery query = new AppChangeLogQuery();
		query.setProductName(productName);
		query.setAppName(appName);
		query.setPageSize(1000);
		query.setCurrentPage(1);
		if ( changeType != null ){
			query.setChangeTypes(Arrays.asList(changeType));
		}
		query.setStartTime(startDate);
		query.setEndTime(endDate);
		query.setEnv(environmentService.getEnvironmentType().ordinal());
		List<AppChangeLogDO> logs = appChangeLogDAO.query(query);
		/*
		List<AppChangeLogVO> logs = ChangeLogVOAdapter.list(query2);
		for(AppChangeLogVO log:logs){
			if(log.getChangeType().equals(AppChangeLogConstants.CHANGE_TYPE_ATEYE_SWITCH)){
				if(log.valueNotChange()){
					//����ֵδ�䣬skip
					continue;						
				}
			}
			logs.add(log);
		}
		*/
		result.addAttribute("logs", logs);
		result.put("logMap", changeLogManager.getCollapsedChangeLog(logs));
		List<AppDO> apps = appDAO.queryAppByProduct(productName);
		result.addAttribute("apps", apps);
		//result.addAttribute("query", param);
		result.addAttribute("productNames", BizUtil.getProducts());
		result.addAttribute("changeTypes", AppChangeLogConstants.changeTypes);

		return LIST_CHANGELOG;
	}
	@RequestMapping(value="detail.htm")
	public void detail(HttpServletResponse response, @RequestParam("id") Long id, ModelMap result) throws DAOException{
		AppChangeLogDO cld = this.appChangeLogDAO.getById(id);
		if ( cld == null ){
			return;
		}
		AppChangeLogVO changeLog = ChangeLogVOAdapter.one(cld);
		response.setCharacterEncoding("UTF-8");
		try {
			response.getOutputStream().write(new Gson().toJson(changeLog).getBytes("UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args)throws Exception{
		String json = "{"
				+"\"global\":[\"/home/admin/${app}/bin/jbossctl\",\"b.x\"]"
				+ "}";
		JSONObject obj = JSON.parseObject(json);
		JSONArray arr = obj.getJSONArray("global");
		System.out.println(arr);
		for(Object i:arr){
			System.out.println(i.toString().replaceAll("\\$\\{app\\}","ato"));
		}
		System.out.println();
	}
}
