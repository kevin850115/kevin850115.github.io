window.mobileCheck = function() {

var check = false;

(function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true})(navigator.userAgent||navigator.vendor||window.opera);

return check;
}

jQuery(document).ready(
		function() {
			//记录生效区间，默认是区间
			var isDateRange = true;
			
			// 时间选择
			jQuery(".set_time .control_input").live('focus', function() {
				WdatePicker({
					skin : 'whyGreen',
					dateFmt : 'yyyy-MM-dd HH:mm:ss',
					minDate : '1999-03-08 11:30:00',
					maxDate : '2088-03-10 20:59:30',
					onpicked : setTimeChange  //自定义范围变化事件
				})
			});
			
			//自定义范围变化事件
			$(".set_time .control_input").change(function() {
				setTimeChange();
			});
			/**
			 * 自定义范围发生变化:
			 * 1.给出数据类型的默认规则：
			 * 	3小时内--明细
			 * 	1个月内--按小时汇总
			 * 	6个月内--按天汇总
			 * 2.记录生效时间(区间/自定义范围)
			 */
			function setTimeChange() {
				var start = jQuery('.set_time [name=starttime]').val();
				var end = jQuery('.set_time [name=endtime]').val();
				if(start != "" && end != "") {
					var sd = new Date(start);
					var ed = new Date(end);
					var times = ed.getTime() - sd.getTime();
					if(times < 0) return;
					if(times <= 4500 * 60 * 1000) { //三天内
						$("#detail").show();
						controlChange("data_control", $("#detail"));
					} else if (times < 50400 * 60 * 1000) {  //1个月内
						$("#detail").hide();
						controlChange("data_control", $("#hour"));
					} else {  //大于1个月
						$("#detail").hide();
						controlChange("data_control", $("#day"));
					}
					isDateRange = false;   //自定义范围
				}
			}
			
			/**
			 * 改变control类型按钮效果，control类型按钮有2钟：
			 * 1.查询区间
			 * 2.数据类型：明细时，隐藏汇总方式，其他显示汇总方式，默认选中avg
			 */
			function controlChange(clz, a) {
				$("." + clz + " a").removeClass("selected");
				a.addClass("selected");
				//明细类型，没有汇总方式选择
				if(clz == "data_control") {
					if(a.attr("value") == "detail") {
						$("#aggrType").hide();
					} else {
						$("#aggrType option[value='AVG']").attr("selected", true);
						$("#aggrType").show();
					}
				}
			}
			/**
			 * 查询区间点击事件：
			 * 
			 */
			jQuery(".time_control a").live('click', function(e) {
				isDateRange = true;
				//选中效果
				controlChange("time_control", $(this));
				//联动
				timeControl();
				//查询
				doSearch();
			});
			
			/**
			 * 查询区间变化时，联动行为
			 */
			function timeControl() {
				//数据类型默认行为
				var value = parseInt($(".time_control .selected").attr("value"));
				if(value >= -4500) {   //3天内
					$("#detail").show();
					controlChange("data_control", $("#detail"));
				} else if(value == -11520) {   //1周
					$("#detail").hide();
					controlChange("data_control", $("#hour"));
				} else if(value == -50400) {   //1个月
					$("#detail").hide();
					controlChange("data_control", $("#day"));
				}
			}
			//初始化
			timeControl();
			
			/**
			 * 数据类型点击事件
			 */
			jQuery(".data_control a").live('click', function() {
				controlChange("data_control", $(this));
				//触发查询
				doSearch();
			});
			
			/**
			 * 汇总方式变化事件
			 */
			$("#aggrType").live("change", function() {
				doSearch();
			});

			// 业务事件
			jQuery('.btn_search').click(function(e) {
				isDateRange = false; //自定义范围
				doSearch();
			});
			
			function doSearch() {
				if($("#compareType").val()=="specialDay" && $("#specialDay").val()==''){
					$("#specialDay").addClass("error_input");
					$("#error_txt").show('300',function(){
						var setError = setTimeout(function(){
							$("#error_txt").hide('300');
						},2000)
					});
		    		return false;
				}
				var dateRange = jQuery('.time_control .selected').attr('value');
				if(isDateRange) {
					getData({
						dateRange : dateRange
					});
				} else {
					var starttime = jQuery('.set_time [name=starttime]').val();
					var enttime = jQuery('.set_time [name=endtime]').val();
					getData({
						startTime : starttime,
						endTime : enttime,
						dateRange : dateRange
					});
				}
			}
			
			//默认查询
			doSearch();
			
			//getData({
				//dateRange : -180
			//});
			
			
			//对比图曲线
			$("#compareType").change(function(){
				 if(jQuery("#compareType").val()=="specialDay"){
					jQuery("#specialDate").show();
				 }else{
					jQuery("#specialDate").hide();
					doSearch();
				 }
			 });
			 
			// 时间选择
				jQuery(".diytime .control_input").live('focus', function() {
					WdatePicker({
						skin : 'whyGreen',
						dateFmt : 'yyyy-MM-dd',
						minDate : '1999-03-08',
						maxDate : '2088-03-10',
						onpicked : doSearch  //自定义范围变化事件
					})
				});
			
			/**
			 *@param options
			 * startTime
			 * endTime
			 * dateRange
			 */
			function getData(options) {
				/**
				 * ajax请求
				 */
				jQuery.ajax({
					url : ctx + '/monitor/queryData.htm?cmd=getData',
					type:'POST',
					data : {
                        beta: $("#beta").val(),
						chartId : jQuery.getUrlParam('chartId'),
						refId : jQuery.getUrlParam('refId'),
						refType : jQuery.getUrlParam('refType'),
						chartName : jQuery.getUrlParam('chartName'),
						dateParam : JSON.stringify(options),
						groupby: jQuery.getUrlParam('groupby'),
						type: $("#type").val(),
						customParam: $("#customParam").val(),
						customParam_1: $("#customParam_1").val(),
						customParam_2: $("#customParam_2").val(),
						customParam_3: $("#customParam_3").val(),
						customParam_4: $("#customParam_4").val(),
						customParam_5: $("#customParam_5").val(),
						customParam_6: $("#customParam_6").val(),
						customParam_7: $("#customParam_7").val(),
						customParam_8: $("#customParam_8").val(),
						customParam_9: $("#customParam_9").val(),
						customParam_10: $("#customParam_10").val(),
						customParam_11: $("#customParam_11").val(),
						customParam_12: $("#customParam_12").val(),
						customParam_13: $("#customParam_13").val(),
						customParam_14: $("#customParam_14").val(),
						customParam_15: $("#customParam_15").val(),
						customParam_16: $("#customParam_16").val(),
						customParam_17: $("#customParam_17").val(),
						customParam_18: $("#customParam_18").val(),
						customParam_19: $("#customParam_19").val(),
						customParam_20: $("#customParam_20").val(),
						customParam_21: $("#customParam_21").val(),
						customParam_22: $("#customParam_22").val(),
						customParam_23: $("#customParam_23").val(),
						customParam_24: $("#customParam_24").val(),
						customParam_25: $("#customParam_25").val(),
						customParam_26: $("#customParam_26").val(),
						customParam_27: $("#customParam_27").val(),
						customParam_28: $("#customParam_28").val(),
						customParam_29: $("#customParam_29").val(),
						customParam_30: $("#customParam_30").val(),
						customParam_31: $("#customParam_31").val(),
						customParam_32: $("#customParam_32").val(),
						customParam_33: $("#customParam_33").val(),
						customParam_34: $("#customParam_34").val(),
						customParam_35: $("#customParam_35").val(),
						customParam_36: $("#customParam_36").val(),
						customParam_37: $("#customParam_37").val(),
						customParam_38: $("#customParam_38").val(),
						customParam_39: $("#customParam_39").val(),
						customParam_40: $("#customParam_40").val(),
						appName: $("#app").val(),
						md5: jQuery.getUrlParam('md5'),
						keys: jQuery.getUrlParam('keys'),
						k1: jQuery.getUrlParam('k1'),
						k2: jQuery.getUrlParam('k2'),
						startDate: jQuery.getUrlParam('startDate'),
						uuid: jQuery.getUrlParam('uuid'),
						puuid: jQuery.getUrlParam('puuid'),
						unitName: jQuery.getUrlParam('unitName'),
						beginTime: jQuery.getUrlParam('beginTime'),
						endDate: jQuery.getUrlParam('endDate'),
						startDate2: jQuery.getUrlParam('startDate2'),
						endDate2: jQuery.getUrlParam('endDate2'),
						key: jQuery.getUrlParam('key'),
						sql: jQuery.getUrlParam('sql'),
						spe: jQuery.getUrlParam('spe'),
						gSize: jQuery.getUrlParam('gSize'),
						valueType: jQuery.getUrlParam('valueType'),
						valueType2: jQuery.getUrlParam('valueType2'),
						mday: jQuery.getUrlParam('mday'),
						mday2: jQuery.getUrlParam('mday2'),
						appName2: jQuery.getUrlParam('appName2'),
						compareType : $("#compareType").val(),
						wholeDay: jQuery.getUrlParam('wholeDay'),
						specialDay : $("#specialDay").val()
					},
					dataType : 'json',
					success : function(resp) {
						/**
						 * 请求返回后，数据格式为
						 * {success: true, data: {...}}
						 * success标识业务是否执行成功，data是返回的业务数据
						 * 可以使用console.info(resp)结合firebug控制台查看数据结构
						 */
						if (resp.success) {
                            var multiData = resp.data;
                            var multiTitles = resp.names;
                            var width = resp.width;
                            var height = resp.height;
                            if ( window.mobileCheck() ){
                            	width = null;
                            	height = null;
                        	}
                            var simple = resp.simpleDesc;
                            var chartType = resp.chartType;
                            jQuery.each(multiData,function(idx2,data){
                                var series = [];
                                jQuery.each(data.lines, function(idx, item) {
                                    var mma = ' max:' + item.max + ' min:'
                                    + item.min + ' avg:' + item.avg + ' sum:' + item.sum + ' ' + item.unit;
                                    var nameStr = item.dateTimeStr?item.dateTimeStr+' '+ item.tag + mma : item.tag + mma;
                                    var chartData = [];

                                    jQuery.each(item.hisData, function(idx, his) {
                                        chartData.push([ his.time,
                                            parseFloat(his.valStr) ]);
                                        });

									if ( simple == 1 ){
	                                    series.push({
	                                        name : item.dateTimeStr?item.dateTimeStr+' '+ item.tag :item.tag  ,
	                                        data : chartData
	                                        });
                                    }else{
	                                    series.push({
	                                        name : nameStr,
	                                        data : chartData
	                                        });
                                    };
                                }); 
                                var title = multiTitles[idx2];
                                var legend_enabled = (simple==1?false:true);
				if ( $("#virtual_scene").val() == "1" ){
					legend_enabled = false;
				}
                                createChart(data.chartType,legend_enabled, series, title,$("#compareType").val(), data.userName,"container"+idx2,width,height);
                                }); 
						} else {
							alert(resp.info);
						}
					}
				});
			}

			/**
			 * 创建拆线图
			 * @param series 图数据
			 */
			function createChart(chartType,legend_enabled, series, title,isCompare, userName,container,w,h) {
				Highcharts.setOptions({
					global : {
						useUTC : false
					},
			        legend:{
                        enabled: legend_enabled
                    },
                    colors: ['#4572A7','#AA4643','#89A54E','#80699B','#3D96AE','#DB843D','#92A8CD','#A47D7C','#B5CA92']
				});

				var chart = new Highcharts.Chart({
					chart : {
						renderTo : container,
						type : chartType,
						zoomType : 'x',
						spacingRight : 20,
						width: w,
						height: h,
						reflow:true,
						events: {
							load: function() {
				                if(userName){
				                       var ren = this.renderer,
				                       colors = Highcharts.getOptions().colors;
				                       var attr={fill: '#FFFFFF',rotation:45,'stroke-width': 0,padding: 5, r: 5};// rotation:-45,
				                       var css={color: '#E8E8E8',fontSize: '18px'}
				                       for(var i=0;i<380;i=i+100){
				                          for(var j=0;j<1005;j=j+100){
				                             ren.label(userName, j, i).attr(attr).css(css).add();
				                          }
				                       }
				                }
				             }
						}
					},
					title : {
						text : title || '',
						useHTML:true
					},
					xAxis : {
						type : 'datetime'

					},
					yAxis : {
						title : {
							text : ' '
						}
//						min : 0
					},

					plotOptions : {
						spline : {
	                        shadow:true,
							lineWidth : 1,
							states : {
								hover : {
									lineWidth : 1
								}
							},
							marker : {
								enabled : false,
								states : {
									hover : {
										enabled : true,
										symbol : 'circle',
										radius : 3,
										lineWidth : 1
									}
								}
							},
                         },
                        //series: {
                        //    cursor: 'pointer',
                        //    point: {
                        //        events: {
                        //        click: function() {
                        //           hs.htmlExpand(null, {
                        //                pageOrigin: {
                        //                x: this.pageX,
                        //                y: this.pageY
                        //                },
                        //                headingText: "ok",
                        //                maincontentText: "OK",
                        //                width: 200
                        //                }
                        //                );
                        //            }
                        //        }
                        //    },
                        //    marker: {
                        //        lineWidth: 1
                        //    }
                        //},
                    },
					tooltip : {
						shared : true,
						crosshairs : true,
						formatter : function() {
								var s = '<b>'
									+ Highcharts.dateFormat('%Y-%m-%d %H:%M:%S',
											this.x) + '</b>';
								if(isCompare){
									s = '<b>'+ Highcharts.dateFormat('%H:%M:%S',this.x) + '</b>';
								}
								if ( $("#virtual_scene").val() == "1" ){
									jQuery.each(this.points, function(i, point) {
											s += '<br/>'
											+'<span style="font-size:16px;font-weight:bold;color:black;text-decoration:underline;">'+point.y+'</span>';
											});

								}else{
									jQuery.each(this.points, function(i, point) {
											if(isCompare){
											s += '<br/><div>'
											+'<span style="font-weight:bold;color:'+point.series.color+'">'
											+ point.series.name.split(" ")[1].replace(/\|/g,'</span><br/><span style="font-weight:bold;color:'+point.series.color+'">-->')
											+ '</span></div>: ' 
											+'<span style="font-size:16px;font-weight:bold;color:black;text-decoration:underline;">'+point.y+'</span>';
											}else{
											s += '<br/><div>'
											+'<span style="font-weight:bold;color:'+point.series.color+'">'
											+ point.series.name.split(" ")[0].replace(/\|/g,'</span><br/><span style="font-weight:bold;color:'+point.series.color+'">-->')
											+ '</span></div>: ' 
											+'<span style="font-size:16px;font-weight:bold;color:black;text-decoration:underline;">'+point.y+'</span>';
											}

											});
								}
								return s;
						}
					},
					series : series
				});
			}
		});
