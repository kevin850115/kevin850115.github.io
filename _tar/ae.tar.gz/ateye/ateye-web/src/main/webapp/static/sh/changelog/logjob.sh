#!/bin/bash

PROG_NAME=$0
ACTION=$1
##环境信息
ENV_IP=""
ENV_APP_NAME=""
ENV_APP_NAME_DEFAULT="ateye"
ENV_TYPE=""
##
FILE_SH="`readlink -f ${PROG_NAME}`"
DIR_SH="${FILE_SH%/*}"
CRON_COMMAND="${FILE_SH} run >> ${DIR_SH}/cron.log < /dev/null"
PATH_FILE_LIST="${DIR_SH}/file.list"
PATH_FILE_MODIFIED_LOG="${DIR_SH}/file.log"
MAX_SECONDS_FILE_LIST_EXPIRED=120
MAX_SECONDS_FILE_SH_EXPIRED=300 #300
##url
URL_HOST="10.218.142.70"
URL_PORT="" #:7001
URL_FILE_LIST="${URL_PORT}/changelog/api/get_monitor_file_list.htm"
URL_ADD_LOG="${URL_PORT}/changelog/api/add_change_log.htm"
URL_DOWNLOAD_SH="${URL_PORT}/static/sh/changelog/logjob.sh"
URL_ATEYE_DAILY="ateye.trip.daily.taobao.net"
URL_ATEYE_PRE="ateye172021094118.cm3.tbsite.net"
#URL_ATEYE_PROD="ateye172021094118.cm3.tbsite.net"
URL_ATEYE_PROD="ateye.trip.taobao.com" 

##echo "FILE_SH:${FILE_SH}"
##echo "DIR_SH:${DIR_SH}"

usage() {
	echo "Usage: $PROG_NAME {setup|run|dry_run}"
	exit 1;
}

setup(){
	update_job_config
}

run(){
	sleep_random_seconds
	dry_run
}

dry_run(){ 
	get_env_info
	##更新app
	update_app_sh
	##如果app更新过，则退出此次脚本执行
	update_file_list
	check_file_list
	clear_expired_log
	update_job_config
}

get_env_info(){
	##获取环境信息
	log_info "$FUNCNAME"
	get_app_name
	get_ip
	get_env_type
	##
	log_info "APP:${ENV_APP_NAME}"
	log_info "IP:${ENV_IP}"
	log_info "ENV_TYPE:${ENV_TYPE}"
	log_info "URL_HOST:${URL_HOST}"
}

sleep_random_seconds(){
	##sleep随机
	log_info "$FUNCNAME"
	local seconds=`expr $RANDOM % 10`
	sleep "${seconds}s"
}

update_file_list(){
	##下载监控文件列表，保存
	log_info "$FUNCNAME"
	##1.查询文件列表最近更新时间
	log_debug "PATH_FILE_LIST:${PATH_FILE_LIST}"
	local last_modified=100000
	if [ -f "${PATH_FILE_LIST}" ]; then
		last_modified=`get_seconds_after_modified ${PATH_FILE_LIST}`
	fi 
	log_debug "last_modified:${last_modified}"
	##2.判断是否需从服务器查询最新列表，如时间超时、规则不存在则更新、创建，否则退出
	if [ "${last_modified}" -lt "${MAX_SECONDS_FILE_LIST_EXPIRED}" ]; then
		log_debug "无需更新文件列表：${last_modified}<=${MAX_SECONDS_FILE_LIST_EXPIRED}"
		return
	fi
	##3.服务器下载文件列表，如果异常则退出
	log_debug "需要更新文件列表：${last_modified}>${MAX_SECONDS_FILE_LIST_EXPIRED}"
	##4.从服务器下载文件规则
	local para="?app=`get_app_name`"
	log_info "${URL_HOST}${URL_FILE_LIST}${para}"
	curl -q "${URL_HOST}${URL_FILE_LIST}${para}" > ${PATH_FILE_LIST}
}

check_file_list(){
	##按文件列表，校验文件
	log_info "$FUNCNAME"
	##0.如文件修改日志不存在则新建
	if [ ! -f "${PATH_FILE_MODIFIED_LOG}" ]; then
		touch ${PATH_FILE_MODIFIED_LOG}
	fi
	##按文件列表循环
	local temp_file="/tmp/file_log_$RANDOM"
	touch $temp_file
	for line in `cat ${PATH_FILE_LIST}`
	do
		##1.0文件不存在
		if [ ! -f "${line}" ]; then
			call_file_change_log_api ${line}
			continue
		fi
		#1.记录文件变化时间、操作人
		local modified=`get_seconds_modified ${line}`
		local modified_inlog=`grep ${line} ${PATH_FILE_MODIFIED_LOG} | awk '{print $2}'`
		log_info "${line} modified:${modified} modified_inlog:${modified_inlog}"		
		##1.1记录修改时间至临时日志		
		write_file_log ${temp_file} ${line} ${modified}
		##1.2日志没有记载，不记为变更
		if [ -z "${modified_inlog}" ]; then
			continue
		fi
		##1.1已记载，修改时间相等
		if [ "${modified}" == "${modified_inlog}" ]; then
			log_info "${line} not modified"
			continue
		fi
		##1.3已记载但修改时间变化
		call_file_change_log_api ${line}
	done	
	##如调用成功，更新文件修改记录至临时文件，以备下次循环调用
	rm ${PATH_FILE_MODIFIED_LOG}
	mv $temp_file ${PATH_FILE_MODIFIED_LOG}
}

call_file_change_log_api(){
	log_info "$FUNCNAME"
	##1.构造参数
	local file=$1
	local key="delete"
	local modifier="unknow"
	local gmtModified=`date "+%Y-%m-%d %H:%M:%S"`
	if [ -f "${file}" ]; then
		key="update"
		modifier=`ls -l ${file} | awk '{print $4}'`
		gmtModified=`get_date_str_modified ${file}`
	fi
	gmtModified=`echo ${gmtModified}|sed "s/ /%20/g"`
	##2.组装调用服务新增日志url
	local para="?"
	para="${para}app=`get_app_name`"
	para="${para}&ip=`get_ip`"
	para="${para}&file=${file}"
	para="${para}&key=${key}"
	para="${para}&operator=${modifier}"
	para="${para}&gmt=${gmtModified}"
	##3.调用服务器新增日志url
	log_info "${URL_HOST}${URL_ADD_LOG}${para}"
	curl "${URL_HOST}${URL_ADD_LOG}${para}"
	##TODO 未调用成功的日志，记入临时文件，下次重试
}

write_file_log(){
	log_info "$FUNCNAME"
	local outfile=$1
	local filename=$2
	local modified=$3
	echo "${outfile} ${filename} ${modified}"
	echo "${filename} ${modified}" >> ${outfile}
}

clear_expired_log(){
	##删除过期日志文件
	log_info "$FUNCNAME"
}

update_job_config(){
	##更新时间程序配置，保存
	log_info "$FUNCNAME"
	##1.查询crontab最近更新时间
	##2.判断是否需从服务器查询最新规则，如时间超时、规则不存在则更新、创建，否则退出
	##3.服务器下载执行频率，如果异常则退出
	##4.更新时间频率至crontab
	##频率格式：分/时/日/月/星期
	local freq="*/1_*_*_*_*"
	add_or_update_job_crontab $freq
}

add_or_update_job_crontab(){
	log_info "$FUNCNAME"
	local CRON_FREQ=`echo $1|sed "s/_/ /g"`
	local CRON_JOB="${CRON_FREQ} ${CRON_COMMAND}"
	##新增/更新 crontab
	##log_debug "CRON_COMMAND:${CRON_COMMAND}"
	##log_debug "CRON_JOB:${CRON_JOB}"
	(crontab -l | grep -v "${FILE_SH}" ; echo "${CRON_JOB}" ) | crontab
}

remove_job_crontab(){
	log_info "$FUNCNAME"
	##删除原crontab
	##log_debug "CRON_COMMAND:${FILE_SH}"
	(crontab -l | grep -v "${FILE_SH}" ) | crontab
}

 
update_app_sh(){
	##更新shell脚本自身
	log_info "$FUNCNAME"
	##1.查询shell创建时间	
	local temp_file="/tmp/logjob_tmp.sh"	
	local last_modified=100000
	if [ -f "${temp_file}" ]; then
		last_modified=`get_seconds_after_modified ${temp_file}`
	fi 
	log_debug "last_modified:${last_modified}"
	##2.判断是否需从服务器查询最新脚本，否则退出
	if [ "${last_modified}" -lt "${MAX_SECONDS_FILE_SH_EXPIRED}" ]; then
		log_debug "no need to check shell ${last_modified}<=${MAX_SECONDS_FILE_SH_EXPIRED}"
		return
	fi
	##3.服务器下载文件列表，如果异常则退出
	log_debug "need to check shell ${last_modified}>${MAX_SECONDS_FILE_SH_EXPIRED}"
	##4.从服务器下载shell，如果异常则退出
	log_debug "${URL_HOST}${URL_DOWNLOAD_SH} -> ${temp_file}"
	wget "${URL_HOST}${URL_DOWNLOAD_SH}" -O "${temp_file}"
	##5.
	local file_size=`get_file_size ${temp_file}`
	log_info "${temp_file} size: ${file_size}"
	if [ ${file_size} -lt 1000 ]; then
		log_info "${temp_file} size: ${file_size} <= 1000,will not update return."
		return
	fi 
	##6.判断是否需一致，是则删除临时文件，否则替换当前脚本
	local md5_cur_sh=`md5sum ${FILE_SH} | awk '{print $1}'`
	local md5_download_sh=`md5sum ${temp_file}| awk '{print $1}'`
	log_debug "${md5_cur_sh}:${FILE_SH}"
	log_debug "${md5_download_sh}:${temp_file}"
	if [ "${md5_cur_sh}" == "${md5_download_sh}" ]; then
		log_info "${FILE_SH} not modified"
	else  
		log_info "${FILE_SH} modified,need replace"
		cp ${temp_file} ${FILE_SH}
		chmod 777 ${FILE_SH}
		log_info "${FILE_SH} replaced, exit!"
		exit 0;
	fi
}

get_seconds_after_modified(){
	local file=$1
	local seconds=`stat -c %Y" "%Z ${file} |awk '{if($1>$2){t=$1}else{t=$2};printf t" ";system("date +%s")}'|awk '{print $2-$1}'`
	##echo "file:${file} seconds:${seconds}"
	##return ${seconds}
	echo ${seconds}
}

get_seconds_modified(){
	##TODO 注意区分last modify和last change的区别
	local file=$1
	local seconds=`stat -c %Y ${file}`
	echo ${seconds}
}

get_date_str_modified(){
	local file=$1
	local str=`stat -c %y ${file} |awk -F"." '{print $1}'`
	echo ${str}
}

get_file_size(){
	local file=$1	
	local size=`ls -l $1 | awk '{ print $5 }'`
	echo ${size}
}


get_app_name(){
	if [ -z "${ENV_APP_NAME}" ]; then
		ENV_APP_NAME=`find /home/admin/*/target -name "*.war" |head -n 1`
		ENV_APP_NAME=`echo ${ENV_APP_NAME##*/} |sed "s/.war//g"`
	fi
	if [ -z "${ENV_APP_NAME}" ]; then
		ENV_APP_NAME="${ENV_APP_NAME_DEFAULT}"
	fi
	echo ${ENV_APP_NAME}
}

get_ip(){
	if [ -z "${ENV_IP}" ]; then
		ENV_IP=`/sbin/ifconfig  | grep "inet.*Mask" |grep -v 127.0.0.1 | awk -F":" '{print $2}'|awk '{print $1}'| head -n 1`
	fi
	echo ${ENV_IP}
}

get_env_type(){
	ping -c 1 "${URL_ATEYE_PRE}"  >/dev/null
	if [ $? -eq 0 ]; then   
		if [ "${URL_ATEYE_PRE}" = "${ENV_IP}" ]; then
			ENV_TYPE="PRE"
			URL_HOST="${URL_ATEYE_PRE}"
		else 
			ENV_TYPE="PROD"
			URL_HOST="${URL_ATEYE_PROD}"
		fi		
	else   
		#ENV_TYPE="DAILY"
		#URL_HOST="${URL_ATEYE_DAILY}"
		ENV_TYPE="PROD"
		URL_HOST="${URL_ATEYE_PROD}"
	fi
}

current_time(){
date "+%Y-%m-%d %H:%M:%S"
}

log_debug(){
echo "[`current_time`][DEBUG] $1"
}

log_info(){
echo "[`current_time`][INFO] $1"
}

log(){
echo "`current_time` $1"
}

main() {
case "$ACTION" in
    setup)
        setup
    ;;
    run)
        run
    ;;
    dry_run)
        dry_run
    ;;
    remove)
	remove_job_crontab
    ;;
    *)
        usage
    ;;
esac
}
    
main $@
