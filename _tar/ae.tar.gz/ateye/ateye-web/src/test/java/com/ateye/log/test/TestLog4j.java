package com.ateye.log.test;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.taobao.ateye.log.Log4jFacility;

public class TestLog4j {
	private static final Logger logger = Logger.getLogger("TrackerDataLogger");
	@Test
	public void test(){
		System.out.println(2&0);
		Log4jFacility.addCustomizedErrorAppender();
		System.out.println(JSON.toJSONString(Log4jFacility.getAllLoggerAppenders()));
		logger.error("btbt");
		logger.warn("warn");
		logger.debug("debug");
		logger.trace("trace");
		logger.info("info");
		try{
			bb();
		}catch(Throwable t){
			logger.error("adfasf", t);
		}
	}
	private void bb(){
		throw new NullPointerException("abcde");
	}
}
