package com.ateye.dao;

import java.io.IOException;

import ch.qos.logback.core.FileAppender;

public class MyFileAppender<E> extends FileAppender<E> {
	@Override
	protected void writeOut(E event) throws IOException {
		try{		
			super.writeOut(event);
			Thread.sleep(10l);	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}