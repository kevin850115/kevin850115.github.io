package com.ateye.log.test;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TestLogback {
	public static Logger log = LoggerFactory.getLogger("asyncLog");

	@Test
	public void test() {
		log.error("test");
	}
}
