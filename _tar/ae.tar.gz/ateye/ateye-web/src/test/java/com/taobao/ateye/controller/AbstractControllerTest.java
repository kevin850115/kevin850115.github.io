package com.taobao.ateye.controller;

import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.ui.ModelMap;

import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dal.MachineDAO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.EnvironmentService;
import com.taobao.ateye.service.OpsServic;

/**
 * Created by wangj.w on 2016/6/6.
 */

public class AbstractControllerTest {

    @Mock
    protected AppDAO appDAO;
    @Mock
    protected MachineDAO machineDAO;
    @Mock
    protected EnvironmentService environmentService;
    @Mock
    protected OpsServic opsServic;


    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Test
    public void testGetValidReturnUrl() {

        AbstractController abstractController = new AbstractController() {
            @Override
            protected Map<String, List<List<String>>> initBizMapOwned(ModelMap result) throws DAOException {
                return super.initBizMapOwned(result);
            }
        };


        Assert.assertNull(
                abstractController.getValidReturnUrl(null));

        Assert.assertEquals("",
                abstractController.getValidReturnUrl(""));


        Assert.assertEquals("http://www.alibaba-inc.com/aaa.htm",
                abstractController.getValidReturnUrl("http://www.alibaba-inc.com/aaa.htm"));


        Assert.assertEquals("",
                abstractController.getValidReturnUrl("http://www.alibaba-inc.com.abc.com/aaa.htm"));



        Assert.assertEquals("http://www.alibaba-inc.com/aaa.htm?a=1&b=2",
                abstractController.getValidReturnUrl("http://www.alibaba-inc.com/aaa.htm?a=1&b=2"));


        Assert.assertEquals("http://www.alitrip.net/aaa.htm?a=1&b=2",
                abstractController.getValidReturnUrl("http://www.alitrip.net/aaa.htm?a=1&b=2"));

    }


}
