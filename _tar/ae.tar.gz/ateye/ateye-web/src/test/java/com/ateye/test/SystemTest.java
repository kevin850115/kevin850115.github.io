package com.ateye.test;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.net.URISyntaxException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import sun.jvmstat.monitor.Monitor;
import sun.jvmstat.monitor.MonitorException;
import sun.jvmstat.monitor.MonitoredHost;
import sun.jvmstat.monitor.MonitoredVm;
import sun.jvmstat.monitor.VmIdentifier;

import com.alibaba.fastjson.JSON;

public class SystemTest {
	static final String YOUNG_GC_MONITOR_NAME = "sun.gc.collector.0.invocations";
	static final String FULL_GC_MONITOR_NAME  = "sun.gc.collector.1.invocations";
	public static void main(String[] args) {
		//CPU���
		System.out.println(ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage());
		List<MemoryPoolMXBean> memoryPoolMXBeans = ManagementFactory.getMemoryPoolMXBeans();
		for ( MemoryPoolMXBean mmm:memoryPoolMXBeans ){
			System.out.println(mmm.getName());
			System.out.println(JSON.toJSONString(mmm.getUsage(),true));
		}
		List<GarbageCollectorMXBean> gcmList=ManagementFactory.getGarbageCollectorMXBeans();
		for ( GarbageCollectorMXBean gcm:gcmList ){
			System.out.println(gcm.getName());
			System.out.println(gcm.getCollectionCount());
		}
		String name = ManagementFactory.getRuntimeMXBean().getName();
		int indexOf = name.indexOf("@");
		String nn = name.substring(0, indexOf);
		try {
			VmIdentifier vmId = new VmIdentifier(nn);
			MonitoredHost monitoredHost = MonitoredHost.getMonitoredHost(vmId);
			MonitoredVm monitoredVm = monitoredHost.getMonitoredVm(vmId, 0);
			Monitor youngGCMonitor = monitoredVm.findByName(YOUNG_GC_MONITOR_NAME);
			Monitor fullGCMonitor = monitoredVm.findByName(FULL_GC_MONITOR_NAME);
			int cnt=0;
			while(cnt++<1000){
				System.out.println(youngGCMonitor.getValue()+":"+fullGCMonitor.getValue());
				TimeUnit.SECONDS.sleep(1l);
				byte bb[] = new byte[102400000];
			}
		} catch (MonitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
