package com.ateye.multi;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.taobao.ateye.multithread.AbstractMultiThreadBatchTask;
import com.taobao.ateye.multithread.IBatchTask;

public class TestMultiThread {

	@Test
	public void test(){
		final List<String> ss = new ArrayList<String>();
		for ( int i=0;i<37;++i ){
			ss.add(String.valueOf(i));
		}
		
		IBatchTask bt = new AbstractMultiThreadBatchTask<String>(20) {

			@Override
			protected void doSingleWork(String obj) {
				System.out.println(obj+",thread:"+Thread.currentThread().getId());
			}

			@Override
			protected List<String> getObjects() {
				return ss;
			}
		};
		bt.doWork();
	}
}
