package com.ateye.dao;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations ={
		"classpath:spring-placeholder.xml"
		})
@TransactionConfiguration(transactionManager = "transactionManager")
public class TestOther {
	private final Log fileLog = LogFactory.getLog("fileLog");
	private final Log asynclog = LogFactory.getLog("asyncLog");
	private final static int LOG_COUNT=100;
	@Test
	public void testMultiThreadLog() throws Exception{
		// 并发查询
		int threads = 100;
		for(int i=0;i<10;i++){
			List<Long> listFile = runLogThreads(fileLog,threads);
			List<Long> listAsync = runLogThreads(asynclog,threads);
			List<Long> listOneAsync = runOneLogThreads(asynclog,threads);
			List<Long> listOneFile = runOneLogThreads(fileLog,threads);
			//
			printList("fileLog", listFile);
			printList("asynclog", listAsync);
			//
			printList("onethread-fileLog", listOneFile);
			printList("onethread-asynclog", listOneAsync);
			//
			Thread.sleep(2000);
		}
	}
	
	@Test
	public void testLogOne() throws Exception{
		fileLog.info("hello");
		asynclog.info("hello");
	}
	
	public List<Long>  runOneLogThreads(Log log,int threads) throws Exception{
		List<Long> list = Lists.newArrayList(); 
		LogThread t = new LogThread(log,list);
		for(int i=0;i<threads;i++){
			t.run();
		}
		return list;
	}
	
	public List<Long>  runLogThreads(Log log,int threads) throws Exception{
		ListeningExecutorService service = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(threads));
		List<Long> list = new CopyOnWriteArrayList<Long>();
		// 放入任务
		for (int i = 0; i < threads; i++) {
			service.submit(new LogThread(log,list));
		}
		//
		service.shutdown();
		service.awaitTermination(1000,TimeUnit.SECONDS);
		//
		return list;
	}
	
	public static void printList(String name,List<Long> list){
		long l = 0;
		for(Long i:list){
			l+=i;
		}		
		System.out.println(name+" total:"+l+",cnt:"+list.size()+",avg:"+(l/list.size())+",max:"+Collections.max(list));
	}
	
	public static class LogThread implements Runnable{
		Log log;
		List<Long> list;
		public LogThread(Log log,List<Long> list){
			this.log = log;
			this.list = list;
		}
		@Override
		public void run(){
			String s = "Log";
			List<Long> tmpList = Lists.newArrayList();
			for(int i=0;i<LOG_COUNT;i++){
				long l = System.currentTimeMillis();
				log.info(s);
				long rt = System.currentTimeMillis() - l;
				if(rt>1){
					//System.out.println((new Date()).getTime()+" "+s+"["+Thread.currentThread().getName()+"] cost time: "+rt);
				}
				tmpList.add(rt);
				try{
					Thread.sleep(20l);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			list.addAll(tmpList);
		}
	}
	
	public static void main(String[] args){
		System.out.println("\u5361\u4e3a\u7a7a");
	}
}
