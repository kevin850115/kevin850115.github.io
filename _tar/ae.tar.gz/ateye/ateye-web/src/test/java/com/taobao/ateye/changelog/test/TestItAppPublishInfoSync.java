/*
 * Copyright 2015 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.taobao.ateye.changelog.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONArray;
import com.taobao.ateye.changelog.AppChangeLogService;
import com.taobao.ateye.changelog.apppub.AppPublishInfoSync;
import com.taobao.ateye.dal.AppChangeLogDAO;
import com.taobao.ateye.dal.AppDAO;
import com.taobao.ateye.dataobject.AppChangeLogDO;
import com.taobao.ateye.exception.DAOException;
import com.taobao.ateye.service.impl.AppChangeLogServiceImpl;

/**
 * 类AppPublishInfoSync.java
 * 
 * @author wangj.w
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations ={
		"classpath:spring-placeholder.xml",
		"classpath:biz-common.xml",
		"classpath:persistent/ateye-ds.xml",
		"classpath:bean/biz-dao.xml"
		})
public class TestItAppPublishInfoSync {

	@Autowired
	private AppPublishInfoSync appPublishInfoSync;
	@Autowired
	AppDAO appDAO;
	@Autowired
	AppChangeLogDAO appChangeLogDAO;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		
	}
	/**
	 * Test method for
	 * {@link com.taobao.ateye.changelog.apppub.AppPublishInfoSync#getAppPubInfo(java.lang.String, java.util.Date, java.util.Date)}
	 * .
	 * @throws ParseException 
	 */
	//@Test
	public void testGetAppPubInfo() throws ParseException {
		//fail("Not yet implemented");
		
		Date startTime = AppPublishInfoSync.sdf.parse("2015-08-08 11:08:00");
		Date finishTime = AppPublishInfoSync.sdf.parse("2015-08-12 18:20:00");
		
		JSONArray jsonArray = appPublishInfoSync.getAppPubInfo("ato", startTime, finishTime);
		
		Assert.assertEquals(15, jsonArray.size());
		
	}

	

	/**
	 * Test method for
	 * {@link com.taobao.ateye.changelog.apppub.AppPublishInfoSync#syncAppPubInfo(java.lang.String)}
	 * .
	 * @throws ParseException 
	 * @throws DAOException 
	 */
	//@Test
	public void testSyncAppPubInfo() throws ParseException, DAOException {
		appPublishInfoSync.syncAppPubInfo(appDAO.getAppByName("tripffa"));
	}

	/**
	 * Test method for
	 * {@link com.taobao.ateye.changelog.apppub.AppPublishInfoSync#syncAllAppPubInfo()}
	 * .
	 */
	//@Test
	public void testSyncAllAppPubInfo() {
		appPublishInfoSync.syncAllAppPubInfo();
		appPublishInfoSync.syncAllAppPubInfo();
	}

	

}
