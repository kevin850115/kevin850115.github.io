package com.ateye.algo;

public class FindMostIP {
	private String mostIp="";
	private Long times=0l;
	public void feedIp(String ip){
		if ( times == 0l ){
			mostIp = ip;
			times = 1l;
		}
		if ( ip.equals(getMostIp()) ){
			setTimes(getTimes() + 1);
		}else{
			setTimes(getTimes() - 1);
		}
	}
	public static void main(String[] args) {
		FindMostIP fmi = new FindMostIP();
		for ( int i=0;i<100;i++ ){
			fmi.feedIp("1000");
			fmi.feedIp(String.valueOf(i));
		}
		System.out.println(fmi.getMostIp());
		System.out.println(fmi.getTimes());
	}
	public void setMostIp(String mostIp) {
		this.mostIp = mostIp;
	}
	public String getMostIp() {
		return mostIp;
	}
	public void setTimes(Long times) {
		this.times = times;
	}
	public Long getTimes() {
		return times;
	}
	
}
