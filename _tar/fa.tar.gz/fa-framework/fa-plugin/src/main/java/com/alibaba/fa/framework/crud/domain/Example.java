package com.alibaba.fa.framework.crud.domain;

/**
 *
 * @author zhanglei
 * @date 2017/3/12
 */
public abstract class Example{

    private Integer limit;

    private Integer start;

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }
}
