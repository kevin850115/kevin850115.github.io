package com.alibaba.fa.framework.plugin.generator;

import java.util.List;

import org.mybatis.generator.api.PluginAdapter;

/**
 * Created by wb-hyl282156 on 2018/2/27.
 */
public class DealMapperPlugin extends PluginAdapter {
    @Override
    public boolean validate(List<String> list) {
        return false;
    }




}
