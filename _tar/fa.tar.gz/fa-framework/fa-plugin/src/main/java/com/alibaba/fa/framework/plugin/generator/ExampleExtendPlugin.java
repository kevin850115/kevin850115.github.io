package com.alibaba.fa.framework.plugin.generator;

import java.util.List;
import java.util.Properties;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.TopLevelClass;

/**
 * Example主动继承父类插件
 *
 * @author wb-hyl282156
 * @date 2018/2/27
 */
public class ExampleExtendPlugin extends PluginAdapter {

    private String rootClass;

    @Override
    public void setProperties(Properties properties) {
        super.setProperties(properties);
        this.rootClass = properties.getProperty("rootClass");
    }

    @Override
    public boolean validate(List<String> list) {
        if(null == rootClass || rootClass.length() == 0 || rootClass.trim().length() == 0){
            return false;
        }
        return true;
    }

    @Override
    public boolean modelExampleClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        FullyQualifiedJavaType subper = new FullyQualifiedJavaType(rootClass);

        //添加继承类
        topLevelClass.setSuperClass(subper);

        //添加导入
        topLevelClass.addImportedType(subper);

        return true;
    }
}
