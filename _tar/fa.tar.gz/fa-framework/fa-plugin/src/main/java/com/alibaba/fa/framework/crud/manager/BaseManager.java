package com.alibaba.fa.framework.crud.manager;

import com.alibaba.fa.framework.crud.dao.IMapper;
import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.crud.domain.Example;
import com.alibaba.fa.framework.crud.domain.Page;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by zhanglei on 2017/4/13.
 */
public abstract class BaseManager<T extends BaseEntity,E extends Example,S extends IMapper<T,E,?>> {

    @Autowired
    protected S mapper;

    public Page<T> queryPage(E example) {
        Page<T> page = new Page<>();
        page.setStart(example.getStart());
        page.setLimit(example.getLimit());

        page.setCount(mapper.countByExample(example));
        page.setData(mapper.selectByExample(example));

        return page;
    }

}
