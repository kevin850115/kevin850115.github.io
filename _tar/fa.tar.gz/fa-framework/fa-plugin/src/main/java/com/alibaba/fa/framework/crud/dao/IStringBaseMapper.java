package com.alibaba.fa.framework.crud.dao;

import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.crud.domain.Example;

/**
 * Created by zhanglei on 2017/4/16.
 */
public interface IStringBaseMapper <T extends BaseEntity,E extends Example> extends IMapper<T,E,String> {
}
