package com.alibaba.fa.framework.crud.domain;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhanglei on 2017/3/12.
 */
public class Page<T> implements Serializable {

    /**
     * 数据集合
     */
    private List<T> data;

    /**
     * 总记录数
     */
    private int count;

    /**
     * 开始记录数
     */
    private int start;

    /**
     * 查询条数
     */
    private int limit;

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}
