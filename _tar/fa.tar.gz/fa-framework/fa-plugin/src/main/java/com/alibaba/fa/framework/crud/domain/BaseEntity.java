package com.alibaba.fa.framework.crud.domain;

import java.io.Serializable;

/**
 *
 * @author zhanglei
 * @date 2017/3/9
 */
public abstract class BaseEntity implements Serializable {

}
