package com.alibaba.fa.framework.util;

/**
 * Created by zhanglei on 2017/10/17.
 */
public class Monitor {
    private String type;

    private String time;

    private Long execTime = 0L;

    private Integer orderStatus = 0;

    private Integer count = 1;

    private Integer success = 0;

    private Integer failed = 0;

    private Long agentId = 0L;

    private String channel = "null";

    private String airways = "null";

    private String operator="null";

    private Long buyPrice = 0L;

    private Long sellPrice = 0L;

    private Integer bizCount1 = 0;

    private Integer bizCount2 = 0;

    private Integer bizCount3 = 0;

    private String bizType = "null";

    private String errorCode = "null";

    public String toLogString(){
        String split = "|";
        return split + type +split + time+split+execTime+split
            +orderStatus+split+count+split+success+split+failed+split+agentId+split
            +channel+split+airways+split+buyPrice+split+sellPrice+split
            +bizType+split+errorCode+split+operator+split+bizCount1 + split +bizCount2 + split + bizCount3;
    }

    public Integer getBizCount2() {
        return bizCount2;
    }

    public void setBizCount2(Integer bizCount2) {
        this.bizCount2 = bizCount2;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Long getExecTime() {
        return execTime;
    }

    public void setExecTime(Long execTime) {
        this.execTime = execTime;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public Integer getFailed() {
        return failed;
    }

    public void setFailed(Integer failed) {
        this.failed = failed;
    }

    public Long getAgentId() {
        return agentId;
    }

    public void setAgentId(Long agentId) {
        this.agentId = agentId;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getAirways() {
        return airways;
    }

    public void setAirways(String airways) {
        this.airways = airways;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Long getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(Long buyPrice) {
        this.buyPrice = buyPrice;
    }

    public Long getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Long sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getErrorCode() {
        return errorCode;
    }


    public Integer getBizCount1() {
        return bizCount1;
    }

    public void setBizCount1(Integer bizCount1) {
        this.bizCount1 = bizCount1;
    }

    public Integer getBizCount3() {
        return bizCount3;
    }

    public void setBizCount3(Integer bizCount3) {
        this.bizCount3 = bizCount3;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
