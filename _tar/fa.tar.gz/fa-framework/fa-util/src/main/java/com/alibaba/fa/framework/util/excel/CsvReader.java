package com.alibaba.fa.framework.util.excel;

import com.opencsv.CSVReader;
import com.opencsv.stream.reader.LineReader;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wb-zgl234479
 * @create 2018/04/26 16:42
 **/

public class CsvReader {
    private IRowReader rowReader;
    private int titleRowNum = 0;
    private int startRowNum = 1;
    private int count = 1000;

    public int getTitleRowNum() {
        return titleRowNum;
    }

    public void setTitleRowNum(int titleRowNum) {
        this.titleRowNum = titleRowNum;
    }

    public int getStartRowNum() {
        return startRowNum;
    }

    public void setStartRowNum(int startRowNum) {
        this.startRowNum = startRowNum;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public IRowReader getRowReader() {
        return rowReader;
    }

    public void setRowReader(IRowReader rowReader) {
        this.rowReader = rowReader;
    }

    private String getCharset(InputStream bin) throws IOException {
        int p = (bin.read() << 8) + bin.read();
        String code = null;
        switch (p) {
            case 0xefbb:
                code = "UTF-8";
                break;
            case 0xfffe:
                code = "Unicode";
                break;
            case 0xfeff:
                code = "UTF-16BE";
                break;
            default:
                code = "GBK";
        }
        return code;
    }

    public void process(InputStream inputStream) throws Exception {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        bufferedInputStream.mark(0);
        String encoding = getCharset(bufferedInputStream);
        bufferedInputStream.reset();
        try {
            if(startRowNum <= titleRowNum) {
                throw new  Exception("标题行要在数据起始行前面");
            }
            inputStreamReader = new InputStreamReader(bufferedInputStream, encoding);
            bufferedReader = new BufferedReader(inputStreamReader);
            int  rowIndex  =  0;
            String[] titleRow = null;
            List<Object> contentList = new ArrayList<>();
            String next;
            while  ((next  = bufferedReader.readLine())  !=  null)  {
                String[]  nextRow  =  next.split(",");
                if (rowIndex != titleRowNum && rowIndex  <  startRowNum)  {
                    continue;
                }
                if (nextRow  ==  null  ||  nextRow.length  <=  0)  {
                    continue;
                }
                int columnSize  =  nextRow.length;
                if(rowIndex == titleRowNum) {
                    for(int colIndex = 0; colIndex < columnSize; colIndex++) {
                        nextRow[colIndex] = StringUtils.remove(nextRow[colIndex] , "\n");
                    }
                    titleRow = nextRow;
                }else {
                    Map<String, Object> row = new HashMap<>();
                    for(int colIndex = 0; colIndex < Math.min(titleRow.length, nextRow.length); colIndex++) {
                        nextRow[colIndex] = StringUtils.remove(nextRow[colIndex] , "\n");
                        String title = titleRow[colIndex];
                        String value = nextRow[colIndex];
                        Object renderValue = rowReader.getCol(0, rowIndex, colIndex, title, value);
                        row.put(title, renderValue);
                    }
                    contentList.add(row);
                }
                if(contentList.size() % count == 0 && contentList.size() > 0) {
                    rowReader.getRows(0, rowIndex, contentList);
                    contentList.clear();
                }
                ++rowIndex;
            }
            if(!contentList.isEmpty()) {
                rowReader.getRows(0, rowIndex, contentList);
                contentList.clear();
            }
        } finally {
            try {
                if(bufferedReader != null) {
                    bufferedReader.close();
                }
            }
            catch (IOException e) {
            }
            try {
                if(inputStreamReader != null) {
                    inputStreamReader.close();
                }
            }
            catch (IOException e) {
            }
            try {
                if(bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
            } catch (IOException e) {
            }
            try {
                if(inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
            }
        }
    }

    public void process(String fileName) throws Exception {
        InputStream inputStream = new FileInputStream(fileName);
        this.process(inputStream);
    }
}
