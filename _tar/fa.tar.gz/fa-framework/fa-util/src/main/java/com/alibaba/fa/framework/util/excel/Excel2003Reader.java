package com.alibaba.fa.framework.util.excel;

import com.alibaba.fa.framework.util.Reflections;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.eventusermodel.EventWorkbookBuilder.SheetRecordCollectingListener;
import org.apache.poi.hssf.eventusermodel.*;
import org.apache.poi.hssf.eventusermodel.dummyrecord.LastCellOfRowDummyRecord;
import org.apache.poi.hssf.eventusermodel.dummyrecord.MissingCellDummyRecord;
import org.apache.poi.hssf.model.HSSFFormulaParser;
import org.apache.poi.hssf.record.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.util.NumberToTextConverter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 抽象Excel2003读取器，通过实现HSSFListener监听器，采用事件驱动模式解析excel2003 中的内容，遇到特定事件才会触发，大大减少了内存的使用。
 * 章磊
 *
 */
public class Excel2003Reader implements HSSFListener {
	private POIFSFileSystem fs;

	/** Should we output the formula, or the value it has? */
	private boolean outputFormulaValues = true;
	/** For parsing Formulas */
	private SheetRecordCollectingListener workbookBuildingListener;
	// excel2003工作薄
	private HSSFWorkbook stubWorkbook;

	// Records we pick up as we process
	private SSTRecord sstRecord;
	private FormatTrackingHSSFListener formatListener;

	// 表索引
	private int sheetIndex = -1;
	private BoundSheetRecord[] orderedBSRs;
	@SuppressWarnings("unchecked")
	private ArrayList boundSheetRecords = new ArrayList();

	// For handling formulas with string results
	private int nextRow;
	private int nextColumn;
	private boolean outputNextStringRecord;
	// 当前行
	private int curRow = 0;
	@SuppressWarnings("unused")
	private String sheetName;

	private IRowReader rowReader;

	private int titleRow = 0;

	private int startRow = 1;//数据起始行

	private List<String> titleRowlist = new ArrayList<String>();

	private List<Object> rowBeanlist = new ArrayList<Object>();
	private Class cls;
	private Object target;
	private boolean isEmptyRow = true;
	private int count = 1000;
	private Map<String,Field> titleFields;
	/**只读指定序号的sheet*/
	private Integer appointedSheetIndex;

	public Integer getAppointedSheetIndex() {
		return appointedSheetIndex;
	}

	public void setAppointedSheetIndex(Integer appointedSheetIndex) {
		this.appointedSheetIndex = appointedSheetIndex;
	}

	public void setTitleRow(int titleRow) {
		this.titleRow = titleRow;
	}
	public void setStartRow(int startRow){
		this.startRow = startRow;
	}
	public void setCls(Class cls) {
		this.cls = cls;
	}

	public void setRowReader(IRowReader rowReader) {
		this.rowReader = rowReader;
	}

	/**
	 * 遍历excel下所有的sheet
	 *
	 * @throws IOException
	 */
	public void process(String fileName) throws Exception {
		this.fs = new POIFSFileSystem(new FileInputStream(fileName));
		_process();
	}

	public void process(InputStream inputStream) throws Exception {
		this.fs = new POIFSFileSystem(inputStream);
		_process();
	}

	private void _process() throws Exception {
		MissingRecordAwareHSSFListener listener = new MissingRecordAwareHSSFListener(this);
		formatListener = new FormatTrackingHSSFListener(listener);
		HSSFEventFactory factory = new HSSFEventFactory();
		HSSFRequest request = new HSSFRequest();
		if (outputFormulaValues) {
			request.addListenerForAllRecords(formatListener);
		} else {
			workbookBuildingListener = new SheetRecordCollectingListener(formatListener);
			request.addListenerForAllRecords(workbookBuildingListener);
		}
		factory.processWorkbookEvents(request, fs);
	}

	/**
	 * HSSFListener 监听方法，处理 Record
	 */
	@Override
    @SuppressWarnings("unchecked")
	public void processRecord(Record record) {
		int thisRow = -1;
		int thisColumn = -1;
		String thisStr = null;
		String value = null;
		if (appointedSheetIndex != null && sheetIndex != appointedSheetIndex.intValue()
				&& record.getSid() != BoundSheetRecord.sid
				&& record.getSid() != BOFRecord.sid
				&& record.getSid() != SSTRecord.sid) {
			return;
		}
		switch (record.getSid()) {
			case BoundSheetRecord.sid:
				boundSheetRecords.add(record);
				break;
			case BOFRecord.sid:
				BOFRecord br = (BOFRecord) record;
				if (br.getType() == BOFRecord.TYPE_WORKSHEET) {
					// 如果有需要，则建立子工作薄
					if (workbookBuildingListener != null && stubWorkbook == null) {
						stubWorkbook = workbookBuildingListener.getStubHSSFWorkbook();
					}

					sheetIndex++;
					if (orderedBSRs == null) {
						orderedBSRs = BoundSheetRecord.orderByBofPosition(boundSheetRecords);
					}
					sheetName = orderedBSRs[sheetIndex].getSheetname();
				}
				break;

			case SSTRecord.sid:
				sstRecord = (SSTRecord) record;
				break;

			case BlankRecord.sid:
				BlankRecord brec = (BlankRecord) record;
				thisRow = brec.getRow();
				thisColumn = brec.getColumn();
				if (thisColumn < 0) {//这是读到最后的空列的情况
					break;
				}
				thisStr = "";
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);
					Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, thisStr);
					setValue(title, valueo);
				} else if (curRow == titleRow) {
					putTitle(thisColumn, thisStr);
				}
				break;
			case BoolErrRecord.sid: // 单元格为布尔类型
				BoolErrRecord berec = (BoolErrRecord) record;
				thisRow = berec.getRow();
				thisColumn = berec.getColumn();
				thisStr = berec.getBooleanValue() + "";
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);
					Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, thisStr);
					setValue(title, valueo);
				} else if (curRow == titleRow) {
					putTitle(thisColumn, thisStr);
				}
				break;

			case FormulaRecord.sid: // 单元格为公式类型
				FormulaRecord frec = (FormulaRecord) record;
				thisRow = frec.getRow();
				thisColumn = frec.getColumn();
				if (outputFormulaValues) {
					if (Double.isNaN(frec.getValue())) {
						// Formula result is a string
						// This is stored in the next record
						outputNextStringRecord = true;
						nextRow = frec.getRow();
						nextColumn = frec.getColumn();
					} else {
						thisStr = formatListener.formatNumberDateCell(frec);
					}
				} else {
					thisStr = '"' + HSSFFormulaParser.toFormulaString(stubWorkbook, frec.getParsedExpression()) + '"';
				}
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);
					Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, thisStr);
					setValue(title, valueo);
				} else if (curRow == titleRow) {
					putTitle(thisColumn, thisStr);
				}
				break;
			case StringRecord.sid:// 单元格中公式的字符串
				if (outputNextStringRecord) {
					// String for formula
					StringRecord srec = (StringRecord) record;
					thisStr = srec.getString();
					thisRow = nextRow;
					thisColumn = nextColumn;
					outputNextStringRecord = false;
				}
				break;
			case LabelRecord.sid:
				LabelRecord lrec = (LabelRecord) record;
				curRow = thisRow = lrec.getRow();
				thisColumn = lrec.getColumn();
				value = lrec.getValue().trim();
				value = value.equals("") ? " " : value;
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);
					Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, value);
					setValue(title, valueo);
				} else if (curRow == titleRow) {
					putTitle(thisColumn, value);
				}
				break;
			case LabelSSTRecord.sid: // 单元格为字符串类型
				LabelSSTRecord lsrec = (LabelSSTRecord) record;
				curRow = thisRow = lsrec.getRow();
				thisColumn = lsrec.getColumn();
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);

					if (sstRecord == null) {
						Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, " ");
						setValue(title, valueo);
					} else {
						value = sstRecord.getString(lsrec.getSSTIndex()).toString().trim();
						value = value.equals("") ? " " : value;
						Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, value);
						setValue(title, valueo);
					}
				} else if (curRow == titleRow) {
					if (sstRecord == null) {
						putTitle(thisColumn, " ");
					} else {
						value = sstRecord.getString(lsrec.getSSTIndex()).toString().trim();
						value = value.equals("") ? " " : value;
						putTitle(thisColumn, value);
					}
				}

				break;
			case NumberRecord.sid: // 单元格为数字类型
				NumberRecord numrec = (NumberRecord) record;
				curRow = thisRow = numrec.getRow();
				thisColumn = numrec.getColumn();
				int formatIndex = formatListener.getFormatIndex(numrec);
				String formatString = formatListener.getFormatString(numrec);
				if (StringUtils.isNotBlank(formatString) && DateUtil.isADateFormat(formatIndex, formatString)) {//日期类型
					value = formatListener.formatNumberDateCell(numrec).trim();
				} else {
					value = NumberToTextConverter.toText(numrec.getValue());
				}
				value = value.equals("") ? " " : value;
				// 向容器加入列值
				if (curRow >= startRow && thisColumn < titleRowlist.size()) {
					String title = titleRowlist.get(thisColumn);
					Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, value);
					setValue(title, valueo);
				} else if (curRow == titleRow) {
					putTitle(thisColumn, value);
				}
				break;
			default:
				break;
		}
		// 空值的操作
		if (record instanceof MissingCellDummyRecord) {
			MissingCellDummyRecord mc = (MissingCellDummyRecord) record;
			curRow = thisRow = mc.getRow();
			thisColumn = mc.getColumn();
			if (curRow >= startRow) {
				String title = titleRowlist.get(thisColumn);
				Object valueo = rowReader.getCol(sheetIndex, curRow, thisColumn, title, " ");
				setValue(title, valueo);
			} else if (curRow == titleRow) {
				putTitle(thisColumn, " ");
			}
		}
		// 行结束时的操作
		if (record instanceof LastCellOfRowDummyRecord) {
			try {
				if (curRow >= startRow && !isEmptyRow) {
					rowBeanlist.add(target);
				}
				if (cls == null) {
					target = new LinkedHashMap();
					isEmptyRow = true;
				} else {
					target = cls.newInstance();
					isEmptyRow = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (rowBeanlist.size() == count) {
			if (!rowBeanlist.isEmpty()) {
				rowReader.getRows(sheetIndex, curRow, rowBeanlist);
			}
			rowBeanlist.clear();
		} else if (record instanceof EOFRecord) {//最后一行
			//最后一行时碰到特殊excel，不能读到列尾，则会漏掉最后一行记录
			if (!isEmptyRow) {
				rowBeanlist.add(target);
			}
			if (!rowBeanlist.isEmpty()) {
				rowReader.getRows(sheetIndex, curRow, rowBeanlist);
			}
			rowBeanlist.clear();
		}
	}

	private void setValue(String title, Object valueo) {
		if (valueo != null && StringUtils.isNotBlank(Objects.toString(valueo,""))) {
			isEmptyRow = false;
		}
		if (cls == null) {
			Map tmpMap = (Map) target;
			tmpMap.put(title, valueo);
		} else {
			try {
				if (titleFields == null) {
					titleFields = ExcelFieldUtil.getTitleFields(target.getClass());
				}
				Field field = titleFields.get(title);
				if (field != null) {
					Reflections.makeAccessible(field);
					field.set(target, valueo);
				}
				//ExcelFieldUtil.setProperty(target, title, valueo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private void putTitle(int colNum, String titleVal){
//		if (StringUtils.isNotBlank(titleVal)) {
//			this.titleRowlist.add(colNum, titleVal);
//		} else {
//			this.titleRowlist.add(colNum, "=blank=");
//		}
		this.titleRowlist.add(StringUtils.remove(titleVal,"\n"));
	}
}
