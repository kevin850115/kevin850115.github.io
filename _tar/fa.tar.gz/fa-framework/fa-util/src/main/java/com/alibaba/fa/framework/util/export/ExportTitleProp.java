package com.alibaba.fa.framework.util.export;

import java.lang.reflect.Method;

/**
 * Created by wb-lns279014 on 2017/5/26.
 */
public class ExportTitleProp {
    private boolean mapFlag;
    private String title;
    private String field;
    private Method method;

    public ExportTitleProp(boolean mapFlag, String title, String field, Method method){
        this.mapFlag = mapFlag;
        this.field = field;
        this.method = method;
        this.title = title;
    }

    public boolean isMapFlag() {
        return mapFlag;
    }

    public void setMapFlag(boolean mapFlag) {
        this.mapFlag = mapFlag;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
