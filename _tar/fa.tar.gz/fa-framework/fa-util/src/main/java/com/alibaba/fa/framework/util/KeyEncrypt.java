package com.alibaba.fa.framework.util;

import org.apache.commons.lang3.StringUtils;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class KeyEncrypt {
    public static String Encrypt4SHA256(String strSrc) {
        return Encrypt(strSrc, "SHA-256");
    }
	/**
	 * 对字符串进行摘要算法 使用MD5,SHA-1,SHA-256,默认使用SHA-256
	 * @param strSrc 要摘要算法的字符串
	 * @param encName 算法类型
	 */
    public static String Encrypt(String strSrc, String encName) {
    	MessageDigest md = null;
    	String strDes = null;
    	if (StringUtils.isEmpty(encName)) {
    		encName = "SHA-256";
    	}
    	byte[] bt = strSrc.getBytes();
    	try {
    		md = MessageDigest.getInstance(encName);
    		md.update(bt);
    		strDes = bytes2Hex(md.digest()); // to HexString
    	} catch (NoSuchAlgorithmException e) {
    		return null;
    	}
    	return strDes;
    }

	/**
	 * 对流进行摘要算法 使用MD5,SHA-1,SHA-256,默认使用SHA-256
	 * @param in 要摘要算法的流
	 * @param encName 算法类型
	 * @return
	 */
    public static String Encrypt4InputSteam(InputStream in, String encName){
    	if(in==null) {
            return null;
        }
    	MessageDigest md = null;
    	if (StringUtils.isEmpty(encName)) {
			encName = "SHA-256";
		}
    	byte[] hash = null;
    	String result = null;
    	BufferedInputStream bis = null;
    	DigestInputStream dis = null;
    	try {
    		md = MessageDigest.getInstance(encName);
    		bis = new BufferedInputStream(in);
    		dis = new DigestInputStream(bis, md);
    		byte[] buffer = new byte[1024];
    	    int read = dis.read(buffer);
    	    while (read > -1) {
    	        read = dis.read(buffer);
    	    }
    	    hash = dis.getMessageDigest().digest();
    	    result = bytes2Hex(hash);
		} catch (Exception e) {
			return result;
		}finally {
			try {
				if(dis!=null) {
                    dis.close();
                }
				if(bis!=null) {
                    bis.close();
                }
				if(in!=null) {
                    in.close();
                }
			} catch (IOException e) {
				return result;
			}
		}
		return result;
	}

	public static String bytes2Hex(byte[] bts) {
		String des = "";
		String tmp = null;
		for (int i = 0; i < bts.length; i++) {
			tmp = (Integer.toHexString(bts[i] & 0xFF));
			if (tmp.length() == 1) {
				des += "0";
			}
			des += tmp;
		}
		return des;
	}
}
