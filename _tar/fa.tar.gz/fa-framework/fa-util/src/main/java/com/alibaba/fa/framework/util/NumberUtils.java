package com.alibaba.fa.framework.util;

import java.math.BigDecimal;
import java.util.*;

import com.alibaba.fastjson.JSON;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.jexl2.Expression;
import org.apache.commons.jexl2.JexlContext;
import org.apache.commons.jexl2.JexlEngine;
import org.apache.commons.jexl2.MapContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;

/**
 *
 * @author wb-zgl234479
 * @date 2017/5/5
 */
public class NumberUtils {
    public static Long add(Long m1, Long m2){
        if(m2 == null){
            return m1;
        }
        if(m1 == null){
            return m2;
        }
        return m1 + m2;
    }

    public static Long sum(Long... arr){
        if(arr == null) {
            return null;
        }
        Long sum = null;
        for(Integer i =0; i< arr.length; i++) {
            if(sum == null && arr[i] != null) {
                sum = arr[i];
                continue;
            }
            if(arr[i] != null) {
                sum += arr[i];
            }

        }
        return sum;
    }

    public static Long sumNullZero(List<Long> arr){
        if(arr == null) {
            return 0L;
        }
        Long sum = 0L;
        for(Integer i =0; i< arr.size(); i++) {
            if(arr.get(i) != null) {
                sum += arr.get(i);
            }

        }
        return sum;
    }

    public static Long sumNullZero(Long... arr){
        if(arr == null) {
            return 0L;
        }
        Long sum = 0L;
        for(Integer i =0; i< arr.length; i++) {
            if(arr[i] != null) {
                sum += arr[i];
            }

        }
        return sum;
    }


    public static Long yuan2Fen(Long yuan) {
        if(yuan == null) {
            return null;
        }
        return yuan * 100;
    }

    public static Long yuan2FenNullZero(Long yuan) {
        if(yuan == null) {
            return 0L;
        }
        return yuan * 100;
    }


    public static Long fen2Yuan(Long fen) {
        if(fen == null) {
            return null;
        }
        return fen / 100;
    }

    public static Long fen2YuanNullZero(Long fen) {
        if(fen == null) {
            return 0L;
        }
        return fen / 100;
    }



    public static Long integer2Long(Integer integer) {
        if(integer == null) {
            return null;
        }
        return Long.valueOf(integer);
    }

    public static Long integer2LongNullZero(Integer integer) {
        if(integer == null) {
            return 0L;
        }
        return Long.valueOf(integer);
    }

    public static Integer long2Integer(Long l) {
        if(l == null) {
            return null;
        }
        return l.intValue();
    }

    public static Integer long2IntegerNullZero(Long l) {
        if(l == null) {
            return 0;
        }
        return l.intValue();
    }



    public static String convertToYuanCell(Long value){
        if (value == null || value == 0) {
            return "0";
        }
        double d = value.doubleValue() / 100;
        return  fmtNumber(Math.ceil(d));
    }

    public static String convertToYuan(Long value) {
        if (value == null || value == 0) {
            return "0";
        }
        return fmtNumber(value.doubleValue() / 100);
    }

    private static String fmtNumber(double d){
        BigDecimal bg = new BigDecimal(d).setScale(1, BigDecimal.ROUND_HALF_UP);
        return bg.toString();
    }

    public static Long yuanConvertToFen(String value) {
        if (StringUtils.isBlank(value)) {
            return 0L;
        }
        Double tmp=Double.parseDouble(value);
        return new BigDecimal(tmp.toString()).multiply(new BigDecimal(100)).longValue();
    }

    private static final Map<String,Expression> EXPRESSION_CACHE = new HashMap<>();

    public static Object formula(Map<String,?> params, String formula){
        Expression e = EXPRESSION_CACHE.get(formula);
        if(e == null){
            e = new JexlEngine().createExpression(formula);
        }
        try {
            JexlContext jc = new MapContext();
            for(Map.Entry<String,?> entry : params.entrySet()){
                jc.set(entry.getKey(),entry.getValue());
            }
            jc.set("res",null);
            e.evaluate(jc);
            return jc.get("res");
        }finally {
            if(!EXPRESSION_CACHE.containsKey(formula)){
                EXPRESSION_CACHE.put(formula,e);
            }
        }
    }


    public static List<Long> split(Long total, List<Long> weights) {
        if(total == null) {
            return null;
        }
        List<Long> result = new ArrayList<>();
        if(CollectionUtils.isEmpty(weights)) {
            result.add(total);
            return result;
        }
        Long weightTotal = sumNullZero(weights);
        Long beforeTotal = 0L;
        for (Long weight : weights) {
            if(weights.indexOf(weight) != weights.size() -1) {
                BigDecimal percent = new BigDecimal(0);
                if(weight != null) {
                    percent = new BigDecimal(weight).divide(new BigDecimal(weightTotal));
                }
                Long num = new BigDecimal(total).multiply(percent).longValue();
                beforeTotal += num;
                result.add(num);
            }else {
                //尾差处理
                result.add(total - beforeTotal);
            }
        }
        return result;
    }


}
