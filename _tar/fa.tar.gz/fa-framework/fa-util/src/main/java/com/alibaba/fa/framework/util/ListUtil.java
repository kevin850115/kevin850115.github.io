package com.alibaba.fa.framework.util;


import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wb-zgl234479 on 2017/4/14.
 */
public class ListUtil {
    public static String join(CharSequence delimiter, boolean isFiltSameData, List<String> elements){
        List<String> filtElements = new ArrayList<>();
        if(isFiltSameData){
            for(String element : elements){
                if(!filtElements.contains(element)) {
                    filtElements.add(element);
                }
            }
            elements = filtElements;
        }
        if(delimiter  == null || elements == null || elements.size() == 0){
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(String element : elements){
            if(StringUtils.isEmpty(element)){
                continue;
            }
            sb.append(delimiter);
            sb.append(element);
        }
        String value = sb.toString();
        if(StringUtils.isNotEmpty(value)){
            value = value.substring(1);
        }
        return value;
    }

    public static String join(CharSequence delimiter, List<String> elements){
        return join(delimiter, false, elements);
    }

}
