package com.alibaba.fa.framework.util.export.enums;

/**
 * Created by wb-lns279014 on 2017/5/26.
 */
public enum  ExportFileTypeEnum {
    CSV("CSV",".csv"),
    XLS("XLS",".xls"),
    XLSX("XLSX",".xlsx")
    ;

    private String key;
    private String code;
    private ExportFileTypeEnum(String key, String code){
        this.key = key;
        this.code = code;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
