package com.alibaba.fa.framework.util;

/**
 * Created by wb-zgl234479 on 2017/4/14.
 */
public interface IKeyDescEnum {
    Integer getKey();
    String getDesc();
    String getCode();
}
