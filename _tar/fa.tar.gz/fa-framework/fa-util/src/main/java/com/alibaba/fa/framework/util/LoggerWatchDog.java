package com.alibaba.fa.framework.util;

import com.alitrip.trade.tracker.Tracer;

/**
 * Created by wb-zxz248731 on 2017/5/4.
 */
public class LoggerWatchDog {

    private com.alitrip.trade.tracker.Tracer tracer;

    private org.slf4j.Logger logger;

    public Tracer getTracer() {
        return tracer;
    }

    public void setTracer(Tracer tracer) {
        this.tracer = tracer;
    }

    public LoggerWatchDog(org.slf4j.Logger logger, Tracer tracer) {
        this.tracer = tracer;
        this.logger = logger;
    }

    public String debug(String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isDebugEnabled()) {
            this.logger.debug(msg);
        }
        return msg;
    }

    public String info(String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isInfoEnabled()) {
            this.logger.info(msg);
        }
        return msg;
    }


    public String warn(String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isWarnEnabled()) {
            this.logger.warn(msg);
        }
        return msg;
    }

    public String error(String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isErrorEnabled()) {
            this.logger.error(msg);
        }
        return msg;
    }

    public String debug4Tracer(Object key, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isDebugEnabled() && key != null) {
            logger.debug(msg);
            if (tracer != null) {
                tracer.debug(String.valueOf(key), message, params);
            }
        }
        return msg;
    }


    public String info4Tracer(Object key, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isInfoEnabled() && key != null) {
            logger.info(msg);
            if (tracer != null) {
                tracer.info(String.valueOf(key), message, params);
            }
        }
        return msg;
    }


    public String warn4Tracer(Object key, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isWarnEnabled() && key != null) {
            logger.warn(msg);
            if (tracer != null) {
                tracer.warn(String.valueOf(key), message, params);
            }
        }
        return msg;
    }

    public String error(Throwable throwable, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isErrorEnabled()) {
            this.logger.error(msg, throwable);
        }
        return msg;
    }

    public String error4Tracer(Object key, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isErrorEnabled() && key != null) {
            logger.error(msg);
            if (tracer != null) {
                tracer.error(String.valueOf(key), message, params);
            }
        }
        return msg;
    }

    public String error4Tracer(Object key, Throwable throwable, String message, Object... params) {
        String msg = LoggerUtils.format(message, params);
        if (logger != null && this.logger.isErrorEnabled() && key != null) {
            logger.error(msg, throwable);
            if (tracer != null) {
                tracer.exception(String.valueOf(key), message, throwable, params);
            }
        }
        return msg;
    }
}
