package com.alibaba.fa.framework.util;

import java.util.*;

/**
 * Created by wb-zxz248731 on 2017/4/11.
 */
public class MathUtils {

    /**
     * 获得 [min,max) 范围的随机数
     * @return
     */
    public static Integer randomNumber(int min,int max) {
        Random random = new Random();
        return  random.nextInt(max)%(max-min+1) + min;
    }

    /**
     * 从List中随机获得指定size大小且从min下标开始的数据
     * @return
     */
    public static <T> List<T> randomList(List<T> list, Integer size ,Integer min){
        if(list==null||list.isEmpty()) {
            return list;
        }
        Integer listSize = list.size();
        size = size==null?0:size;
        min = min==null?0:min;
        Integer max = listSize;
        size = size > listSize ? listSize:size;
        if(min>=max) {
            return null;
        }
        Set<Integer> indexSet = new HashSet<>();
        do{
            indexSet.add(randomNumber(min,max));
        }while (indexSet.size()<size);
        List<Integer> indexList = new ArrayList<>(indexSet);
        Collections.sort(indexList,new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                if(o1<o2) {
                    return 1;
                }
                if(o1>o2) {
                    return -1;
                }
                return 0;
            }
        });
        List<T> randomList= new ArrayList<>();
        for (Integer index:indexList) {
            randomList.add(list.get(index));
        }
        return randomList;
    }

    /**
     * 取最小值
     * @param numbers
     * @return
     */
    public static long min(long... numbers){
        long min = Long.MAX_VALUE;
        for(long number : numbers){
            if(number < min){
                min = number;
            }
        }
        return min;
    }

    /**
     * 取最小值
     * @param numbers
     * @return
     */
    public static long min(int... numbers){
        int min = Integer.MAX_VALUE;
        for(int number : numbers){
            if(number < min){
                min = number;
            }
        }
        return min;
    }
}
