package com.alibaba.fa.framework.util.export;

import java.util.Collection;

/**
 * Created by wb-lns279014 on 2017/5/15.
 */
public abstract class ExportPage<T> {
    /**
     * 获取数据，必须实现此类
     *a
     * @param param
     * @param start
     * @param count
     * @return
     */
    public abstract Collection getCollection(T param, int start, int count) throws Exception;

    /**
     * 到出的数据需要特殊加工时重载此方法
     * @param one
     * @param field
     * @return
     */
    public Object processData(Object one, String field) {
        return one;
    }
}
