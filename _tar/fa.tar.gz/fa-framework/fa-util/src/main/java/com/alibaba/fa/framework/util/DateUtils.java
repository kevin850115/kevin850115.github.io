package com.alibaba.fa.framework.util;


import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateUtils {

    public static final String YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYYMMDD = "yyyy-MM-dd";

    /**
     * 日期加减
     *
     * @param d
     * @param field  是Calendar的静态常量
     * @param amount
     * @return
     */
    public static Date add(Date d, int field, int amount) {
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.add(field, amount);
        return c.getTime();
    }

    /**
     * 获得指定天的凌晨时间
     *
     * @param date
     * @return
     */
    public static Date getCalendarDay(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    /**
     * 获取指定天的结束时间
     * @param d
     * @return
     */
    public static Date getCalendarDayEnd(Date d) {
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.set(Calendar.HOUR, 23);
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 999);
        return c.getTime();
    }

    /**
     * 日期 字符串格式化
     *
     * @param date
     * @param pattern yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static String format(Date date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    /**
     * 日期 字符串格式化
     *
     * @param date
     * @param pattern yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static Date foramtToDate(String date, String pattern) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            return sdf.parse(date);
        } catch (Exception e) {
            return null;
        }

    }

    /**
     * 解析成东八区时间
     * @param dateStr
     * @param pattern
     * @return
     */
    public static Date foramtToDateGMT8(String dateStr, String pattern){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
            return sdf.parse(dateStr);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 将字符串转化为DATE
     *
     * @param dtFormat 格式yyyy-MM-dd HH:mm:ss 或 yyyy-MM-dd或 yyyy-M-dd或 yyyy-M-d或   yyyy-MM-d或 yyyy-M-dd
     *                 格式yyyy/MM/dd HH:mm:ss 或 yyyy/MM/dd或 yyyy/M/dd或 yyyy/M/d或   yyyy/MM/d或 yyyy/M/dd
     * @return 如果格式化失败返回null
     */
    public static Date fmtStrToDate(String dtFormat) {
        if (StringUtils.isBlank(dtFormat)) {
            return null;
        }
        try {
            if (dtFormat.length() == 9 || dtFormat.length() == 8) {
                String[] dateStr = null;
                if (dtFormat.indexOf("-") > -1) {
                    dateStr = dtFormat.split("-");
                } else if (dtFormat.indexOf("/") > -1) {
                    dateStr = dtFormat.split("/");
                }
                dtFormat = dateStr[0] + (dateStr[1].length() == 1 ? "-0" : "-")
                        + dateStr[1] + (dateStr[2].length() == 1 ? "-0" : "-")
                        + dateStr[2];
            }
            if (dtFormat.length() != 10 & dtFormat.length() != 19) {
                return null;
            }
            if (dtFormat.length() == 10) {
                dtFormat = dtFormat + " 00:00:00";
            }


            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return dateFormat.parse(dtFormat);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获得日期的指定值 年 月  日 周  星期  时间
     *
     * @param  field 是Calendar的静态常量
     * @return
     */
    public static int get(Date date, int field) {
        if (date == null) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        if (Calendar.MONTH == field) {
            return (calendar.get(field) + 1);
        }
        if (Calendar.DAY_OF_WEEK == field) {
            boolean isFirstSunday = (calendar.getFirstDayOfWeek() == Calendar.SUNDAY);
            int weekDay = calendar.get(field);
            if (isFirstSunday) {
                weekDay = weekDay - 1;
                if (weekDay == 0) {
                    weekDay = 7;
                }
            }
            return weekDay;
        }
        return calendar.get(field);
    }

    /**
     * 是否是天
     *
     * @param date
     * @return
     */
    public static boolean isDay(Date date) {
        if (date == null) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        if (calendar.get(Calendar.HOUR_OF_DAY) > 0
                || calendar.get(Calendar.MINUTE) > 0
                || calendar.get(Calendar.SECOND) > 0
                || calendar.get(Calendar.MILLISECOND) > 0) {
            return false;
        }
        return true;
    }
}
