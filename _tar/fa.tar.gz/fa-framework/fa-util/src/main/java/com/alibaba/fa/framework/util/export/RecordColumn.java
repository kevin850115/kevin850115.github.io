package com.alibaba.fa.framework.util.export;

/**
 * Created by wb-zxz248731 on 2017/5/15.
 */
public class RecordColumn {
    private String title;
    private String field;
    public RecordColumn(){

    }
    public RecordColumn(String title, String field){
        this.title = title;
        this.field = field;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }
}
