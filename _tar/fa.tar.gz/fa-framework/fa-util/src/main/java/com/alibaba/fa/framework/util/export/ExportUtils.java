package com.alibaba.fa.framework.util.export;


import com.alibaba.fa.framework.util.Reflections;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by wb-lns279014 on 2017/5/26.
 */
public class ExportUtils {
    public static List<ExportTitleProp> titleConvert(List<RecordColumn> recordColumnList, Object dataBean) {
        List<ExportTitleProp> list = new ArrayList<>();
        boolean mapFlag = dataBean instanceof Map;
        for (RecordColumn recordColumn : recordColumnList) {
            Method method = null;
            if (!mapFlag) {
                method = Reflections.getGetterMethod(dataBean, recordColumn.getField());
            }
            ExportTitleProp exportTitleProp = new ExportTitleProp(mapFlag, recordColumn.getTitle(), recordColumn.getField(), method);
            list.add(exportTitleProp);
        }
        return list;
    }
    public static Object evaluateVal(ExportTitleProp titleProp, Object data) {
        if (titleProp.isMapFlag()) {
            return ((Map)data).get(titleProp.getField());
        } else {
            try {
                return titleProp.getMethod().invoke(data);
            } catch (Exception e) {
                throw Reflections.convertReflectionExceptionToUnchecked(e);
            }
        }
    }
}
