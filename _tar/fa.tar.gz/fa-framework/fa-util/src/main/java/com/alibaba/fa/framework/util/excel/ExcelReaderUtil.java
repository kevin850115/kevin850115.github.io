package com.alibaba.fa.framework.util.excel;

import java.io.InputStream;

/**
 *
 * @author 章磊
 *
 */
public class ExcelReaderUtil {
	// excel2003扩展名
	public static final String EXCEL03_EXTENSION = ".xls";
	// excel2007扩展名
	public static final String EXCEL07_EXTENSION = ".xlsx";
	// csv扩展名
	public static final String CSV_EXTENSION = ".csv";

	/**
	 * 读取Excel文件，可能是03也可能是07版本,标题行默认为0
	 * @param reader
	 * @param startRow
	 * @param fileName
	 * @param cls
	 * @throws Exception
	 */
	public static void readExcel(IRowReader reader,int startRow, String fileName,Class cls) throws Exception {
		readExcel(reader,startRow,0,fileName,cls);
	}

	/**
	 * 读取Excel文件，可能是03也可能是07版本
	 * @param reader
	 * @param startRow
	 * @param titleRow
	 * @param fileName
	 * @param cls
	 * @throws Exception
	 */
	public static void readExcel(IRowReader reader,int startRow,int titleRow, String fileName,Class cls) throws Exception {
		readExcel(reader, startRow, titleRow, fileName, cls, null);
	}

	/**
	 * /**
	 * 读取Excel文件，可能是03也可能是07版本;
	 * @param reader
	 * @param startRow
	 * @param titleRow
	 * @param fileName
	 * @param cls
	 * @param appointedSheetIndex 指定sheet下标，传下标后则只读该下标的sheet;sheet下标从0开始
	 * @throws Exception
	 */
	public static void readExcel(IRowReader reader,int startRow,int titleRow, String fileName,Class cls,Integer appointedSheetIndex) throws Exception {
		readExcel(reader,startRow,titleRow,fileName,null,cls,appointedSheetIndex);
	}

	public static void readExcel(IRowReader reader, int startRow, int titleRow, String fileName, InputStream inputStream, Class cls, Integer appointedSheetIndex) throws Exception {
		// 处理excel2003文件
		if (fileName.endsWith(EXCEL03_EXTENSION)) {
			Excel2003Reader excel03 = new Excel2003Reader();
			excel03.setRowReader(reader);
			excel03.setCls(cls);
			excel03.setStartRow(startRow);
			excel03.setTitleRow(titleRow);
			excel03.setAppointedSheetIndex(appointedSheetIndex);
			if (inputStream == null){
				excel03.process(fileName);
			}else {
				excel03.process(inputStream);
			}
			// 处理excel2007文件
		} else if (fileName.endsWith(EXCEL07_EXTENSION)) {
			Excel2007Reader excel07 = new Excel2007Reader();
			excel07.setRowReader(reader);
			excel07.setCls(cls);
			excel07.setStartRow(startRow);
			excel07.setTitleRow(titleRow);
			if (appointedSheetIndex != null) {
				if (inputStream == null){
					excel07.processOneSheet(fileName, appointedSheetIndex + 1);
				}else {
					excel07.processOneSheet(inputStream, appointedSheetIndex + 1);
				}
			} else {
				if (inputStream == null){
					excel07.process(fileName);
				}else {
					excel07.process(inputStream);
				}
			}
		} else if(fileName.endsWith(CSV_EXTENSION)) {
			CsvReader csvReader = new CsvReader();
			csvReader.setRowReader(reader);
			csvReader.setTitleRowNum(titleRow);
			csvReader.setStartRowNum(startRow);
			if (inputStream == null){
				csvReader.process(fileName);
			}else {
				csvReader.process(inputStream);
			}
		} else {
			throw new Exception("文件格式错误，fileName的扩展名只能是xls或xlsx。");
		}
	}
}
