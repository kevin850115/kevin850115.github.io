package com.alibaba.fa.framework.util.export.excel;


import com.alibaba.fa.framework.util.DateUtils;
import com.alibaba.fa.framework.util.export.ExportTitleProp;
import com.alibaba.fa.framework.util.export.ExportUtils;
import com.alibaba.fa.framework.util.export.RecordColumn;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class ExportExcel2003Util {
    private static final Logger logger = LoggerFactory.getLogger(ExportExcel2003Util.class);

    /**
     * 根据集合创建data行
     *
     * @param list
     * @param recordColumnList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRowList(Collection<?> list, List<RecordColumn> recordColumnList, HSSFSheet sheet, HSSFCellStyle dataRowCellStyle) {
        try {
            int rowNum = sheet.getLastRowNum() + 1;
            List<ExportTitleProp> titlePropList = null;
            for (Object data : list) {
                if (titlePropList == null) {
                    titlePropList = ExportUtils.titleConvert(recordColumnList, data);
                }
                createRow(data, titlePropList, sheet, rowNum++ ,dataRowCellStyle);
            }
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 根据集合创建data行
     *
     * @param data
     * @param titlePropList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRow(Object data, List<ExportTitleProp> titlePropList, HSSFSheet sheet, int rowNum, HSSFCellStyle dataRowCellStyle) {
        try {
            createRow(data, titlePropList, sheet, rowNum, dataRowCellStyle, null);
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 根据集合创建data行
     *
     * @param data
     * @param titlePropList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRow(Object data, List<ExportTitleProp> titlePropList, HSSFSheet sheet, int rowNum, HSSFCellStyle dataRowCellStyle, ExportBefore exportBefore) {
        try {
            HSSFRow datarow = sheet.createRow(rowNum);
            int dataCellNum = 0;
            for (ExportTitleProp titleProp : titlePropList) {
                HSSFCell datacell = datarow.createCell(dataCellNum);
                datacell.setCellStyle(dataRowCellStyle);
                Object cellValue = ExportUtils.evaluateVal(titleProp, data);
                if (exportBefore != null) {
                    cellValue = exportBefore.processData(cellValue, titleProp.getField());
                }
                setCellValue(datacell, cellValue);
                dataCellNum++;
            }
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 通过class创建表头,并返回sheet
     *
     * @param recordColumnList
     * @param workbook
     * @return
     */
    public static HSSFSheet createHead(List<RecordColumn> recordColumnList, HSSFWorkbook workbook, String sheetName) {
        // 解析出list中的bean的注解和属性名字
        // 生成一个表格
        HSSFSheet sheet = null;
        if (StringUtils.isBlank(sheetName)) {
           sheet = workbook.createSheet();
        } else {
            sheet = workbook.createSheet(sheetName);
        }
        // 生成表格头单元格样式
        HSSFCellStyle headCellStyle = getHeadCellStyle(workbook);
        int rowNum = 0;
        int headCellNum = 0;
        // 产生表格标题行
        HSSFRow headrow = sheet.createRow(0);
        for (RecordColumn titleProp : recordColumnList) {
            HSSFCell headcell = headrow.createCell(headCellNum);
            headcell.setCellStyle(headCellStyle);
            headcell.getCellStyle().setWrapText(true);
            String headText = StringUtils.trimToEmpty(titleProp.getTitle());
            HSSFRichTextString richHeadText = new HSSFRichTextString(headText);
            headcell.setCellValue(richHeadText);
            int withWord = headText.length();
            sheet.setColumnWidth(headCellNum, 100 * 8 * withWord);
            headCellNum++;
        }
        return sheet;
    }
    /**
     * 按数据类型写入数据到cell
     * @param cell excel 单元格
     * @param obj  写入cell的数据
     */
    private static void setCellValue(HSSFCell cell, Object obj) {
        cell.getCellStyle().setWrapText(false);
        if (obj instanceof String) {
            cell.setCellType(CellType.STRING);
            cell.setCellValue((String) obj);
        } else if (obj instanceof Double) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue((Double) obj);
        } else if (obj instanceof Integer) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue((Integer) obj);
        } else if (obj instanceof Date) {
            cell.setCellType(CellType.STRING);
            cell.setCellValue(DateUtils.format((Date) obj, "yyyy-MM-dd HH:mm:ss"));
        } else if (obj instanceof Number) {
            if (obj != null) {
                cell.setCellType(CellType.NUMERIC);
                cell.setCellValue(obj.toString());
            }
        } else {
            try {
                if (obj != null) {
                    cell.setCellValue(obj.toString());
                }
            } catch (Exception e) {
                cell.setCellValue("");
            }
        }
    }

    /**
     * 表头单元格样式
     *
     * @param workbook
     * @return
     */
    private static HSSFCellStyle getHeadCellStyle(HSSFWorkbook workbook) {
        HSSFCellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER); // 居中
        style.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直居中
        //style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框

        HSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 12);
        // font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        // 把字体应用到当前的样式
        style.setFont(font);
        return style;
    }

    /**
     * 数据单元格样式
     *
     * @param workbook
     * @return
     */
    public static HSSFCellStyle getDataRowCellStyle(HSSFWorkbook workbook) {
        HSSFCellStyle style2 = workbook.createCellStyle();
        // style2.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
        style2.setAlignment(HorizontalAlignment.CENTER);
        style2.setVerticalAlignment(VerticalAlignment.CENTER);
        //style2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        //style2.setBorderBottom(BorderStyle.THIN);
        //style2.setBorderLeft(BorderStyle.THIN);
        //style2.setBorderRight(BorderStyle.THIN);
        //style2.setBorderTop(BorderStyle.THIN);
        // 生成另一个字体
        // HSSFFont font2 = workbook.createFont();
        // font2.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
        // 把字体应用到当前的样式
        // style2.setFont(font2);
        return style2;
    }

    public static void writeFile(File file, HSSFWorkbook workbook) throws IOException {
        OutputStream out = null;
        try {
            out = new FileOutputStream(file);
            workbook.write(out);
        } finally {
            IOUtils.closeQuietly(out);
        }
    }

    /**
     * 声明一个工作薄
     *
     * @param file 如果文件存在则在这个文件上添加一个新的sheet
     */
    public static HSSFWorkbook getWorkbook(File file) throws IOException {
        if (file.exists()) {
            new HSSFWorkbook(new FileInputStream(file));
        }
        return new HSSFWorkbook();
    }
    static class ExportBefore{
        public Object processData(Object o, String field) {
            return o;
        }
    }
}
