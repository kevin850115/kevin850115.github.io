package com.alibaba.fa.framework.util.export.excel;

import com.alibaba.fa.framework.util.export.ExportPage;
import com.alibaba.fa.framework.util.export.ExportTitleProp;
import com.alibaba.fa.framework.util.export.ExportUtils;
import com.alibaba.fa.framework.util.export.RecordColumn;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Created by wb-lns279014 on 2017/5/26.
 */
public class ExportExcel2003<T> {
    private Logger logger = LoggerFactory.getLogger(ExportExcel2003.class);
    private static int PECOUNT = 5000;//每次导出5000条
    private static final int MAX_ROWNUM = 65000;
    private boolean stop;//是否终止

    public boolean isStop() {
        return stop;
    }

    public void setStop(boolean stop) {
        this.stop = stop;
    }

    /**
     * 导出excel
     *
     * @param serachParam
     * @throws Exception
     */
    public void export(T serachParam, final ExportPage<T> exportPage, List<RecordColumn> titles, File file, String sheeName) throws Exception {
        long t1 = System.currentTimeMillis();
        long dataGetTime = 0;
        HSSFWorkbook workbook = ExportExcel2003Util.getWorkbook(file);
        try {
            ExportExcel2003Util.writeFile(file, workbook);
            //写入表头
            HSSFSheet sheet = ExportExcel2003Util.createHead(titles, workbook, sheeName);
            // 数据行单元格样式
            HSSFCellStyle dataRowCellStyle = ExportExcel2003Util.getDataRowCellStyle(workbook);
            Collection<?> data = null;
            int pageNum = 1;
            long t2 = System.currentTimeMillis();
            data = exportPage.getCollection(serachParam, (pageNum - 1) * PECOUNT, PECOUNT);
            dataGetTime += System.currentTimeMillis() - t2;
            List<ExportTitleProp> titlePropList = null;
            int rowNum = sheet.getLastRowNum() + 1;
            int sheetNum = 1;
            while (true) {
                if (isStop()) {//任务被终止
                    return;
                }
                if (CollectionUtils.isNotEmpty(data)) {
                    Iterator<?> itr = data.iterator();
                    StringBuffer rowStrs = new StringBuffer();
                    while (itr.hasNext()) {
                        Object one = itr.next();
                        if (titlePropList == null) {
                            titlePropList = ExportUtils.titleConvert(titles, one);
                        }
                        if (rowNum > MAX_ROWNUM) {
                           return;
                        }
                        ExportExcel2003Util.createRow(one, titlePropList, sheet, rowNum++, dataRowCellStyle, new ExportExcel2003Util.ExportBefore(){
                            @Override
                            public Object processData(Object o, String field) {
                                return exportPage.processData(o, field);
                            }
                        });
                    }
                } else {
                    break;
                }
                if (data.size() < PECOUNT) {
                    break;
                }
                if (isStop()) {//任务被终止
                    return;
                }
                pageNum++;
                t2 = System.currentTimeMillis();
                data = exportPage.getCollection(serachParam, (pageNum - 1) * PECOUNT, PECOUNT);
                dataGetTime += System.currentTimeMillis() - t2;
            }
        } finally {
            ExportExcel2003Util.writeFile(file, workbook);
            logger.info("本次导出，数据查询耗时：" + dataGetTime + "，导出总耗时：" + (System.currentTimeMillis() - t1));
        }
    }
}
