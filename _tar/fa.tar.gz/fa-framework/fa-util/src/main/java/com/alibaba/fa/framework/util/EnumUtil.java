package com.alibaba.fa.framework.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;

import org.apache.commons.collections.CollectionUtils;

/**
 * Created by wb-zgl234479 on 2017/4/14.
 */
public class EnumUtil {

    private static JSONObject toJsonObject(Collection<Integer> filter, Class<? extends IKeyDescEnum> clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method method = clazz.getMethod("values");
        IKeyDescEnum inter[]  = (IKeyDescEnum[])method.invoke(null,null);
        Arrays.sort(inter, new Comparator<IKeyDescEnum>() {
            @Override
            public int compare(IKeyDescEnum o1, IKeyDescEnum o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });
        Map<String,Object> map = new LinkedHashMap();
        for(IKeyDescEnum iKeyDescEnum : inter){
            if(filter != null &&  filter.contains(iKeyDescEnum.getKey())){
                continue;
            }
            map.put("_" + iKeyDescEnum.getKey(), iKeyDescEnum.getDesc());
        }
        return  new JSONObject(map);
    }

    public static JSONObject toJsonObject(Collection<Integer> filter,Class<? extends IKeyDescEnum> ... clazzs) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Map<String,Object> map = new LinkedHashMap<>();
        for(Class clazz : clazzs){
            map.put(clazz.getName(), toJsonObject(filter, clazz));
        }
        JSONObject jsonObject = new JSONObject(map);
        return jsonObject;
    }

    public static String toJsonString(Collection<Integer> filter,Class<? extends IKeyDescEnum> ... clazzs) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, UnsupportedEncodingException {
        return URLEncoder.encode(EnumUtil.toJsonObject(Arrays.asList(-1),clazzs).toJSONString(),"utf-8");
    }

    public static String toJsonStringWithFilter(Collection<Integer> filter,Class<? extends IKeyDescEnum> ... clazzs) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, UnsupportedEncodingException {
        return URLEncoder.encode(EnumUtil.toJsonObject(filter,clazzs).toJSONString(),"utf-8");
    }

    public static JSONObject toJsonObject4List(Collection<Integer> filter, Collection<? extends IKeyDescEnum> collection) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Map<String, Object> map = new LinkedHashMap();
        if (collection == null || collection.size() <= 0) {
            return new JSONObject();
        }
        for(IKeyDescEnum iKeyDescEnum : collection){
            if(filter != null &&  filter.contains(iKeyDescEnum.getKey())){
                continue;
            }
            map.put("_" + iKeyDescEnum.getKey(), iKeyDescEnum.getDesc());
        }
        return new JSONObject(map);
    }

    public static JSONObject toJsonObject4List(Collection<Integer> filter, Collection<? extends IKeyDescEnum> collection,Class clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Map<String,Object> map = new LinkedHashMap<>();
        map.put(clazz.getName(), EnumUtil.toJsonObject4List(filter,collection));
        return new JSONObject(map);
    }

    public static String toJsonString4List(Collection<Integer> filter,Collection<? extends IKeyDescEnum> collection,Class clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException,
        UnsupportedEncodingException {
        return URLEncoder.encode(EnumUtil.toJsonObject4List(Arrays.asList(-1),collection,clazz).toJSONString(), "utf-8");
    }

    public static String toJsonStringWithFilter4List(Collection<Integer> filter,Collection<? extends IKeyDescEnum> collection,Class clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException,
        UnsupportedEncodingException {
        return URLEncoder.encode(EnumUtil.toJsonObject4List(filter,collection,clazz).toJSONString(), "utf-8");
    }

    public static String collectionEnum(String... enumStrs) throws UnsupportedEncodingException {
        JSONObject jsonObject = new JSONObject();
        for (String str : enumStrs) {
            JSONObject map = JSON.parseObject(URLDecoder.decode(str, "utf-8"));
            jsonObject.fluentPutAll(map);
        }
        return URLEncoder.encode(jsonObject.toJSONString(), "utf-8");
    }

}
