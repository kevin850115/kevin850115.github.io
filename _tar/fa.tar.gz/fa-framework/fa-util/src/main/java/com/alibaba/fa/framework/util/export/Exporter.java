package com.alibaba.fa.framework.util.export;

import java.io.File;
import java.util.Date;
import java.util.List;

import com.alibaba.fa.framework.util.DateUtils;
import com.alibaba.fa.framework.util.export.csv.ExportCsv;
import com.alibaba.fa.framework.util.export.enums.ExportFileTypeEnum;
import com.alibaba.fa.framework.util.export.excel.ExportExcel2003;
import com.alibaba.fa.framework.util.export.excel.ExportExcel2007;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by wb-lns279014 on 2017/5/26.
 */
public class Exporter<T> {
    public static final String EXPORT_DIR_PATH = "/home/admin/iatkf/tmp/export/";

    private static final int RANDMON_NAME_LENGTH = 5;//随机文件名长度

    private String charset;

    private ExportFileTypeEnum exportFileTypeEnum;

    public Exporter (ExportFileTypeEnum exportFileTypeEnum){
        this.exportFileTypeEnum = exportFileTypeEnum;
    }
    /**
     * 导出csv
     *
     * @param serachParam
     * @throws Exception
     */
    public String export(T serachParam, ExportPage<T> exportPage, List<RecordColumn> titles, String fileNamePreff) throws Exception {
        if (CollectionUtils.isEmpty(titles)) {
            throw new Exception("导出列头不能为空");
        }
        if (exportPage == null) {
            throw new Exception("exportPage不能为空");
        }
        fileNamePreff = StringUtils.trimToEmpty(fileNamePreff);
        String path = EXPORT_DIR_PATH + DateUtils.format(new Date(), "yyyyMMdd") + "/"
                + fileNamePreff + RandomStringUtils.randomAlphanumeric(RANDMON_NAME_LENGTH) + exportFileTypeEnum.getCode();
        File file = new File(path);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        if (ExportFileTypeEnum.CSV.equals(this.exportFileTypeEnum)) {
            if(charset!=null){
                new ExportCsv<T>().export(serachParam, exportPage, titles, file,charset);
            }else{
                new ExportCsv<T>().export(serachParam, exportPage, titles, file);
            }
        } else if (ExportFileTypeEnum.XLS.equals(this.exportFileTypeEnum)) {
            new ExportExcel2003<T>().export(serachParam, exportPage, titles, file, fileNamePreff);
        }else if (ExportFileTypeEnum.XLSX.equals(this.exportFileTypeEnum)) {
            new ExportExcel2007<T>().export(serachParam, exportPage, titles, file, fileNamePreff);
        }
        return path;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }
}
