package com.alibaba.fa.framework.util;

import com.alibaba.fastjson.JSONArray;
import com.alitrip.trade.tracker.Tracer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.MessageFormatter;

import java.text.MessageFormat;
import java.util.regex.Pattern;

/**
 * 格式化的Log工具，方便日志内容拼装过程
 *
 * @author siyong.dxh
 */
public class LoggerUtils {
    public final static Pattern FORMAT_WITHOUT_NUMBER_PATTEN = Pattern.compile("\\{\\d+\\}");
    public static LoggerWatchDog getLogger(Class<?> clazz,String space,String tage){
        return new LoggerWatchDog(LoggerFactory.getLogger(clazz),Tracer.getTracer(space, clazz, tage));
    }

    /**
     * 输出info level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void info(Logger logger, String message, Object... params) {
        if (logger.isInfoEnabled()) {
            logger.info(format(message, params));
        }
    }

    /**
     * 输出info level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void info(Throwable throwable, Logger logger, String message, Object... params) {
        if (logger.isInfoEnabled()) {
            logger.info(format(message, params), throwable);
        }
    }

    /**
     * 输出warn level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void warn(Logger logger, String message, Object... params) {
        if (logger.isWarnEnabled()) {
            logger.warn(format(message, params));
        }
    }

    /**
     * 输出warn level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void warn(Throwable throwable, Logger logger, String message, Object... params) {
        if (logger.isWarnEnabled()) {
            logger.warn(format(message, params), throwable);
        }
    }

    /**
     * 输出debug level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void debug(Logger logger, String message, Object... params) {
        if (logger.isDebugEnabled()) {
            logger.debug(format(message, params));
        }
    }

    /**
     * 输出debug level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void debug(Throwable throwable, Logger logger, String message, Object... params) {
        if (logger.isDebugEnabled()) {
            logger.debug(format(message, params), throwable);
        }
    }

    /**
     * 输出error level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static String error(Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isErrorEnabled()) {
            logger.error(msg);
        }
        return msg;
    }

    /**
     * 输出error level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static String error(Throwable throwable, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isErrorEnabled()) {
            logger.error(msg, throwable);
        }
        return msg;
    }

    /**
     * 日志信息参数化格式化
     *
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     * @return 格式化后的日志信息
     */
    public static String format(String message, Object... params) {
        if (params == null || params.length == 0) {
            return message;
        }
        if (StringUtils.isBlank(message)) {
            return message;
        }
        boolean hasSeg = message.contains("{}");
        boolean hasNumSeg = FORMAT_WITHOUT_NUMBER_PATTEN.matcher(message).find();
        if (!hasSeg && !hasNumSeg) {
            return message;
        }
        if (hasSeg && hasNumSeg) {
            return message;
        }
        String[] args = new String[params.length];
        for (int i = 0; i < params.length; i++) {
            if (params[i] == null) {
                args[i] = "null";
            } else if(params[i] instanceof String) {
                args[i] = params[i].toString();
            } else {
                args[i] = JSONArray.toJSONString(params[i]);
            }
        }
        if (hasSeg) {
            return MessageFormatter.arrayFormat(message, args).getMessage();
        } else if (hasNumSeg) {
            return MessageFormat.format(message, args);
        }
        return message;
    }

    public static String formatMessage(String message, Object[] params) {
        return format(message, params);
    }


    /**
     * 输出info level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void info4Tracer(Tracer tracer, String objId, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isInfoEnabled()) {
            logger.info(msg);
        }
        tracer.info(objId, msg);
    }

    /**
     * 输出info level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void info4Tracer(Tracer tracer,String objId, Throwable throwable, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isInfoEnabled()) {
            logger.info(msg, throwable);
        }
        tracer.info(objId, msg, throwable);
    }

    /**
     * 输出warn level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void warn4Tracer(Tracer tracer, String objId, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isWarnEnabled()) {
            logger.warn(msg);
        }
        tracer.warn(objId, msg);
    }

    /**
     * 输出warn level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void warn4Tracer(Tracer tracer, String objId, Throwable throwable, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isWarnEnabled()) {
            logger.warn(msg, throwable);
        }
        tracer.warn(objId, msg, throwable);
    }

    /**
     * 输出debug level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void debug4Tracer(Tracer tracer, String objId, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isDebugEnabled()) {
            logger.debug(msg);
        }
        tracer.debug(objId, msg);
    }

    /**
     * 输出debug level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static void debug4Tracer(Tracer tracer, String objId, Throwable throwable, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isDebugEnabled()) {
            logger.debug(msg, throwable);
        }
        tracer.debug(objId, msg, throwable);
    }

    /**
     * 输出error level的log信息.
     *
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static String error4Tracer(Tracer tracer, String objId, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isErrorEnabled()) {
            logger.error(msg);
        }
        tracer.error(objId, msg);
        return msg;
    }

    /**
     * 输出error level的log信息.
     *
     * @param throwable 异常对象
     * @param logger 日志记录器
     * @param message log信息,如:<code>xxx{0},xxx{1}...</code>
     * @param params log格式化参数,数组length与message参数化个数相同, 如: <code>Object[]  object=new Object[]{"xxx","xxx"}</code>
     */
    public static String error4Tracer(Tracer tracer, String objId, Throwable throwable, Logger logger, String message, Object... params) {
        String msg = format(message, params);
        if (logger.isErrorEnabled()) {
            logger.error(msg, throwable);
        }
        tracer.error(objId, msg, throwable);
        return msg;
    }

}
