package com.alibaba.fa.framework.util;


import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 *  反射工具类
 * zhangsan
 */
public class ReflectionWrapper {

	private final int LRU_CACHE_SIZE = 1 << 8;

	private final Map<Class<?>, Map<String, Field>> FIELD_CACHED = new LRUCache<Class<?>, Map<String, Field>>(LRU_CACHE_SIZE);

	private final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();

	private final Lock writeLock = readWriteLock.writeLock();

	public class LRUCache<K,V> extends LinkedHashMap<K,V> implements Map<K,V> {

		private static final long serialVersionUID = 3287465019378048110L;

		private static final float DEFAULT_LOADFACTOR = 0.75F;

		private final int cacheSize;

		public LRUCache(int cacheSize) {

			this(cacheSize, DEFAULT_LOADFACTOR);
		}

		public LRUCache(int cacheSize, float loadFactor) {

			super(cacheSize + (int)(cacheSize * (1.0F - loadFactor)) + 1, loadFactor, true);

			this.cacheSize = cacheSize;
		}

		@Override
		protected boolean removeEldestEntry(Entry<K, V> eldest) {

			return this.size() > cacheSize;
		}
	}

	public Map<String, Field> getFields(Class<?> clazz) {
		writeLock.lock();
		try {
			if (!FIELD_CACHED.containsKey(clazz)) {
				fillFields(clazz);
			}
			return FIELD_CACHED.get(clazz);
		} finally {
			writeLock.unlock();
		}
	}

	public void copyBeanByField(final Object source, final Object target) {
		final Class<?> sourceClazz = source.getClass();
		final Class<?> targetClazz = target.getClass();

		Map<String, Field> sourceFields = getFields(sourceClazz);
		Map<String, Field> targetFields = getFields(targetClazz);

		for (Map.Entry<String, Field> entry : sourceFields.entrySet()) {
			String fieldName  = entry.getKey();
			Field sourceField = entry.getValue();
			Field targetField = targetFields.get(fieldName);
			if (targetField == null) {
				continue;
			}
			setField(targetField, target, invokeField(sourceField, source));
		}
	}

	public void setField(Field field, Object target, Object value) {
		try {
			ReflectionUtils.makeAccessible(field);
			field.set(target, value);
		} catch (Exception e) {
			// ignore
		}
	}

	public Object invokeField(Field field, Object target) {
		try {
			ReflectionUtils.makeAccessible(field);
			return field.get(target);
		} catch (Exception e) {
			// ignore
		}
		return null;
	}

	private void fillFields(Class<?> clazz) {

		final Map<String, Field> fields = new HashMap<String, Field>();
		FIELD_CACHED.put(clazz, fields);

		ReflectionUtils.doWithFields(clazz, new ReflectionUtils.FieldCallback() {

			@Override
            public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
				String fieldName = field.getName();
				if (!fields.containsKey(fieldName)) {
					fields.put(fieldName, field);
				}
			}
		});
	}

}
