package com.alibaba.fa.framework.util.export.excel;

import com.alibaba.fa.framework.util.DateUtils;
import com.alibaba.fa.framework.util.export.ExportTitleProp;
import com.alibaba.fa.framework.util.export.ExportUtils;
import com.alibaba.fa.framework.util.export.RecordColumn;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created by wb-lns279014 on 2017/5/27.
 */
public class ExportExcel2007Util {
    private static final Logger logger = LoggerFactory.getLogger(ExportExcel2007Util.class);
    private static final int ROW_SIZE = 5000;
    /**
     * 根据集合创建data行
     *
     * @param list
     * @param recordColumnList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRowList(Collection<?> list, List<RecordColumn> recordColumnList, SXSSFSheet sheet, CellStyle dataRowCellStyle) {
        try {
            int rowNum = sheet.getLastRowNum() + 1;
            List<ExportTitleProp> titlePropList = null;
            for (Object data : list) {
                if (titlePropList == null) {
                    titlePropList = ExportUtils.titleConvert(recordColumnList, data);
                }
                createRow(data, titlePropList, sheet, rowNum++ ,dataRowCellStyle);
            }
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 根据集合创建data行
     *
     * @param data
     * @param titlePropList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRow(Object data, List<ExportTitleProp> titlePropList, SXSSFSheet sheet, int rowNum, CellStyle dataRowCellStyle) {
        try {
            createRow(data, titlePropList, sheet, rowNum, dataRowCellStyle, null);
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 根据集合创建data行
     *
     * @param data
     * @param titlePropList
     * @param sheet
     * @param dataRowCellStyle
     */
    public static void createRow(Object data, List<ExportTitleProp> titlePropList, SXSSFSheet sheet, int rowNum, CellStyle dataRowCellStyle, ExportBefore exportBefore) {
        try {
            SXSSFRow datarow = sheet.createRow(rowNum);
            int dataCellNum = 0;
            for (ExportTitleProp titleProp : titlePropList) {
                SXSSFCell datacell = datarow.createCell(dataCellNum);
                datacell.setCellStyle(dataRowCellStyle);
                Object cellValue = ExportUtils.evaluateVal(titleProp, data);
                if (exportBefore != null) {
                    cellValue = exportBefore.processData(cellValue, titleProp.getField());
                }
                setCellValue(datacell, cellValue);
                dataCellNum++;
            }
        } catch (Exception e) {
            logger.error("导出Excel失败", e);
        }
    }
    /**
     * 通过class创建表头,并返回sheet
     *
     * @param recordColumnList
     * @param workbook
     * @return
     */
    public static SXSSFSheet createHead(List<RecordColumn> recordColumnList, SXSSFWorkbook workbook, String sheetName) {
        // 解析出list中的bean的注解和属性名字
        // 生成一个表格
        SXSSFSheet sheet = null;
        if (StringUtils.isBlank(sheetName)) {
            sheet = workbook.createSheet();
        } else {
            sheet = workbook.createSheet(sheetName);
        }
        // 生成表格头单元格样式
        CellStyle headCellStyle = getHeadCellStyle(workbook);
        int rowNum = 0;
        int headCellNum = 0;
        // 产生表格标题行
        SXSSFRow headrow = sheet.createRow(0);
        for (RecordColumn titleProp : recordColumnList) {
           SXSSFCell headcell = headrow.createCell(headCellNum);
            headcell.setCellStyle(headCellStyle);
            headcell.getCellStyle().setWrapText(true);
            String headText = StringUtils.trimToEmpty(titleProp.getTitle());
            XSSFRichTextString richHeadText = new XSSFRichTextString(headText);
            headcell.setCellValue(richHeadText);
            int withWord = headText.length();
            sheet.setColumnWidth(headCellNum, 100 * 8 * withWord);
            headCellNum++;
        }
        return sheet;
    }
    /**
     * 按数据类型写入数据到cell
     * @param cell excel 单元格
     * @param obj  写入cell的数据
     */
    private static void setCellValue(SXSSFCell cell, Object obj) {
        cell.getCellStyle().setWrapText(false);
        if (obj instanceof String) {
            cell.setCellType(CellType.STRING);
            cell.setCellValue((String) obj);
        } else if (obj instanceof Double) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue((Double) obj);
        } else if (obj instanceof Integer) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue((Integer) obj);
        } else if (obj instanceof Date) {
            cell.setCellType(CellType.STRING);
            cell.setCellValue(DateUtils.format((Date) obj, "yyyy-MM-dd HH:mm:ss"));
        } else if (obj instanceof Number) {
            if (obj != null) {
                cell.setCellType(CellType.NUMERIC);
                cell.setCellValue(obj.toString());
            }
        } else {
            try {
                if (obj != null) {
                    cell.setCellValue(obj.toString());
                }
            } catch (Exception e) {
                cell.setCellValue("");
            }
        }
    }

    /**
     * 表头单元格样式
     *
     * @param workbook
     * @return
     */
    private static CellStyle getHeadCellStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER); // 居中
        style.setVerticalAlignment(VerticalAlignment.CENTER);// 垂直居中
        //style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框

        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12);
        // font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        // 把字体应用到当前的样式
        style.setFont(font);
        return style;
    }

    /**
     * 数据单元格样式
     *
     * @param workbook
     * @return
     */
    public static CellStyle getDataRowCellStyle(Workbook workbook) {
        CellStyle style2 = workbook.createCellStyle();
        // style2.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
        style2.setAlignment(HorizontalAlignment.CENTER);
        style2.setVerticalAlignment(VerticalAlignment.CENTER);
        //style2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        //style2.setBorderBottom(BorderStyle.THIN);
        //style2.setBorderLeft(BorderStyle.THIN);
        //style2.setBorderRight(BorderStyle.THIN);
        //style2.setBorderTop(BorderStyle.THIN);
        // 生成另一个字体
        // HSSFFont font2 = workbook.createFont();
        // font2.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
        // 把字体应用到当前的样式
        // style2.setFont(font2);
        return style2;
    }

    public static SXSSFWorkbook getSXSSFWorkbook(Integer memoryRowSize) throws IOException {
        int _memoryRowSize = ROW_SIZE;
        if (memoryRowSize == null && memoryRowSize > 0) {
            _memoryRowSize = memoryRowSize;
        }
        SXSSFWorkbook workbook = new SXSSFWorkbook(_memoryRowSize);
        return workbook;
    }

    public static void writeFile(File file, SXSSFWorkbook workbook) throws IOException {
        OutputStream out = null;
        try {
            out = new FileOutputStream(file);
            workbook.write(out);
        } finally {
            IOUtils.closeQuietly(out);
        }
    }


    static class ExportBefore{
        public Object processData(Object o, String field) {
            return o;
        }
    }
}
