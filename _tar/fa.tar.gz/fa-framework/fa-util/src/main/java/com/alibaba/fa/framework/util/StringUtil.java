package com.alibaba.fa.framework.util;

/**
 * Created by wb-wmf250057 on 2017/4/15.
 */
public class StringUtil {

    /**
     * 合并成字符串
     * @param objects
     * @return
     */
    public static String join(String separator, Object... objects){
        if(null == objects){
            return null;
        }
        separator = separator == null ? "" : separator;
        String joinStr = "";
        for(Object obj : objects){
            joinStr += obj.toString() + separator;
        }
        if(joinStr.endsWith(separator)){
            joinStr = joinStr.substring(0, joinStr.length() - separator.length());
        }
        return joinStr;
    }

}
