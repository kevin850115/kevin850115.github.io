package com.alibaba.fa.framework.util;

import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Base64;

/**
 * @author jason.zgl
 * @date 2019-04-03 14:37
 */
public class StreamUtil {
    public static  <T> String objToBase64(T object) {
        if(object == null) {
            return null;
        }
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(object);
            byte[] bytes = byteArrayOutputStream.toByteArray();
            return Base64.getEncoder().encodeToString(bytes);
        } catch (Exception e) {
            return null;
        }
    }

    public static  <T> T base64ToObj(String base64) {
        if(StringUtils.isBlank(base64)) {
            return null;
        }
        try {
            byte[] bytes =  Base64.getDecoder().decode(base64);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
            return  (T) objectInputStream.readObject();
        } catch (Exception e) {
            return null;
        }
    }
}
