package com.alibaba.fa.framework.util.export.csv;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import com.alibaba.fa.framework.util.export.ExportPage;
import com.alibaba.fa.framework.util.export.ExportTitleProp;
import com.alibaba.fa.framework.util.export.ExportUtils;
import com.alibaba.fa.framework.util.export.RecordColumn;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by wb-lns279014 on 2017/5/15.
 */
public class ExportCsv<T> {
    private Logger logger = LoggerFactory.getLogger(ExportCsv.class);

    private static int PECOUNT = 5000;//每次导出5000条

    private int rownum = 1;//序号计数

    private boolean stop;//是否终止

    private ExportPage<T> exportPage;

    public boolean isStop() {
        return stop;
    }

    public void setStop(boolean stop) {
        this.stop = stop;
    }

    public int getRownum() {
        return rownum;
    }

    public void export(T serachParam, ExportPage<T> exportPage, List<RecordColumn> titles, File file,String charset)throws Exception{
        PrintWriter pw = null;
        long t1 = System.currentTimeMillis();
        long dataGetTime = 0;
        this.exportPage = exportPage;
        try {
            pw = new PrintWriter(
                new BufferedWriter(
                    new OutputStreamWriter(
                        new FileOutputStream(file), charset)), false);
            //写入表头
            ExportCsv.addCsvHead(pw, titles);
            Collection<?> data = null;
            int pageNum = 1;
            long t2 = System.currentTimeMillis();
            data = this.exportPage.getCollection(serachParam, (pageNum - 1) * PECOUNT, PECOUNT);
            dataGetTime += System.currentTimeMillis() - t2;
            List<ExportTitleProp> titlePropList = null;
            while (true) {
                if (isStop()) {//任务被终止
                    return;
                }
                if (CollectionUtils.isNotEmpty(data)) {
                    Iterator<?> itr = data.iterator();
                    StringBuffer rowStrs = new StringBuffer();
                    while (itr.hasNext()) {
                        Object one = itr.next();
                        if (titlePropList == null) {
                            titlePropList = ExportUtils.titleConvert(titles, one);
                        }
                        //按照csv格式组装一行数据
                        this.addCsvRow(rowStrs, one, titlePropList, rownum++);
                    }
                    pw.print(rowStrs.toString());//写入CSV文本
                } else {
                    break;
                }
                if (data.size() < PECOUNT) {
                    break;
                }
                if (isStop()) {//任务被终止
                    return;
                }
                pageNum++;
                t2 = System.currentTimeMillis();
                data = this.exportPage.getCollection(serachParam, (pageNum - 1) * PECOUNT, PECOUNT);
                dataGetTime += System.currentTimeMillis() - t2;
            }
        } finally {
            logger.info("本次导出，数据查询耗时：" + dataGetTime + "，导出总耗时：" + (System.currentTimeMillis() - t1));
            IOUtils.closeQuietly(pw);
        }
    }

    /**
     * 导出csv
     *
     * @param serachParam
     * @throws Exception
     */
    public void export(T serachParam, ExportPage<T> exportPage, List<RecordColumn> titles, File file) throws Exception {
        export(serachParam,exportPage,titles,file,StandardCharsets.UTF_8.name());
    }

    /**
     * 添加表头
     */
    public static void addCsvHead(PrintWriter pw, List<RecordColumn> recordColumns) throws Exception {
        StringBuffer sb = new StringBuffer();
        for (RecordColumn recordColumn : recordColumns) {
            sb.append(recordColumn.getTitle() + ",");
        }
        pw.println(sb.toString());
    }

    /**
     * @param sb
     * @param rowMap
     * @param fields
     * @param rownum
     */
    private  void addCsvRow(StringBuffer sb, Object rowMap, List<ExportTitleProp> fields, int rownum) {
        for (ExportTitleProp exportTitleProp : fields) {
            try {
                Object o_value = ExportUtils.evaluateVal(exportTitleProp, rowMap);
                o_value = this.exportPage.processData(o_value, exportTitleProp.getField());
                if (null == o_value) {
                    sb.append("" + "" + ",");
                    continue;
                }
                //不为空
                // 特殊字符处理 回车 替换为 空格 逗号替换为大写逗号
                String o_value_s = Objects.toString(o_value, "");
                o_value_s = o_value_s.replaceAll("\n", "	").replaceAll("\r", "	").replaceAll(",", "，")
                        .replaceAll("\"", "“");
                if (NumberUtils.isDigits(o_value_s) && (o_value_s.length() > 13 || (o_value_s.startsWith("0") && o_value_s.length() > 1))) {
                    sb.append("\t" + o_value_s + ",");
                } else if (o_value_s.indexOf("/") >= 0 && countStr(o_value_s, "/") > 1) {// 防止/excel自动转为月份了
                    sb.append("\t" + o_value_s + ",");
                    //日期有2个 “/”   乘机人有一个‘/’ 乘机人不处理
                } else {
                    String reg = "^\\d+[eE]\\d*$";//文本型科学计数，如客户名称为8000E2，导出会以科学计数显示，需要加”\t“处理
                    //String regcsz = "\\d{5,}";//纯数字数据，当大于5位是加“\t”，避免被科学计数
                    if (o_value.toString().matches(reg)) {
                        sb.append("" + o_value_s + "\t,");
                    } else {
                        sb.append("" + o_value_s + ",");
                    }
                }
            } catch (Exception e) {
                sb.append("" + "" + ",");
            }
        }
        sb.append("\n");
    }

    private static int countStr(String str1, String str2) {
        int counter = 0;
        if (str1.indexOf(str2) == -1) {
            return 0;
        }
        while (str1.indexOf(str2) != -1) {
            counter++;
            str1 = str1.substring(str1.indexOf(str2) + str2.length());
        }
        return counter;
    }
}
