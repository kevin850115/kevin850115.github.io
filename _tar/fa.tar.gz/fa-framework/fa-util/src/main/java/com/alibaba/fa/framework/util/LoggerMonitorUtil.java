package com.alibaba.fa.framework.util;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author zhanglei
 * @date 2017/10/17
 */
public class LoggerMonitorUtil {
    private static ThreadLocal<Monitor> threadLocal = new ThreadLocal<Monitor>();
    private static final Logger monitorLogger = LoggerFactory.getLogger("bussinesMonitorLogger");

    public static Monitor createMonitor(String type){
        Monitor monitor = threadLocal.get();
        if(monitor==null){
            monitor = new Monitor();
            monitor.setType(type);
            monitor.setTime(DateUtils.format(new Date(),DateUtils.YYYYMMDDHHMMSS));
            threadLocal.set(monitor);
        }
        return monitor;
    }

    public static Monitor getMonitor(){
        return threadLocal.get();
    }

    public static void log(){
        try {
            Monitor monitor = threadLocal.get();
            if(monitor!=null) {
                monitorLogger.warn(monitor.toLogString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            threadLocal.remove();
        }
    }

    public static void setExecTime(Long start) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setExecTime(System.currentTimeMillis()-start);
        }
    }

    public static void setOrderStatus(Integer orderStatus) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setOrderStatus(orderStatus);
        }
    }

    public static void setSuccess() {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setSuccess(1);
        }
    }

    public static void setFailed(String errorCode) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setFailed(1);
            if(errorCode!=null && !"".equals(errorCode.trim())){
                monitor.setErrorCode(errorCode);
            }
        }
    }

    public static void setOperator(String operator){
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setOperator(operator);
        }
    }

    public static void setBizCount1(Integer bizCount1){
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setBizCount1(bizCount1);
        }
    }
    public static void setBizCount2(Integer bizCount2){
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setBizCount1(bizCount2);
        }
    }
    public static void setBizCount3(Integer bizCount3){
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setBizCount1(bizCount3);
        }
    }
    public static void setAgentId(Long agentId) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setAgentId(agentId);
        }
    }

    public static void setChannel(String channel) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setChannel(channel);
        }
    }

    public static void setAirways(String airways) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setAirways(airways);
        }
    }

    public static void setBuyPrice(Long buyPrice) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setBuyPrice(buyPrice);
        }
    }

    public static void setSellPrice(Long sellPrice) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setSellPrice(sellPrice);
        }
    }

    public static void setBizType(String bizType) {
        Monitor monitor = threadLocal.get();
        if(monitor != null){
            monitor.setBizType(bizType);
        }
    }

}
