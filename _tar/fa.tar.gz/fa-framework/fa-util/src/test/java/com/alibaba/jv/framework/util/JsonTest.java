package com.alibaba.jv.framework.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fa.framework.util.JsonMapper;
import com.alibaba.fa.framework.util.NumberUtils;

import org.junit.Test;

/**
 * Created by zhanglei on 2017/9/27.
 */
public class JsonTest {
    @Test
    public void toJson(){
        Student s = new Student();
        s.setId("1");
        s.setName("zzz");
        String json = JsonMapper.nonDefaultMapper().toJson(s);
        Student s1 = JsonMapper.nonDefaultMapper().fromJson(json,Student.class);
        System.out.println(s1.getName());
    }

    @Test
    public void testFormula(){
        Student student = new Student();
        student.setId("www");
        student.setName("agent.flight");

        String formula = "student.setName(\"aaaaaa\")";
        Map<String,Object> map = new HashMap<>();
        map.put("student",student);

        NumberUtils.formula(map,formula);
        System.out.println(student.getName());
    }

    @Test
    public void test(){
        String formula = "res = ticketPrice.multiply(one.subtract(commission).multiply(one.subtract(reward))).add(taxPrice).add(reserveMoney);";
        Map<String,BigDecimal> map = new HashMap<>();
        map.put("ticketPrice",new BigDecimal("1400"));
        map.put("taxPrice",new BigDecimal("687"));
        map.put("yqTax",new BigDecimal("140"));
        map.put("yrTax",new BigDecimal("90"));
        map.put("commission",new BigDecimal("0.03"));
        map.put("reward",new BigDecimal("0.023"));
        map.put("reserveMoney",new BigDecimal("10"));
        map.put("one",BigDecimal.ONE);
        BigDecimal decimal =(BigDecimal) NumberUtils.formula(map,formula);
        System.out.println(decimal);
    }

    public static class Student{
        private String id;

        private String name;

        public void setId(String id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

    }
}
