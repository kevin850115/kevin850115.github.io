package com.alibaba.fa.framework.acl.exception;

/**
 *
 * @author zhanglei
 * @date 2017/3/19
 */
public class BusinessException extends RuntimeException {
    /**
     * 文本替换的参数
     */
    private Object[] args;
    /**
     * 错误代码
     */
    private Code code;

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }

    /**
     * 构造
     *
     * @param code  错误代码
     * @param cause 异常
     * @param args  文本替换的参数
     */
    public BusinessException(Code code, Throwable cause, Object... args) {
        super(cause);
        this.args = args;
        this.code = code;
    }

    /**
     * 构造
     *
     * @param code 错误代码
     * @param args 文本替换的参数
     */
    public BusinessException(Code code, Object... args) {
        this.code = code;
        this.args = args;
    }

    /**
     * @return 错误代码
     */
    public Code getCode() {
        return code;
    }

    /**
     * @param code 错误代码
     */
    public void setCode(Code code) {
        this.code = code;
    }


    /**
     * @return 文本替换的参数
     */
    public Object[] getArgs() {
        return args;
    }

    @Override
    public String getMessage() {
        if (code != null) {
            return String.format(code.getMessage(), args);
        } else if (this.getCause() != null) {
            return this.getCause().getMessage();
        } else {
            return super.getMessage();
        }
    }
}
