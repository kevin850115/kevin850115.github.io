package com.alibaba.fa.framework.acl.intercepter;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fa.framework.acl.annotation.Permission;
import com.alibaba.fa.framework.acl.exception.AuthorizationException;
import com.alibaba.fa.framework.acl.service.AclHandler;
import com.alibaba.fa.framework.acl.service.AuthorizationInfo;
import com.alibaba.fa.framework.util.Reflections;

import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.AbstractHandlerMapping;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * Created by zhanglei on 2017/4/14.
 */
public class AclBucInterceptor extends HandlerInterceptorAdapter {

    @Setter
    private AclHandler aclHandler;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        Class beanType;
        String beanName;
        HandlerMethod handlerMethod;
        if(handler instanceof HandlerMethod){
            //获取拦截的处理方法
            handlerMethod = (HandlerMethod)handler;
            beanType = handlerMethod.getBeanType();
            beanName = handlerMethod.getMethod().getName();
        }else{
            return super.preHandle(request, response, handler);
        }

        Permission controller = Reflections.getAnnotation(beanType, Permission.class);

        if (controller == null) {
            return super.preHandle(request, response, handler);
        }

        String moduleNo = controller.value();
        if (StringUtils.isBlank(moduleNo)) {
            throw new AuthorizationException("必须在Permission配置模块编号[mkbh]!");
        }

        if (StringUtils.isBlank(beanName)) {
            throw new AuthorizationException("非法请求!");
        }

        Method method = Reflections.getAccessibleMethodByName(handlerMethod.getBean(), beanName);
        if (method == null) {
            throw new AuthorizationException("非法请求,无效的方法!");
        }

        Permission requestMapping = method.getAnnotation(Permission.class);
        String func = "";
        if (requestMapping != null) {
            func = requestMapping.value();
            if (StringUtils.isBlank(func)) {
                throw new AuthorizationException("必须在Permission配置功能编号[gnbh]!");
            }
        }

        String permissionKey = moduleNo;
        String sessionKey = "AUTHORIZATION_INFO" + "_";
        if (StringUtils.isNotBlank(func)) {
            permissionKey = permissionKey + "_" + func;
        }
        sessionKey = sessionKey + permissionKey;
        AuthorizationInfo authorizationInfo = (AuthorizationInfo)request.getSession().getAttribute(sessionKey);
        if (authorizationInfo == null) {
            authorizationInfo = aclHandler.checkPermission(request, moduleNo, func);

            if (authorizationInfo != null) {
                request.getSession().setAttribute(sessionKey, authorizationInfo);
            }
        }
        if (authorizationInfo == null) {
            request.setAttribute("moduleNo_func", permissionKey);
            throw new AuthorizationException("没有权限!");
        }

        return super.preHandle(request, response, handler);
    }
}
