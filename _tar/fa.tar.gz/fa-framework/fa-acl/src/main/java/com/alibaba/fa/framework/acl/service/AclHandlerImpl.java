package com.alibaba.fa.framework.acl.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.buc.acl.api.common.AclResult;
import com.alibaba.buc.acl.api.input.check.CheckPermissionsParam;
import com.alibaba.buc.acl.api.output.check.CheckPermissionsResult;
import com.alibaba.buc.acl.api.output.check.CheckPermissionsResult.CheckPermissionResultInner;
import com.alibaba.buc.acl.api.service.AccessControlService;
import com.alibaba.buc.acl.api.service.DataAccessControlService;
import com.alibaba.buc.api.datapermission.param.CheckDataPermissionParam;
import com.alibaba.buc.api.datapermission.param.DataProfileParam;
import com.alibaba.buc.api.datapermission.param.OperationProfileParam;
import com.alibaba.buc.api.datapermission.param.UserProfileParam;
import com.alibaba.buc.api.datapermission.result.CheckDataPermissionResult;
import com.alibaba.buc.sso.client.util.SimpleUserUtil;
import com.alibaba.buc.sso.client.vo.BucSSOUser;
import com.alibaba.fastjson.JSON;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.util.CollectionUtils;

/**
 * @author zhanglei
 * @date 2017/7/17
 */
@Slf4j
public class AclHandlerImpl implements AclHandler {

    /**
     * 功能权限
     */
    @Setter
    private AccessControlService accessControlService;

    @Setter
    private ApplicationContext applicationContext;

    private DataAccessControlService dataAccessControlService;

    @Setter
    private String accessKey;

    @Override
    public AuthorizationInfo checkPermission(HttpServletRequest request, String moduleNo, String func) {
        try {
            BucSSOUser bucSSOUser = SimpleUserUtil.getBucSSOUser(request);
            Integer userId = bucSSOUser.getId();
            String authority = moduleNo;
            if (StringUtils.isNotBlank(func)) {
                authority = authority + "_" + func;
            }
            Boolean flag = checkPermission(userId, authority);
            if (flag) {
                AuthorizationInfo authorizationInfo = new AuthorizationInfo();
                authorizationInfo.addStringPermissions(moduleNo, func);
                return authorizationInfo;
            }

        } catch (IOException | ServletException e) {
            log.error("AclHandlerImpl", e);
        }
        return null;
    }

    @Override
    public Boolean checkPermission(Integer userId, String authority) {
        try {
            CheckPermissionsParam checkPermissionsParam = new CheckPermissionsParam();

            List<String> list = new ArrayList<>();
            list.add(authority);

            checkPermissionsParam.setPermissionNames(list);
            checkPermissionsParam.setUserId(userId);
            checkPermissionsParam.setAccessKey(accessKey);

            CheckPermissionsResult checkPermissionsResult = accessControlService.checkPermissions(
                checkPermissionsParam);

            log.info("user:{} ACL权限返回内容:{}", userId, JSON.toJSONString(checkPermissionsResult));

            if (checkPermissionsResult.isSuccess()) {
                List<CheckPermissionResultInner> permissions = checkPermissionsResult.getCheckPermissionResults();
                boolean flag = true;
                if (CollectionUtils.isEmpty(permissions)) {
                    return flag;
                }

                for (CheckPermissionResultInner permission : permissions) {
                    if (!permission.isAccessible()) {
                        flag = false;
                    }
                }

                return flag;
            }
        } catch (Exception e) {
            log.error("Check Permission error.", e);
        }

        return false;
    }

    /**
     * 检查数据权限
     *
     * @return
     */
    @Override
    public Map<String, Boolean> checkDataPermission(Integer userId, String operation, String dataPermissionName,
                                                    List<DataProfileParam> dataList) {
        try {
            //懒加载，加载数据权限
            if (null == dataAccessControlService) {
                dataAccessControlService = applicationContext.getBean(
                    DataAccessControlService.class);
                if (null == dataAccessControlService) {
                    throw new RuntimeException("DataAccessControlService instance get error.");
                }
            }

            CheckDataPermissionParam dataPermissionParam = new CheckDataPermissionParam();
            dataPermissionParam.setDataList(dataList);
            dataPermissionParam.setDataPermissionName(dataPermissionName);
            OperationProfileParam operationProfileParam = new OperationProfileParam();
            operationProfileParam.setOperationName(operation);
            dataPermissionParam.setOperation(operationProfileParam);
            dataPermissionParam.setAccessKey(accessKey);

            UserProfileParam userProfileParam = new UserProfileParam();
            userProfileParam.setUserId(userId);
            dataPermissionParam.setUser(userProfileParam);

            AclResult<Map<DataProfileParam, CheckDataPermissionResult>> aclResult = dataAccessControlService
                .checkDataPermission(dataPermissionParam);

            if (aclResult.isSuccess()) {
                Map<String, Boolean> map = new HashMap<>();

                if (null == aclResult.getResult() || CollectionUtils.isEmpty(aclResult.getResult())) {
                    return map;
                }

                aclResult.getResult().forEach((dataProfileParam, checkDataPermissionResult) -> map
                    .put(dataProfileParam.getDataId(), checkDataPermissionResult.getAccessible()));

                return map;
            }
        } catch (Exception e) {
            log.error("Check data permission error.", e);
        }
        return new HashMap<>();
    }
}
