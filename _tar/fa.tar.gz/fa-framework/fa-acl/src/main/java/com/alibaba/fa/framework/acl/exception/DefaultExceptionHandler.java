package com.alibaba.fa.framework.acl.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fa.framework.util.Exceptions;

import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by zhanglei on 2017/3/19.
 */
public class DefaultExceptionHandler implements HandlerExceptionResolver {
    protected final Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {

        logger.error("统一异常日志",ex);
        if(ex instanceof AuthorizationException){
            ModelAndView modelAndView = new ModelAndView("/error/403");
            return modelAndView;
        }else {
            ModelAndView modelAndView = new ModelAndView("/error/500");
            modelAndView.addObject("ERROR_MESSAGE_500", ex.getMessage() + "");
            modelAndView.addObject("ERROR_MESSAGE_DETAIL_500", Exceptions
                .getStackTraceAsString(ex).replaceAll("\r|\n|\r\n", "</br>"));
            return modelAndView;
        }
    }
}
