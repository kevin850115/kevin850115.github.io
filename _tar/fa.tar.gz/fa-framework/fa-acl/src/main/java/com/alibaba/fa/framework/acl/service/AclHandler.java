package com.alibaba.fa.framework.acl.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.buc.api.datapermission.param.DataProfileParam;

/**
 * Created by zhanglei on 2017/4/14.
 */
public interface AclHandler {

    /**
     * 检查功能权限
     *
     * @param request
     * @param moduleNo
     * @param func
     * @return
     */
    AuthorizationInfo checkPermission(HttpServletRequest request, String moduleNo, String func);

    /**
     * 权限位检查
     * @param userId
     * @param authority
     * @return
     */
    Boolean checkPermission(Integer userId, String authority);

    /**
     * 数据权限检查
     * @param userId 用户
     * @param dataPermissionName 数据权限名
     * @param operation 数据权限操作
     * @param dataList 数据权限详情
     * @return
     */
    Map<String, Boolean> checkDataPermission(Integer userId, String operation, String dataPermissionName,
                                             List<DataProfileParam> dataList);
}
