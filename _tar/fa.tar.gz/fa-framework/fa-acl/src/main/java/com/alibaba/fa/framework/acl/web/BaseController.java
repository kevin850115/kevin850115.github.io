package com.alibaba.fa.framework.acl.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.buc.sso.client.util.SimpleUserUtil;
import com.alibaba.buc.sso.client.vo.BucSSOUser;
import com.alibaba.fa.framework.acl.exception.BusinessException;
import com.alibaba.fa.framework.util.Exceptions;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

/**
 * Created by zhanglei on 2017/3/12.
 */
public abstract class BaseController {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    @InitBinder
    public void initListBinder(WebDataBinder binder) {
        binder.setAutoGrowCollectionLimit(1024);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(
                new SimpleDateFormat("yyyy-MM-dd"), true));

    }
    protected void addError(ModelMap model,Exception ex){
        logger.error("",ex);
        if(ex instanceof BusinessException){
            BusinessException ex1 = (BusinessException) ex;
            if(ex1.getCode()!=null) {
                model.addAttribute("ERROR_CODE", ex1.getCode().getCode());
            }
        }
        model.addAttribute("ERROR_MESSAGE",ex.getMessage()+"");
        model.addAttribute("ERROR_MESSAGE_DETAIL", Exceptions.getStackTraceAsString(ex));

    }

    protected BucSSOUser getBucSSOUser(HttpServletRequest request) {
        BucSSOUser user = null;
        try {
            user = SimpleUserUtil.getBucSSOUser(request);
        } catch (Exception e) {
            logger.error("getBucSSOUser exception", e);
        }
        return user;
    }

    protected String getBucUserNick(HttpServletRequest request) {
        String nick = StringUtils.EMPTY;
        try {
            BucSSOUser user = SimpleUserUtil.getBucSSOUser(request);
            if (StringUtils.isNotBlank(user.getNickNameCn())) {
                nick = user.getNickNameCn();
            } else if (StringUtils.isNotBlank(user.getLastName())) {
                nick = user.getLastName();
            }
        } catch (Exception e) {
            logger.error("getBucUserNick exception", e);
        }
        return nick;
    }

    protected String getOperator(HttpServletRequest request){
        return getBucUserNick(request);
    }

}


