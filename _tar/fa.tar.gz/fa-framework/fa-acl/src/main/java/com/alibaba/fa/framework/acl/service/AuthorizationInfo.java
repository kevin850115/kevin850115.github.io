package com.alibaba.fa.framework.acl.service;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by zhanglei on 2017/4/14.
 */
public class AuthorizationInfo {
    protected Set<String> stringPermissions = new HashSet<String>();

    public void addStringPermissions(String modul, String func) {
        stringPermissions.add(modul + "_" + func);
    }

    public boolean check(String modul, String func) {
        return stringPermissions.contains(modul + "_" + func);
    }
}
