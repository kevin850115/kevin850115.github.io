package com.alibaba.fa.framework.acl.exception;

/**
 * Created by zhanglei on 2017/4/16.
 */
public class AuthorizationException extends RuntimeException {
    public AuthorizationException(String error){
        super(error);
    }
}
