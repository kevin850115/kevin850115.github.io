package com.alibaba.fa.framework.dto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alibaba.fastjson.JSON;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;

public class SimpleSetTest {

    @Test
    public void test(){
        Set<String> set1 = Sets.newHashSet();
        Set<String> set2 = Sets.newHashSet();

        set1.add("1111");
        set2.add("1111");

        System.out.println(JSON.toJSONString(set1));
        System.out.println(JSON.toJSONString(set2));
        System.out.println(set1.retainAll(set2));

        set2.add("2222");
        System.out.println(set1.retainAll(set2));
    }

    @Test
    public void test2(){
        Set<String> servers =  Sets.newTreeSet();
        servers.add("1111");
        servers.add("4444");
        servers.add("3333");
        servers.add("5555");
        servers.add("2222");
        servers.add("99999");

        Integer totalThread = 10;
        Integer serverNum = 6;
        Integer averageNum = (totalThread % serverNum == 0) ? totalThread / serverNum : totalThread / serverNum + 1;
        Map<String, List<Integer>> uidParamMap = Maps.newHashMap();

        int index = 0;
        for (String uuid : servers) {
            List<Integer> params = uidParamMap.get(uuid);
            if (CollectionUtils.isEmpty(params)){
                params = Lists.newArrayList();
                uidParamMap.put(uuid, params);
            }

            while (index < totalThread) {
                ++index;
                params.add(index);

                if (index % averageNum == 0) {
                    break;
                }
            }
        }

        System.out.println(JSON.toJSONString(uidParamMap));

        servers.forEach((uuid) -> System.out.println(uuid+"="+uidParamMap.get(uuid).size() +"  " +JSON.toJSONString(uidParamMap.get(uuid))));

    }

    @Test
    public void testLamda(){
        Set<String> servers =  Sets.newTreeSet();
        servers.add("1111");
        servers.add("4444");
        servers.add("3333");
        servers.add("5555");
        servers.add("2222");
        servers.add("99999");

        servers.forEach(server -> {

            if(server.contains("2")){
                return;
            }
            System.out.println(server);

        });
    }

    @Test
    public void logAnalizy() throws IOException {
       /* String filePath = "C:\\Users\\wb-hyl282156\\Desktop\\remove.log";
        FileReader reader = new FileReader(new File(filePath));

        Integer pushNum = 0,remove = 0;

        BufferedReader reader1 = new BufferedReader(reader);

        String tmp = "";
        while ((tmp = reader1.readLine()) != null){
            String[] data = tmp.split(" ,Success remove ");
            pushNum+= paseInt(data[0],"push ",true);
            remove+= paseInt(data[1]," data.",false);
        }

        System.out.println("total push:" + pushNum + ";total remove:"+remove);*/
    }

    public Integer paseInt(String tmp,String key,boolean tailf){
        Integer data;
        if(tailf){
            data = Integer.parseInt(tmp.substring(tmp.indexOf(key)+key.length(),tmp.length()));
        }else{
            data = Integer.parseInt(tmp.substring(0,tmp.indexOf(key)));
        }

        System.out.println(data);

        return data;
    }

    @Test
    public void logDealAnalizy() throws IOException {
       /* String filePath = "C:\\Users\\wb-hyl282156\\Desktop\\deal.log";
        FileReader reader = new FileReader(new File(filePath));
        Integer dealNum = 0;

        BufferedReader reader1 = new BufferedReader(reader);

        String tmp = "";
        while ((tmp = reader1.readLine()) != null){
            dealNum+= Integer.parseInt(tmp.substring(tmp.indexOf("Scan ")+"Scan ".length(),tmp.indexOf(" do to deal.")));
        }

        System.out.println("total deal:" + dealNum);*/
    }
}
