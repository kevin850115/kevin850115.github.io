package com.alibaba.fa.framework.dto.job;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;

import com.alibaba.dts.client.executor.job.processor.SimpleJobProcessor;
import com.alibaba.dts.client.executor.simple.processor.SimpleJobContext;
import com.alibaba.dts.common.domain.result.ProcessResult;
import com.alibaba.fa.framework.dto.bean.PushTask;
import com.alibaba.fa.framework.dto.config.DtoConfig;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.CollectionUtils;

/**
 * @Description
 * @Author wb-hyl282156
 * @Date 2019/1/15 15:05
 * @Version 1.0
 */
public class BalanceJobProcessor implements SimpleJobProcessor {

    public static DtoConfig config;

    @Override
    public ProcessResult process(SimpleJobContext simpleJobContext) {
        //重新分配任务队列，按照服务UUID排序，顺序将线程均匀分配到每台服务器
        Integer totalThread = config.getTotalCoreThread();
        Integer serverNum = simpleJobContext.getAvailableMachineAmount();
        Integer averageNum = (totalThread % serverNum == 0) ? totalThread / serverNum : totalThread / serverNum + 1;
        Map<Integer, List<Integer>> uidParamMap = Maps.newHashMap();

        int index = 0;
        for (int i = 0; i < serverNum; i++) {
            Integer serverIndex = i;

            List<Integer> params = uidParamMap.get(serverIndex);
            if (CollectionUtils.isEmpty(params)) {
                params = Lists.newArrayList();
                uidParamMap.put(serverIndex, params);
            }

            while (index < totalThread) {
                params.add(index++);

                if (index % averageNum == 0) {
                    break;
                }
            }
        }

        //获取当前主机的任务
        List<Integer> newProcessingParam = uidParamMap.get(simpleJobContext.getCurrentMachineNumber());

        //和现有的比较，是否改变 如果重新分配后本地无任务，则直接提升版本信息
        if (CollectionUtils.isEmpty(newProcessingParam)) {
            //提升当前处理队列标志，让已存在任务全部失效，再执行队列重分配添加操作
            config.getCurrentJobIndex().incrementAndGet();
            return new ProcessResult(true);
        }

        //新分配和本地一致，直接完成
        if (CollectionUtils.isEqualCollection(newProcessingParam, config.getProcessingParam())) {
            return new ProcessResult(true);
        }

        //不一致，失效旧的处理，重新分配任务
        config.setProcessingParam(newProcessingParam);

        //提升当前处理队列标志，让已存在任务全部失效，再执行队列重分配添加操作
        int currentIndex = config.getCurrentJobIndex().incrementAndGet();

        if (CollectionUtils.isNotEmpty(config.getProcessingParam())) {
            config.getProcessingParam().forEach(
                param -> config.getPushTaskQueue().offer(new PushTask(param, currentIndex)));
            //设置信号量
            config.setPushTaskSemaphore(new Semaphore(config.getProcessingParam().size()));
        }

        return new ProcessResult(true);
    }
}
