package com.alibaba.fa.framework.dto.service.impl;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.alibaba.fa.framework.dto.service.MessageService;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.commons.collections.CollectionUtils;

/**
 * @Description 告警处理抽象类
 * @Author wb-hyl282156
 * @Date 2018/12/21 11:56
 * @Version 1.0
 */
public class AbstractMessageService implements MessageService {

    /**
     * 消息通知实现集合
     */
    private static final List<MessageService> messageServices = Lists.newArrayList();

    /**
     * 通知线程池
     */
    private static final ExecutorService executors = new ThreadPoolExecutor(10, 100,
        0L, TimeUnit.MILLISECONDS,
        new LinkedBlockingQueue<>(500),
        new ThreadFactoryBuilder().setNameFormat("message_executor-%d").build());

    @Override
    public boolean sendMessage(String content) {
        //通过消息服务发送消息通知
        if (CollectionUtils.isNotEmpty(messageServices)) {
            messageServices.forEach(messageService -> executors.execute(() -> messageService.sendMessage(content)));
        }
        return true;
    }

    /**
     * 添加消息告警服务
     *
     * @param service
     * @return
     */
    public boolean addService(MessageService service) {
        return messageServices.add(service);
    }
}
