package com.alibaba.fa.framework.dto.jinwei;

import com.alibaba.fa.framework.dto.config.DtoConfig;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;
import com.alibaba.middleware.jingwei.externalApi.message.DataMessage;
import com.google.common.collect.Lists;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @Description
 * @Author wb-hyl282156
 * @Date 2019/1/10 12:03
 * @Version 1.0
 */
@Slf4j
public class JingweiMessageListener {

    @Setter
    private DtoConfig config;

    public boolean onReceiveMessage(List<DataMessage> list) {
        if (CollectionUtils.isEmpty(list)) {
            return true;
        }

        list.forEach(eventMessage -> {
            switch (eventMessage.getAction()) {
                case UPDATE:
                    pushRecord(eventMessage, OpenSearchDO.UPDATE);
                    config.getCounter().getDtsUpd().incrementAndGet();
                    break;
                case DELETE:
                    pushRecord(eventMessage, OpenSearchDO.DELETE);
                    config.getCounter().getDtsDel().incrementAndGet();
                    break;
                case INSERT:
                    pushRecord(eventMessage, OpenSearchDO.ADD);
                    config.getCounter().getDtsAdd().incrementAndGet();
                    break;
                default:
                    break;
            }
        });

        return true;
    }

    /**
     * 运算hash值，得出应该存入的redis队列
     *
     * @param record
     * @return
     */
    protected void pushRecord(DataMessage record, String command) {
        try {
            OpenSearchDO openSearchDO = new OpenSearchDO();

            //获取完整表名
            String tableName = config.getTddlTableNameMapperMap().get(record.getTableName());
            if (tableName == null){
                throw new Exception("No corresponding table was found according to the record.getTableName()，please check the dto configuration!");
            }
            openSearchDO.setTableName(tableName);

            log.debug("DtsOpenSearchHandler pushRecord start do {},table:{},time:{}", command, tableName,
                System.currentTimeMillis());

            //按照配置设置对应的索引值
            openSearchDO.setIndex(config.getTableIndexMap().get(tableName));



            //获取字段信息，构建成推送到opensearch需要的形式，主要是清理掉不关心字段，避免存入redis过多冗余内容
            if (!CollectionUtils.isEmpty(record.getRowDataMaps())) {

                //精卫是多行数据，此处需要遍历
                for (Map<String, Serializable> fieldMap : record.getRowDataMaps()) {
                    if (CollectionUtils.isEmpty(fieldMap)) {
                        continue;
                    }
                    //对象转换
                    Map<String, Object> fields = null;
                    if (OpenSearchDO.UPDATE.equals(command)){
                        fields = config.getTableConvertMap().get(tableName).filedTypeAdapter(fieldMap, record.getChangedRowDataMaps());
                    }else {
                        fields = config.getTableConvertMap().get(tableName).filedTypeAdapter(fieldMap, null);
                    }


                    openSearchDO.setFields(Lists.newArrayList(fields));

                    //执行指令，增删改
                    openSearchDO.setCommand(command);

                    //构建运算因子 表名+id，按照运算因子计算hash得到应该存入的redis队列
                    Object primaryValue = openSearchDO.getFields().get(0).get(config.getHashFieldKeys());
                    String indexSeed = String.format("%s-%s", openSearchDO.getTableName(), primaryValue);
                    int index = Math.abs(indexSeed.hashCode()) % config.getTotalCoreThread();

                    log.debug("DtsOpenSearchHandler pushRecord calc do {}, table:{}, index:{}, time:{}", command,
                        tableName,
                        index, System.currentTimeMillis());

                    config.getRdbTemplate().api().rpush(config.getQueueNamePrefix() + index, openSearchDO);

                    log.debug("DtsOpenSearchHandler pushRecord success do {}, table:{}, indexSeed:{}, time:{}", command,
                        tableName, indexSeed, System.currentTimeMillis());

                }
            }

        } catch (Exception e) {
            String content = String.format("%s executor %s error \n msg:%s", record.getTableName(), command,
                e.getMessage());
            config.getMessageService().sendMessage(content);

            log.error(content + "record:{}", record.toString(), e);
        }
    }
}
