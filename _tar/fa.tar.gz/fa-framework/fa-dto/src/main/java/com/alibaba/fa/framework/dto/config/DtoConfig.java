package com.alibaba.fa.framework.dto.config;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import com.alibaba.fa.framework.dto.bean.PushTask;
import com.alibaba.fa.framework.dto.service.ConvertService;
import com.alibaba.fa.framework.dto.service.MessageService;
import com.alibaba.fa.framework.rdb.RdbTemplate;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.Data;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * DTS消息接收配置
 *
 * @author wb-hyl282156
 */
@Data
public class DtoConfig {

    /**
     * 应用名
     */
    private String appName = "DTO";

    /**
     * redis入队dts消息队列前缀
     */
    private String queueNamePrefix = ":dts/message/queue-";

    /**
     * 转型失败的异常数据队列
     */
    private String errorQueueName = ":dts/error/message/queue";

    /**
     * 用于确保局部顺序的分组的字段
     */
    private String hashFieldKeys = "id";

    /**
     * 单次处理最大数量
     */
    private Integer limit = 100;

    /**
     * 总处理线程数，集群总和，也是取余分布消息的运算因子
     */
    private Integer totalCoreThread = 10;

    /**
     * 消息处理类
     */
    private MessageService messageService;

    /**
     * 消息源
     * 云上：DTS
     * 淘内：精卫
     */
    private String sourceServiceString = "com.alibaba.fa.framework.dto.jinwei.JingweiMessageListener";

    /**
     * 处理参数集合，本机获取到的参数处理集合
     */
    private List<Integer> processingParam = Lists.newArrayList();

    /**
     * 表索引模型
     */
    private Map<String, String> tableIndexMap = Maps.newHashMap();

    /**
     * 表数据模型转换器
     */
    private Map<String, ConvertService> tableConvertMap = Maps.newHashMap();

    /**
     * 当前有效JOB序号
     */
    private AtomicInteger currentJobIndex = new AtomicInteger(0);

    /**
     * 本地按照job分配执行调度的队列
     */
    private BlockingQueue<PushTask> pushTaskQueue = new LinkedBlockingDeque<>();

    /**
     * 推送队列信号量，控制资源处理和的有序进行
     */
    private Semaphore pushTaskSemaphore;

    /**
     * redis连接配置
     */
    private RdbTemplate<String, OpenSearchDO> rdbTemplate;

    /**
     * redis注册中心的相关配置
     */
    private DtoRegisterConfig register = new DtoRegisterConfig();

    /**
     * 异常消息通知配置
     */
    private MessageConfig message = new MessageConfig();

    /**
     * 计数器，统计调用量
     */
    private DtoCounter counter = new DtoCounter();

    public String getQueueNamePrefix() {
        return appName + queueNamePrefix;
    }

    public String getErrorQueueName() {
        return appName + errorQueueName;
    }

    /**
     * 分库分表之分表表名映射器
     * key：分表表名，如bill_0016，value：全表表名，如bill
     */
    private Map<String, String> tddlTableNameMapperMap = Maps.newHashMap();

    /**
     * Redis注册机制配置
     */
    @Data
    public class DtoRegisterConfig {

        /**
         * redis订阅通道名
         */
        private String channel = ":channel/DTO";

        /**
         * redis服务器列表key
         */
        private String serversKey = ":server/DTO";

        /**
         * 默认有效时间跨度是60秒，心跳时间的2倍
         */
        private int expirePeriod = 60 * 1000;

        /**
         * 当前实例唯一标志，方便在服务集群中定位主机信息
         */
        private String uuid = UUID.randomUUID().toString();

        /**
         * 本地缓存一份服务队列，当心跳消息判断没有服务变动时，则不需要变动
         */
        private Set<String> servers = Sets.newTreeSet();

        /**
         * 控制当前主机暂停处理消息开关
         */
        private volatile Boolean handleSwitch = true;

        public String getChannel() {
            return appName + channel;
        }

        public String getServersKey() {
            return appName + serversKey;
        }
    }

    /**
     * 计数器，统计总数据量
     */
    @Data
    public class DtoCounter {
        /**
         * 接收到的添加消息
         */
        private AtomicLong dtsAdd = new AtomicLong();

        /**
         * 接收到的修改消息数
         */
        private AtomicLong dtsUpd = new AtomicLong();

        /**
         * 接收到的删除消息数
         */
        private AtomicLong dtsDel = new AtomicLong();

        /**
         * 推送到opensearch的数据总数
         */
        private AtomicLong dtoPush = new AtomicLong();

        private AtomicLong totalDeal = new AtomicLong();

        private AtomicLong totalConvert = new AtomicLong();

        private AtomicLong dtoDelete = new AtomicLong();

        @Override
        public String toString() {
            return "dtsAdd=" + dtsAdd +
                ",  dtsUpd=" + dtsUpd +
                ",  dtsDel=" + dtsDel +
                ",  dtoPush=" + dtoPush +
                ",  totalDeal=" + totalDeal +
                ",  totalConvert=" + totalConvert +
                ",  dtoDelete=" + dtoDelete;
        }
    }

    @Data
    public class MessageConfig {
        /**
         * 消息通知地址
         */
        private String url;

        /**
         * 消息通知人
         */
        private String notifiers;

        /**
         * 通过消息定时打印统计值，默认是1小时输出一次
         */
        private Boolean printCounter = false;
    }

}
