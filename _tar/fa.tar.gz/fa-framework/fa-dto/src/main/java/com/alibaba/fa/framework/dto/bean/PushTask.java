package com.alibaba.fa.framework.dto.bean;

import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import com.alibaba.fastjson.JSON;
import com.alibaba.fa.framework.dto.service.DtoService;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务信息
 *
 * @author wb-hyl282156
 */
public class PushTask implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(PushTask.class);

    /**
     * 任务参数
     */
    private Integer num;
    /**
     * 当前执行任务序号
     */
    private Integer currentIndex;

    /**
     * 信号量，控制job执行情况，确保前一次执行完，后一次才可以执行
     */
    private Semaphore semaphore = new Semaphore(1);

    /**
     * DTO逻辑处理类
     */
    private DtoService dtoService;

    public PushTask(Integer num, Integer currentIndex) {
        this.num = num;
        this.currentIndex = currentIndex;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Integer getCurrentIndex() {
        return currentIndex;
    }

    public void setCurrentIndex(Integer currentIndex) {
        this.currentIndex = currentIndex;
    }

    public Semaphore getSemaphore() {
        return semaphore;
    }

    public void setSemaphore(Semaphore semaphore) {
        this.semaphore = semaphore;
    }

    public DtoService getDtoService() {
        return dtoService;
    }

    public void setDtoService(DtoService dtoService) {
        this.dtoService = dtoService;
    }

    @Override
    public void run() {
        try {
            //尝试获取信号量200毫秒，获取信号量，取到执行当前任务，获取失败，结束执行
            if (!semaphore.tryAcquire(200, TimeUnit.MILLISECONDS)) {
                return;
            }

            //外面做过校验，此处应该不会出现空情况，出现肯定是异常了
            List<OpenSearchDO> openSearchDOS = dtoService.query(num);
            if (CollectionUtils.isEmpty(openSearchDOS)) {
                return;
            }

            LOGGER.debug("Job {} Scan {} do to deal.", num, openSearchDOS.size());

            //调用自定义转换逻辑转换数据
            List<OpenSearchDO> openSearchDOList = dtoService.convert(openSearchDOS);

            //执行推送到openSearch
            boolean result = dtoService.push(openSearchDOList);
            if (result) {
                LOGGER.debug("JOB {} success push {} data.", num, openSearchDOList.size());

                dtoService.remove(num, openSearchDOList.size());
            } else {
                LOGGER.error("Job {} Error push {} data:{}", num, openSearchDOList.size(),
                    JSON.toJSONString(openSearchDOList));
            }

        } catch (Exception e) {
            LOGGER.error("OpenSearch push executor error,msg:{}", e.getMessage(), e);
        } finally {
            //释放信号量
            semaphore.release();

            dtoService.offer(this);
        }
    }
}
