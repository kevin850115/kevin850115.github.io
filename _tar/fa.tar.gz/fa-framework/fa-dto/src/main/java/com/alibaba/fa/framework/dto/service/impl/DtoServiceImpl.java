package com.alibaba.fa.framework.dto.service.impl;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.alibaba.fa.framework.dto.bean.PushTask;
import com.alibaba.fa.framework.dto.config.DtoConfig;
import com.alibaba.fa.framework.dto.service.ConvertService;
import com.alibaba.fa.framework.dto.service.DtoService;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;
import com.alibaba.fa.framework.search.opensearch.OpenSearchService;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

/**
 * 默认synchronous dts to opensearch 服务处理实现
 *
 * @author wb-hyl282156
 */
public class DtoServiceImpl implements InitializingBean, DtoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DtoServiceImpl.class);

    private DtoConfig config;

    private OpenSearchService openSearchService;

    private RedisSyncApiWrap<String, OpenSearchDO> redisWrap;

    private ExecutorService push_executor;

    public DtoServiceImpl(DtoConfig config, OpenSearchService openSearchService) {
        this.config = config;
        this.openSearchService = openSearchService;
        this.redisWrap = config.getRdbTemplate().getRedisApiWrap();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        redisWrap = config.getRdbTemplate().getRedisApiWrap();

        //按照最大同步线程数构建，并发核心线程数最大不会超过这个值
        int thread = config.getTotalCoreThread();

        push_executor = new ThreadPoolExecutor(thread, thread,
            0L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(),
            new ThreadFactoryBuilder().setNameFormat("push_executor-%d").build());

        //启动自循环，处理推送任务
        push_executor.execute(() -> exec());

        //定时输出运行数据监控
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    printCount();
                } catch (Exception e) {
                    LOGGER.error("DTO print error!", e);
                }
            }
        }, 30_000, 30 * 60 * 1000);

        LOGGER.info("DTO start success!");
    }

    /**
     * 触发重分配,此操作目前只对redis做注册中心有效
     *
     * @return
     */
    @Override
    public void reBalance() throws Exception {
        //删除当前服务列表，等待下次心跳检查发现服务异常，执行重新分配
        redisWrap.del(config.getRegister().getServersKey());
    }

    /**
     * 定时的RT输出
     *
     * @return
     */
    @Override
    public String printCount() throws Exception {
        StringBuffer stringBuffer = new StringBuffer();

        stringBuffer.append("DTO ").append(config.getAppName()).append(" report: \n\n");
        stringBuffer.append("Counter:").append(config.getCounter().toString()).append("\n");
        stringBuffer.append("Task Queue Size:").append(config.getPushTaskQueue().size()).append("\n");

        for (int i = 0; i < config.getTotalCoreThread(); i++) {
            stringBuffer.append("Queue-").append(i).append(":").append(
                redisWrap.llen(config.getQueueNamePrefix() + i)).append("\n");
        }
        stringBuffer.append("ErrorTaskQueue:").append(
            redisWrap.llen(config.getErrorQueueName())).append("\n");

        String counterInfo = stringBuffer.toString();

        LOGGER.info("{}", counterInfo);

        if (config.getMessage().getPrintCounter()) {
            config.getMessageService().sendMessage(counterInfo);
        }

        return counterInfo;
    }

    /**
     * 真正的执行推送的方法
     */
    @Override
    public void exec() {
        //任务队列
        BlockingQueue<PushTask> pushTaskQueue = config.getPushTaskQueue();

        //计数器，当队列都是等待执行，则说明在忙，等到200毫秒
        int busyNum = 0, emptyNum = 0;

        while (true) {

            //当忙碌线程等于队列任务数时或者全部空闲，则等待200毫秒，避免空转。等待后重新计数
            try {
                if (busyNum == pushTaskQueue.size() || emptyNum == pushTaskQueue.size()) {
                    Thread.sleep(200);
                    busyNum = 0;
                    emptyNum = 0;
                }
            } catch (Exception e) {
                LOGGER.error("Job judge error，msg:{} ", e.getMessage(), e);

                config.getMessageService().sendMessage(
                    String.format("DTO main thread error,app:%s \n msg:%s", config.getAppName(), e.getMessage()));
            }

            //任务序号
            PushTask pushTask = null;

            //获取有效任务
            try {
                //出队分配的job序号，如果队列为空，则执行等待，最大等待20000毫秒
                pushTask = pushTaskQueue.poll(20000, TimeUnit.MILLISECONDS);
                //2000毫秒等待后还没取到值，进入下一次等待
                if (null == pushTask) {
                    continue;
                }

                //判断当然任务是否还有效，有效任务进入执行，无效则丢弃
                if (!pushTask.getCurrentIndex().equals(config.getCurrentJobIndex().get())) {
                    continue;
                }

                //执行有效任务
                Integer jobNum = pushTask.getNum();
                String key = config.getQueueNamePrefix() + jobNum;
                //判断对应的队列为空
                if (redisWrap.llen(key) == 0) {
                    emptyNum++;

                    pushTaskQueue.offer(pushTask);
                    continue;
                }

                //如果当前任务在忙，则跳过，计数器加1
                if (pushTask.getSemaphore().availablePermits() == 0) {
                    busyNum++;

                    pushTaskQueue.offer(pushTask);
                    continue;
                }

                //执行逻辑
                pushTask.setDtoService(this);
                push_executor.execute(pushTask);
            } catch (Exception e) {
                //出现异常也要入队，确保不会丢失
                if (null != pushTask) {
                    pushTaskQueue.offer(pushTask);
                }

                LOGGER.error("Job submit error,msg:{}", e.getMessage(), e);

                config.getMessageService().sendMessage(
                    String.format("DTO main thread error,app:%s \n msg:%s", config.getAppName(), e.getMessage()));

                continue;
            }
        }
    }

    /**
     * 缓存中查询数据
     *
     * @param taskNum
     * @return
     */
    @Override
    public List<OpenSearchDO> query(Integer taskNum) throws Exception {
        List<OpenSearchDO> openSearchDOS = redisWrap.lrange(config.getQueueNamePrefix() + taskNum, 0,
            config.getLimit() - 1);
        if (CollectionUtils.isEmpty(openSearchDOS)) {
            return Lists.newArrayList();
        }
        return openSearchDOS;
    }

    /**
     * 转换类
     *
     * @param openSearchDOS
     * @return
     */
    @Override
    public List<OpenSearchDO> convert(List<OpenSearchDO> openSearchDOS) {

        //转换前进行数据统计
        //推送计数
        config.getCounter().getTotalDeal().addAndGet(openSearchDOS.size());

        //执行转换逻辑
        List<OpenSearchDO> openSearchDOList = Lists.newArrayList();
        openSearchDOS.forEach(data -> {
            ConvertService convert = config.getTableConvertMap().get(data.getTableName());

            if (null == convert) {
                LOGGER.error("{} Converter not found!", data.getTableName());
                return;
            }

            try {
                OpenSearchDO openSearchDO = convert.convert(data);
                if (null != openSearchDO) {
                    openSearchDOList.add(openSearchDO);
                }
            } catch (Exception e) {
                try {
                    redisWrap.rpush(config.getErrorQueueName(), data);
                } catch (Exception e1) {
                    LOGGER.error("Executor convert error，Push error error.", e1);
                }

                String content = String.format("%s convert %s error \n msg:%s", data.getTableName(), data.getCommand(),
                    e.getMessage());
                config.getMessageService().sendMessage(content);

                LOGGER.error("Executor convert error,msg:{}", e.getMessage(), e);
            }
        });

        //转换后进行数据统计
        //推送计数
        config.getCounter().getTotalConvert().addAndGet(openSearchDOList.size());

        return openSearchDOList;
    }

    /**
     * 删除指定队列数据
     *
     * @param end
     * @return
     */
    @Override
    public boolean remove(Integer taskNum, Integer end) throws Exception {
        if (null == end || end.equals(0)) {
            return true;
        }

        //从缓存队列移除已推送任务,避免上面复制导致数据变更，无法匹配到原对象，此处再取一次
        redisWrap.ltrim(config.getQueueNamePrefix() + taskNum, end, -1);

        //推送计数
        config.getCounter().getDtoDelete().addAndGet(end);

        return true;
    }

    /**
     * 推送到opensearch
     *
     * @param openSearchDOS
     * @return
     */
    @Override
    public boolean push(List<OpenSearchDO> openSearchDOS) {
        if (CollectionUtils.isEmpty(openSearchDOS)) {
            return true;
        }

        boolean pushResult = openSearchService.push(openSearchDOS);
        if (pushResult) {
            config.getCounter().getDtoPush().addAndGet(openSearchDOS.size());
        }

        return pushResult;
    }

    /**
     * 重新入队
     *
     * @param pushTask
     */
    @Override
    public void offer(PushTask pushTask) {
        config.getPushTaskQueue().offer(pushTask);
    }

}
