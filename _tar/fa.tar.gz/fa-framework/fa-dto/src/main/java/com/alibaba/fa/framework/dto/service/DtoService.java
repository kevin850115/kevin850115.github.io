package com.alibaba.fa.framework.dto.service;

import java.util.List;

import com.alibaba.fa.framework.dto.bean.PushTask;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;

/**
 * DTO推送处理类
 *
 * @author wb-hyl282156
 */
public interface DtoService {
    void reBalance() throws Exception;

    /**
     * 输出当前的统计信息
     *
     * @return
     */
    String printCount() throws Exception;

    /**
     * 执行从redis队列获取内容，并推送到openSearch
     */
    void exec();

    /**
     * 消息查询
     *
     * @param taskNum
     * @return
     */
    List<OpenSearchDO> query(Integer taskNum) throws Exception;

    /**
     * 消息转换
     *
     * @param openSearchDOS
     * @return
     */
    List<OpenSearchDO> convert(List<OpenSearchDO> openSearchDOS);

    /**
     * 消息移除
     *
     * @param taskNum
     * @param end
     * @return
     */
    boolean remove(Integer taskNum, Integer end) throws Exception;

    /**
     * 执行推送
     *
     * @param openSearchDOS
     * @return
     */
    boolean push(List<OpenSearchDO> openSearchDOS);

    /**
     * 重新入队
     *
     * @param pushTask
     */
    void offer(PushTask pushTask);
}
