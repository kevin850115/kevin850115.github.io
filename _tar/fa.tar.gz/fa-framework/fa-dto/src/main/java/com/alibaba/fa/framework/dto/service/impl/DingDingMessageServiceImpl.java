package com.alibaba.fa.framework.dto.service.impl;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fa.framework.dto.config.DtoConfig.MessageConfig;
import com.alibaba.fa.framework.dto.service.MessageService;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Description 通过钉钉进行消息发送
 * @Author wb-hyl282156
 * @Date 2018/12/21 10:53
 * @Version 1.0
 */
public class DingDingMessageServiceImpl implements MessageService {

    protected static final Logger LOGGER = LoggerFactory.getLogger(DingDingMessageServiceImpl.class);

    private MessageConfig config;

    public DingDingMessageServiceImpl(MessageConfig config) {
        this.config = config;
    }

    @Override
    public boolean sendMessage(String content) {
        try {
            HttpResponse<JsonNode> response = Unirest.post(config.getUrl()).header("Content-type",
                "application/json; charset=utf-8").body(
                new TextMessage(content,config.getNotifiers()).toJsonString()).asJson();
            if (response.getStatus() == HttpStatus.SC_OK) {
                return true;
            }
        } catch (UnirestException e) {
            LOGGER.error("Send ding ding alarm error！content：{},cause：{}", content, e.getMessage(), e);
        }
        return false;
    }

    class TextMessage {

        private String text;
        private List<String> atMobiles;

        public TextMessage(String text, String notifiers) {
            this.text = text;

            if(StringUtils.isNotBlank(notifiers)){
                this.atMobiles = Lists.newArrayList(notifiers.split(","));
            }
        }

        public String toJsonString() {
            Map<String, Object> items = Maps.newHashMap();
            items.put("msgtype", "text");

            Map<String, String> textContent = Maps.newHashMap();
            textContent.put("content", text);
            items.put("text", textContent);

            Map<String, Object> atItems = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(atMobiles)) {
                atItems.put("atMobiles", atMobiles);
            }

            atItems.put("isAtAll", false);

            items.put("at", atItems);

            return JSON.toJSONString(items);
        }
    }

}
