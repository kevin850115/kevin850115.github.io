package com.alibaba.fa.framework.dto.service;

import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 转换器，执行消息到opensearchDO的逻辑转换
 *
 * @author wb-hyl282156
 */
public interface ConvertService {

    /**
     * 执行转换操作
     *
     * @param data
     * @return
     */
    OpenSearchDO convert(OpenSearchDO data);


    /**
     * 精卫发送的消息用map封装，全是key-value，
     * 没有提供字段的类型信息，有需要的业务方需要
     * 自己实现类型转换，避免opensearch报错
     * @param fieldMap
     * @return
     */
    Map<String, Object> filedTypeAdapter(Map<String, Serializable> fieldMap, List<Map<String, Serializable>> updateMapList);
}
