package com.alibaba.fa.framework.dto.service.impl;

import com.alibaba.fa.framework.dto.service.ConvertService;
import com.alibaba.fa.framework.search.opensearch.OpenSearchDO;
import com.google.common.collect.Maps;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 默认转换器，不做任何修改，直接发布
 * @author wb-hyl282156
 */
public class DefaultConvertServiceImpl implements ConvertService {

    @Override
    public OpenSearchDO convert(OpenSearchDO data) {
        return data;
    }

    @Override
    public Map<String, Object> filedTypeAdapter(Map<String, Serializable> fieldMap, List<Map<String, Serializable>> updateMapList) {
        Map<String, Object> fields = Maps.newHashMap();
        fieldMap.entrySet().forEach(entry -> fields.put(entry.getKey(), entry.getValue()));
        if (updateMapList != null){
            for (Map<String, Serializable> map : updateMapList){
                map.entrySet().forEach(entry -> fields.put(entry.getKey(), entry.getValue()));
            }
        }
        return fields;
    }
}
