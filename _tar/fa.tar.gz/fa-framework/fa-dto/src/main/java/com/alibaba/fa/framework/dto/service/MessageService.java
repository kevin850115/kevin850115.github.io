package com.alibaba.fa.framework.dto.service;

/**
 * 消息发送接口
 *
 * @author wb-hyl282156
 */
public interface MessageService {

    /**
     * 消息来源
     * @param content 消息内容
     * @return
     */
    boolean sendMessage(String content);
}
