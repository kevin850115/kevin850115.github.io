package com.alibaba.fa.framework.rdb.core;

/**
 * Created by wb-zxy279015 on 2019/3/4.
 */
public interface BoundLockOperations {
    /**
     * 获得锁
     * @return true 成功
     */
    Boolean tryLock();

    /**
     * 是否锁
     * @return 锁定人
     */
    String hasLocked();

    /**
     * 释放锁
     */
    void unlock();
}
