package com.alibaba.fa.framework.rdb;

import java.util.List;

import com.alibaba.fa.framework.rdb.core.BoundHashOperations;
import com.alibaba.fa.framework.rdb.core.BoundLockOperations;
import com.alibaba.fa.framework.rdb.core.DefaultBoundHashOperations;
import com.alibaba.fa.framework.rdb.core.DefaultBoundListOperations;
import com.alibaba.fa.framework.rdb.core.DefaultBoundValueOperations;
import com.alibaba.fa.framework.rdb.core.SyncBatchLock;
import com.alibaba.fa.framework.rdb.core.SyncLock;

import com.taobao.rdb2.client.RedisSyncApi;
import com.taobao.rdb2.wrap.RdbCodec;
import com.taobao.rdb2.wrap.RedisSyncApiWrap;

/**
 * @Description
 * @Author wb-hyl282156
 * @Date 2019/1/15 13:26
 * @Version 1.0
 */
public class RdbTemplate<K, V> {

    private RedisSyncApiWrap<K, V> redisApiWrap;

    private RedisSyncApi redisSyncApi;

    private RdbCodec<K, V> rdbCodec;

    public void init() {
        if (null == redisApiWrap) {
            redisApiWrap = RedisSyncApiWrap.wrap(redisSyncApi, rdbCodec);
        }
    }

    public RedisSyncApiWrap<K, V> api() {
        return redisApiWrap;
    }

    public RedisSyncApiWrap<K, V> getRedisApiWrap() {
        return redisApiWrap;
    }

    public void setRedisApiWrap(RedisSyncApiWrap<K, V> redisApiWrap) {
        this.redisApiWrap = redisApiWrap;
    }

    public RedisSyncApi getRedisSyncApi() {
        return redisSyncApi;
    }

    public void setRedisSyncApi(RedisSyncApi redisSyncApi) {
        this.redisSyncApi = redisSyncApi;
    }

    public RdbCodec<K, V> getRdbCodec() {
        return rdbCodec;
    }

    public void setRdbCodec(RdbCodec<K, V> rdbCodec) {
        this.rdbCodec = rdbCodec;
    }

    public <H, HK, HV> BoundHashOperations boundHashOperations(H h){
        return new DefaultBoundHashOperations<>(h,api());
    }

    public <K,V> DefaultBoundValueOperations defaultBoundValueOperations(K k){
        return new DefaultBoundValueOperations<>(k,api());
    }

    public <K,V> DefaultBoundListOperations defaultBoundListOperations(K k){
        return new DefaultBoundListOperations<>(k,api());
    }

    public BoundLockOperations buildBatchLock(String namespace, List<String> keys,Long expire,String locker){
        if(locker == null || "".equals(locker)){
            return new SyncBatchLock(namespace,keys,expire,api());
        }
        return new SyncBatchLock(namespace,keys,expire,locker,api());
    }

    public BoundLockOperations buildLock(String namespace, String key,Long expire,String locker){
        if(locker == null || "".equals(locker)){
            return new SyncLock(namespace,key,expire,api());
        }
        return new SyncLock(namespace,key,expire,locker,api());
    }



}
