package com.alibaba.fa.framework.rdb;

import org.springframework.cache.Cache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/17
 */
public class RdbCacheManager extends ConcurrentMapCacheManager {

    private RdbTemplate<Object, Object> rdbTemplate;

    public void setRdbTemplate(RdbTemplate<Object, Object> rdbTemplate) {
        this.rdbTemplate = rdbTemplate;
    }

    @Override
    protected Cache createConcurrentMapCache(String name) {
        try {
            return new RdbCache(name,rdbTemplate);
        }catch (Exception e){
            return super.createConcurrentMapCache(name);
        }
    }
}
