package com.alibaba.fa.framework.rdb;

import com.taobao.rdb2.client.RedisSyncApi;
import com.taobao.rdb2.wrap.RedisSyncApiWrap;

/**
 * @Description
 * @Author wb-hyl282156
 * @Date 2019/1/15 13:36
 * @Version 1.0
 */
public class StringRdbTemplate extends RdbTemplate<String,String> {

    public StringRdbTemplate(RedisSyncApi redisSyncApi) {
        setRedisSyncApi(redisSyncApi);
        setRedisApiWrap(RedisSyncApiWrap.wrap(getRedisSyncApi()));
    }
}
