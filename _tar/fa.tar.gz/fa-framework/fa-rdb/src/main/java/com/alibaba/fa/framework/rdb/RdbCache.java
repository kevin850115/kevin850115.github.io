package com.alibaba.fa.framework.rdb;

import java.util.Set;
import java.util.concurrent.Callable;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.support.AbstractValueAdaptingCache;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/17
 */
public class RdbCache extends AbstractValueAdaptingCache {

    private String name;

    private RdbTemplate<Object, Object> rdbTemplate;

    private static final Logger logger = LoggerFactory.getLogger(RdbCache.class);

    RdbCache(String name,RdbTemplate<Object, Object> rdbTemplate) {
        super(true);
        this.name =name;
        this.rdbTemplate = rdbTemplate;
    }

    /**
     * 查询单个
     * @param o key
     * @return
     */
    @Override
    protected Object lookup(Object o) {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            return wrap.exhget(getName(),o);
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache lookup error",e);
            return null;
        }
    }

    /**
     * 缓存分组
     * @return
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * 获取所有
     * @return
     */
    @Override
    public Object getNativeCache() {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            return wrap.exhgetAll(getName());
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache getNativeCache error",e);
            return null;
        }
    }

    /**
     * 回调获取
     * @param o
     * @param callable 如果缓存中无则缓存数据
     * @param <T>
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> T get(Object o, Callable<T> callable) {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {

            if(wrap.exhexists(getName(),o)){
                return (T) wrap.exhget(getName(),o);
            }else{
                T value;
                try {
                    value = callable.call();
                }catch (Throwable ex) {
                    throw new ValueRetrievalException(o, callable, ex);
                }
                put(o, value);
                return value;
            }
        }catch (Exception e){
            logger.error(getName()  + " RdbCache get callable error",e);
        }
        return null;
    }

    /**
     * 缓存数据
     * @param o
     * @param o1
     */
    @Override
    public void put(Object o, Object o1) {
        if(o1==null){
            return;
        }
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            wrap.exhset(getName(),o,o1);
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache put error",e);
        }
    }

    /**
     * 线程安全的缓存版本控制
     * @param o
     * @param o1
     * @return 缓存成功则返回null 否则退回数据
     */
    @Override
    public ValueWrapper putIfAbsent(Object o, Object o1) {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            if(wrap.exhsetnx(getName(),o,o1)>0L){
                return null;
            }else{
                return toValueWrapper(lookup(o));
            }
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache putIfAbsent error",e);
        }
        return null;
    }

    /**
     * 清除单个缓存
     * @param o
     */
    @Override
    public void evict(Object o) {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            wrap.exhdel(getName(),o);
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache delete error",e);
        }
    }

    /**
     * 清除全组缓存
     */
    @Override
    public void clear() {
        RedisSyncApiWrap<Object, Object> wrap = rdbTemplate.api();
        try {
            Set<Object> fields =  wrap.exhkeys(getName());
            if(fields!=null && fields.size()>0){
                wrap.exhdel(getName(),fields.toArray());
            }
        } catch (Exception e) {
            logger.error(getName()  + " RdbCache clear error",e);
        }
    }
}
