package com.alibaba.fa.framework.rdb.core;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wb-zxy279015
 * @date 2019/3/4
 */
public class DefaultBoundHashOperations<H, HK, HV> extends DefaultBoundKeyOperations<H> implements BoundHashOperations<H, HK, HV> {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultBoundHashOperations.class);

    public DefaultBoundHashOperations(H key, RedisSyncApiWrap<?, ?> operations) {
        super(key, operations);
    }

    @Override
    public Long delete(Object... keys) {
        try {
            return ops.hdel(getKey(),keys);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations delete error",e);
        }
        return null;
    }

    @Override
    public Boolean hasKey(Object key) {
        try {
            return ops.hexists(getKey(),key);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations hasKey error",e);
            return Boolean.FALSE;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public HV get(Object key) {
        try {
            return (HV)ops.hget(getKey(),key);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations get error",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<HV> multiGet(Collection<HK> fields) {
        if (fields.isEmpty()) {
            return Collections.emptyList();
        }

        try {
            return (List<HV>)ops.hmget(getKey(),fields);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations multiGet error",e);
            return null;
        }
    }

    @Override
    public Long increment(HK key, long delta) {
        try {
            return ops.hincrBy(getKey(),key,delta);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations increment error.",e);
            return null;
        }
    }

    @Override
    public Double increment(HK key, double delta) {
        try {
            return ops.hincrByFloat(this.key,key,delta);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations increment double error.",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<HK> keys() {
        try {
            return (Set<HK>)ops.hkeys(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations keys error.",e);
            return null;
        }
    }

    @Override
    public Long size() {
        return null;
    }

    @Override
    public void putAll(Map<? extends HK, ? extends HV> m) {
        try {
            if(m.size() == 0){
                return;
            }
            Map map = new HashMap(m.size());
            map.putAll(m);
            ops.hmset(getKey(),map);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations putAll error.",e);
        }
    }

    @Override
    public void put(HK key, HV value) {
        try {
            ops.hset(getKey(),key,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations put error.",e);
        }
    }

    @Override
    public Boolean putIfAbsent(HK key, HV value) {
        try {
            return ops.hsetnx(getKey(),key,value) == 1L;
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations putIfAbsent error.",e);
            return Boolean.FALSE;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<HV> values() {
        try {
            return (List<HV>)ops.hvals(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations values error.",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<HK, HV> entries() {

        try {
            return (Map<HK, HV>)ops.hgetAll(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundHashOperations entries error.",e);
            return  null;
        }
    }
}
