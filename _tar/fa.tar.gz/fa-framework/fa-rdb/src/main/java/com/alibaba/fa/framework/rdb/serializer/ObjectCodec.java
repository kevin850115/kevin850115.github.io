package com.alibaba.fa.framework.rdb.serializer;

import com.taobao.rdb2.wrap.RdbCodec;

/**
 * @Description
 * @Author wb-hyl282156
 * @Date 2019/1/14 17:51
 * @Version 1.0
 */
public class ObjectCodec implements RdbCodec<Object, Object> {

    private RedisSerializer serializer;

    public RedisSerializer getSerializer() {
        return serializer;
    }

    public void setSerializer(RedisSerializer serializer) {
        this.serializer = serializer;
    }

    @Override
    public Object decodeKey(byte[] var1) throws Exception {
        return serializer.deserialize(var1);
    }

    @Override
    public Object decodeValue(byte[] var1) throws Exception {
        return serializer.deserialize(var1);
    }

    @Override
    public byte[] encodeKey(Object var1) throws Exception {
        return serializer.serialize(var1);
    }

    @Override
    public byte[] encodeValue(Object var1) throws Exception {
        return serializer.serialize(var1);
    }
}
