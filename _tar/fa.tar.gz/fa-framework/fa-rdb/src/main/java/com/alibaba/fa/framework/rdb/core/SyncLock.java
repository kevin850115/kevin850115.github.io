package com.alibaba.fa.framework.rdb.core;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/31
 */
public class SyncLock implements BoundLockOperations {
    private static final Logger LOG = LoggerFactory.getLogger(SyncLock.class);
    /**
     * key
     * value:threadName+time
     */
    private String key;

    /**
     * 应用名
     */
    private String nameSpace;

    /**
     * 加锁对象
     */
    private String locker = "SYS";

    /**
     * 失效时间
     */
    private Long expire;

    /**
     * RDB操作
     */
    private RedisSyncApiWrap<Object, Object> redisApiWrap;

    public SyncLock(String nameSpace, String key, Long expire, String locker,
                         RedisSyncApiWrap<?, ?> redisApiWrap) {
        this.nameSpace = nameSpace;
        this.key = key;
        this.expire = expire;
        this.locker = locker;
        this.redisApiWrap = (RedisSyncApiWrap<Object, Object>)redisApiWrap;
    }

    public SyncLock( String nameSpace, String key,Long expire,
                          RedisSyncApiWrap<?, ?> redisApiWrap) {
        this.nameSpace = nameSpace;
        this.key = key;
        this.expire = expire;
        this.redisApiWrap = (RedisSyncApiWrap<Object, Object>)redisApiWrap;
    }

    @Override
    public Boolean tryLock() {
        try {
            String redisKey = nameSpace + key;
            Boolean locked = redisApiWrap.setnx(redisKey,locker) == 1L;
            if (locked && null != expire) {
                redisApiWrap.expire(redisKey, expire.intValue());
            }
            return locked;
        } catch (Throwable throwable) {
            LOG.error("SyncLock tryLock exception.", throwable);
            return Boolean.FALSE;
        }
    }

    @Override
    public String hasLocked() {
        try {
            String redisKey = nameSpace + key;
            Object locker = redisApiWrap.get(redisKey);
            if (null != locker) {
                return locker.toString();
            } else {
                return null;
            }
        } catch (Throwable throwable) {
            LOG.error("SyncLock hasLocked exception.", throwable);
            return "jv hasLocked exception";
        }
    }

    @Override
    public void unlock() {
        try {
            String redisKey = nameSpace + key;
            Object locker = redisApiWrap.get(redisKey);
            if (null != locker) {
                redisApiWrap.del(redisKey);
            }
        } catch (Throwable throwable) {
            LOG.error("SyncLock unlock exception.", throwable);
        }
    }
}
