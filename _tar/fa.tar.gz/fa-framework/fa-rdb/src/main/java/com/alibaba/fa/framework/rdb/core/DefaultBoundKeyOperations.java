/*
 * Copyright 2011-2013 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.fa.framework.rdb.core;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default {@link BoundKeyOperations} implementation. Meant for internal usage.
 * 
 * @author Costin Leau
 */
abstract class DefaultBoundKeyOperations<K> implements BoundKeyOperations<K> {
	private static final Logger LOG = LoggerFactory.getLogger(DefaultBoundKeyOperations.class);

	protected K key;
	protected final RedisSyncApiWrap<Object, Object> ops;

	@SuppressWarnings("unchecked")
	DefaultBoundKeyOperations(K key, RedisSyncApiWrap<?, ?> operations) {
		setKey(key);
		this.ops = (RedisSyncApiWrap<Object, Object>)operations;
	}

	@Override
	public K getKey() {
		return key;
	}

	protected void setKey(K key) {
		this.key = key;
	}

	@Override
	public Boolean expire(long timeout, TimeUnit unit) {
		try {
			return ops.pexpire(key,toMillis(timeout, unit)) == 1L;
		} catch (Exception e) {
			LOG.error("BoundKeyOperations expire error.",e);
			return Boolean.FALSE;
		}
	}

	@Override
	public Boolean expireAt(Date date) {
		try {
			return ops.pexpireAt(key, date.getTime()) == 1L;
		} catch (Exception e) {
			LOG.error("BoundKeyOperations expireAt error.",e);
			return Boolean.FALSE;
		}
	}

	@Override
	public Long getExpire() {
		try {
			return ops.ttl(key);
		} catch (Exception e) {
			LOG.error("BoundKeyOperations getExpire error.",e);
		}
		return 0L;
	}

	@Override
	public Boolean persist() {
		try {
			return ops.persist(key) == 1L;
		} catch (Exception e) {
			LOG.error("BoundKeyOperations persist error.",e);
			return Boolean.FALSE;
		}
	}

	@Override
	public void rename(K newKey) {
		try {
			if (ops.exists(key)) {
				ops.rename(key, newKey);
			}
			key = newKey;
		}catch (Throwable e){
			LOG.error("BoundKeyOperations rename error.",e);
		}
	}

	@Override
	public void remove() {
		try {
			ops.del(key);
		} catch (Exception e) {
			LOG.error("BoundKeyOperations remove error",e);
		}
	}

	@Override
	public Boolean exists() {
		try {
			return ops.exists(key);
		} catch (Exception e) {
			LOG.error("BoundKeyOperations exists error",e);
			return false;
		}
	}

	protected long toMillis(long timeout, TimeUnit unit) {
		return roundUpIfNecessary(timeout, unit.toMillis(timeout));
	}

	protected long roundUpIfNecessary(long timeout, long convertedTimeout) {
		// A 0 timeout blocks some Redis ops indefinitely, round up if that's
		// not the intention
		if (timeout > 0 && convertedTimeout == 0) {
			return 1;
		}
		return convertedTimeout;
	}

	protected long toSeconds(long timeout, TimeUnit unit) {
		return roundUpIfNecessary(timeout, unit.toSeconds(timeout));

	}
}
