package com.alibaba.fa.framework.rdb.core;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.taobao.rdb2.client.struct.LIST_POSITION;
import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wb-zxy279015
 * @date 2019/3/4
 */
public class DefaultBoundListOperations<K, V> extends DefaultBoundKeyOperations<K> implements BoundListOperations<K, V> {
    private static final Logger LOG = LoggerFactory.getLogger(DefaultBoundKeyOperations.class);

    public DefaultBoundListOperations(K key, RedisSyncApiWrap<?, ?> operations) {
        super(key, operations);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<V> range(long start, long end) {
        try {
            return (List<V>)ops.lrange(getKey(),start,end);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations range error.",e);
            return null;
        }
    }

    @Override
    public void trim(long start, long end) {
        try {
            ops.ltrim(getKey(),start,end);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations trim error.",e);
        }
    }

    @Override
    public Long size() {
        try {
            return ops.llen(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations size error.",e);
            return 0L;
        }
    }

    @Override
    public Long leftPush(V value) {
        try {
            return ops.lpush(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPush error.",e);
            return 0L;
        }
    }

    @Override
    public Long leftPushAll(V[] values) {
        try {
            return ops.lpush(getKey(),values);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPushAll error.",e);
            return 0L;
        }
    }

    @Override
    public Long leftPushIfPresent(V value) {
        try {
            return ops.lpushx(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPushIfPresent error.",e);
            return 0L;
        }
    }

    @Override
    public Long leftPush(V pivot, V value) {
        try {
            return ops.linsert(getKey(), LIST_POSITION.BEFORE,pivot,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPush error.",e);
            return 0L;
        }
    }

    @Override
    public Long rightPush(V value) {
        try {
            return ops.rpush(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations rightPush error.",e);
            return 0L;
        }
    }

    @Override
    public Long rightPushAll(V[] values) {
        try {
            return ops.rpush(getKey(),values);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations rightPushAll error.",e);
            return 0L;
        }
    }

    @Override
    public Long rightPushIfPresent(V value) {
        try {
            return ops.rpushx(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations rightPushIfPresent error.",e);
            return 0L;
        }
    }

    @Override
    public Long rightPush(V pivot, V value) {
        try {
            return ops.linsert(getKey(), LIST_POSITION.AFTER,pivot,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations rightPush error.",e);
            return 0L;
        }
    }

    @Override
    public void set(long index, V value) {
        try {
            ops.lset(getKey(),index,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations set error.",e);
        }
    }

    @Override
    public Long remove(long count, Object value) {
        try {
            return ops.lrem(getKey(),count,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations remove error.",e);
            return 0L;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public V index(long index) {
        try {
            return (V)ops.lindex(getKey(),index);
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations index error.",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public V leftPop() {
        try {
            return (V)ops.lpop(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPop error.",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public V leftPop(long timeout, TimeUnit unit) {
        try {
            List l = ops.blpop(toSeconds(timeout,unit),getKey());
            if(l!=null && l.size()>0){
                return (V)l.get(0);
            }
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPop error.",e);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public V rightPop() {
        try {
            return (V)ops.rpop(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPop error.",e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public V rightPop(long timeout, TimeUnit unit) {
        try {
            List l = ops.brpop(toSeconds(timeout,unit),getKey());
            if(l!=null && l.size()>0){
                return (V)l.get(0);
            }
        } catch (Exception e) {
            LOG.error("DefaultBoundListOperations leftPop error.",e);
        }
        return null;
    }
}
