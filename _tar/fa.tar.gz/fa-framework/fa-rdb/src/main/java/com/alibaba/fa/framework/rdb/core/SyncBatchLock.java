package com.alibaba.fa.framework.rdb.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/31
 */
public class SyncBatchLock implements BoundLockOperations {
    private static final Logger LOG = LoggerFactory.getLogger(SyncBatchLock.class);

    /**
     * key
     * value:threadName+time
     */
    private List<String> keys;

    /**
     * 应用名
     */
    private String nameSpace;

    /**
     * 锁单对象
     */
    private String locker = "SYS";

    /**
     * 失效时间
     */
    private Long expire;

    /**
     * RDB操作
     */
    private RedisSyncApiWrap<Object, Object> redisApiWrap;

    public SyncBatchLock( String nameSpace, List<String> keys,Long expire,String locker,
                         RedisSyncApiWrap<?, ?> redisApiWrap) {
        this.nameSpace = nameSpace;
        this.keys = keys;
        this.expire = expire;
        this.locker = locker;
        this.redisApiWrap = (RedisSyncApiWrap<Object, Object>)redisApiWrap;
    }

    public SyncBatchLock( String nameSpace, List<String> keys,Long expire,
                          RedisSyncApiWrap<?, ?> redisApiWrap) {
        this.nameSpace = nameSpace;
        this.keys = keys;
        this.expire = expire;
        this.redisApiWrap = (RedisSyncApiWrap<Object, Object>)redisApiWrap;
    }

    @Override
    public Boolean tryLock() {
        if(null == keys){
            return Boolean.FALSE;
        }
        try {
            Map<Object, Object> map = new HashMap<>(keys.size());
            for (String key : keys) {
                String redisKey = nameSpace + key;
                map.put(redisKey, locker);
            }
            Boolean locked = redisApiWrap.msetnx(map) == 1L;
            if(locked && null != expire){
                for (Object redisKey : map.keySet()) {
                    redisApiWrap.expire(redisKey,expire.intValue());
                }
            }
            return locked;
        }catch (Throwable e){
            LOG.error("SyncBatchLock tryLock exception.", e);
            return Boolean.FALSE;
        }
    }

    @Override
    public String hasLocked() {
        throw new RuntimeException("SyncBatchLock can not execute the hasLocked method ");
    }

    @Override
    public void unlock() {
        if (null == keys) {
            return;
        }
        try {
            for (String key : keys) {
                String redisKey = nameSpace + key;
                Object value = redisApiWrap.get(redisKey);
                if (null != value) {
                    redisApiWrap.del(redisKey);
                }
            }
        } catch (Throwable throwable) {
            LOG.error("SyncBatchLock unlock exception.", throwable);
        }
    }
}
