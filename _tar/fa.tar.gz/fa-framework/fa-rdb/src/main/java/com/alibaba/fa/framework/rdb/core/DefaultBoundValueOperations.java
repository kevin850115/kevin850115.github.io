package com.alibaba.fa.framework.rdb.core;

import java.util.concurrent.TimeUnit;

import com.taobao.rdb2.wrap.RedisSyncApiWrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wb-zxy279015
 * @date 2019/3/4
 */
public class DefaultBoundValueOperations<K, V> extends DefaultBoundKeyOperations<K> implements BoundValueOperations<K, V> {
    private static final Logger LOG = LoggerFactory.getLogger(DefaultBoundKeyOperations.class);


    public DefaultBoundValueOperations(K key, RedisSyncApiWrap<?, ?> operations) {
        super(key, operations);
    }

    @Override
    public void set(V value) {
        try {
            ops.set(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations set error.",e);
        }
    }

    @Override
    public void set(V value, long timeout, TimeUnit unit) {
        try {
            ops.setex(getKey(),(int)toSeconds(timeout,unit),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations set error.",e);
        }
    }

    @Override
    public Boolean setIfAbsent(V value) {
        try {
            return ops.setnx(getKey(),value) == 1L;
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations setIfAbsent error.",e);
            return Boolean.FALSE;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public V get() {
        try {
            return (V)ops.get(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations get error.",e);
            return null;
        }
    }
    @SuppressWarnings("unchecked")
    @Override
    public V getAndSet(V value) {
        try {
            return (V)ops.getSet(getKey(),value);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations getAndSet error.",e);
            return null;
        }
    }

    @Override
    public Long increment(long delta) {
        try {
            return ops.incrBy(getKey(),delta);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations increment error.",e);
            return null;
        }
    }

    @Override
    public Double increment(double delta) {
        try {
            return ops.incrByFloat(getKey(),delta);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations increment error.",e);
            return null;
        }
    }

    @Override
    public Integer append(String value) {
        try {
            return ops.append(getKey(),value).intValue();
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations append error.",e);
            return 0;
        }
    }

    @Override
    public String get(long start, long end) {
        try {
            Object obj = ops.getrange(getKey(),start,end);
            if(obj!=null){
                return obj.toString();
            }
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations get error.",e);
        }
        return null;
    }

    @Override
    public void set(V value, long offset) {
        try {
            ops.setrange(getKey(),offset,value);
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations set error.",e);
        }
    }

    @Override
    public Long size() {
        try {
            return ops.strlen(getKey());
        } catch (Exception e) {
            LOG.error("DefaultBoundValueOperations size error.",e);
            return 0L;
        }
    }
}
