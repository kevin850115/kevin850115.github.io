package com.alibaba.fa.framework.crud.manager;

import com.alibaba.fa.framework.crud.dao.IMapper;
import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.crud.domain.Example;
import com.alibaba.fa.framework.crud.domain.Page;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by zhanglei on 2017/4/13.
 */
public abstract class BaseManager<T extends BaseEntity,E extends Example,S extends IMapper<T,E,?>> {
    @Autowired
    protected S mapper;

    public Page<T> queryPage(E excampleObject, int start, int count) {

        com.github.pagehelper.Page pp =  PageHelper.startPage((start+count)/count,count);
        List<T> list = mapper.selectByExampleWithRowbounds(excampleObject,new RowBounds(start,count));
        Page page = new Page();
        page.setCount(count);
        page.setRecordsFiltered((int)pp.getTotal());
        page.setRecordsTotal((int)pp.getTotal());
        page.setData(list);
        PageHelper.clearPage();
        return page;
    }

}
