package com.alibaba.fa.framework.web.vo;

/**
 * Created by zhanglei on 2017/3/12.
 */
public class ColumnVO {
    private String data;

    private Boolean orderable;
    private String name;
    public Boolean getOrderable() {
        return orderable;
    }

    public void setOrderable(Boolean orderable) {
        this.orderable = orderable;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
