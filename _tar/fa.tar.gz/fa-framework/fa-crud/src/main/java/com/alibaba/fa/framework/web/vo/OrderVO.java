package com.alibaba.fa.framework.web.vo;

/**
 * Created by zhanglei on 2017/3/12.
 */
public class OrderVO {
    private int column;

    private String dir;     //asc,desc

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }
}
