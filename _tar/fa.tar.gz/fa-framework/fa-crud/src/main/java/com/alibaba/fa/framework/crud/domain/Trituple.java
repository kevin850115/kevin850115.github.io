package com.alibaba.fa.framework.crud.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by wb-wmf250057 on 2017/4/14.
 * 三元组
 */
public class Trituple<A, B, C> {

    private A a;
    private B b;
    private C c;

    public Trituple() {
    }

    public Trituple(A first, B second, C third){
        this.a = first;
        this.b = second;
        this.c = third;
    }

    public A getFirst() {
        return a;
    }

    public void setFirst(A first) {
        this.a = first;
    }

    public B getSecond() {
        return b;
    }

    public void setSecond(B second) {
        this.b = second;
    }

    public C getThird() {
        return c;
    }

    public void setThird(C third) {
        this.c = third;
    }

    public static <A, B, C> Trituple<A, B, C> newTrituple() {
        return new Trituple<A, B, C>();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
