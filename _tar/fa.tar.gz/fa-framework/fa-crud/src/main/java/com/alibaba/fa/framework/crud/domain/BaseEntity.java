package com.alibaba.fa.framework.crud.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * Created by zhanglei on 2017/3/9.
 */
public abstract class BaseEntity implements Serializable {
        @Override
        public String toString() {
                return ToStringBuilder.reflectionToString(this);
        }
}
