package com.alibaba.fa.framework.web.vo;

import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.domain.SortingParam;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2017/3/12.
 */
public class BaseVO extends BaseEntity {
    private int draw;
    private int start;

    private int length;
    private List<ColumnVO> columns;
    private List<OrderVO> order;
    public String getOrderByClause(){
        StringBuffer orderBy = new StringBuffer();
        if(order!=null){
            for(OrderVO orderVO : order){
                ColumnVO columnVO = columns.get(orderVO.getColumn());
                if(columnVO.getOrderable()) {
                    orderBy.append(columnVO.getName()).append(" ").append(orderVO.getDir()).append(",");
                }
            }
            if(!orderBy.toString().equals("")) {
                return orderBy.substring(0, orderBy.length() - 1);
            }
        }
        return null;
    }

    public List<SortingParam> getSortingParam(){
        List<SortingParam> sortingParams = new ArrayList<>();
        if(order!=null){
            for(OrderVO orderVO : order){
                ColumnVO columnVO = columns.get(orderVO.getColumn());
                if(columnVO.getOrderable()) {
                    SortingParam sortingParam = new SortingParam();
                    sortingParam.setField(columnVO.getName());
                    if("ASC".equalsIgnoreCase(orderVO.getDir())){
                        sortingParam.setAsc(true);
                    } else {
                        sortingParam.setAsc(false);
                    }
                    sortingParams.add(sortingParam);
                }
            }
        }
        return sortingParams;
    }
    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getDraw() {
        return draw;
    }

    public void setDraw(int draw) {
        this.draw = draw;
    }

    public List<ColumnVO> getColumns() {
        return columns;
    }

    public void setColumns(List<ColumnVO> columns) {
        this.columns = columns;
    }

    public List<OrderVO> getOrder() {
        return order;
    }

    public void setOrder(List<OrderVO> order) {
        this.order = order;
    }
}
