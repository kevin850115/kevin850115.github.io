package com.alibaba.fa.framework.crud.service;

import com.alibaba.fa.framework.crud.dao.IBaseMapper;
import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.crud.domain.Example;
import com.alibaba.fa.framework.crud.domain.Page;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by zhanglei on 2017/3/12.
 */
public class BaseService<T extends BaseEntity,E extends Example,S extends IBaseMapper<T,E>> implements IBaseService<T,E> {
    @Autowired
    private S mapper;

    @Override
    public Page<T> queryPage(E excampleObject, int start, int count) {
        int total = mapper.countByExample(excampleObject);
        List<T> list = mapper.selectByExampleWithRowbounds(excampleObject,new RowBounds(start,count));
        Page page = new Page();
        page.setCount(count);
        page.setRecordsFiltered(total);
        page.setRecordsTotal(total);
        page.setData(list);
        return page;
    }
}
