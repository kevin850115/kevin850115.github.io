package com.alibaba.fa.framework.crud.service;

import com.alibaba.fa.framework.crud.domain.BaseEntity;
import com.alibaba.fa.framework.crud.domain.Example;
import com.alibaba.fa.framework.crud.domain.Page;

/**
 * Created by zhanglei on 2017/3/12.
 */
public interface IBaseService<T extends BaseEntity,E extends Example> {

    Page<T> queryPage(E excampleObject, int start, int count);
}
