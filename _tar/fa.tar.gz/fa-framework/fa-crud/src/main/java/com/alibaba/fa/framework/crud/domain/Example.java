package com.alibaba.fa.framework.crud.domain;

/**
 * Created by zhanglei on 2017/3/12.
 */
public abstract class Example{
}
