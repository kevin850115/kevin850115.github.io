package com.alibaba.fa.framework.loghub;

/**
 * Created by zhanglei on 2017/12/5.
 */
public class LogContent {
    private String ip;

    private long logTime;

    private String content;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
    public long getLogTime() {
        return logTime;
    }

    public void setLogTime(long logTime) {
        this.logTime = logTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
