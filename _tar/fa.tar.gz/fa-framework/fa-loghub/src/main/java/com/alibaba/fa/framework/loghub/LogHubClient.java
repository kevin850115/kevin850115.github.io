package com.alibaba.fa.framework.loghub;

import com.aliyun.openservices.loghub.client.ClientWorker;
import com.aliyun.openservices.loghub.client.config.LogHubConfig;
import com.aliyun.openservices.loghub.client.exceptions.LogHubClientWorkerException;
import com.aliyun.openservices.loghub.client.interfaces.ILogHubProcessorFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by zhanglei on 2017/12/5.
 */
public class LogHubClient {
    // 日志服务域名，根据实际情况填写
    private String endpoint;
    // 日志服务项目名称，根据实际情况填写
    private String project;
    // 日志库名称，根据实际情况填写
    private String logstore;
    // 消费组名称，根据实际情况填写
    private String consumerGroup;
    // 消费数据的ak，根据实际情况填写
    private String accessKeyId;
    private String accessKey;

    private ILogHubProcessorFactory logHubProcessorFactory;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    public void start() throws LogHubClientWorkerException {
        LogHubConfig config = new LogHubConfig(consumerGroup, getLocalIp(), endpoint, project, logstore, accessKeyId, accessKey, LogHubConfig.ConsumePosition.BEGIN_CURSOR);
        ClientWorker worker = new ClientWorker(logHubProcessorFactory, config);
        executor.submit(worker);
    }

    private String getLocalIp() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            return null;
        }
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getLogstore() {
        return logstore;
    }

    public void setLogstore(String logstore) {
        this.logstore = logstore;
    }

    public String getConsumerGroup() {
        return consumerGroup;
    }

    public void setConsumerGroup(String consumerGroup) {
        this.consumerGroup = consumerGroup;
    }

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public void setAccessKeyId(String accessKeyId) {
        this.accessKeyId = accessKeyId;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public ILogHubProcessorFactory getLogHubProcessorFactory() {
        return logHubProcessorFactory;
    }

    public void setLogHubProcessorFactory(ILogHubProcessorFactory logHubProcessorFactory) {
        this.logHubProcessorFactory = logHubProcessorFactory;
    }

    public ExecutorService getExecutor() {
        return executor;
    }

    public void setExecutor(ExecutorService executor) {
        this.executor = executor;
    }
}
