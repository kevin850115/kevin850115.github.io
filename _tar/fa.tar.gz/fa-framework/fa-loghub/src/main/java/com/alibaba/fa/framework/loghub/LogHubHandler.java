package com.alibaba.fa.framework.loghub;

import java.util.List;

/**
 * Created by zhanglei on 2017/12/6.
 */
public interface LogHubHandler {
    public void handler(List<LogContent> logContentList);
}
