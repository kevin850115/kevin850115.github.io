package com.alibaba.fa.framework.loghub;

import com.aliyun.openservices.log.common.*;
import com.aliyun.openservices.loghub.client.ILogHubCheckPointTracker;
import com.aliyun.openservices.loghub.client.exceptions.LogHubCheckPointException;
import com.aliyun.openservices.loghub.client.interfaces.ILogHubProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2017/12/5.
 */
public class LogHubProcessor implements ILogHubProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(LogHubProcessor.class);
    private int mShardId;
    // 记录上次持久化 check point 的时间
    private long mLastCheckTime = 0;

    private LogHubHandler logHubHandler;

    @Override
    public void initialize(int shardId) {
        mShardId = shardId;
    }

    // 消费数据的主逻辑，这里面的所有异常都需要捕获，不能抛出去。
    @Override
    public String process(List<LogGroupData> logGroups, ILogHubCheckPointTracker checkPointTracker) {
        // 这里简单的将获取到的数据打印出来
        List<LogContent> logContents = new ArrayList<LogContent>();
        for (LogGroupData logGroup : logGroups) {
            FastLogGroup flg = logGroup.GetFastLogGroup();
            for (int lIdx = 0; lIdx < flg.getLogsCount(); ++lIdx) {
                FastLog log = flg.getLogs(lIdx);
                for (int cIdx = 0; cIdx < log.getContentsCount(); ++cIdx) {
                    FastLogContent content = log.getContents(cIdx);
                    LogContent logContent = new LogContent();
                    logContent.setContent(content.getValue());
                    logContent.setIp(flg.getSource());
                    logContent.setLogTime(log.getTime());
                    logContents.add(logContent);
                }
            }
        }
        try {
            logHubHandler.handler(logContents);
        } catch (Exception e) {
            LOGGER.error("LogHubProcessor  handler error", e);
        }
        long curTime = System.currentTimeMillis();
        // 每隔 30 秒，写一次 check point 到服务端，如果 30 秒内，worker crash，
        // 新启动的 worker 会从上一个 checkpoint 其消费数据，有可能有少量的重复数据
        if (curTime - mLastCheckTime > 30 * 1000) {
            try {
                //参数true表示立即将checkpoint更新到服务端，为false会将checkpoint缓存在本地，后台默认隔60s会将checkpoint刷新到服务端。
                checkPointTracker.saveCheckPoint(true);
            } catch (LogHubCheckPointException e) {
                e.printStackTrace();
                LOGGER.error("LogHubProcessor  handler error", e);
            }
            mLastCheckTime = curTime;
        }
        return null;
    }

    // 当 worker 退出的时候，会调用该函数，用户可以在此处做些清理工作。
    @Override
    public void shutdown(ILogHubCheckPointTracker iLogHubCheckPointTracker) {
        //将消费断点保存到服务端。
        try {
            iLogHubCheckPointTracker.saveCheckPoint(true);
        } catch (LogHubCheckPointException e) {
            e.printStackTrace();
        }
    }

    public LogHubHandler getLogHubHandler() {
        return logHubHandler;
    }

    public void setLogHubHandler(LogHubHandler logHubHandler) {
        this.logHubHandler = logHubHandler;
    }
}
