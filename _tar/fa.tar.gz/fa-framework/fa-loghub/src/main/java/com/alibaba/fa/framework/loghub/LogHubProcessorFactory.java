package com.alibaba.fa.framework.loghub;

import com.aliyun.openservices.loghub.client.interfaces.ILogHubProcessor;
import com.aliyun.openservices.loghub.client.interfaces.ILogHubProcessorFactory;

/**
 * Created by zhanglei on 2017/12/5.
 */
public class LogHubProcessorFactory implements ILogHubProcessorFactory {
    private LogHubProcessor logHubProcessor;
    public LogHubProcessorFactory(LogHubProcessor logHubProcessor){
        this.logHubProcessor = logHubProcessor;
    }
    @Override
    public ILogHubProcessor generatorProcessor() {
        return logHubProcessor;
    }
}
