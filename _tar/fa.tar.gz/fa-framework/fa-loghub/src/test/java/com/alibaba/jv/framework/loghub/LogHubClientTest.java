package com.alibaba.fa.framework.loghub;

import com.aliyun.openservices.loghub.client.exceptions.LogHubClientWorkerException;
import org.junit.Test;

/**
 * Created by zhanglei on 2017/12/5.
 */
public class LogHubClientTest {
    @Test
    public void test() throws LogHubClientWorkerException, InterruptedException {
        /*
        group=jveye
        dataId=jveye.loghub
        timeout=6000
        endpoint=acm.aliyun.com
        nameSpace=e4927e6f-c343-4687-a907-d1f9d3eda3ab
        accessKey=d569fa8b6e594530835986eb78b85023
        accessSecret=2/7TWvUq9ju1FPkkZZjoEwgZi3A=
        */
        LogHubClient logHubClient = new LogHubClient();
        logHubClient.setAccessKey("eAGabNlfnxseBc4jasmhQqKtbBjE8y");
        logHubClient.setAccessKeyId("LTAIHdQKtSsLgVUK");
        logHubClient.setConsumerGroup("consumerGroupX");
        logHubClient.setEndpoint("cn-hangzhou.log.aliyuncs.com");
        logHubClient.setLogstore("iatkf-monitor");
        logHubClient.setProject("fliggy-iatkf");
        logHubClient.setLogHubProcessorFactory(new LogHubProcessorFactory(new LogHubProcessor()));
        logHubClient.start();
        Thread.sleep(60 * 60 * 1000);
    }
}
