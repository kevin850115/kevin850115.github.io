package com.alibaba.fa.framework.statemachine.impl;

import java.util.Date;
import java.util.concurrent.ThreadPoolExecutor;

import javax.annotation.PostConstruct;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.rdb.RdbTemplate;
import com.alibaba.fa.framework.rdb.core.BoundLockOperations;
import com.alibaba.fa.framework.statemachine.dao.ProcessTaskDao;
import com.alibaba.fa.framework.statemachine.model.BaseProcessContext;
import com.alibaba.fa.framework.statemachine.model.ProcessFailOverException;
import com.alibaba.fa.framework.statemachine.model.ProcessFailRetryException;
import com.alibaba.fa.framework.statemachine.model.ProcessTaskDO;
import com.alibaba.fa.framework.statemachine.model.ProcessTaskStatusEnum;
import com.alibaba.fa.framework.util.LoggerUtils;
import com.alibaba.fa.framework.util.LoggerWatchDog;

import com.taobao.ateye.monitor.TripMonitor;
import com.taobao.ateye.monitor.TripMonitorFailRate;
import com.taobao.ateye.monitor.TripMonitorRT;
import com.taobao.ateye.monitor.TripMonitorSuccessRate;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
public abstract class AbstractFaProcessService<CONTEXT extends BaseProcessContext> extends AbstractFaScenarioService<CONTEXT> {

    protected static final LoggerWatchDog LOG = LoggerUtils.getLogger(AbstractFaProcessService.class, "fa-framework", "process");

    private static final String KEY1 = "processTask";

    @Autowired
    private ProcessTaskDao processTaskDao;

    @Autowired
    private RdbTemplate<Object, Object> rdbTemplate;

    /**
     * 异步线程池
     */
    protected ThreadPoolExecutor threadPoolExecutor;

    @PostConstruct
    public void init() {
        threadPoolExecutor = initThreadPoolExecutor();
    }

    /**
     * 初始化线程池
     */
    protected abstract ThreadPoolExecutor initThreadPoolExecutor();

    /**
     * 任务创建后的检查
     *
     * 如：限流控制
     *
     * @param processContext
     * @return
     */
    protected ResultDO<Void> afterTaskCreateCheck(CONTEXT processContext) {
        return ResultDO.buildSuccessResult(null);
    }

    /**
     * 任务执行失败结束回调
     * @throw RunTimeException 抛异常后不会更新任务失败，任务继续重试
     * @param processContext
     */
    protected void taskFailCallback(CONTEXT processContext) {}

    /**
     * 执行任务+内存工作流
     *
     * 异步启动场景
     *
     * @param processContext
     */
    public ResultDO<Void> executeProcessTask(CONTEXT processContext) {

        long start = System.currentTimeMillis();
        // 加锁
        String key = processContext.getBizInstanceId().getBizInstanceId()+processContext.getBizInstanceId().getBizCode();
        BoundLockOperations lock = rdbTemplate.buildLock("processtask", key, 70L, "SYSTEM");
        if(!lock.tryLock()) {
            LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaProcessService executeProcessTask lock fail");
            return ResultDO.buildFailResult("乐观锁加锁失败");
        }

        try {
            // 初始化上下文
            ResultDO resultDO = initContext(processContext);
            if (!resultDO.isSuccess()) {
                LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaProcessService executeProcessTask initContext resultDO:{}", resultDO);
                resultDOToException(resultDO);
            }

            // 执行前检查
            resultDO = beforeExecuteCheck(processContext);
            if (!resultDO.isSuccess()) {
                LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaProcessService executeProcessTask beforeExecuteCheck resultDO:{}", resultDO);
                resultDOToException(resultDO);
            }

            // 校验
            if (null == processContext || processContext.getBizInstanceId() == null) {
                throw new ProcessFailRetryException("上下文或上下文业务身份空");
            }

            // 查询任务
            ResultDO<ProcessTaskDO> queryRes = processTaskDao.queryByBizIdAndBizCodeAndScenario(
                (Long)processContext.getBizInstanceId().getBizInstanceId(),
                processContext.getBizInstanceId().getBizCode(), scenarioName());
            if (!queryRes.isSuccess()) {
                resultDOToException(queryRes);
            }
            // 没有任务则新增
            ProcessTaskDO processTaskDO = null;
            if (queryRes.getModule() == null) {
                processTaskDO = new ProcessTaskDO();
                processTaskDO.setStatus(ProcessTaskStatusEnum.INIT.getKey());
                processTaskDO.setBizId((Long)processContext.getBizInstanceId().getBizInstanceId());
                processTaskDO.setBizCode(processContext.getBizInstanceId().getBizCode());
                processTaskDO.setScenarioName(scenarioName());
                processTaskDO.setRetryStopTime(processContext.getRetryStopTime());
                processTaskDO.setRetryInterval(processContext.getRetryInterval());
                processTaskDO.setMaxRetryTimes(processContext.getMaxRetryTimes());
                ResultDO<Void> insertRes = processTaskDao.insert(processTaskDO);
                if (!insertRes.isSuccess()) {
                    resultDOToException(insertRes);
                }
            } else {
                processTaskDO = queryRes.getModule();
            }

            // 任务创建后的检查
            resultDO = afterTaskCreateCheck(processContext);
            if (!resultDO.isSuccess()) {
                LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaProcessService executeProcessTask afterTaskCreateCheck resultDO:{}", resultDO);
                resultDOToException(resultDO);
            }

            // 异步执行
            final ProcessTaskDO processTaskDOFinal = processTaskDO;
            threadPoolExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        _executeProcessTask(processContext, processTaskDOFinal);
                    } finally {
                        lock.unlock();
                    }
                }
            });
            return ResultDO.buildSuccessResult(null);

        } catch(ProcessFailRetryException e) {
            lock.unlock();
            return ResultDO.buildFailResult(e.getMessage());
        } catch(ProcessFailOverException e) {
            lock.unlock();
            return ResultDO.buildFailResultCanNotRetry(e.getMessage());
        } catch (Exception e) {
            String msg = LOG.error4Tracer(
                processContext.getBizInstanceId().getBizInstanceId(),
                "AbstractFaProcessService executeProcessTask exception " + e.getMessage());
            lock.unlock();
            return ResultDO.buildFailResult(msg);
        }
    }


    private ResultDO<Void> _executeProcessTask(CONTEXT processContext, ProcessTaskDO processTaskDO) {
        // 埋点
        TripMonitorSuccessRate successRate = TripMonitor.succRate(KEY1, "executeProcessTask", "");
        TripMonitorFailRate failRate = TripMonitor.failRate(KEY1, "executeProcessTask", "");
        TripMonitorRT rt = TripMonitor.rt(KEY1, "executeProcessTask", "");
        failRate.incrTotal();
        successRate.incrTotal();
        try {
            // 状态校验
            if (ProcessTaskStatusEnum.FAILED.getKey().equals(processTaskDO.getStatus())
                || ProcessTaskStatusEnum.SUCCESS.getKey().equals(processTaskDO.getStatus())) {
                processTaskDO.setCurrentRetryTimes(0);
                LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),
                    "AbstractFaProcessService executeProcessTask end status(FAILED/SUCCESS) repeat execute");
            }

            // 更新任务执行中
            ProcessTaskDO processTaskUpdate = new ProcessTaskDO();
            processTaskUpdate.setBizCode(processContext.getBizInstanceId().getBizCode());
            processTaskUpdate.setBizId((Long)processContext.getBizInstanceId().getBizInstanceId());
            processTaskUpdate.setScenarioName(scenarioName());
            processTaskUpdate.setStatus(ProcessTaskStatusEnum.PROCESSING.getKey());
            ResultDO<Void> updateRes = processTaskDao.updateStatus(processTaskUpdate);
            if (!updateRes.isSuccess()) {
                failRate.incrFail();
                return updateRes;
            }

            // 启动场景
            ResultDO<Void> resultDO = _startScenario(processContext);

            // 执行结果
            if (resultDO.isSuccess()) {
                successRate.incrSucc();
                processTaskUpdate.setStatus(ProcessTaskStatusEnum.SUCCESS.getKey());
                processTaskDao.updateStatus(processTaskUpdate);
                return resultDO;
            }
            if (!resultDO.isSuccess() && !resultDO.getCanRetry()) {
                failRate.incrFail();
                processTaskUpdate.setStatus(ProcessTaskStatusEnum.FAILED.getKey());
                processTaskUpdate.setErrMsg(resultDO.getMsg());
                // 失败回调
                taskFailCallback(processContext);
                processTaskDao.updateFail(processTaskUpdate);
                return resultDO;
            }
            if (!resultDO.isSuccess() && resultDO.getCanRetry()) {
                failRate.incrFail();
                // 超出最大重试次数
                if (null != processTaskDO.getMaxRetryTimes()
                    && processTaskDO.getCurrentRetryTimes() + 1 > processTaskDO.getMaxRetryTimes()) {
                    processTaskUpdate.setErrMsg(resultDO.getMsg());
                    processTaskDao.updateFail(processTaskUpdate);
                    return ResultDO.buildFailResultCanNotRetry(resultDO.getCode(), resultDO.getMsg());
                }
                // 超出重试截止时间
                if (null == processTaskDO.getRetryInterval()) {
                    processTaskDO.setRetryInterval(60);
                }
                if (null != processTaskDO.getRetryStopTime()
                    && processTaskDO.getRetryStopTime().getTime()
                    > processTaskDO.getRetryStopTime().getTime() + processTaskDO.getRetryInterval() * 1000) {
                    processTaskUpdate.setErrMsg(resultDO.getMsg());
                    processTaskDao.updateFail(processTaskUpdate);
                    // 失败回调
                    taskFailCallback(processContext);
                    return ResultDO.buildFailResultCanNotRetry(resultDO.getCode(), resultDO.getMsg());
                }

                // 继续重试
                processTaskUpdate.setCurrentRetryTimes(processTaskDO.getCurrentRetryTimes() + 1);
                processTaskUpdate.setNextRetryTime(DateUtils.addSeconds(new Date(), processTaskDO.getRetryInterval()));
                processTaskUpdate.setErrMsg(resultDO.getMsg());
                processTaskDao.updateRetry(processTaskUpdate);
                return resultDO;

            }
            return resultDO;

        } catch (Throwable e) {
            String msg = LOG.error4Tracer(
                processContext.getBizInstanceId().getBizInstanceId(),
                "AbstractFaProcessService executeProcessTask exception " + e.getMessage());
            failRate.incrFail();
            return ResultDO.buildFailResult(msg);

        }

    }
}
