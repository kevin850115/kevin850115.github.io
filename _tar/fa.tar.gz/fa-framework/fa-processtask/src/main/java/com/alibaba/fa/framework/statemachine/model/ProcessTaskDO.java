package com.alibaba.fa.framework.statemachine.model;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
@Getter
@Setter
public class ProcessTaskDO implements Serializable {

    private Long id;

    private Date gmtCreate;

    private Date gmtModified;

    /**
     * 状态
     * @see ProcessTaskStatusEnum
     */
    private Integer status;

    /**
     * 失败错误信息
     */
    private String errMsg;

    /**
     * 业务ID
     */
    private Long bizId;

    /**
     * 业务身份
     */
    private String bizCode;

    /**
     * 场景名称
     */
    private String scenarioName;

    /**
     * 环境
     */
    private String env;

    /**
     * 工作流名称
     */
    private String processName;

    /**
     * 当前重试次数
     */
    private Integer currentRetryTimes;

    /**
     * 下次重试时间
     */
    private Date nextRetryTime;

    /**
     * 最大重试次数
     */
    private Integer maxRetryTimes;

    /**
     * 重试时间间隔
     */
    private Integer retryInterval;

    /**
     * 重试截止时间
     */
    private Date retryStopTime;

    private String extra;

}
