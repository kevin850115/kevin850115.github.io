package com.alibaba.fa.framework.statemachine.dao;

import java.util.List;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.statemachine.model.ProcessTaskDO;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
public interface ProcessTaskDao {

    /**
     * 插入
     * @param processTaskDO
     * @return
     */
    ResultDO<Void> insert(ProcessTaskDO processTaskDO);

    /**
     * 批量插入
     * @param processTaskDO
     * @return
     */
    ResultDO<Void> insertBatch(List<ProcessTaskDO> processTaskDO);

    /**
     * 更新
     * @param processTaskDO
     * @return
     */
    ResultDO<Void> updateFail(ProcessTaskDO processTaskDO);

    ResultDO<Void> updateStatus(ProcessTaskDO processTaskDO);

    ResultDO<Void> updateRetry(ProcessTaskDO processTaskDO);

    /**
     * 批量更新失败
     * @param processTaskDOs
     * @return
     */
    ResultDO<Void> updateFailBatch(String bizCode, Long bizInstanceId);

    /**
     * 初始化更新
     * @param bizId
     * @param bizCode
     * @param scenarioName
     * @return
     */
    ResultDO<Void> updateInit(Long bizId, String bizCode, String scenarioName);

    /**
     * 删除
     *
     * @param processTaskDO
     * @return
     */
    ResultDO<Void> deleteBatch(List<Long> ids);

    /**
     * 根据业务ID+场景 查询任务
     * @param bizId
     * @param bizCode
     * @return
     */
    ResultDO<ProcessTaskDO> queryByBizIdAndBizCodeAndScenario(Long bizId, String bizCode, String scenarioName);

    /**
     * 任务扫描
     * @param processTaskDO
     * @param limit
     * @return
     */
    ResultDO<List<ProcessTaskDO>> queryLimit(ProcessTaskDO processTaskDO, Integer limit);


}
