package com.alibaba.fa.framework.statemachine.model;

import lombok.Getter;
import lombok.Setter;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
@Getter
@Setter
public class ProcessFailRetryException extends RuntimeException {

    private String errCode;

    public ProcessFailRetryException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
    }

    public ProcessFailRetryException(String message) {
        super(message);
    }

    public ProcessFailRetryException() {

    }
}
