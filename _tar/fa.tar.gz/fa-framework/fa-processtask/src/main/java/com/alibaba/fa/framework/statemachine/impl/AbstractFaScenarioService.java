package com.alibaba.fa.framework.statemachine.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.rdb.RdbTemplate;
import com.alibaba.fa.framework.rdb.core.BoundLockOperations;
import com.alibaba.fa.framework.statemachine.model.BaseProcessContext;
import com.alibaba.fa.framework.statemachine.model.ProcessFailOverException;
import com.alibaba.fa.framework.statemachine.model.ProcessFailRetryException;
import com.alibaba.fa.framework.statemachine.model.ScenarioConstant;
import com.alibaba.fa.framework.util.LoggerUtils;
import com.alibaba.fa.framework.util.LoggerWatchDog;
import com.alibaba.tmf.function.config.BusinessConfig;
import com.alibaba.tmf.function.config.ProcessConfig;
import com.alibaba.tmf.function.specific.impl.IBizInstance;
import com.alibaba.tmf.session.BizSession;
import com.alibaba.tmf.session.BizSessionScope;
import com.alibaba.tmf.session.SessionConfig;

import com.taobao.tbbpm.process.ProcessEngine;
import com.taobao.tbbpm.process.ProcessEngineFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
public abstract class AbstractFaScenarioService<CONTEXT extends BaseProcessContext> {

    protected static final LoggerWatchDog LOG = LoggerUtils.getLogger(AbstractFaScenarioService.class, "fa-framework", "process");

    @Autowired
    private RdbTemplate<Object, Object> rdbTemplate;

    /**
     * 场景名称
     * @return
     */
    protected abstract String scenarioName();

    /**
     * 标准流程编排
     * @return
     */
    protected abstract String standardProcessName();


    /**
     * 初始化场景上下文
     * @param processContext
     */
    protected abstract ResultDO<Void> initContext(CONTEXT processContext);

    /**
     * 场景或者任务准入检查
     * @param processContext
     * @return
     */
    protected ResultDO<Void> beforeExecuteCheck(CONTEXT processContext) {
        return ResultDO.buildSuccessResult(null);
    }


    /**
     * 启动场景
     * 根据ProcessConfig场景找到工作流，再启动工作流执行
     * @param processContext
     * @return
     */
    public ResultDO<Void> startScenario(CONTEXT processContext) {
        // 加锁
        String key = processContext.getBizInstanceId().getBizInstanceId()+processContext.getBizInstanceId().getBizCode();
        BoundLockOperations lock = rdbTemplate.buildLock("startScenario", key, 70L, "SYSTEM");
        if(!lock.tryLock()) {
            LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaScenarioService startScenario lock fail");
            return ResultDO.buildFailResult("乐观锁加锁失败");
        }

        try {
            return startScenarioNoLock(processContext);
        } finally {
            lock.unlock();
        }
    }

    public ResultDO<Void> startScenarioNoLock(CONTEXT processContext) {
        // 初始化上下文
        ResultDO resultDO = initContext(processContext);
        if (!resultDO.isSuccess()) {
            String msg = LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaScenarioService executeProcessTask initContext resultDO:{}", resultDO);
            return resultDO;
        }

        // 执行前检查
        resultDO = beforeExecuteCheck(processContext);
        if (!resultDO.isSuccess()) {
            String msg = LOG.warn4Tracer(processContext.getBizInstanceId().getBizInstanceId(),"AbstractFaScenarioService executeProcessTask beforeExecuteCheck resultDO:{}", resultDO);
            return resultDO;
        }

        return _startScenario(processContext);
    }


    /**
     * 启动工作流
     * @param processContext
     * @param processName
     * @return
     */
    private ResultDO<Void> _startProcess(CONTEXT processContext, String processName) {
        Map<String, Object> context = new HashMap<>();
        context.put(ScenarioConstant.CONTEXT_NAME, processContext);
        return this.startProcess(context, processName, processContext.getTraceId());
    }

    protected ResultDO<Void> _startScenario(CONTEXT processContext) {

        try {
            List<IBizInstance> bizInstances = new ArrayList<>();
            if (processContext.getBizInstanceId() != null) {
                bizInstances.add(processContext);
            }

            //构建一次业务调用的会话
            ResultDO<Void> processResult = new BizSessionScope<ResultDO<Void>, Exception>(scenarioName(), bizInstances) {
                @Override
                protected ResultDO<Void> _execute() {
                    String processName = findProcessName(processContext.getBizInstanceId().getBizCode(),
                        processContext.getTraceId());
                    return _startProcess(processContext, processName);
                }
            }.invoke();
            return processResult;

        } catch (Exception e) {
            String msg = LOG.error4Tracer(processContext.getTraceId(), e, "AbstractFaScenarioService _startScenario exception" + e.getMessage());
            return ResultDO.buildFailResult(msg);
        }
    }

    private ResultDO<Void> startProcess(Map<String, Object> processContext, String processName, String traceId) {
        try {
            ProcessEngine engine = ProcessEngineFactory.getProcessEngine();
            engine.start(processName, processContext);
            return ResultDO.buildSuccessResult(null);

        } catch (ProcessFailOverException e) {
            return ResultDO.buildFailResultCanNotRetry(e.getErrCode(), e.getMessage());
        } catch (ProcessFailRetryException e) {
            return ResultDO.buildFailResult(e.getErrCode(), e.getMessage());
        } catch (Throwable e) {
            String msg = LOG.error4Tracer(traceId, e, "AbstractFaScenarioService startProcess exception" + e.getMessage());
            return ResultDO.buildFailResult(msg);
        }
    }

    /**
     * 根据业务身份和场景，确定流程定义文件的名称 ——基于插件的业务配置
     *
     * @param bizCode
     * @return
     */
    private String findProcessName(String bizCode, String traceId) {

        Set<String> processNameSet = new HashSet<>();
        String scenario = BizSession.currentSession().getScenario();

        if (bizCode != null) {
            SessionConfig sessionConfig = BizSession.currentSession().getSessionConfig();
            if (sessionConfig != null) {
                BusinessConfig businessConfig = sessionConfig.getBusinessConfig(bizCode);

                if (businessConfig != null) {
                    List<ProcessConfig> processConfigs = businessConfig.getProcessConfigs();
                    processConfigs.forEach(processConfig -> {
                        processConfig.getScenarioEntrances().forEach(scenarioName -> {
                            if (scenarioName.equals(scenario)) {
                                processNameSet.add(processConfig.getCode());
                            }
                        });
                    });
                }
            }
        }

        if (processNameSet.size() == 0) {
            // 返回平台默认的场景流程定义
            return standardProcessName();
        } else {
            String processName = processNameSet.stream().findFirst().get();
            if (processNameSet.size() > 1) {
                LOG.error4Tracer(traceId, "业务插件配置，流程定义存在重复配置，默认使用第1个 bizCode={}, scenario={} processName:{}", bizCode,
                    scenario, processName);
                return processName;
            }
            return processName;
        }
    }

    /**
     * 处理resultDO
     * -失败抛异常
     * -成功继续执行
     * @param resultDO
     * @param <T>
     */
    protected <T> void resultDOToException(ResultDO<T> resultDO) {
        if (null == resultDO) {
            throw new ProcessFailRetryException("响应结果空");
        }
        if (!resultDO.isSuccess()) {
            String code = StringUtils.isBlank(resultDO.getCode()) ? "" : resultDO.getCode();
            if(resultDO.getCanRetry()) {
                throw new ProcessFailRetryException(code + "/" + resultDO.getMsg());
            } else {
                throw new ProcessFailOverException(code + "/" + resultDO.getMsg());
            }
        }
    }
}
