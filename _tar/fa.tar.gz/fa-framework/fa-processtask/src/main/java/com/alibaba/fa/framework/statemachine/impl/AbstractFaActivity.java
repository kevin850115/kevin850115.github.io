package com.alibaba.fa.framework.statemachine.impl;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.statemachine.model.BaseProcessContext;
import com.alibaba.fa.framework.statemachine.model.ProcessFailOverException;
import com.alibaba.fa.framework.statemachine.model.ProcessFailRetryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;

/**
 * @author: shiye.ys
 * @date: 2019-05-06
 */
public abstract class AbstractFaActivity<RETURN, CONTEXT extends BaseProcessContext> {

    /**
     * 活动节点执行入口
     * @param scenarioContext
     * @return
     */
    public abstract RETURN process(CONTEXT scenarioContext);

    /**
     * 处理resultDO
     * -失败抛异常
     * -成功继续执行
     * @param resultDO
     * @param <T>
     */
    protected <T> void validateResultDO(ResultDO<T> resultDO) {
        if (null == resultDO) {
            throw new ProcessFailRetryException("响应结果空");
        }
        if (!resultDO.isSuccess()) {
            String code = StringUtils.isBlank(resultDO.getCode()) ? "" : resultDO.getCode();
            if(resultDO.getCanRetry()) {
                throw new ProcessFailRetryException(code + "/" + resultDO.getMsg());
            } else {
                throw new ProcessFailOverException(code + "/" + resultDO.getMsg());
            }
        }
    }
}
