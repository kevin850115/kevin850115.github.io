package com.alibaba.fa.framework.statemachine.model;

/**
 * @author: shiye.ys
 * @date: 2019-04-23
 */
public class ScenarioConstant {

    /**
     * 上下文请求
     */
    public static final String CONTEXT_NAME = "scenarioContext";

}
