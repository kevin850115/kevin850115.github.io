package com.alibaba.fa.framework.statemachine.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.tmf.function.specific.BizInstanceId;
import com.alibaba.tmf.function.specific.impl.IBizInstance;

import lombok.Getter;
import lombok.Setter;

/**
 * 流程请求基础入参
 */
public class BaseProcessContext implements Serializable, IBizInstance {

    private static final long serialVersionUID = -5309270608612489949L;

    @Setter
    @Getter
    private String traceId;

    @Setter
    private BizInstanceId instanceId;

    @Setter
    @Getter
    private Integer retryInterval;

    @Setter
    @Getter
    private Integer maxRetryTimes;

    @Setter
    @Getter
    private Date retryStopTime;

    @Override
    public BizInstanceId getBizInstanceId() {
        return instanceId;
    }
}
