package com.alibaba.fa.framework.statemachine.model;

import com.alibaba.fa.framework.util.IKeyDescEnum;

/**
 * @author: shiye.ys
 * @date: 2019-01-18
 */
public enum ProcessTaskStatusEnum implements IKeyDescEnum {
    ENUM_INVALID(-1, "ENUM_INVALID", "未知"),
    INIT(1, "INIT", "初始"),
    PROCESSING(2, "PROCESSING", "处理中"),
    FAILED(3, "FAILED", "失败"),
    RETRY(4, "RETRY", "待重试"),
    SUCCESS(5, "SUCCESS", "成功"),
    ;

    private Integer key;
    private String code;
    private String desc;

    ProcessTaskStatusEnum(Integer key, String code, String desc) {
        this.key = key;
        this.code = code;
        this.desc = desc;
    }


    @Override
    public Integer getKey() {
        return this.key;
    }

    @Override
    public String getDesc() {
        return this.desc;
    }

    @Override
    public String getCode() {
        return this.code;
    }

    public static ProcessTaskStatusEnum keyOf(Integer key) {
        if (key == null){ return ENUM_INVALID;}
        for (ProcessTaskStatusEnum value : ProcessTaskStatusEnum.values()) {
            if (key.equals(value.getKey())) {
                return value;
            }
        }
        return ENUM_INVALID;
    }

}
