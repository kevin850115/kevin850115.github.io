package com.alibaba.fa.framework.statemachine.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.statemachine.dao.ProcessTaskDao;
import com.alibaba.fa.framework.statemachine.model.ProcessTaskDO;
import com.alibaba.fa.framework.statemachine.model.ProcessTaskStatusEnum;
import com.alibaba.fa.framework.util.LoggerUtils;
import com.alibaba.fa.framework.util.LoggerWatchDog;

import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
public class ProcessTaskDaoImpl implements ProcessTaskDao {

    protected static final LoggerWatchDog LOG = LoggerUtils.getLogger(AbstractFaProcessService.class, "fa-framework", "processTaskDao");

    @Setter
    private DataSource dataSource;

    @Setter
    private String env;

    private final String INSERT = "INSERT INTO PROCESS_TASK(GMT_CREATE, GMT_MODIFIED, NEXT_RETRY_TIME, STATUS, BIZ_ID, BIZ_CODE, SCENARIO_NAME, PROCESS_NAME, CURRENT_RETRY_TIMES, RETRY_INTERVAL, MAX_RETRY_TIMES, RETRY_STOP_TIME, ENV, EXTRA) VALUES(now(), now(), now(), ?,?,?,?,?,?,?,?,?,?,?)";

    @Override
    public ResultDO<Void> insert(ProcessTaskDO processTaskDO) {
        List<String> validate = ProcessTaskDOValidator.validateInsert(processTaskDO);
        if (CollectionUtils.isNotEmpty(validate)) {
            return ResultDO.buildFailResult(StringUtils.join(validate, ","));
        }
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(INSERT);
            int i = 0;
            preparedStatement.setInt(i+=1, ProcessTaskStatusEnum.INIT.getKey());
            preparedStatement.setLong(i+=1, processTaskDO.getBizId());
            preparedStatement.setString(i+=1, processTaskDO.getBizCode());
            preparedStatement.setString(i+=1, processTaskDO.getScenarioName());
            if (StringUtils.isBlank(processTaskDO.getProcessName())) {
                preparedStatement.setNull(i+=1, Types.VARCHAR);
            } else {
                preparedStatement.setString(i += 1, processTaskDO.getProcessName());
            }
            preparedStatement.setInt(i+=1, 0);
            preparedStatement.setInt(i+=1, processTaskDO.getRetryInterval() == null ? 60 : processTaskDO.getRetryInterval());
            if(processTaskDO.getMaxRetryTimes() == null) {
                preparedStatement.setNull(i+=1, Types.INTEGER);
            } else {
                preparedStatement.setInt(i+=1, processTaskDO.getMaxRetryTimes());
            }

            if(processTaskDO.getRetryStopTime() == null) {
                preparedStatement.setNull(i+=1, Types.DATE);
            } else {
                preparedStatement.setTimestamp(i+=1, new Timestamp(processTaskDO.getRetryStopTime().getTime()));
            }
            preparedStatement.setString(i+=1, env);
            if (StringUtils.isNotBlank(processTaskDO.getExtra())) {
                preparedStatement.setNull(i+=1, Types.VARCHAR);
            } else {
                preparedStatement.setString(i += 1, processTaskDO.getExtra());
            }
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao insert rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(processTaskDO.getBizId(), e,
                "ProcessTaskDao insert exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, processTaskDO.getBizId().toString());
        }

    }

    @Override
    public ResultDO<Void> insertBatch(List<ProcessTaskDO> processTaskDOs) {
        if (CollectionUtils.isEmpty(processTaskDOs)) {
            return ResultDO.buildFailResult("批量任务为空");
        }
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(INSERT);
            for (ProcessTaskDO processTaskDO : processTaskDOs) {
                List<String> validate = ProcessTaskDOValidator.validateInsert(processTaskDO);
                if (CollectionUtils.isNotEmpty(validate)) {
                    continue;
                }
                int i = 0;
                preparedStatement.setInt(i+=1, ProcessTaskStatusEnum.INIT.getKey());
                preparedStatement.setLong(i+=1, processTaskDO.getBizId());
                preparedStatement.setString(i+=1, processTaskDO.getBizCode());
                preparedStatement.setString(i+=1, processTaskDO.getScenarioName());
                if (StringUtils.isBlank(processTaskDO.getProcessName())) {
                    preparedStatement.setNull(i+=1, Types.VARCHAR);
                } else {
                    preparedStatement.setString(i += 1, processTaskDO.getProcessName());
                }
                preparedStatement.setInt(i+=1, 0);
                preparedStatement.setInt(i+=1, processTaskDO.getRetryInterval() == null ? 60 : processTaskDO.getRetryInterval());
                preparedStatement.setInt(i+=1, processTaskDO.getMaxRetryTimes() == null ? 1 : processTaskDO.getMaxRetryTimes());
                if(processTaskDO.getRetryStopTime() == null) {
                    preparedStatement.setNull(i+=1, Types.DATE);
                } else {
                    preparedStatement.setTimestamp(i+=1, new Timestamp(processTaskDO.getRetryStopTime().getTime()));
                }
                preparedStatement.setString(i+=1, env);
                if (StringUtils.isNotBlank(processTaskDO.getExtra())) {
                    preparedStatement.setNull(i+=1, Types.VARCHAR);
                } else {
                    preparedStatement.setString(i += 1, processTaskDO.getExtra());
                }
                preparedStatement.addBatch();
            }

            preparedStatement.executeBatch();
            return ResultDO.buildSuccessResult(null);
        } catch (Exception e) {
            String msg = LOG.error4Tracer(processTaskDOs.get(0).getBizId(), e, "ProcessTaskDao insert exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, processTaskDOs.get(0).getBizId().toString());
        }
    }

    @Override
    public ResultDO<Void> updateFail(ProcessTaskDO processTaskDO) {
        String sql = "update process_task set gmt_modified = now(), status=?, err_msg=? where biz_id=? and biz_code=? and scenario_name=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.FAILED.getKey());
            if (StringUtils.isBlank(processTaskDO.getErrMsg())) {
                preparedStatement.setNull(i += 1, Types.VARCHAR);
            } else {
                preparedStatement.setString(i += 1, processTaskDO.getErrMsg());
            }
            preparedStatement.setLong(i += 1, processTaskDO.getBizId());
            preparedStatement.setString(i += 1, processTaskDO.getBizCode());
            preparedStatement.setString(i += 1, processTaskDO.getScenarioName());
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao updateFail rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(processTaskDO.getBizId(), e, "ProcessTaskDao updateFail exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, processTaskDO.getBizId().toString());
        }
    }

    @Override
    public ResultDO<Void> updateStatus(ProcessTaskDO processTaskDO) {
        String sql = "update process_task set gmt_modified = now(), status=? where biz_id=? and biz_code=? and scenario_name=? and env=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setInt(i += 1, processTaskDO.getStatus());
            preparedStatement.setLong(i += 1, processTaskDO.getBizId());
            preparedStatement.setString(i += 1, processTaskDO.getBizCode());
            preparedStatement.setString(i += 1, processTaskDO.getScenarioName());
            preparedStatement.setString(i += 1, env);
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao updateStatus rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(processTaskDO.getBizId(), e, "ProcessTaskDao updateStatus exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, processTaskDO.getBizId().toString());
        }
    }

    @Override
    public ResultDO<Void> updateRetry(ProcessTaskDO processTaskDO) {
        String sql = "update process_task set gmt_modified = now(), status=?, err_msg=?, current_retry_times=?, next_retry_time=? where biz_id=? and biz_code=? and scenario_name=? and env=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.RETRY.getKey());
            if (StringUtils.isBlank(processTaskDO.getErrMsg())) {
                preparedStatement.setNull(i += 1, Types.VARCHAR);
            } else {
                preparedStatement.setString(i += 1, processTaskDO.getErrMsg());
            }
            preparedStatement.setInt(i += 1, processTaskDO.getCurrentRetryTimes());
            preparedStatement.setTimestamp(i += 1, new Timestamp(processTaskDO.getNextRetryTime().getTime()));

            preparedStatement.setLong(i += 1, processTaskDO.getBizId());
            preparedStatement.setString(i += 1, processTaskDO.getBizCode());
            preparedStatement.setString(i += 1, processTaskDO.getScenarioName());
            preparedStatement.setString(i += 1, env);
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao updateRetry rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(processTaskDO.getBizId(), e, "ProcessTaskDao updateRetry exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, processTaskDO.getBizId().toString());
        }
    }

    @Override
    public ResultDO<Void> updateInit(Long bizId, String bizCode, String scenarioName) {
        String sql = "update process_task set gmt_modified = now(), status=?, current_retry_times=?, next_retry_time=? where biz_id=? and biz_code=? and scenario_name=? and env=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.RETRY.getKey());
            preparedStatement.setInt(i += 1, 0);
            preparedStatement.setTimestamp(i += 1, new Timestamp(new Date().getTime()));

            preparedStatement.setLong(i += 1, bizId);
            preparedStatement.setString(i += 1, bizCode);
            preparedStatement.setString(i += 1, scenarioName);
            preparedStatement.setString(i += 1, env);
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao updateInit rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(bizId, e, "ProcessTaskDao updateInit exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, bizId.toString());
        }
    }

    @Override
    public ResultDO<Void> updateFailBatch(String bizCode, Long bizInstanceId) {
        if (StringUtils.isBlank(bizCode) || null == bizInstanceId) {
            return ResultDO.buildFailResult("updateFailBatch业务身份或者业务ID空");
        }
        String sql = "update process_task set gmt_modified = now(), status=? where biz_id=? and biz_code=? and env=? and status in(?,?,?)";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.FAILED.getKey());
            preparedStatement.setLong(i += 1, bizInstanceId);
            preparedStatement.setString(i += 1, bizCode);
            preparedStatement.setString(i += 1, env);
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.INIT.getKey());
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.PROCESSING.getKey());
            preparedStatement.setInt(i += 1, ProcessTaskStatusEnum.RETRY.getKey());
            int rowcount = preparedStatement.executeUpdate();
            if (rowcount > 0) {
                return ResultDO.buildSuccessResult(null);
            }
            return ResultDO.buildFailResult("ProcessTaskDao updateFailBatch rowcount<=0");
        } catch (Exception e) {
            String msg = LOG.error4Tracer(bizInstanceId, e, "ProcessTaskDao updateFailBatch exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, bizInstanceId.toString());
        }
    }

    @Override
    public ResultDO<Void> deleteBatch(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultDO.buildFailResult("删除任务集合空");
        }
        String sql = "delete from process_task where id=? and env=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            for (Long id : ids) {
                preparedStatement.setLong(1, id);
                preparedStatement.setString(2, env);
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
            return ResultDO.buildSuccessResult(null);
        } catch (Exception e) {
            String msg = LOG.error4Tracer(ids.get(0), e, "ProcessTaskDao updateInitBatch exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, null, ids.get(0).toString());
        }
    }

    @Override
    public ResultDO<ProcessTaskDO> queryByBizIdAndBizCodeAndScenario(Long bizId, String bizCode, String scenarioName) {
        if (null == bizId || StringUtils.isBlank(bizCode) || StringUtils.isBlank(scenarioName)) {
            return ResultDO.buildFailResult("查询条件空");
        }
        String sql = "select * from process_task where biz_id=? and biz_code=? and scenario_name=? and env=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            int i = 0;
            preparedStatement.setLong(i += 1, bizId);
            preparedStatement.setString(i += 1, bizCode);
            preparedStatement.setString(i += 1, scenarioName);
            preparedStatement.setString(i += 1, env);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                ProcessTaskDO processTaskDO = assignData(resultSet);
                return ResultDO.buildSuccessResult(processTaskDO);
            }
            return ResultDO.buildSuccessResult(null);

        } catch (Exception e) {
            String msg = LOG.error4Tracer(bizId, e, "ProcessTaskDao queryByBizIdAndBizCodeAndScenario exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, resultSet, bizId.toString());
        }
    }

    @Override
    public ResultDO<List<ProcessTaskDO>> queryLimit(ProcessTaskDO processTaskDO, Integer limit) {
        StringBuilder sql = new StringBuilder("select * from process_task where status=? and next_retry_time >= now() ");
        if (null == processTaskDO || null == processTaskDO.getStatus()) {
            return ResultDO.buildFailResult("查询条件空");
        }
        if (null == limit) {
            limit = 200;
        }
        if (StringUtils.isNotBlank(processTaskDO.getBizCode())) {
            sql.append("and biz_code=? ");
        }
        if (StringUtils.isNotBlank(processTaskDO.getScenarioName())) {
            sql.append("and scenario_name=? ");
        }
        sql.append("and env=? limit ?");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sql.toString());
            int i = 0;
            preparedStatement.setInt(i += 1, processTaskDO.getStatus());
            if (StringUtils.isNotBlank(processTaskDO.getBizCode())) {
                preparedStatement.setString(i += 1, processTaskDO.getBizCode());
            }
            if (StringUtils.isNotBlank(processTaskDO.getScenarioName())) {
                preparedStatement.setString(i += 1, processTaskDO.getScenarioName());
            }
            preparedStatement.setString(i += 1, env);
            preparedStatement.setInt(i += 1, limit);
            resultSet = preparedStatement.executeQuery();

            List<ProcessTaskDO> res = new ArrayList<>();
            while (resultSet.next()) {
                ProcessTaskDO processTask = assignData(resultSet);
                res.add(processTask);
            }
            return ResultDO.buildSuccessResult(res);

        } catch (Exception e) {
            String msg = LOG.error( e, "ProcessTaskDao queryByBizIdAndBizCodeAndScenario exception");
            return ResultDO.buildFailResult(msg);
        } finally {
            close(preparedStatement, connection, resultSet, null);
        }
    }

    private ProcessTaskDO assignData(ResultSet resultSet) throws Exception {
        ProcessTaskDO processTaskDO = new ProcessTaskDO();
        processTaskDO.setId(resultSet.getLong("id"));
        processTaskDO.setGmtCreate(resultSet.getDate("gmt_create"));
        processTaskDO.setGmtModified(resultSet.getDate("gmt_modified"));
        processTaskDO.setStatus(resultSet.getInt("status"));
        processTaskDO.setErrMsg(resultSet.getString("err_msg"));
        processTaskDO.setBizId(resultSet.getLong("biz_id"));
        processTaskDO.setBizCode(resultSet.getString("biz_code"));
        processTaskDO.setScenarioName(resultSet.getString("scenario_name"));
        processTaskDO.setProcessName(resultSet.getString("process_name"));
        processTaskDO.setCurrentRetryTimes(resultSet.getInt("current_retry_times"));
        processTaskDO.setNextRetryTime(resultSet.getDate("next_retry_time"));
        processTaskDO.setRetryInterval(resultSet.getInt("retry_interval"));
        processTaskDO.setMaxRetryTimes(resultSet.getInt("max_retry_times"));
        processTaskDO.setRetryStopTime(resultSet.getDate("retry_stop_time"));
        processTaskDO.setEnv(resultSet.getString("env"));
        processTaskDO.setExtra(resultSet.getString("extra"));
        return processTaskDO;

    }

    private void close(PreparedStatement preparedStatement, Connection connection, ResultSet resultSet, String traceId) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                if (null == traceId) {
                    LOG.error(e, "ProcessTaskDao ResultSet close exception");
                }else {
                    LOG.error4Tracer(traceId, e, "ProcessTaskDao ResultSet close exception");
                }
            }
        }
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                if (null == traceId) {
                    LOG.error(e, "ProcessTaskDao preparedStatement close exception");
                }else {
                    LOG.error4Tracer(traceId, e, "ProcessTaskDao preparedStatement close exception");
                }
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                if (null == traceId) {
                    LOG.error(e, "ProcessTaskDao connection close exception");
                }else {
                    LOG.error4Tracer(traceId, e, "ProcessTaskDao connection close exception");
                }
            }
        }
    }
}
