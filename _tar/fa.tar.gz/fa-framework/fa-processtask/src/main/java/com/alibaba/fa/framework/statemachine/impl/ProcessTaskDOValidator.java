package com.alibaba.fa.framework.statemachine.impl;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fa.framework.statemachine.model.ProcessTaskDO;
import com.alibaba.fa.framework.util.StringUtil;

import org.apache.commons.lang.StringUtils;

/**
 * @author: shiye.ys
 * @date: 2019-04-27
 */
public class ProcessTaskDOValidator {

    public static List<String> validateInsert(ProcessTaskDO processTaskDO) {
        List<String> res = new ArrayList<>();
        if (null == processTaskDO) {
            res.add("请求空");
        } else {
            if (null == processTaskDO.getBizId()) {
                res.add("业务ID为空");
            }
            if (StringUtils.isEmpty(processTaskDO.getBizCode())) {
                res.add("业务身份为空");
            }
            if (StringUtils.isEmpty(processTaskDO.getScenarioName())) {
                res.add("业务场景名称为空");
            }
        }
        return res;
    }
}
