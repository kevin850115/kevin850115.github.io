package com.alibaba.fa.framework.statemachine.model;

import lombok.Getter;
import lombok.Setter;

/**
 * @author: shiye.ys
 * @date: 2019-04-25
 */
@Getter
@Setter
public class ProcessFailOverException extends RuntimeException {

    private String errCode;

    public ProcessFailOverException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
    }

    public ProcessFailOverException(String message) {
        super(message);
    }

    public ProcessFailOverException() {

    }
}
