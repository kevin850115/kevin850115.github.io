package com.alibaba.fa.framework.search.opensearch;

import java.util.List;

import com.alibaba.fastjson.JSONObject;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 *  查询结果
 *
 * @author 曰仁（xiujiao.zxj）
 * @since 2016-12-14
 */
public class SearchData {

	/** 查出来的数据大小 **/
	private int hit;

	/** 共多少条 **/
	private int total;

	/** 当前鲁出来的数据 **/
	private List<JSONObject> items;

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

    public List<JSONObject> getItems() {
        return items;
    }

    public void setItems(List<JSONObject> items) {
        this.items = items;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
