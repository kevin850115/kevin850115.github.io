package com.alibaba.fa.framework.search.opensearch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;

import com.aliyun.opensearch.DocumentClient;
import com.aliyun.opensearch.OpenSearchClient;
import com.aliyun.opensearch.SearcherClient;
import com.aliyun.opensearch.sdk.dependencies.com.google.common.collect.Lists;
import com.aliyun.opensearch.sdk.dependencies.com.google.common.collect.Maps;
import com.aliyun.opensearch.sdk.generated.OpenSearch;
import com.aliyun.opensearch.sdk.generated.commons.OpenSearchResult;
import com.aliyun.opensearch.sdk.generated.search.Config;
import com.aliyun.opensearch.sdk.generated.search.Distinct;
import com.aliyun.opensearch.sdk.generated.search.Order;
import com.aliyun.opensearch.sdk.generated.search.SearchFormat;
import com.aliyun.opensearch.sdk.generated.search.SearchParams;
import com.aliyun.opensearch.sdk.generated.search.Sort;
import com.aliyun.opensearch.sdk.generated.search.SortField;
import com.aliyun.opensearch.sdk.generated.search.general.SearchResult;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author zhanglei
 * @date 2017/4/9
 */
public class OpenSearchService {
    private static final Logger LOGGER = LoggerFactory.getLogger(OpenSearchService.class);

    private OpenSearchClient opensearchClient;

    private String accessKey;

    private String secretKey;

    private String host;

    private String index;

    public void init() {
        this.init(accessKey, secretKey, host, null);
    }

    private void init(String accessKey, String secretKey, String host, Map<String, Object> opts) {
        LOGGER.info("opensearch正在初始化 connecting host {} with option {}", host, opts);
        try {
            HashMap<String, String> innerOpts = Maps.newHashMap();
            innerOpts.put("host", host);
            if(opts!=null && opts.size()>0){
                opts.forEach((key, value) -> innerOpts.put(key, ObjectUtils.toString(value)));
            }
            OpenSearch opensearch = new OpenSearch(accessKey,secretKey,host);
            opensearch.setOptions(innerOpts);
            opensearchClient = new OpenSearchClient(opensearch);
            LOGGER.info("opensearch初始化成功 host {} with option {}", host, innerOpts);
        } catch (Exception e) {
            LOGGER.error("opensearch初始化失败 fail to init opensearch", e);
            throw new RuntimeException("fail to init opensearch ", e);
        }
    }

    public boolean push(List<OpenSearchDO> save) {
        Map<String, List<OpenSearchDO>> indexDoMap = Maps.newHashMap();
        Map<String, String> indexTableMap = Maps.newHashMap();

        //为空，无需推送
        if (CollectionUtils.isEmpty(save)) {
            return true;
        }

        //按照index拆分不同表，避免同一个集合包含多个表导致部分插入问题
        for (OpenSearchDO openSearchDO : save) {
            String tableName = openSearchDO.getTableName();
            String tableIndex = openSearchDO.getIndex();

            //历史逻辑兼容，默认外部配置index
            if (StringUtils.isBlank(tableIndex)) {
                tableIndex = index;
            }

            List<OpenSearchDO> list = indexDoMap.get(tableIndex);
            if (CollectionUtils.isEmpty(list)) {
                list = Lists.newArrayList(openSearchDO);
                indexDoMap.put(tableIndex, list);
            } else {
                list.add(openSearchDO);
            }

            if (!indexTableMap.containsKey(tableIndex)) {
                indexTableMap.put(tableIndex, tableName);
            }
        }

        for (String tableIndex : indexDoMap.keySet()) {
            String saveData = DataConvertor.convertToString(indexDoMap.get(tableIndex));
            if(StringUtils.isBlank(saveData)){
                continue;
            }
            DocumentClient doc = new DocumentClient(opensearchClient);
            try {
                OpenSearchResult result = doc.push(saveData, tableIndex,indexTableMap.get(tableIndex));
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("save data: " + JSON.toJSONString(save) + ", save result: " + result);
                }
                if(!StringUtils.contains(result.getResult(),"true")){
                    throw new Exception("push fail:" + result.getResult());
                }
            } catch (Exception e) {
                LOGGER.error("push error", e);
                throw new RuntimeException(e);
            }
        }
        return true;
    }

    public SearchData search(SearchQuery query) {
        SearcherClient opensearchSearch = new SearcherClient(opensearchClient);
        Config config = new Config();
        if (StringUtils.isNotBlank(query.getIndex())) {
            config.setAppNames(Lists.newArrayList(query.getIndex()));
        } else {
            config.setAppNames(Lists.newArrayList(index));
        }
        config.setSearchFormat(SearchFormat.JSON);
        config.setStart(query.getStartHit());
        config.setHits(query.getHits());
        //指定返回字段
        if (CollectionUtils.isNotEmpty(query.getFetches())) {
            config.setFetchFields(query.getFetches());
        }

        SearchParams searchParams = new SearchParams(config);
        searchParams.setFilter(query.getFilter());
        searchParams.setQuery(query.getQueryString());
        if(StringUtils.isBlank(searchParams.getQuery())){
            //默认需要传一个'' 否则会返回语法解析错误
            searchParams.setQuery("''");
        }
        if (query.getDistinct() != null) {
            config.setKvpairs("duniqfield:" + query.getDistinct());
            Distinct elem = new Distinct();
            elem.setKey(query.getDistinct());
            elem.setDistCount(1);
            elem.setDistTimes(1);
            elem.setReserved(false);
            searchParams.addToDistincts(elem);
        }
        if (query.getSort() != null) {
            Sort sort = new Sort();
            if(SymbolConstant.SORT_DESC.equals(query.getSort().getSecond())){
                sort.addToSortFields(new SortField(query.getSort().getFirst(), Order.DECREASE));
            }else{
                sort.addToSortFields(new SortField(query.getSort().getFirst(), Order.INCREASE));
            }
            searchParams.setSort(sort);
        }
        try {
            SearchResult searchResult = opensearchSearch.execute(searchParams);
            return DataConvertor.convertToSearchData(searchResult.getResult());
        } catch (Exception e) {
            LOGGER.error("search error", e);
        }
        return null;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
}
