package com.alibaba.fa.framework.search.opensearch;

/**
 *  OpenSearch符号常量
 *
 * @author zhangsan
 */
public class SymbolConstant {

	public static final String JSON_TYPE = "json";

	public static final String BLANK = " ";

    public static final String QUOTATION = "'";

    public static final String COLON = ":";

    public static final String SORT_ASC = "+";

    public static final String SORT_DESC = "-";

    public static final String LT = "<";

    public static final String RT = ">";

    public static final String EQ = "=";

    public static final String NEQ = "!=";

    public static final String AND = " AND ";

    public static final String OR = " OR ";

    public static final String OPEN = " ( ";

    public static final String CLOSE = " ) ";

    public static final String BUY_ORDER_INDEX = "iatkfb";


}
