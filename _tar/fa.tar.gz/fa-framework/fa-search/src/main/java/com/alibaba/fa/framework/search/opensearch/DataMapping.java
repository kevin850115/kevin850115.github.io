package com.alibaba.fa.framework.search.opensearch;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *  数据映射
 *
 * @author zhangsan
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DataMapping {

	public String column();

	public String desc() default "";

}
