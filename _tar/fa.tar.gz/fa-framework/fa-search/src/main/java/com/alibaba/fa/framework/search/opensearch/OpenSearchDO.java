package com.alibaba.fa.framework.search.opensearch;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 *
 * @author zhanglei
 * @date 2017/4/9
 */
public class OpenSearchDO implements Serializable {
    private static final long serialVersionUID = 1296251893900342890L;

    public static final String ADD 	  = "add";
    public static final String UPDATE = "update";
    public static final String DELETE = "delete";

    /** 应用名称 **/
    private String index;

    /** 表名 **/
    private String tableName;

    /** 动作（add, update, remove） **/
    private String command;

    /** 数据字段 **/
    private List<Map<String, Object>> fields;

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public List<Map<String, Object>> getFields() {
        return fields;
    }

    public void setFields(List<Map<String, Object>> fields) {
        this.fields = fields;
    }
}
