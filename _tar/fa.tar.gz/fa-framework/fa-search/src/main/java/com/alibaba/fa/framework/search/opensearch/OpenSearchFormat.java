package com.alibaba.fa.framework.search.opensearch;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author wb-zgl234479
 * @create 2018/04/17 20:35
 **/

@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OpenSearchFormat {
    /**
     * 字段名称
     * @return
     */
    String columnKey() default "";

    /**
     * 查询类型
     * @return
     */
    OpenSearchTypeEnum searchType() default OpenSearchTypeEnum.QUERY;

    /**
     * 条件运算符号
     * @return
     */
    String condition() default " = ";

    /**
     * 操作运算符
     * @return
     */
    String operator() default " AND ";
}
