package com.alibaba.fa.framework.search.opensearch;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alibaba.fa.framework.util.ReflectionWrapper;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

import com.aliyun.opensearch.sdk.dependencies.com.google.common.collect.Lists;
import com.aliyun.opensearch.sdk.dependencies.com.google.common.collect.Maps;
import org.apache.commons.collections.CollectionUtils;

/**
 *  数据转换辅助类
 *
 * @author zhangsan
 */
public class DataConvertor {

	private static final ReflectionWrapper reflectionWrapper = new ReflectionWrapper();

	public static String convertToString(List<OpenSearchDO> saves) {
		JSONArray jsonArray = new JSONArray();
		JSONObject json;
		for(OpenSearchDO openSearchDO : saves){
			if(CollectionUtils.isEmpty(openSearchDO.getFields())){
				continue;
			}
			for(Map<String, Object> fieldMap : openSearchDO.getFields()){
				json = new JSONObject();
				json.put("cmd", openSearchDO.getCommand());
				json.put("fields", fieldMap);
				jsonArray.add(json);
			}
		}
		try {
			return new String(JSON.toJSONBytes(jsonArray, SerializerFeature.WriteMapNullValue), "UTF-8");
		} catch (Exception e) {
		}
		return null;
		//return jsonArray.toJSONString();
	}

	public static SearchData convertToSearchData(String searchResult) {
		SearchData searchData = new SearchData();
		JSONObject jsonObject = JSON.parseObject(searchResult);
		if ("OK".equalsIgnoreCase(jsonObject.getString("status"))) {
			JSONObject resultJson = jsonObject.getJSONObject("result");
			searchData.setHit(resultJson.getInteger("num"));
			searchData.setTotal(resultJson.getInteger("total"));

            List<JSONObject> items = new ArrayList<>();
            JSONArray jsonItems = resultJson.getJSONArray("items");
            if (null != jsonItems && jsonItems.size() > 0) {
                for (int i = 0; i < jsonItems.size(); i++) {
                    items.add(jsonItems.getJSONObject(i));
                }
            }
            searchData.setItems(items);
		}
		return searchData;
	}

	//public static List<Map<String, String>> jsonArrayToList(JSONArray jsonArray) {
	//	List<Map<String, String>> items = Lists.newArrayList();
	//	for (int i = 0; i < jsonArray.size(); i++) {
	//		Map<String, String> item = Maps.newHashMap();
	//		for (Map.Entry<String, Object> entry : jsonArray.getJSONObject(i).entrySet()) {
	//			item.put(entry.getKey(), (String) entry.getValue());
	//		}
	//		items.add(item);
	//	}
	//	return items;
	//}

	/**
	 * 将opensearch文档结构转换成opensearch的json结构
	 * @param docs
	 * @return
	 */
	public static List<Map<String, Object>> convertOpenSearchDO(List<?> docs) {
		List<Map<String, Object>> items = Lists.newArrayList();
		for (Object dto : docs) {
			items.add(convertToSaveOrderDTO(dto));
		}
		return items;
	}

	private static Map<String, Object> convertToSaveOrderDTO(Object dto) {
		Map<String, Object> itemMappings = Maps.newHashMap();
		Class<?> clazz = dto.getClass();
		Map<String, Field> fieldMappings = reflectionWrapper.getFields(clazz);
		for (Field field : fieldMappings.values()) {
			DataMapping dataMapping = field.getAnnotation(DataMapping.class);
			if(dataMapping!=null) {
				itemMappings.put(dataMapping.column(), reflectionWrapper.invokeField(field, dto));
			}
		}
		return itemMappings;
	}
}
