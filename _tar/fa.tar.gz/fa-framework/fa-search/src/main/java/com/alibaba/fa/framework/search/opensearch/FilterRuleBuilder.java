package com.alibaba.fa.framework.search.opensearch;

import java.util.List;

import static com.alibaba.fa.framework.search.opensearch.SymbolConstant.*;

/**
 * zhangsan
 */
public class FilterRuleBuilder {

	public static String buildF(String columnKey, Object value, String condition) {

		return buildF(columnKey, value, condition, AND);
	}

	public static String buildF(String columnKey, Object value, String condition, String operator) {

		StringBuilder filter = new StringBuilder();

		filter.append(columnKey).append(condition).append(value).append(operator);

		return filter.toString();
	}

	public static String buildFs(String columnKey, List<?> value, String condition, String operator) {

		StringBuilder filter = new StringBuilder();

		filter.append(OPEN);
		for (Object object : value) {
			filter.append(buildF(columnKey, object, condition, OR));
		}
		int index = filter.lastIndexOf(OR);
		if (index != -1) {
			filter.delete(index, filter.length());
		}
		filter.append(CLOSE).append(operator);

		return filter.toString();
	}
}
