package com.alibaba.fa.framework.search.opensearch;


import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * 	K V工具
 *
 * @author 曰仁（xiujiao.zxj）
 *
 * @since 2016-12-15
 */
public final class Pair<K, V> {

    private K first;

    private V second;

    public Pair() {
    }

    public Pair(K first, V second){
        this.first = first;
        this.second = second;
    }

	public K getFirst() {
		return first;
	}

	public void setFirst(K first) {
		this.first = first;
	}

	public V getSecond() {
		return second;
	}

	public void setSecond(V second) {
		this.second = second;
	}

	/** JDK1.7可恶的泛型
	 * @param <K>
	 * @param <V>
	 * @return K, V
	 */
	public static <K, V> Pair<K, V> newPair() {
		return new Pair<K, V>();
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
