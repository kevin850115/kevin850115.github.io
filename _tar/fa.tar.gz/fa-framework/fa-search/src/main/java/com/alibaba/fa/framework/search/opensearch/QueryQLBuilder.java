package com.alibaba.fa.framework.search.opensearch;

import static com.alibaba.fa.framework.search.opensearch.SymbolConstant.*;

/**
 * zhangsan
 */

public class QueryQLBuilder {

	public static String buildQ(String columnKey, String value) {

		return buildQ(columnKey, value, AND);
	}

	public static String buildQ(String columnKey, String value, String operator) {

		StringBuilder filter = new StringBuilder();

		filter.append(columnKey).append(COLON).append(QUOTATION).append(value).append(QUOTATION).append(operator);

		return filter.toString();
	}
}
