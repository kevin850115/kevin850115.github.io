package com.alibaba.fa.framework.search.opensearch;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *  查询条件
 *
 * @author 曰仁（xiujiao.zxj）
 * @since 2016-12-14
 */
public class SearchQuery {

	/** 应用名称 **/
	private String index;

	/** 返回结果的偏移量 **/
	private Integer startHit = 0;

	/** 当前返回结果集的文档个数 **/
	private Integer hits = 20;

	/** 筛选条件 **/
	private String filter;

	/** 搜索条件 **/
	private String queryString;

	/** 排序条件 **/
	private Pair<String, String> sort;

	/**
	 * 结果字段
	 */
	private List<String> fetches;

	private String distinct;

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public Integer getStartHit() {
		return startHit;
	}

	public void setStartHit(Integer startHit) {
		this.startHit = startHit;
	}

	public Integer getHits() {
		return hits;
	}

	public void setHits(Integer hits) {
		this.hits = hits;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getQueryString() {
		return queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public Pair<String, String> getSort() {
		return sort;
	}

	public void setSort(Pair<String, String> sort) {
		this.sort = sort;
	}

	public String getDistinct() {
		return distinct;
	}

	public void setDistinct(String distinct) {
		this.distinct = distinct;
	}

	public List<String> getFetches() {
		return fetches;
	}

	public void setFetches(List<String> fetches) {
		this.fetches = fetches;
	}

    public void build(Object request) throws Throwable {
        Field[] fields = request.getClass().getDeclaredFields();
        // 过滤参数
        StringBuilder filterString = new StringBuilder();
        // 索引参数
        StringBuilder queryString = new StringBuilder();
        for(Field field : fields) {
            if(!field.isAnnotationPresent(OpenSearchFormat.class)) {
                continue;
            }
            OpenSearchFormat openFormat = field.getAnnotation(OpenSearchFormat.class);
            field.setAccessible(true);
            Object value = field.get(request);
            if(value == null) {
                continue;
            }
            if(StringUtils.isBlank(value.toString())) {
                continue;
            }
            if(field.getType().equals(Date.class)) {
                value = ((Date)value).getTime();
            }
            if(OpenSearchTypeEnum.FILTER == openFormat.searchType()) {
                // Filter
                if(field.getType().equals(List.class)) {
                    List lst = (List)value;
                    if (!CollectionUtils.isEmpty(lst)) {
                        filterString.append(FilterRuleBuilder.buildFs(openFormat.columnKey(), lst, openFormat.condition(), openFormat.operator()));
                    }
                }else {
                    if(field.getType().equals(String.class)) {
                        value = String.format("\"%s\"", StringUtils.trim((String)value));
                    }
                    filterString.append(FilterRuleBuilder.buildF(openFormat.columnKey(), value, openFormat.condition()));
                }
            }else if(OpenSearchTypeEnum.QUERY == openFormat.searchType() || OpenSearchTypeEnum.PART_WORD.equals(openFormat.searchType())){
                // 索引
                String query = buildQuery(field, value, openFormat);
                queryString.append(query);
            }
        }
        if (filterString.length() != 0) {
            filterString.delete(filterString.lastIndexOf(SymbolConstant.AND), filterString.length());
        }
        if (queryString.length() != 0) {
            queryString.delete(queryString.lastIndexOf(SymbolConstant.AND), queryString.length());
        }
        //设置查询条件
        this.setFilter(filterString.toString());
        this.setQueryString(queryString.toString());
    }

    private String buildQuery(Field field, Object value, OpenSearchFormat openFormat) throws Throwable {
        StringBuilder queryString = new StringBuilder();

        if (OpenSearchTypeEnum.PART_WORD.equals(openFormat.searchType())) {
            // 分词索引自定义对象解析
            // 子类型对应属性
            Field[] declaredFields = field.getType().getDeclaredFields();
            if (null != declaredFields && declaredFields.length != 0) {
                Map<String, Object> map = new HashMap<>();
                for (Field fieldIn : declaredFields) {
                    if(!fieldIn.isAnnotationPresent(OpenSearchFormat.class)) {
                        continue;
                    }
                    fieldIn.setAccessible(true);
                    OpenSearchFormat declaredAnnotation = fieldIn.getDeclaredAnnotation(OpenSearchFormat.class);
                    map.put(declaredAnnotation.columnKey(), fieldIn.get(value));
                }
                queryString.append(buildQueryByMap(openFormat, map));
            }

        } else if(field.getType().equals(Map.class)) {
            // 分词索引的Map
            Map map = (Map)value;
            queryString.append(buildQueryByMap(openFormat, map));

        } else if (field.getType().equals(List.class)) {
            List lst = (List)value;
            if (!CollectionUtils.isEmpty(lst)) {
                queryString.append(buildQS(openFormat.columnKey(), lst, openFormat.operator()));
            }
        } else {
            if(StringUtils.isNotBlank(value.toString())) {
                queryString.append(QueryQLBuilder.buildQ(openFormat.columnKey(), value.toString(), openFormat.operator()));
            }
        }
        return queryString.toString();
    }

    /**
     * 通过map构造分词查询
     *
     * searchType 不使用
     * @param parentOpenFormat
     * @param map
     * @return
     */
    private String buildQueryByMap(OpenSearchFormat parentOpenFormat, Map map) {
        if (MapUtils.isEmpty(map)) {
            return "";
        }
        StringBuilder query = new StringBuilder();
	    for(Object key : map.keySet()) {
            if(key == null || map.get(key) == null) {
                continue;
            }
            if(StringUtils.isBlank(map.get(key).toString())) {
                continue;
            }
            StringBuilder partWordQuery = new StringBuilder();
            partWordQuery.append("\"").append(key.toString()).append("\":");
            if (map.get(key) instanceof String) {
                partWordQuery.append("\"").append(map.get(key)).append("\"");
            } else {
                partWordQuery.append(map.get(key));
            }
            query.append(QueryQLBuilder.buildQ(parentOpenFormat.columnKey(), partWordQuery.toString(), parentOpenFormat.operator()));
        }

	    return query.toString();
    }

    private String buildQS(String columnKey, List<?> value, String operator) {
        StringBuilder query = new StringBuilder();
        query.append(" ( ");
        Iterator var5 = value.iterator();

        while(var5.hasNext()) {
            Object object = var5.next();
            query.append(QueryQLBuilder.buildQ(columnKey, StringUtils.trim(object.toString()), " OR "));
        }

        int index = query.lastIndexOf(" OR ");
        if (index != -1) {
            query.delete(index, query.length());
        }

        query.append(" ) ").append(operator);
        return query.toString();
    }

    private String convert(String extra) {
        if(StringUtils.isEmpty(extra)) {
            return null;
        }
        extra = extra.replace("{", "");
        extra = extra.replace("}", "");
        extra = extra.replace(",", "\t");
        return extra;
    }
}
