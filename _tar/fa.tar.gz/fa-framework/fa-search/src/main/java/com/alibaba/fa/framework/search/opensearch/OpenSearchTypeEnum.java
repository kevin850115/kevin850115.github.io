package com.alibaba.fa.framework.search.opensearch;

import com.alibaba.fa.framework.util.IKeyDescEnum;

/**
 * @author wb-zgl234479
 * @create 2018/04/17 20:33
 **/

public enum OpenSearchTypeEnum implements IKeyDescEnum {
    QUERY(1, "QUERY", "QUERY"),
    FILTER(2, "FILTER", "FILTER"),
    PART_WORD(3, "PART_WORD", "PART_WORD");


    OpenSearchTypeEnum(Integer key, String code, String desc) {
        this.key = key;
        this.code = code;
        this.desc = desc;
    }

    private Integer key;
    private String code;
    private String desc;

    @Override
    public Integer getKey() {
        return key;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
