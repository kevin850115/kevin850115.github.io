package com.alibaba.fa.framework.distributed;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/4
 */
public interface DistributedProcessor<P extends Serializable,T extends Serializable> {
    /**
     * 处理配置信息
     * @return 处理配置信息
     */
    DistributedConfig getDistributedConfig();
    /**
     * 构建数据
     * @param param 构建参数
     * @return 数据集合
     */
    List<T> buildTaskList(P param);

    /**
     * 开始消费
     */
    void start();
    /**
     * 单条数据处理
     * @param task 单条数据
     */
    void process(T task);

    /**
     * 本机处理完毕
     */
    void localOver();
    /**
     * 所有任务结束
     */
    void over();
}
