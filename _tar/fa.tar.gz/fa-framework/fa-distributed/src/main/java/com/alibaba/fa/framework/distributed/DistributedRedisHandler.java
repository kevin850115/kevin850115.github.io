package com.alibaba.fa.framework.distributed;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.BoundListOperations;
import org.springframework.data.redis.core.BoundValueOperations;
import org.springframework.data.redis.core.RedisTemplate;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/11
 */
public class DistributedRedisHandler implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(DistributedManager.class);

    private static final long serialVersionUID = 5203556270100125250L;

    /**
     * 处理器
     */
    private transient DistributedProcessor processor;
    /**
     * 缓存数据源
     */
    private transient RedisTemplate<Object,Object> redisTemplate;
    /**
     * 消费数据队列
     */
    private transient LinkedBlockingQueue<DistributedDO> consumerDataList;
    /**
     * 消费线程池
     */
    private transient ThreadPoolExecutor consumerExecutor;

    /**
     * 判断本机票有没有开始干活
     */
    private AtomicBoolean start;
    /**
     * 是否关闭
     */
    private AtomicBoolean close;
    /**
     * 正在处理的任务
     */
    private AtomicInteger count;
    /**
     * 处理器名
     */
    private String processorName;
    /**
     * 前置处理器名
     */
    private String conditionName;
    /**
     * 服务器名
     */
    private String hostName;
    /**
     * 配置信息
     */
    private DistributedConfig config;

    public DistributedConfig getConfig() {
        return config;
    }

    public void setConfig(DistributedConfig config) {
        this.config = config;
    }

    public int getLockDataSize() {
        return consumerDataList.size();
    }

    public AtomicInteger getCount() {
        return count;
    }

    public void setCount(AtomicInteger count) {
        this.count = count;
    }

    public Long getRedisDataSize(){
        return dataOperations().size();
    }

    public void setConsumerDataList(LinkedBlockingQueue<DistributedDO> consumerDataList) {
        this.consumerDataList = consumerDataList;
    }

    public String getConditionName() {
        return conditionName;
    }

    public void setConditionName(String conditionName) {
        this.conditionName = conditionName;
    }

    public AtomicBoolean getClose() {
        return close;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public void setClose(AtomicBoolean close) {
        this.close = close;
    }

    public String getProcessorName() {
        return processorName;
    }

    public void setProcessor(DistributedProcessor processor) {
        this.processor = processor;
    }

    public DistributedProcessor getProcessor() {
        return processor;
    }

    public void setProcessorName(String processorName) {
        this.processorName = processorName;
    }

    public AtomicBoolean getStart() {
        return start;
    }

    public void setStart(AtomicBoolean start) {
        this.start = start;
    }

    /**
     * 锁
     */
    private String getLockCacheName(String processorName){
        return processorName +"@LockCache";
    }

    /**
     * 数据
     */
    private String getDataCacheName(String processorName){
        return processorName +"@DataCache";
    }

    /**
     * 注册机器
     */
    private String getParamCacheName(String processorName){
        return processorName +"@ParamCache";
    }

    public void setRedisTemplate(
        RedisTemplate<Object, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    private void put(DistributedDO aDo){
        try {
            consumerDataList.put(aDo);
        } catch (InterruptedException e) {
            logger.error(processorName +"消费数据如队列失败",e);
        }

    }

    /**
     * redis数据放入本地缓冲队列
     * @param o 处理数据
     */
    public void put(Object o){
        put(new DistributedDO(o));
    }

    /**
     * 消费一条数据
     * @return 是否继续 true 表示继续消费
     */
    private boolean eatAndContinue() throws InterruptedException {
        int timeout = config.getActiveTime();
        DistributedDO aDo = timeout==0 ? consumerDataList.take() : consumerDataList.poll(timeout, TimeUnit.MINUTES);
        if(aDo!=null){
            count.getAndIncrement();
            try {
                processor.process((Serializable)aDo.getO());
            }catch (Throwable e){
                //重试
                logger.error(processorName + "消费线程错误",e);
                aDo.setRepeat(aDo.getRepeat()+1);
                if(aDo.getRepeat()<5){
                    put(aDo);
                }
            }
            count.getAndDecrement();
            return true;
        }
        return hasData();
    }

    /**
     * 判断是否有数据需要处理
     */
    public boolean hasData() {
        return dataOperations().size()>0;
    }
    /**
     * 开始处理，并且处理完毕
     * @return true 完毕
     */
    public boolean startedAndOver(){
        return start.get() && !hasData() && consumerDataList.size()==0 && count.get()==0;
    }

    /**
     * 放入数据
     */
    public void addData(List dataList){
        //插入前是否清理掉已有数据
        if(config.isClear()){
            deleteDataCache();
        }
        //从头部插入
        dataOperations().leftPushAll(dataList.toArray());
    }

    /**
     * 取出数据
     */
    public List<Object> redisData(){
        BoundListOperations<Object, Object> operations = dataOperations();
        int size = operations.size().intValue();
        if(size<=0){
            return null;
        }
        int length = config.getDataLength();
        if(length>=size){
            length = size;
        }
        List<Object> list = new ArrayList<>(length);
        for(int i=0;i<length;i++){
            //从尾部弹出数据
            Object o = operations.rightPop();
            if(o!=null){
                list.add(o);
            }
        }
        return list;
    }

    /**
     * 上报开始服务
     */
    public void reportHost(){
        if(start.get()){
            return;
        }
        BoundValueOperations<Object, Object> paramOperations = paramOperations();
        DistributedCallBack callBack = (DistributedCallBack)paramOperations.get();
        if(callBack == null){
            callBack = new DistributedCallBack();
            callBack.setHosts(new ArrayList<>());
        }
        if(!callBack.getHosts().contains(hostName)){
            callBack.getHosts().add(hostName);
            paramOperations.set(callBack);
        }
        //如果之前我没有数据
        if(!start.get()){
            start.set(Boolean.TRUE);
        }
    }

    /**
     * 判断是否执行  全部处理完成接口
     * @return true执行
     */
    private boolean hostOver(){
        BoundValueOperations<Object, Object> paramOperations = paramOperations();
        DistributedCallBack callBack = (DistributedCallBack)paramOperations.get();
        if(callBack == null){
            return false;
        }
        if(callBack.getHosts()!=null && callBack.getHosts().size()>0){
            callBack.getHosts().removeIf(h -> hostName.equals(h));
        }
        paramOperations.set(callBack);
        boolean res = callBack.getHosts()==null || callBack.getHosts().size() ==0;
        if(res){
            deleteParamCache();
        }
        return res;
    }

    /**
     * 完成消费
     */
    public void over(){
        try {
            processor.localOver();
            if(hostOver()){
                //如果所有服务器都处理完毕了，当前服务器调用 结束方法
                processor.over();
                deleteDataCache();
            }
        }catch (Throwable e){
            logger.error(processorName+"结束任务错误",e);
        }finally {
            start.set(Boolean.FALSE);
        }
    }

    /**
     * 加锁
     * @return 成功
     */
    public boolean lock(){
        BoundValueOperations<Object, Object> operations = lockOperations();
        DistributeLock lock = (DistributeLock)operations.get();
        Date now = new Date();
        if(lock!=null){
            if(lock.getLockTime()!=null){
                long lockTime = 1000*60*10;
                long t = (now.getTime() -lock.getLockTime().getTime());
                if(t > lockTime){
                    unLock();
                }
            }
            if(lock.getLockTime() == null){
                unLock();
            }
            return false;
        }
        lock = new DistributeLock();
        lock.setLocked(2);
        lock.setLocker(hostName);
        lock.setLockTime(now);
        return operations.setIfAbsent(lock);
    }

    /**
     * 判断前置处理任务是否已经完成
     * @return true 前置任务完成
     */
    public boolean conditionOver(){
        return (conditionName == null || "".equals(conditionName)) ||
            (!redisTemplate.hasKey(getParamCacheName(conditionName)) && !redisTemplate.hasKey(getDataCacheName(conditionName)));
    }

    private BoundListOperations<Object, Object> dataOperations(){
        BoundListOperations<Object, Object> operations = redisTemplate.boundListOps(getDataCacheName(processorName));
        operations.expire(24,TimeUnit.HOURS);
        return operations;
    }

    private BoundValueOperations<Object, Object> paramOperations(){
        BoundValueOperations<Object, Object> operations = redisTemplate.boundValueOps(getParamCacheName(processorName));
        operations.expire(24,TimeUnit.HOURS);
        return operations;
    }

    private BoundValueOperations<Object, Object> lockOperations(){
        BoundValueOperations<Object, Object> operations = redisTemplate.boundValueOps(getLockCacheName(processorName));
        operations.expire(24,TimeUnit.HOURS);
        return operations;
    }

    public void unLock(){
        redisTemplate.delete(getLockCacheName(processorName));
    }

    private void deleteDataCache(){
        redisTemplate.delete(getDataCacheName(processorName));
    }

    private void deleteParamCache(){
        redisTemplate.delete(getParamCacheName(processorName));
    }

    public void deleteAllCache(){
        deleteParamCache();
        deleteDataCache();
        unLock();
    }

    public void stopConsumer(){
        if(consumerExecutor!=null && consumerExecutor.getActiveCount() == 0 && !start.get()){
            logger.info(processorName+"所有消费线程处理完毕，关闭线程池。");
            consumerExecutor.shutdown();
            consumerExecutor = null;
        }
    }

    public void startConsumer(int length){
        int s = config.getThreadLength();
        if(consumerExecutor == null){
            consumerExecutor = new ThreadPoolExecutor(0,s,60L, TimeUnit.SECONDS,
                new SynchronousQueue<>(),
                new DistributedThreadFactory(processorName+"-consumerExecutor"),
                new CallerRunsPolicy());
            logger.info(processorName+"创建线程池，线程数量"+s);
        }
        //减去存活的线程
        s = s-consumerExecutor.getActiveCount();
        //判断任务大小，如果小于默认线程总数，则使用获取到的任务大小
        s = s>length ? length : s;
        if(s>0 && consumerExecutor.getActiveCount()<config.getThreadLength()){
            //分配任务
            for(int i=0;i<s;i++){
                consumerExecutor.submit(new Runnable() {
                    @Override
                    public void run() {
                        while (true){
                            try {
                                if(!eatAndContinue()){
                                    break;
                                }
                            } catch (InterruptedException e) {
                                //停止线程时，会抛出此异常
                                logger.error(processorName+"消费线程因错误终止",e);
                                return;
                            }
                        }
                    }
                });
            }
            logger.info(processorName+"提交消费线程"+s+"个");
        }
    }
}
