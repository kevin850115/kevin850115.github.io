package com.alibaba.fa.framework.distributed;

import java.io.Serializable;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/28
 */
public class DistributedConfig implements Serializable {
    private static final long serialVersionUID = 2312956540613020270L;
    /**
     * 开放处理任务的线程数量
     */
    private int threadLength;
    /**
     * 线程存活时间（分钟） 0 表示不销毁，1表示1分钟
     */
    private int activeTime;
    /**
     * 从redis中一次性提取待处理的数据条数
     */
    private int dataLength;
    /**
     * 当构建数据时，是否删除未处理完的任务
     */
    private boolean clear;
    /**
     * 所有任务结束条件
     */
    private transient Class<? extends DistributedProcessor> conditionOver;
    /**
     * 数据缓冲长度
     */
    private int buffer;

    public int getBuffer() {
        return buffer;
    }

    public void setBuffer(int buffer) {
        this.buffer = buffer;
    }

    public int getThreadLength() {
        return threadLength;
    }

    public void setThreadLength(int threadLength) {
        this.threadLength = threadLength;
    }

    public int getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(int activeTime) {
        this.activeTime = activeTime;
    }

    public int getDataLength() {
        return dataLength;
    }

    public void setDataLength(int dataLength) {
        this.dataLength = dataLength;
    }

    public boolean isClear() {
        return clear;
    }

    public void setClear(boolean clear) {
        this.clear = clear;
    }

    public Class<? extends DistributedProcessor> getConditionOver() {
        return conditionOver;
    }

    public void setConditionOver(
        Class<? extends DistributedProcessor> conditionOver) {
        this.conditionOver = conditionOver;
    }
}
