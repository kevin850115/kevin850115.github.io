package com.alibaba.fa.framework.distributed;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/14
 */
public class DistributedCallBack implements Serializable {
    private static final long serialVersionUID = 1096251893900342890L;
    private List<String> hosts;

    public List<String> getHosts() {
        return hosts;
    }

    public void setHosts(List<String> hosts) {
        this.hosts = hosts;
    }


}
