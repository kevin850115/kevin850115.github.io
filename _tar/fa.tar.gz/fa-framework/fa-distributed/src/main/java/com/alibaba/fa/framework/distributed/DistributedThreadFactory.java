package com.alibaba.fa.framework.distributed;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/25
 */
public class DistributedThreadFactory implements ThreadFactory {
    private AtomicInteger integer = new AtomicInteger(1);
    private String name;
    DistributedThreadFactory(String name) {
        this.name = name;
    }
    @Override
    public Thread newThread(Runnable r) {
        Thread thread = new Thread(r,name +"-" + integer.getAndIncrement());
        thread.setDaemon(true);
        return thread;
    }
}
