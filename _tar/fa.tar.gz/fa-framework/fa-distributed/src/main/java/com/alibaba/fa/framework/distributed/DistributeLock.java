package com.alibaba.fa.framework.distributed;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/5
 */
public class DistributeLock implements Serializable{
    private static final long serialVersionUID = 3216873991918547074L;
    private Integer locked;
    private Date lockTime;
    private String locker;

    public Date getLockTime() {
        return lockTime;
    }

    public void setLockTime(Date lockTime) {
        this.lockTime = lockTime;
    }

    public Integer getLocked() {
        return locked;
    }

    public String getLocker() {
        return locker;
    }

    public void setLocker(String locker) {
        this.locker = locker;
    }

    public void setLocked(Integer locked) {
        this.locked = locked;
    }
}
