package com.alibaba.fa.framework.distributed;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/27
 */
public class DistributedDO {
    private Object o;
    private int repeat;

    public DistributedDO(Object o) {
        this.o = o;
        repeat = 0;
    }

    public Object getO() {
        return o;
    }

    public void setO(Object o) {
        this.o = o;
    }

    public int getRepeat() {
        return repeat;
    }

    public void setRepeat(int repeat) {
        this.repeat = repeat;
    }
}
