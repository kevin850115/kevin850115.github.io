package com.alibaba.fa.framework.distributed;

import java.net.InetAddress;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.data.redis.core.RedisTemplate;

/**
 *
 * @author wb-zxy279015
 * @date 2018/6/4
 */
@Aspect
public class DistributedManager{

    private static final Logger logger = LoggerFactory.getLogger(DistributedManager.class);
    /**
     * 上下文
     */
    private ApplicationContext applicationContext;
    /**
     * 缓存
     */
    private RedisTemplate<Object, Object> redisTemplate;
    /**
     * 处理器集合
     */
    private Map<String,DistributedRedisHandler> processorDOMap = new ConcurrentHashMap<>();
    /**
     * 生产者扫描任务队列
     */
    private LinkedBlockingQueue<DistributedRedisHandler> processors = new LinkedBlockingQueue<>();
    /**
     * 主要扫描线程
     */
    private ScheduledThreadPoolExecutor
        scheduledThreadPool = new ScheduledThreadPoolExecutor(1,new DistributedThreadFactory("DistributedManager-scheduled"));
    /**
     * 数据扫描线程池
     */
    private ThreadPoolExecutor producerExecutor;


    public Map<String,DistributedRedisHandler> getProcessors(){
        return processorDOMap;
    }

    public DistributedRedisHandler clearProcessorCache(String name){
        if(!isNotBlank(name)){
            return null;
        }
        DistributedRedisHandler handler = processorDOMap.get(name);
        if(handler!=null){
            while (true){
                if(!handler.lock()){
                    continue;
                }
                handler.deleteAllCache();
                handler.unLock();
                break;
            }
        }
        return handler;
    }

    public DistributedRedisHandler updateThreadLength(String processorName ,Integer l){
        if(!isNotBlank(processorName) || l == null){
            return null;
        }
        DistributedRedisHandler handler = processorDOMap.get(processorName);
        if(handler!=null){
            handler.getConfig().setThreadLength(l);
            return handler;
        }
        return null;
    }

    public DistributedRedisHandler closeProcessor(String name){
        DistributedRedisHandler res = null;
        try {
            for(DistributedRedisHandler handler : processorDOMap.values()){
                if(isNotBlank(name)&& !name.equals(handler.getProcessorName())){
                    continue;
                }
                if(handler.getProcessorName().equals(name)){
                    res = handler;
                }
                if(handler.getClose().get()){
                    continue;
                }
                handler.getClose().set(Boolean.TRUE);
                while (true){
                    DistributedRedisHandler take = processors.take();
                    if(!isNotBlank(name) || take.getProcessorName().equals(name)){
                        break;
                    }
                    processors.put(take);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return res;
    }

    public DistributedRedisHandler startProcessor(String name){
        DistributedRedisHandler res = null;
        for(DistributedRedisHandler handler : processorDOMap.values()){
            if(isNotBlank(name)&& !name.equals(handler.getProcessorName())){
                continue;
            }
            if(handler.getProcessorName().equals(name)){
                res = handler;
            }
            if(!handler.getClose().get()){
                continue;
            }
            handler.getClose().set(Boolean.FALSE);
            putInTasks(handler);

        }
        return res;
    }

    /**
     * 初始化方法
     */
    public void start() throws Exception {
        if(applicationContext!=null){
            Map<String, DistributedProcessor> processorMap = applicationContext.getBeansOfType(DistributedProcessor.class);
            if(processorMap == null || processorMap.isEmpty()){
                return;
            }
            String hostName = InetAddress.getLocalHost().getHostName();
            for(Map.Entry<String,DistributedProcessor> entry : processorMap.entrySet()){
                DistributedConfig config =  entry.getValue().getDistributedConfig();
                String msg = validConfig(config);
                if(isNotBlank(msg)){
                    logger.error("分布式任务初始化-"+entry.getKey() +"服务配置信息验证失败:" + msg);
                    continue;
                }
                DistributedRedisHandler handler = new DistributedRedisHandler();
                handler.setConfig(config);
                handler.setProcessorName(entry.getKey());
                handler.setProcessor(entry.getValue());
                handler.setHostName(hostName);
                handler.setStart(new AtomicBoolean(Boolean.FALSE));
                handler.setClose(new AtomicBoolean(Boolean.FALSE));
                handler.setCount(new AtomicInteger(0));
                handler.setRedisTemplate(this.redisTemplate);
                handler.setConsumerDataList(new LinkedBlockingQueue<>(config.getBuffer()));
                handler.setConditionName(getByProcessorName(config.getConditionOver()));
                handler.deleteAllCache();
                processorDOMap.put(handler.getProcessorName(), handler);
                if(!handler.getClose().get()){
                    processors.add(handler);
                }
                logger.info("分布式任务初始化["+entry.getKey() +"]服务");
            }
            startProducer();
        }
    }

    private String validConfig(DistributedConfig config) {
        if(config == null){
            return "未获取到配置信息";
        }
        if(config.getDataLength()<=0){
            return "从redis中一次性提取待处理的数据条数必须大于0";
        }
        if(config.getThreadLength()<=0){
            return "消费线程数量必须大于0";
        }
        if(config.getBuffer()<=0){
            return "缓冲队列长度必须大于0";
        }
        return null;
    }

    public void destroy(){
        this.applicationContext = null;
        this.redisTemplate = null;
        if(producerExecutor!=null){
            producerExecutor.shutdown();
            producerExecutor =null;
        }
        if(processorDOMap!=null){
            processorDOMap.clear();
            processorDOMap = null;
        }
        if(processors!=null){
            processors.clear();
            processors = null;
        }
    }

    /**
     * 拦截 数据构建方法
     *
     */
    @Around("execution(* DistributedProcessor.buildTaskList(..))")
    public Object buildTaskList(ProceedingJoinPoint joinPoint) throws Throwable {
        List data = (List)joinPoint.proceed();
        buildProcessData(data, (DistributedProcessor)joinPoint.getTarget());
        return data;
    }

    private String getByProcessorName(Class<? extends DistributedProcessor> processor){
        if(processor == null){
            return null;
        }
        String[] names = applicationContext.getBeanNamesForType(processor);
        if(names == null || names.length ==0){
            return null;
        }
        return names[0];
    }

    /**
     * 将数据放入 写  队列
     */
    private void buildProcessData(List data,DistributedProcessor processor){
        if(isEmpty(data)){
            return;
        }
        String processorName = getByProcessorName(processor.getClass());
        if(!isNotBlank(processorName)){
            return;
        }
        BuildDataTask buildDataTask = new BuildDataTask(processorDOMap.get(processorName),data);
        buildDataTask.run();
    }

    /**
     * 初始化生产者
     */
    private void startProducer(){
        //初始化生产者线程池
        int size =processorDOMap.size();
        producerExecutor = new ThreadPoolExecutor(
            0,size,
            120L,
            TimeUnit.SECONDS,
            new SynchronousQueue<>(),
            new DistributedThreadFactory("DistributedManager-producerExecutor"),
            new CallerRunsPolicy());
        //启动生产者扫描线程
        scheduledThreadPool.scheduleWithFixedDelay(new Runnable(){
            @Override
            public void run() {
                DistributedRedisHandler handler = null;
                try {
                    handler = processors.take();
                    //我干了活，并且我干完了
                    if(handler.startedAndOver()){
                        producerExecutor.submit(new DistributedTask(true,handler));
                        return;
                    }
                    //有事情干
                    if(handler.hasData()){
                        producerExecutor.submit(new DistributedTask(false,handler));
                        return;
                    }
                    handler.stopConsumer();
                    putInTasks(handler);
                } catch (Exception e) {
                    logger.error("主线程错误",e);
                    putInTasks(handler);
                }
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void setRedisTemplate(
        RedisTemplate<Object, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }


    private class BuildDataTask implements Runnable{
        private DistributedRedisHandler handler;
        private List dataList;
        BuildDataTask(DistributedRedisHandler handler, List dataList) {
            this.handler = handler;
            this.dataList = dataList;
        }

        @Override
        public void run() {
            if(handler == null || handler.getClose().get()){
                return;
            }
            while (true){
                if(!handler.lock()){
                    continue;
                }
                handler.addData(dataList);
                handler.unLock();
                break;
            }
        }
    }

    private class DistributedTask implements Runnable{
        private boolean over;
        private DistributedRedisHandler handler;

        DistributedTask(boolean over, DistributedRedisHandler handler) {
            this.over = over;
            this.handler = handler;
        }

        @Override
        public void run() {
            if(over){
                produceOver(handler);
            }else{
                handler.getProcessor().start();
                produce(handler);
            }
            //还回
            putInTasks(handler);
        }
    }
    /**
     * 结束 回调
     */
    private void produceOver(DistributedRedisHandler handler){
        while (true){
            if(!handler.lock()){
                continue;
            }
            handler.over();
            handler.unLock();
            break;
        }
    }


    /**
     * 取任务
     */
    private void produce(DistributedRedisHandler handler) {
        //取任务
        while (true){
            if(handler.getClose().get()){
                break;
            }
            //我先锁定数据
            if(!handler.lock()){
                continue;
            }
            List<Object> list = handler.redisData();
            if(isEmpty(list)){
                handler.unLock();
                //前置任务是否完毕
                if(handler.conditionOver()){
                    break;
                }
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                continue;
            }
            //报名
            handler.reportHost();
            //交还锁
            handler.unLock();
            //开启线程
            handler.startConsumer(list.size());
            //任务缓冲
            for(Object o : list){
                handler.put(o);
            }
            try {
                Thread.sleep(200L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void putInTasks(DistributedRedisHandler handler){
        if(handler!=null && !processors.contains(handler)){
            try {
                //我取完了数据，回到队列中
                processors.put(handler);
            } catch (InterruptedException e) {
                logger.error("回到队列失败",e);
            }
        }
    }

    private <T> boolean isEmpty(Collection<T> coll){
        return coll == null || coll.size() ==0;
    }

    private boolean isNotBlank(String str){
        return str !=null && !"".equals(str.trim());
    }
}
