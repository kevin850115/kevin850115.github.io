package com.alibaba.fa.framework.rds4db;

import java.util.Map;

import com.alibaba.fastjson.JSON;

import com.taobao.top.messaging.ReceivedMessageDO;
import com.taobao.top.messaging.util.SerializeUtils;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/23
 */
public class Rds2DbProcessor {

    private boolean enabled;

    private Map<String,RdsDataHandle> handleMap;

    public void process(byte[] body) throws Exception{
        if(!enabled){
            throw new Exception("Rds2DbProcessor is not enabled");
        }
        if(handleMap == null || handleMap.size()==0){
            throw new Exception("Rds2DbProcessor handles is empty");
        }
        ReceivedMessageDO messageDO = SerializeUtils.convertBytesToObject(ReceivedMessageDO.class,body);
        IatkfSyncDataObject dataObject = JSON.parseObject(messageDO.getContent(),IatkfSyncDataObject.class);
        RdsDataHandle handle = handleMap.get(dataObject.getTableName());
        if(handle == null){
            throw new Exception("the table named " + dataObject.getTableName() + " has no handle ");
        }
        if(IatkfSyncDataObject.DELETE.equals(dataObject.getCommand())){
            handle.delete(dataObject.getProperties());
        }else{
            handle.save(dataObject.getProperties());
        }
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void setHandleMap(Map<String, RdsDataHandle> handleMap) {
        this.handleMap = handleMap;
    }
}
