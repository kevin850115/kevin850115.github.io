package com.alibaba.fa.framework.rds4db;

import java.lang.reflect.ParameterizedType;
import java.util.Map;
import java.util.Map.Entry;

import com.alibaba.fastjson.JSONObject;

import com.google.common.base.CaseFormat;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/22
 */
public abstract class AbstractHandle<K,T>{

    protected Class<T> clazz;

    @SuppressWarnings("unchecked")
    public AbstractHandle() {
        this.clazz = (Class<T>)((ParameterizedType)this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
    }

    public void save(String json) {
        T t = convertJsonFormat(json);
        if(validate(t)){
            if(idempotent(t)){
                insert(t);
            }else{
                update(t);
            }
        }
    }

    public void delete(String json) {
        T t = convertJsonFormat(json);
        if(validate(t)){
            del(t);
        }
    }

    protected boolean validate(T t) {
        return getPrimaryKey(t)!=null;
    }

    protected T convertJsonFormat(String json){
        Map<String,Object> map = JSONObject.parseObject(json);
        JSONObject jsonObject = new JSONObject();
        for(Entry<String,Object> entry : map.entrySet()){
            jsonObject.put(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, entry.getKey()),entry.getValue());

        }
        return jsonObject.toJavaObject(clazz);
    }

    /**
     * 获取主键
     * @param t
     * @return
     */
    protected abstract K getPrimaryKey(T t);

    /**
     * 幂等方法
     * @param t
     * @return true  需要插入
     */
    protected abstract boolean idempotent(T t);

    protected abstract void update(T t);

    protected abstract void insert(T t);

    protected abstract void del(T t);
}
