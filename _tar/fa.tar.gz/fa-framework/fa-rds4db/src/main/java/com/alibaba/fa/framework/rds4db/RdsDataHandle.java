package com.alibaba.fa.framework.rds4db;

/**
 *
 * @author wb-zxy279015
 * @date 2019/1/22
 */
public interface RdsDataHandle {
    /**
     * 获取表名
     */
    String tableName();

    /**
     * 处理同步数据
     * @param json 数据josn
     */
    void save(String json);

    /**
     * 删除
     */
    void delete(String json);
}
