package com.alibaba.fa.framework.rds4db;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * description
 *
 * @author wb-yc282155
 * @date 2019/1/18
 */
public class IatkfSyncDataObject implements Serializable {
    private static final long serialVersionUID = -7063954946167127214L;

    public static final String ADD 	  = "add";
    public static final String UPDATE = "update";
    public static final String DELETE = "delete";
    /**
     * 业务id，用于日志查询
     */
    @JSONField(name = "business_id")
    private Long businessId;

    /**
     * 表名
     */
    @JSONField(name = "table_name")
    private String tableName;

    /**
     * 操作 add delete update
     */
    @JSONField(name = "command")
    private String command;

    /**
     * 数据字段信息
     */
    @JSONField(name = "properties")
    private String properties;

    /**
     * 业务类型
     */
    @JSONField(name = "biz_type")
    private String bizType;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getProperties() {
        return properties;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
}
