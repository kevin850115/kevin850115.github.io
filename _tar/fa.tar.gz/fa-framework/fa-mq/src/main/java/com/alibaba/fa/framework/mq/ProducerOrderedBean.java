package com.alibaba.fa.framework.mq;

import java.util.Properties;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.exception.ONSClientException;
import com.aliyun.openservices.ons.api.order.OrderProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by zhanglei on 2017/3/25.
 */
public class ProducerOrderedBean implements OrderProducer {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProducerOrderedBean.class);
    private Properties properties;
    private String start;
    private OrderProducer producer;

    @Override
    public void start() {
        if ("0".equals(start)) {
            LOGGER.info("MQ 发布者不启动...");
            return;
        }
        LOGGER.info("MQ 发布者正在启动...");
        if (null == this.properties) {
            throw new ONSClientException("properties not set");
        }

        this.producer = ONSFactory.createOrderProducer(this.properties);
        this.producer.start();
        LOGGER.info("MQ 发布者启动完成...");
    }

    @Override
    public void shutdown() {
        if (this.producer != null) {
            this.producer.shutdown();
        }
    }

    @Override
    public SendResult send(Message message, String shardingKey) {
        return producer.send(message, shardingKey);
    }

    @Override
    public boolean isStarted() {
        return this.producer.isStarted();
    }

    @Override
    public boolean isClosed() {
        return this.producer.isClosed();
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }
}
