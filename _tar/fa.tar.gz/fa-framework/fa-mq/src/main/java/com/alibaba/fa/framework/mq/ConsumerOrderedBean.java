package com.alibaba.fa.framework.mq;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.aliyun.openservices.ons.api.bean.SubscriptionExt;
import com.aliyun.openservices.ons.api.exception.ONSClientException;
import com.aliyun.openservices.ons.api.order.MessageOrderListener;
import com.aliyun.openservices.ons.api.order.OrderConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by zhanglei on 2017/3/25.
 */
public class ConsumerOrderedBean implements OrderConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerOrderedBean.class);
    private Properties properties;
    private Map<Subscription, MessageOrderListener> subscriptionTable;
    private String start;
    private OrderConsumer consumer;

    @Override
    public void start() {
        if ("0".equals(start)) {
            LOGGER.info("MQ 消费者不启动...");
            return;
        }
        LOGGER.info("MQ 消费者正在启动...");
        if (null == this.properties) {
            throw new ONSClientException("properties not set");
        }

        if (null == this.subscriptionTable) {
            throw new ONSClientException("subscriptionTable not set");
        }

        this.consumer = ONSFactory.createOrderedConsumer(this.properties);

        Iterator<Map.Entry<Subscription, MessageOrderListener>> it = this.subscriptionTable.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Subscription, MessageOrderListener> next = it.next();
            if (this.consumer.getClass().getCanonicalName()
                .equals("com.aliyun.openservices.ons.api.impl.notify.ConsumerImpl")
                && (next.getKey() instanceof SubscriptionExt)) {
                SubscriptionExt subscription = (SubscriptionExt)next.getKey();
                for (Method method : this.consumer.getClass().getMethods()) {
                    if ("subscribeNotify".equals(method.getName())) {
                        try {
                            method.invoke(consumer, subscription.getTopic(), subscription.getExpression(),
                                subscription.isPersistence(), next.getValue());
                        } catch (Exception e) {
                            throw new ONSClientException("subscribeNotify invoke exception", e);
                        }
                        break;
                    }
                }

            } else {
                this.subscribe(next.getKey().getTopic(), next.getKey().getExpression(), next.getValue());
            }

        }

        this.consumer.start();
        LOGGER.info("MQ 消费者启动完成");
    }

    @Override
    public void shutdown() {
        if (this.consumer != null) {
            this.consumer.shutdown();
        }
    }

    @Override
    public void subscribe(String topic, String subExpression, MessageOrderListener listener) {
        if (null == this.consumer) {
            throw new ONSClientException("subscribe must be called after consumerBean started");
        }
        this.consumer.subscribe(topic, subExpression, listener);
    }

    @Override
    public boolean isStarted() {
        return this.consumer.isStarted();
    }

    @Override
    public boolean isClosed() {
        return this.consumer.isClosed();
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public Map<Subscription, MessageOrderListener> getSubscriptionTable() {
        return subscriptionTable;
    }

    public void setSubscriptionTable(Map<Subscription, MessageOrderListener> subscriptionTable) {
        this.subscriptionTable = subscriptionTable;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }
}
