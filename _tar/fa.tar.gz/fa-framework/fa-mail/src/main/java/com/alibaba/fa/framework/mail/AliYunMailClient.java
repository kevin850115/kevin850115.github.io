package com.alibaba.fa.framework.mail;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dm.model.v20151123.BatchSendMailRequest;
import com.aliyuncs.dm.model.v20151123.BatchSendMailResponse;
import com.aliyuncs.dm.model.v20151123.SingleSendMailRequest;
import com.aliyuncs.dm.model.v20151123.SingleSendMailResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import lombok.Setter;

/**
 * @author zhanglei
 * @date 2018/01/24
 */
public class AliYunMailClient {
    private IAcsClient client;

    @Setter
    private AliYunMailConfig config;

    public AliYunMailClient() {
    }

    public AliYunMailClient(AliYunMailConfig config) {
        this.config = config;
    }

    public void init() {
        IClientProfile profile = DefaultProfile.getProfile(config.getRegionId(), config.getAccessKey(),
            config.getAccessSecret());
        client = new DefaultAcsClient(profile);
    }

    public SingleSendMailResponse send(SingleSendMailRequest request) throws ClientException {
        SingleSendMailResponse httpResponse = client.getAcsResponse(request);
        return httpResponse;
    }

    public BatchSendMailResponse sendBatch(BatchSendMailRequest request) throws ClientException {
        BatchSendMailResponse httpResponse = client.getAcsResponse(request);
        return httpResponse;
    }
}
