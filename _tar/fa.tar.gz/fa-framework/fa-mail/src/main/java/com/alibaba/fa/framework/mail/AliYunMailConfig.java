package com.alibaba.fa.framework.mail;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author zhanglei
 * @date 2018/1/30
 */
@Setter
@Getter
public class AliYunMailConfig {
    private String regionId;

    private String accessKey;

    private String accessSecret;
}
