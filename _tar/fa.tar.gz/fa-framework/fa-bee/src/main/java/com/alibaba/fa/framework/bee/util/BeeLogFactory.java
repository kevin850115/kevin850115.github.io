package com.alibaba.fa.framework.bee.util;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.charset.Charset;

/**
 * 日志工厂
 *
 * @author wb-zwl332502
 * @date 2018/08/08
 */
public class BeeLogFactory {

    private static String logPath = "/home/admin/ateye/bee";
    private static String logName = "bee_client.log";
    private static String logLevel = "info";
    private static Logger logger;
    private static String pattern = "[%d{yyyy-MM-dd HH:mm:ss.SSS}][%level][%thread] %logger{20} - %m%n";
    private static final Logger log = LoggerFactory.getLogger(BeeLogFactory.class);

    static {
        //初始化日志
        try {
            initLogger(logPath, logName, logLevel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Logger getLogger() {
        return logger;
    }

    /**
     * 初始化日志
     *
     * @param filePath 日志存储地址
     * @param fileName 日志名称
     * @param logLevel 日志级别
     */
    private static void initLogger(String filePath, String fileName, String logLevel) {
        try {
            String loggerName = "bee_client";
            logger = LoggerFactory.getLogger(loggerName);
            String logFile = filePath + "/" + fileName;

            if (log.isInfoEnabled()) {
                log.info("InitLogger Logger={} File={} Level={}", loggerName, logFile, logLevel);
            }
            if (logger instanceof ch.qos.logback.classic.Logger) {
                RollingFileAppender appender = new RollingFileAppender();

                LoggerContext context = (LoggerContext)LoggerFactory.getILoggerFactory();
                File file = new File(logFile);
                appender.setFile(file.getAbsolutePath());

                PatternLayoutEncoder encoder = new PatternLayoutEncoder();
                encoder.setContext(context);
                encoder.setCharset(Charset.forName("GBK"));
                encoder.setPattern(pattern);
                encoder.start();

                TimeBasedRollingPolicy policy = new TimeBasedRollingPolicy();
                policy.setFileNamePattern(logFile + ".%d{yyyy-MM-dd}");
                policy.setCleanHistoryOnStart(true);
                policy.setContext(context);
                policy.setMaxHistory(7);
                policy.setParent(appender);
                policy.start();

                appender.setRollingPolicy(policy);
                appender.setContext(context);
                appender.setEncoder(encoder);
                appender.start();

                ((ch.qos.logback.classic.Logger)logger).setAdditive(false);
                ((ch.qos.logback.classic.Logger)logger).setLevel(Level.toLevel(logLevel));

                ((ch.qos.logback.classic.Logger)logger).detachAndStopAllAppenders();
                ((ch.qos.logback.classic.Logger)logger).addAppender(appender);
            }
        } catch (Exception e) {
            log.error("", e);
        }
    }
}
