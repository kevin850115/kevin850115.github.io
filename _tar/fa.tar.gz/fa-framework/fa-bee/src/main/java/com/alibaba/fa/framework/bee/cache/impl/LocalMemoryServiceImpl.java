package com.alibaba.fa.framework.bee.cache.impl;

import com.alibaba.fa.framework.bee.cache.CacheService;
import com.alibaba.fa.framework.bee.core.BeeConfig;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.apache.commons.lang3.StringUtils;

/**
 * @author wb-wf262539
 * @date 2018/08/08
 */
public class LocalMemoryServiceImpl implements CacheService {

    private final Cache<String, String> pathValues;

    private BeeConfig beeClientProperty;

    public LocalMemoryServiceImpl(BeeConfig beeClientProperty) {
        this.beeClientProperty = beeClientProperty;
        this.pathValues = CacheBuilder.newBuilder()
            .expireAfterWrite(beeClientProperty.getMemoryCacheExpireTime(),
                beeClientProperty.getMemoryCacheExpireTimeUnit())
            .build();
    }

    /**
     * 获取内存中缓存的值
     *
     * @param path 缓存地址
     * @return
     */
    @Override
    public String get(String path) {
        return pathValues.getIfPresent(path);
    }

    /**
     * 设置内存中缓存的值
     *
     * @param path  缓存地址
     * @param value 设置的值
     */
    @Override
    public void set(String path, String value) {
        pathValues.put(path, value);
    }

    /**
     * 清除缓存
     *
     * @param path 地址
     */
    public void invalidateCache(String path) {
        if (StringUtils.isEmpty(path)) {
            pathValues.invalidateAll();
        } else {
            pathValues.invalidate(path);
        }
    }
}
