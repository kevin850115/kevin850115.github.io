package com.alibaba.fa.framework.bee.core;

import java.util.concurrent.TimeUnit;

/**
 * 片段参数类
 *
 * @author wb-zwl332502
 * @date 2018/08/08
 */
public class BeeConfig {

    /**
     * 服务器地址
     */
    private String serverAddress;

    /**
     * 环境
     */
    private String env;

    /**
     * 内存缓存过期时间
     */
    private Long memoryCacheExpireTime;

    /**
     * 内存缓存过期时间单位
     */
    private TimeUnit memoryCacheExpireTimeUnit;

    /**
     * 定时任务执行的频率
     */
    private Long timeTaskDelay;

    /**
     * 定时任务执行的频率
     */
    private Long timeTaskInterval;

    /**
     * 定时任务执行的时间单位
     */
    private TimeUnit timeTaskTimeUnit;


    /**
     * 片段路径
     */
    private String[] path;

    /**
     * 片段token
     */
    private String[] token;

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Long getMemoryCacheExpireTime() {
        return memoryCacheExpireTime;
    }

    public void setMemoryCacheExpireTime(Long memoryCacheExpireTime) {
        this.memoryCacheExpireTime = memoryCacheExpireTime;
    }

    public TimeUnit getMemoryCacheExpireTimeUnit() {
        return memoryCacheExpireTimeUnit;
    }

    public void setMemoryCacheExpireTimeUnit(TimeUnit memoryCacheExpireTimeUnit) {
        this.memoryCacheExpireTimeUnit = memoryCacheExpireTimeUnit;
    }

    public Long getTimeTaskDelay() {
        return timeTaskDelay;
    }

    public void setTimeTaskDelay(Long timeTaskDelay) {
        this.timeTaskDelay = timeTaskDelay;
    }

    public Long getTimeTaskInterval() {
        return timeTaskInterval;
    }

    public void setTimeTaskInterval(Long timeTaskInterval) {
        this.timeTaskInterval = timeTaskInterval;
    }

    public TimeUnit getTimeTaskTimeUnit() {
        return timeTaskTimeUnit;
    }

    public void setTimeTaskTimeUnit(TimeUnit timeTaskTimeUnit) {
        this.timeTaskTimeUnit = timeTaskTimeUnit;
    }

    public String[] getPath() {
        return path;
    }

    public void setPath(String[] path) {
        this.path = path;
    }

    public String[] getToken() {
        return token;
    }

    public void setToken(String[] token) {
        this.token = token;
    }


    public BeeConfig() {
        this.memoryCacheExpireTime = 30L;
        this.memoryCacheExpireTimeUnit = TimeUnit.MINUTES;
        this.timeTaskInterval = 1L;
        this.timeTaskTimeUnit = TimeUnit.MINUTES;
        this.timeTaskDelay = 5L;
    }

}
