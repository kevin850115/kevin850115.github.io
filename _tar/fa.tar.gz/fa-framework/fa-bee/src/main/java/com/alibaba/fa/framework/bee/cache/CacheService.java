package com.alibaba.fa.framework.bee.cache;

/**
 * 缓存接口类
 *
 * @author wb-wf262539
 * @date 2018/08/08
 */
public interface CacheService {

    /**
     * 获取缓存数据
     *
     *
     * @param path 缓存地址
     * @return
     */
    String get(String path);

    /**
     * 设置缓存数据
     *
     * @param path  缓存地址
     * @param value 设置的值
     */
    void set(String path, String value);
}
