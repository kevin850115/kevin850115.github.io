package com.alibaba.fa.framework.bee.job;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fa.framework.bee.BeeClient;
import com.alibaba.fa.framework.bee.core.BeeResult;
import com.alibaba.fa.framework.bee.service.HttpService;
import com.alibaba.fa.framework.bee.util.BeeLogFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import java.util.Map;

/**
 * 定时检查版本任务
 *
 * @author wb-zwl332502
 * @date 2018/08/08
 */
public class CheckBeeVersionTask implements Runnable {

    private static final Logger logger = BeeLogFactory.getLogger();

    private BeeClient beeClient;

    public CheckBeeVersionTask(BeeClient beeClient) {
        this.beeClient = beeClient;
    }

    @Override
    public void run() {
        invalidCacheIfDataChanged(beeClient);
    }

    public void invalidCacheIfDataChanged(BeeClient beeClient) {
        Map<String, Pair<String,String>> existBeeInfoMap = beeClient.getExistBeeInfoMap();
        logger.info("定时任务--start--,bee path:{}", JSON.toJSONString(existBeeInfoMap));
        HttpService httpService = beeClient.getHttpService();
        if (existBeeInfoMap == null || existBeeInfoMap.size() == 0) {
            logger.info("定时任务--end--,bee path不存在");
            return;
        }
        for (Map.Entry<String,  Pair<String,String>> map : existBeeInfoMap.entrySet()) {
            Pair<String,String> value = map.getValue();
            String beeResultStr = httpService.getOssAddress(map.getKey(), value.getRight());
            BeeResult<String> beeResult = JSONObject.parseObject(beeResultStr, BeeResult.class);
            if (beeResult.isSuccess()) {
                String ossUrl = beeResult.getData().toString();
                if (!StringUtils.equalsIgnoreCase(value.getLeft(), ossUrl)) {
                    beeClient.invalidateLocalCache(map.getKey());
                    logger.info("定时任务--ing--,invalidate path:{}", map.getKey());
                }
            }
        }
        logger.info("定时任务--end--");
    }
}
