package com.alibaba.fa.framework.bee;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fa.framework.bee.cache.impl.LocalFileServiceImpl;
import com.alibaba.fa.framework.bee.cache.impl.LocalMemoryServiceImpl;
import com.alibaba.fa.framework.bee.core.BeeConfig;
import com.alibaba.fa.framework.bee.core.BeeResult;
import com.alibaba.fa.framework.bee.exception.BeeClientException;
import com.alibaba.fa.framework.bee.job.CheckBeeVersionTask;
import com.alibaba.fa.framework.bee.service.HttpService;
import com.alibaba.fa.framework.bee.service.impl.HttpServiceImpl;
import com.alibaba.fa.framework.bee.util.BeeLogFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/**
 * @author wb-zwl332502
 * @date 2018/08/09
 */
public class BeeClient {
    private static final Logger logger = BeeLogFactory.getLogger();

    public HttpService getHttpService() {
        return httpService;
    }

    public void setHttpService(HttpService httpService) {
        this.httpService = httpService;
    }

    public LocalFileServiceImpl getLocalFileService() {
        return localFileService;
    }

    public void setLocalFileService(LocalFileServiceImpl localFileService) {
        this.localFileService = localFileService;
    }

    public LocalMemoryServiceImpl getLocalMemoryService() {
        return localMemoryService;
    }

    public void setLocalMemoryService(LocalMemoryServiceImpl localMemoryService) {
        this.localMemoryService = localMemoryService;
    }

    public BeeConfig getBeeConfig() {
        return beeConfig;
    }

    public CheckBeeVersionTask getCheckBeeVersionTask() {
        return checkBeeVersionTask;
    }

    public void setCheckBeeVersionTask(CheckBeeVersionTask checkBeeVersionTask) {
        this.checkBeeVersionTask = checkBeeVersionTask;
    }

    public Map<String,  Pair<String,String>> getExistBeeInfoMap() {
        return existBeeInfoMap;
    }

    /**
     * 请求bee服务器包装类
     */
    private HttpService httpService;
    /**
     * 本地文件缓存处理类
     */
    private LocalFileServiceImpl localFileService;
    /**
     * 本地缓存处理类
     */
    private LocalMemoryServiceImpl localMemoryService;

    /**
     * 配置项
     */
    private BeeConfig beeConfig;

    public void setBeeConfig(BeeConfig beeConfig) {
        this.beeConfig = beeConfig;
    }

    /**
     * 定时比对版本任务
     */
    private CheckBeeVersionTask checkBeeVersionTask;

    /**
     * 项目中存在的所有片段的path
     */
    private Map<String, Pair<String, String>> existBeeInfoMap = new ConcurrentHashMap<>();


    /**
     * 初始化各参数以及任务
     */
    public void init() {
        this.httpService = new HttpServiceImpl(beeConfig);
        this.localFileService = new LocalFileServiceImpl(beeConfig);
        this.localMemoryService = new LocalMemoryServiceImpl(beeConfig);
        this.checkBeeVersionTask = new CheckBeeVersionTask(this);
        initScheduled();
        loadBeeAsync();
    }

    /**
     * 初始化时启动定时任务
     */
    private void initScheduled() {
        ScheduledExecutorService service = new ScheduledThreadPoolExecutor(10,
            new BasicThreadFactory.Builder().namingPattern("beeConfigManager-schedule-pool-%d").daemon(true).build());
        service.scheduleAtFixedRate(checkBeeVersionTask, beeConfig.getTimeTaskDelay(),
            beeConfig.getTimeTaskInterval(), beeConfig.getMemoryCacheExpireTimeUnit());
    }

    public void bee(String path, String token) {
        try {
            HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print(importRgn(path, token));
        } catch (Exception e) {
            logger.error("print error",e);
        }
    }

    public void bee() {
        bee(0);
    }

    public void bee(String path) {
        if(!pathValid() || StringUtils.isEmpty(path)) {
            return;
        }
        for(int i = 0; i < beeConfig.getPath().length; i++) {
            String match = beeConfig.getPath()[i];
            if(path.equals(match)) {
                bee(i);
                break;
            }
        }
    }

    public void bee(int index) {
        if(!pathValid()) {
            return;
        }
        if(index >= beeConfig.getPath().length) {
            return;
        }
        bee(beeConfig.getPath()[index], beeConfig.getToken()[index]);
    }



    /**
     * 获取片段的值
     *
     * @param path 链接
     * @return
     */
    public String importRgn(String path, String token) {
        String value = null;
        Boolean cached = false;
        boolean errorHappened = false;

        try {
            value = localMemoryService.get(path);
            if (StringUtils.isNotBlank(value)) {
                cached = true;
            } else {
                String beeResultStr = httpService.getOssAddress(path, token);
                BeeResult<String> beeResult = JSONObject.parseObject(beeResultStr, BeeResult.class);
                if (beeResult.isSuccess()) {
                    //获取所有的片段的url
                    String ossUrl = beeResult.getData().toString();
                    MutablePair<String, String> pair = new MutablePair();
                    pair.setLeft(ossUrl);
                    pair.setRight(token);
                    existBeeInfoMap.put(path, pair);
                    //接口调用
                    value = httpService.getContentFromUrl(ossUrl);
                    updateLocalCache(path, value);
                } else {
                    errorHappened = true;
                    logger.error("get config " + path + " from server error, beeResult:" + beeResultStr);
                }
            }
        } catch (BeeClientException e) {
            errorHappened = true;
            logger.error("get config " + path + " from server error", e);
        }

        if (errorHappened) {
            return localFileService.get(path);
        }

        if (!cached) {
            localFileService.set(path, value);
        }

        return value;
    }

    /**
     * 更新缓存
     *
     * @param path  请求path地址
     * @param value 值
     */
    private void updateLocalCache(String path, String value) {
        localMemoryService.set(path, value);
        localFileService.set(path, value);
    }

    /**
     * 删除指定key的本地缓存 场景:在版本变化之后
     *
     * @param path
     */
    public void invalidateLocalCache(String path) {
        if (StringUtils.isNotBlank(path)) {
            localMemoryService.invalidateCache(path);
        }
    }


    private void loadBeeAsync() {
        if(!pathValid()) {
            return;
        }
        new Thread(null,
                () -> {
                    for(int i = 0; i< beeConfig.getPath().length; i++) {
                        String path = beeConfig.getPath()[i];
                        String token = beeConfig.getToken()[i];
                        this.importRgn(path, token);
                    }
                },
                "init-bee-thread"
        ).start();
    }

    private boolean pathValid() {
        return beeConfig.getPath() != null && beeConfig.getToken() != null && beeConfig.getPath().length > 0 &&  beeConfig.getPath().length == beeConfig.getToken().length;
    }
}
