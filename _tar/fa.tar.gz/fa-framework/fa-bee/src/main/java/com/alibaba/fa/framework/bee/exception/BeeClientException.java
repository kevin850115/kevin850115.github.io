package com.alibaba.fa.framework.bee.exception;

/**
 * 异常类
 *
 * @author wb-wf262539
 * @date 2018/08/08
 */
public class BeeClientException extends RuntimeException {

    public BeeClientException(Throwable throwable) {
        super(throwable);
    }

    public BeeClientException(String message) {
        super(message);
    }

    public BeeClientException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
