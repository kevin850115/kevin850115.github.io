package com.alibaba.fa.framework.bee.service.impl;

import com.alibaba.fa.framework.bee.core.BeeConfig;
import com.alibaba.fa.framework.bee.exception.BeeClientException;
import com.alibaba.fa.framework.bee.service.HttpService;
import com.alibaba.fa.framework.bee.util.BeeLogFactory;
import com.alibaba.fa.framework.bee.util.CommonUtil;
import com.alibaba.fa.framework.bee.util.HttpClientUtils;
import org.slf4j.Logger;

/**
 * @author wb-zwl332502
 * @date 2018/08/08
 */
public class HttpServiceImpl implements HttpService {

    private static final Logger logger = BeeLogFactory.getLogger();

    private BeeConfig beeClientProperty;

    public HttpServiceImpl(BeeConfig beeClientProperty) {
        this.beeClientProperty = beeClientProperty;
    }

    /**
     * 获取oss地址
     *
     * @param path 请求地址
     * @return
     */
    @Override
    public String getOssAddress(String path, String token) throws BeeClientException {
        String serverAddress = beeClientProperty.getServerAddress();
        if (!serverAddress.startsWith("http")) {
            serverAddress = "http://" + serverAddress;
        }
        String requestUrl = serverAddress + path +
                "?env=" + beeClientProperty.getEnv() + "&token=" + token;
        try {
            return HttpClientUtils.doGet(requestUrl);
        } catch (Exception e) {
            logger.warn("通过http获取oss地址失败,url:{},e:{}", requestUrl, CommonUtil.errInfo(e));
            throw new BeeClientException(e);
        }
    }

    /**
     * 获取url的内容
     *
     * @param url 请求地址
     * @return
     */
    @Override
    public String getContentFromUrl(String url) {
        try {
            return HttpClientUtils.doGet(url);
        } catch (Exception e) {
            logger.warn("通过http获取内容失败,url:{},e:{}", url, CommonUtil.errInfo(e));
            throw new BeeClientException(e);
        }
    }
}
