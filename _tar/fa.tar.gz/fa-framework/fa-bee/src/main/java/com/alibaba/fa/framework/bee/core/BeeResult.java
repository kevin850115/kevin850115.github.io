package com.alibaba.fa.framework.bee.core;

import java.io.Serializable;

/**
 * Created by wb-zwl332502 on 2018/9/29
 */
public class BeeResult<T> implements Serializable {
    private boolean success = false;
    private T data;
    private String message;
    private Integer code;

    public BeeResult() {

    }



    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

}
