package com.alibaba.fa.framework.bee.service;

/**
 * @author wb-zwl332502
 * @date 2018/08/08
 */
public interface HttpService {

    /**
     * 获取oss地址
     *
     * @param path 请求地址
     * @param token
     * @return
     */
    String getOssAddress(String path, String token);

    /**
     * 获取url的内容
     *
     * @param url 请求地址
     * @return
     */
    String getContentFromUrl(String url);
}
