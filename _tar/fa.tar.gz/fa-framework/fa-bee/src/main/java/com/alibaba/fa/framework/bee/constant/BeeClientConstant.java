package com.alibaba.fa.framework.bee.constant;

/**
 * @author wb-wf262539
 * @date 2018/08/08
 */
public interface BeeClientConstant {

    String BACKUP_FILE_PATH = "/home/admin/ateye/bee/backup";
}
