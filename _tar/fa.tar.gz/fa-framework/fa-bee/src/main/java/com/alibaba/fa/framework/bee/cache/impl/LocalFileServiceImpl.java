package com.alibaba.fa.framework.bee.cache.impl;

import com.alibaba.fa.framework.bee.cache.CacheService;
import com.alibaba.fa.framework.bee.constant.BeeClientConstant;
import com.alibaba.fa.framework.bee.core.BeeConfig;
import com.alibaba.fa.framework.bee.exception.BeeClientException;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * 本地文件获取/存储实现类
 *
 * @author wb-wf262539
 * @date 2018/08/08
 */
public class LocalFileServiceImpl implements CacheService {

    private BeeConfig beeClientProperty;

    public LocalFileServiceImpl(BeeConfig beeClientProperty) {
        this.beeClientProperty = beeClientProperty;
    }

    /**
     * 获取文件内容
     *
     * @param path 缓存地址
     * @return
     * @throws BeeClientException
     */
    @Override
    public synchronized String get(String path) throws BeeClientException {
        String backUpFilePath = getBackUpFilePath(path);

        File backUpFile = new File(backUpFilePath);
        if (!backUpFile.exists()) {
            return null;
        }
        try {
            return IOUtils.toString(new FileInputStream(backUpFilePath), Charset.defaultCharset());
        } catch (IOException e) {
            throw new BeeClientException(e);
        }
    }

    /**
     * 设置文件内容
     *
     * @param path  缓存地址
     * @param value 设置的值
     */
    @Override
    public synchronized void set(String path, String value) throws BeeClientException {
        String backUpFilePath = getBackUpFilePath(path);
        try {
            File backUpFile = new File(backUpFilePath);

            if (!backUpFile.exists()) {
                backUpFile.getParentFile().mkdirs();
                backUpFile.createNewFile();
            }

            IOUtils.write(value, new FileOutputStream(backUpFilePath), Charset.defaultCharset());
        } catch (IOException e) {
            throw new BeeClientException(e);
        }
    }

    /**
     * 获取备份文件在服务器上的地址
     *
     * @param path 地址
     * @return
     */
    private String getBackUpFilePath(String path) {
        return BeeClientConstant.BACKUP_FILE_PATH + path;
    }

    public static void main(String[] args) {
        String backUpFilePath = "D:\\hello.txt";

        File backUpFile = new File(backUpFilePath);
        if (!backUpFile.exists()) {
            System.out.println("null");
        }
        try {
            IOUtils.write("hahaha", new FileOutputStream(backUpFilePath), Charset.defaultCharset());
        } catch (IOException e) {
            throw new BeeClientException(e);
        }
    }
}
