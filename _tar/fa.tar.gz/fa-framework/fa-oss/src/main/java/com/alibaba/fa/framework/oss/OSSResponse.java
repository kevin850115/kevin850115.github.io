package com.alibaba.fa.framework.oss;

import com.aliyun.oss.model.OSSObject;

/**
 * @author wb-hyl282156
 * @date 2017/7/5
 */
public class OSSResponse {

    private String code;

    private boolean isSuccess = true;

    private String msg;

    /**
     * 公开访问的url
     */
    private String url;

    /**
     * 上传的文件名
     */
    private String fileName;

    /**
     * 获取存储对象
     */
    private OSSObject object;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean success) {
        isSuccess = success;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public OSSObject getObject() {
        return object;
    }

    public void setObject(OSSObject object) {
        this.object = object;
    }
}
