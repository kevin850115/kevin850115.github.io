package com.alibaba.fa.framework.oss;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSException;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.CreateBucketRequest;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PutObjectRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.UUID;

/**
 *
 * @author wb-hyl282156
 * @date 2017/7/5
 */
public class OSSServiceImpl implements OSSService {

    protected final Logger logger = LoggerFactory.getLogger(OSSServiceImpl.class);

    /**
     * 文件名重复错误码
     */
    public static String DUPLICATE_CODE = "10010";

    private String endpoint;

    private String accessKeyId;

    private String accessKeySecret;

    private String defaultBucketName;

    private String defaultPackage;

    private String defaultUrl;

    public OSSClient ossClient;

    public void init() {
        try {
            ossClient = new OSSClient(endpoint, accessKeyId, accessKeySecret);
            logger.info("启动 OSSClient 成功！");
        } catch (Exception e) {
            logger.error("启动 OSSClient 失败！", e);
        }
    }

    /**
     * 按照规则获取上传文件名
     *
     * @return
     */
    public String getKey() {
        return UUID.randomUUID().toString();
    }

    public String getKey(String fileName) {
        return UUID.randomUUID().toString() + "_" + fileName;
    }

    /**
     * 上传byte数组，自动生成文件名,默认bucket
     *
     * @param fileBytes 文件的byte数组
     * @return
     */
    @Override
    public OSSResponse upload(byte[] fileBytes) {
        OSSResponse ossResponse = upload(fileBytes, getKey());

        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            upload(fileBytes);
        }
        return ossResponse;
    }

    /**
     * 上传byte数组,指定文件名,默认bucket
     *
     * @param fileBytes 文件的byte数组
     * @param fileName  指定文件名
     * @return
     */
    @Override
    public OSSResponse upload(byte[] fileBytes, String fileName) {
        OSSResponse ossResponse = upload(fileBytes, fileName, defaultBucketName);
        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            return upload(fileBytes, getKey(fileName));
        }
        return ossResponse;
    }

    /**
     * 上传byte数组,指定文件名,指定bucket
     *
     * @param fileBytes  文件的byte数组
     * @param fileName   指定文件名
     * @param bucketName 指定bucket名
     * @return
     */
    @Override
    public OSSResponse upload(byte[] fileBytes, String fileName, String bucketName) {
        OSSResponse ossrs = new OSSResponse();

        if (null == fileBytes && fileBytes.length == 0) {
            ossrs.setSuccess(false);
            ossrs.setMsg("空数据，无法上传！");
            return ossrs;
        }

        //入参检查
        if (checkParam(fileName, ossrs)) { return ossrs; }

        try {
            //bucket检查，默认bucket创建
            if (checkBucket(bucketName, ossrs)) {
                return ossrs;
            }

            fileName = defaultPackage + fileName;

            //文件名重复校验
            if (checkExist(fileName, bucketName, ossrs)) { return ossrs; }

            ossClient.putObject(bucketName, fileName, new ByteArrayInputStream(fileBytes));

            ossrs.setUrl(buildOutUrl(fileName, bucketName));
            ossrs.setFileName(fileName);

            return ossrs;
        } catch (OSSException oe) {
            logger.error("Error Message", oe);
            ossrs.setMsg(oe.getErrorMessage());
            ossrs.setSuccess(false);
        } catch (ClientException ce) {
            logger.error("Error Message", ce);
            ossrs.setMsg(ce.getMessage());
            ossrs.setSuccess(false);
        }

        return ossrs;
    }

    /**
     * 上传流，自动生成文件名,默认bucket
     *
     * @param inputStream 上传的数据流
     * @return
     */
    @Override
    public OSSResponse upload(InputStream inputStream) {
        OSSResponse ossResponse = upload(inputStream, getKey());

        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            upload(inputStream);
        }
        return ossResponse;
    }

    /**
     * 上传流，指定文件名,默认bucket
     *
     * @param inputStream 上传的流数据
     * @param fileName    指定文件名
     * @return
     */
    @Override
    public OSSResponse upload(InputStream inputStream, String fileName) {
        OSSResponse ossResponse = upload(inputStream, fileName, defaultBucketName);
        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            return upload(inputStream, getKey(fileName));
        }
        return ossResponse;
    }

    /**
     * 上传流，指定文件名,指定bucket
     *
     * @param inputStream 上传的流数据
     * @param fileName    指定文件名
     * @param bucketName  指定bucket名
     * @return
     */
    @Override
    public OSSResponse upload(InputStream inputStream, String fileName, String bucketName) {
        OSSResponse ossrs = new OSSResponse();

        if (null == inputStream) {
            ossrs.setSuccess(false);
            ossrs.setMsg("空数据，无法上传！");
            return ossrs;
        }

        //入参检查
        if (checkParam(fileName, ossrs)) { return ossrs; }

        try {
            //bucket检查，默认bucket创建
            if (checkBucket(bucketName, ossrs)) {
                return ossrs;
            }

            fileName = defaultPackage + fileName;

            //文件名重复校验
            if (checkExist(fileName, bucketName, ossrs)) {
                return ossrs;
            }

            ossClient.putObject(bucketName, fileName, inputStream);

            ossrs.setUrl(buildOutUrl(fileName, bucketName));
            ossrs.setFileName(fileName);

            return ossrs;
        } catch (OSSException oe) {
            logger.error("Error Message", oe);
            ossrs.setMsg(oe.getErrorMessage());
            ossrs.setSuccess(false);
        } catch (ClientException ce) {
            logger.error("Error Message", ce);
            ossrs.setMsg(ce.getMessage());
            ossrs.setSuccess(false);
        }

        return ossrs;
    }
    /**
     * 文件上传指定类，系统自动按照规则生成文件名
     *
     * @param file 待上传的文件
     * @return
     */
    @Override
    public OSSResponse upload(File file) {
        OSSResponse ossResponse = upload(file, getKey());

        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            upload(file);
        }
        return ossResponse;
    }

    /**
     * 文件上传指定类
     *
     * @param file     待上传的文件
     * @param fileName 指定保存的文件名
     * @return
     */
    @Override
    public OSSResponse upload(File file, String fileName) {
        OSSResponse ossResponse = upload(file, fileName, defaultBucketName,defaultPackage);
        //如果是文件名重复异常，尝试再次获取文件名,重新上传
        if (!ossResponse.isSuccess() && DUPLICATE_CODE.equals(ossResponse.getCode())) {
            return upload(file, getKey(fileName));
        }
        return ossResponse;
    }

    /**
     * 文件上传指定类
     *
     * @param file       要上传的文件
     * @param fileName   指定保存的文件名
     * @param bucketName 指定保存的目录,不指定默认保存到默认文件下
     * @return
     */
    @Override
    public OSSResponse upload(File file, String fileName, String bucketName,String packageName) {
        OSSResponse ossrs = new OSSResponse();

        if (null == file || file.length() == 0) {
            ossrs.setSuccess(false);
            ossrs.setMsg("文件不存在或为空，无法上传！");
            return ossrs;
        }

        //入参检查
        if (checkParam(fileName, ossrs)) {
            return ossrs;
        }

        try {
            //bucket检查，默认bucket创建
            if (checkBucket(bucketName, ossrs)) {
                return ossrs;
            }

            fileName = packageName + fileName;

            //文件名重复校验
            if (checkExist(fileName, bucketName, ossrs)) {
                return ossrs;
            }

            ossClient.putObject(new PutObjectRequest(bucketName, fileName, file));

            ossrs.setUrl(buildOutUrl(fileName, bucketName));
            ossrs.setFileName(fileName);

            return ossrs;
        } catch (OSSException oe) {
            logger.error("Error Message", oe);
            ossrs.setMsg(oe.getErrorMessage());
            ossrs.setSuccess(false);
        } catch (ClientException ce) {
            logger.error("Error Message", ce);
            ossrs.setMsg(ce.getMessage());
            ossrs.setSuccess(false);
        }

        return ossrs;
    }

    /**
     * 检查文件存在性，是否存在同名文件
     *
     * @param fileName
     * @param bucketName
     * @param ossrs
     * @return
     */
    private boolean checkExist(String fileName, String bucketName, OSSResponse ossrs) {
        //校验文件名是否已被使用
        if (ossClient.doesObjectExist(bucketName, fileName)) {
            ossrs.setSuccess(false);
            ossrs.setCode(DUPLICATE_CODE);
            ossrs.setMsg("文件已存在，请修改后重试！");
            return true;
        }
        return false;
    }

    /**
     * 检查bucket是否存在，不存在用默认bucket，默认bucket不存在则创建
     *
     * @param bucketName
     * @param ossrs
     * @return
     */
    private boolean checkBucket(String bucketName, OSSResponse ossrs) {
        if (null == ossClient) {
            init();
        }

        //bucket校验，默认bucket创建
        if (StringUtils.isBlank(bucketName)) {
            bucketName = defaultBucketName;
            if (!ossClient.doesBucketExist(bucketName)) {
                logger.info("默认的bucket:{0}不存在，执行创建！", bucketName);

                ossClient.createBucket(bucketName);
                CreateBucketRequest createBucketRequest = new CreateBucketRequest(bucketName);
                createBucketRequest.setCannedACL(CannedAccessControlList.PublicRead);
                ossClient.createBucket(createBucketRequest);

                logger.info("默认的bucket：{0}创建成功！", bucketName);
            }
        } else {
            if (!ossClient.doesBucketExist(bucketName)) {
                ossrs.setSuccess(false);
                ossrs.setMsg("指定的bucket不存在，请联系OSS管理员创建！");
                return true;
            }
        }
        return false;
    }

    /**
     * 参数校验，必填参数检查
     *
     * @param fileName
     * @param ossrs
     * @return
     */
    private boolean checkParam(String fileName, OSSResponse ossrs) {
        if (StringUtils.isBlank(fileName)) {
            ossrs.setSuccess(false);
            ossrs.setMsg("文件名不能为空！");
            return true;
        }
        return false;
    }

    private String buildOutUrl(String fileName, String bucketName) {
        StringBuffer urlBuffer = new StringBuffer(defaultUrl);
        urlBuffer.append(fileName);
        return urlBuffer.toString();
    }

    /**
     * 在默认bucket中删除指定文件
     *
     * @param fileName 指定删除的文件名
     * @return
     */
    @Override
    public OSSResponse delete(String fileName) {
        return delete(fileName, defaultBucketName);
    }

    /**
     * 按照文件名和bucket删除文件
     *
     * @param fileName   指定删除的文件名
     * @param bucketName 指定删除文件的bucket
     * @return
     */
    @Override
    public OSSResponse delete(String fileName, String bucketName) {
        OSSResponse ossrs = new OSSResponse();

        if (StringUtils.isBlank(fileName)) {
            ossrs.setSuccess(false);
            ossrs.setMsg("文件名不能为空！");
            return ossrs;
        }

        if (!ossClient.doesBucketExist(bucketName)) {
            ossrs.setSuccess(false);
            ossrs.setMsg("指定的bucket不存在，请传入正确的bucketName！");
            return ossrs;
        }

        ossClient.deleteObject(bucketName, fileName);
        return ossrs;
    }

    /**
     * 按照文件名读取文件
     *
     * @param fileName 指定读取的文件名
     * @return
     */
    @Override
    public OSSResponse read(String fileName) {
        return read(fileName, defaultBucketName);
    }

    /**
     * 按照文件名和bucket读取文件
     *
     * @param fileName   指定读取的文件名
     * @param bucketName 指定读物文件的bucket
     * @return
     */
    @Override
    public OSSResponse read(String fileName, String bucketName) {
        OSSResponse ossrs = new OSSResponse();

        if (StringUtils.isBlank(fileName)) {
            ossrs.setSuccess(false);
            ossrs.setMsg("文件名不能为空！");
            return ossrs;
        }

        if (!ossClient.doesBucketExist(bucketName)) {
            ossrs.setSuccess(false);
            ossrs.setMsg("指定的bucket不存在，请传入正确的bucketName！");
            return ossrs;
        }

        OSSObject object = ossClient.getObject(bucketName, fileName);

        ossrs.setFileName(object.getKey());
        ossrs.setObject(object);
        ossrs.setUrl(buildOutUrl(fileName, bucketName));

        return ossrs;
    }

    public String getDefaultPackage() {
        return defaultPackage;
    }

    public void setDefaultPackage(String defaultPackage) {
        this.defaultPackage = defaultPackage;
    }

    public String getDefaultUrl() {
        return defaultUrl;
    }

    public void setDefaultUrl(String defaultUrl) {
        this.defaultUrl = defaultUrl;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public void setAccessKeyId(String accessKeyId) {
        this.accessKeyId = accessKeyId;
    }

    public String getAccessKeySecret() {
        return accessKeySecret;
    }

    public void setAccessKeySecret(String accessKeySecret) {
        this.accessKeySecret = accessKeySecret;
    }

    public String getDefaultBucketName() {
        return defaultBucketName;
    }

    public void setDefaultBucketName(String defaultBucketName) {
        this.defaultBucketName = defaultBucketName;
    }
}
