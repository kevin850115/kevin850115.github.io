package com.alibaba.fa.framework.oss;

import java.io.File;
import java.io.InputStream;

/**
 * @author wb-hyl282156
 * @date 2017/7/6
 */
public interface OSSService {

    /**
     * 上传byte数组，自动生成文件名,默认bucket
     *
     * @param fileBytes 文件的byte数组
     * @return
     */
    OSSResponse upload(byte[] fileBytes);

    /**
     * 上传byte数组,指定文件名,默认bucket
     *
     * @param fileBytes 文件的byte数组
     * @param fileName  指定文件名
     * @return
     */
    OSSResponse upload(byte[] fileBytes, String fileName);

    /**
     * 上传byte数组,指定文件名,指定bucket
     *
     * @param fileBytes  文件的byte数组
     * @param fileName   指定文件名
     * @param bucketName 指定bucket名
     * @return
     */
    OSSResponse upload(byte[] fileBytes, String fileName, String bucketName);

    /**
     * 上传流，自动生成文件名,默认bucket
     *
     * @param inputStream 上传的数据流
     * @return
     */
    OSSResponse upload(InputStream inputStream);

    /**
     * 上传流，指定文件名,默认bucket
     *
     * @param inputStream 上传的流数据
     * @param fileName    指定文件名
     * @return
     */
    OSSResponse upload(InputStream inputStream, String fileName);

    /**
     * 上传流，指定文件名,指定bucket
     *
     * @param inputStream 上传的流数据
     * @param fileName    指定文件名
     * @param bucketName  指定bucket名
     * @return
     */
    OSSResponse upload(InputStream inputStream, String fileName, String bucketName);

    /**
     * 文件上传指定类，系统自动按照规则生成文件名
     *
     * @param file 待上传的文件
     * @return
     */
    OSSResponse upload(File file);

    /**
     * 文件上传指定类
     *
     * @param file     待上传的文件
     * @param fileName 指定保存的文件名
     * @return
     */
    OSSResponse upload(File file, String fileName);

    /**
     * 文件上传指定类
     *
     * @param file       要上传的文件
     * @param fileName   指定保存的文件名
     * @param bucketName 指定保存的目录,不指定默认保存到默认文件下
     * @return
     */
    OSSResponse upload(File file, String fileName, String bucketName, String packageName);

    /**
     * 在默认bucket中删除指定文件
     *
     * @param fileName 指定删除的文件名
     * @return
     */
    OSSResponse delete(String fileName);

    /**
     * 按照文件名和bucket删除文件
     *
     * @param fileName   指定删除的文件名
     * @param bucketName 指定删除文件的bucket
     * @return
     */
    OSSResponse delete(String fileName, String bucketName);

    /**
     * 按照文件名读取文件
     *
     * @param fileName 指定读取的文件名
     * @return
     */
    OSSResponse read(String fileName);

    /**
     * 按照文件名和bucket读取文件
     *
     * @param fileName   指定读取的文件名
     * @param bucketName 指定读物文件的bucket
     * @return
     */
    OSSResponse read(String fileName, String bucketName);
}
