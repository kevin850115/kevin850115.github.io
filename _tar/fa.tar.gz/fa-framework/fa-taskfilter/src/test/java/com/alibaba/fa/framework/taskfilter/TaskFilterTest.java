/*
package com.alibaba.fa.framework.taskfilter;

import com.alibaba.fa.framework.domain.ResultDO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

*/
/**
 * Created by zhanglei on 2017/12/11.
 *//*

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-applicationContext.xml"})
public class TaskFilterTest {
    @Autowired
    private com.alibaba.fa.framework.taskfilter.HelloServiceImpl helloService;
    @Test
    public void test(){
        ResultDO resultDO = helloService.hello("1",3,new Object());
        System.out.println(resultDO);
    }
}
*/
