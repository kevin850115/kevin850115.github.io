package com.alibaba.fa.framework.taskfilter;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.taskfilter.task.BaseRequest;
import com.alibaba.fa.framework.taskfilter.task.BaseResponse;
import com.alibaba.fa.framework.taskfilter.task.Filter;
import org.springframework.stereotype.Component;

/**
 * Created by zhanglei on 2017/12/11.
 */
@Component
public class HelloFilter implements Filter {

    @Override
    public boolean check(ResultDO resultDO) {
        return true;
    }

    @Override
    public ResultDO execute(BaseRequest baseRequest, BaseResponse baseResponse) {
        System.out.println("hello1");
        return null;
    }
}
