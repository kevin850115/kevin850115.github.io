package com.alibaba.fa.framework.taskfilter;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.taskfilter.task.BaseRequest;
import com.alibaba.fa.framework.taskfilter.task.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by zhanglei on 2017/12/11.
 */
@Component
public class HelloServiceImpl {
    @Autowired
    private HelloTask helloTask;
    public ResultDO hello(String sss,Integer s,Object o){
       return helloTask.execute(new BaseRequest(),new BaseResponse());
    }
}
