package com.alibaba.fa.framework.taskfilter;

import com.alibaba.fa.framework.taskfilter.processor.TaskFilters;
import com.alibaba.fa.framework.taskfilter.task.BaseTask;
import org.springframework.stereotype.Component;

/**
 * Created by zhanglei on 2017/12/11.
 */
@Component
@TaskFilters(value = {HelloFilter.class,HelloFilter1.class})
public class HelloTask extends BaseTask {

}
