package com.alibaba.fa.framework.taskfilter.task;

/**
 * Created by zhanglei on 2017/12/11.
 */
public class BuildContext<R extends BaseRequest,P extends BaseResponse> {
    private R request;

    private P response;

    public R getRequest() {
        return request;
    }

    public void setRequest(R request) {
        this.request = request;
    }

    public P getResponse() {
        return response;
    }

    public void setResponse(P response) {
        this.response = response;
    }
}
