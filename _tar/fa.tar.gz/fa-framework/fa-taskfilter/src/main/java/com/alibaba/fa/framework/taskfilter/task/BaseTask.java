package com.alibaba.fa.framework.taskfilter.task;

import com.alibaba.fa.framework.domain.ResultDO;
import com.alibaba.fa.framework.util.Exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2017/12/11.
 */
public abstract class BaseTask<Q extends BaseRequest, P extends BaseResponse> {
    public static final Logger LOG = LoggerFactory.getLogger(BaseTask.class);
    /**
     * 职责链列表
     */
    private List<Filter<Q, P>> filters = new ArrayList<Filter<Q, P>>();
    /**
     * 执行职责链前操作
     */
    protected void beforeExecute(Q request, P response) throws Throwable {

    }
    public ResultDO execute(Q request,P response){
        ResultDO resultDO = null;
        try {
            beforeExecute(request,response);

            for (int i = 0; i < filters.size(); i++) {
                Filter filter = filters.get(i);
                if (!filter.check(resultDO)) {
                    break;
                }
                resultDO = filter.execute(request, response);
            }
            resultDO = afterExecute(resultDO,request,response);

        }catch (Throwable e){
            LOG.error("taskfilter execute error",e);
            //throw new RuntimeException(e);
            return ResultDO.buildFailResult("任务职责异常:"+ Exceptions.getMessageAsString(e));
        }finally {
            try {
                resultDO = finallyExecute(resultDO,request,response);
            } catch (Throwable throwable) {
                LOG.error("taskfilter execute error",throwable);
                return ResultDO.buildFailResult("未知异常");
            }
        }
        return resultDO;
    }
    /**
     * 执行职责链后操作
     *
     * @param request
     * @param response
     * @throws Throwable
     */
    protected ResultDO afterExecute(ResultDO resultDO,Q request, P response) throws Throwable {
        return resultDO;
    }
    protected ResultDO finallyExecute(ResultDO resultDO,Q request, P response) throws Throwable {
        return resultDO;
    }
    public void addFilter(Filter filter){
        this.filters.add(filter);
    }
}
