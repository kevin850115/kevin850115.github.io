package com.alibaba.fa.framework.taskfilter.task;

import com.alibaba.fa.framework.domain.ResultDO;

/**
 * Created by zhanglei on 2017/12/11.
 */
public interface Filter<R extends BaseRequest,P extends BaseResponse> {
    boolean check(ResultDO resultDO);
    ResultDO execute(R baseRequest,P baseResponse);
}
