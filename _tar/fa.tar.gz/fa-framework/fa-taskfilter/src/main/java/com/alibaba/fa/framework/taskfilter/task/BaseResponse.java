package com.alibaba.fa.framework.taskfilter.task;

/**
 * Created by zhanglei on 2017/12/11.
 */
public class BaseResponse {

}
