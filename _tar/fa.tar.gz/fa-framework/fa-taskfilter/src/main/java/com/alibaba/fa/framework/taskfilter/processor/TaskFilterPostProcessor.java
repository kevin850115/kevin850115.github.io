package com.alibaba.fa.framework.taskfilter.processor;

import com.alibaba.fa.framework.taskfilter.task.BaseTask;
import com.alibaba.fa.framework.taskfilter.task.Filter;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author zhanglei
 * @date 2017/12/11
 */
public class TaskFilterPostProcessor implements BeanPostProcessor, ApplicationContextAware {
    private ApplicationContext applicationContext;
    @Override
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        return o;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class cls = AopUtils.getTargetClass(bean);
        TaskFilters anno = null;
        while (anno == null && cls != null) {
            anno = (TaskFilters) cls.getAnnotation(TaskFilters.class);
            cls = cls.getSuperclass();
        }
        List<Filter> filters = new ArrayList<Filter>();
        if(anno!=null){
            BaseTask baseTask = (BaseTask)bean;
            for(Class filterCls : anno.value()){
                Filter filter = (Filter)applicationContext.getBean(filterCls);
                baseTask.addFilter(filter);
            }
        }
        return bean;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
