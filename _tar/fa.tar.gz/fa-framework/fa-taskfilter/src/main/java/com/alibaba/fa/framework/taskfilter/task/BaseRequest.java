package com.alibaba.fa.framework.taskfilter.task;


public class BaseRequest {

    @Override
    public String toString() {
        return "";
    }
}
