package com.alibaba.fa.framework.domain;

/**
 * Created by wb-zxz248731 on 2017/4/10.
 */
public interface BaseResult{

	boolean isSuccess();

	BaseResult setSuccess(boolean isSuccess);

	String getCode();

	BaseResult setCode(String errorCode);

	String getMsg();

	BaseResult setMsg(String errorMsg);
}
