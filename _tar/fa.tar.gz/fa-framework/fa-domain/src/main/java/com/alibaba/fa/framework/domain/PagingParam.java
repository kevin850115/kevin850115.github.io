package com.alibaba.fa.framework.domain;

import java.io.Serializable;

/**
 * Created by wb-wmf250057 on 2017/12/5.
 * 分页参数
 */
public class PagingParam implements Serializable {

    private int pageSize;

    private int currentPage;

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getRowBoundsStart() {
        return (currentPage - 1 < 0 ? 0 : currentPage - 1) * pageSize;
    }

    public int getRowBoundsCount() {
        return pageSize;
    }
}
