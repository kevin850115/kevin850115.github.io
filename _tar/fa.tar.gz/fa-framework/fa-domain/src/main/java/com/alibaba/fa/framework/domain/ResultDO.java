package com.alibaba.fa.framework.domain;

import java.io.Serializable;

import com.alibaba.fa.framework.util.IKeyDescEnum;

/**
 * Created by wb-zxz248731 on 2017/4/10.
 */
public class ResultDO<T> implements BaseResult, Serializable {

    private T module;

    private Boolean success = true;

    private String code;

    private String msg;

    private Boolean canRetry = true;

    @Override
    public boolean isSuccess() {
        return success;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }

    public T getModule() {
        return module;
    }

    public <M> M forceGetModule() {
        return (M)module;
    }

    public Boolean getCanRetry() {
        return canRetry;
    }

    public void setCanRetry(Boolean canRetry) {
        this.canRetry = canRetry;
    }

    public ResultDO<T> setModule(T module) {
        this.module = module;
        return this;
    }

    @Override
    public ResultDO<T> setSuccess(boolean isSuccess) {
        this.success = isSuccess;
        return this;
    }

    @Override
    public ResultDO<T> setCode(String code) {
        this.code = code;
        return this;
    }

    @Override
    public ResultDO<T> setMsg(String msg) {
        this.msg = msg;
        return this;
    }

    public ResultDO<T> setResult(T t, IKeyDescEnum error) {
        this.code = error.getCode().toString();
        this.msg = error.getDesc();
        this.setModule(t);
        return this;
    }

    public static <T> ResultDO<T> buildSuccessResult(T t) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(true);
        res.setModule(t);
        return res;
    }

    public static <T> ResultDO<T> buildSuccessResult(T t, String msg) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(true);
        res.setModule(t);
        res.setMsg(msg);
        return res;
    }

    public static <T> ResultDO<T> buildFailResult(IKeyDescEnum error) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(error.getCode().toString());
        res.setMsg(error.getDesc());
        return res;
    }

    public static <T> ResultDO<T> buildFailResult(ErrorCode errorCode) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(errorCode.getErrCode());
        res.setMsg(errorCode.getErrMsg());
        return res;
    }

    public static <T> ResultDO<T> buildFailResult(String errorCode, String errorMsg) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(errorCode);
        res.setMsg(errorMsg);
        return res;
    }
    public static <T> ResultDO<T> buildFailResultCanNotRetry(IKeyDescEnum keyDescEnum) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(keyDescEnum.getCode());
        res.setMsg(keyDescEnum.getDesc());
        res.setCanRetry(false);
        return res;
    }
    public static <T> ResultDO<T> buildFailResultCanNotRetry(ErrorCode errorCode) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(errorCode.getErrCode());
        res.setMsg(errorCode.getErrMsg());
        res.setCanRetry(false);
        return res;
    }
    public static <T> ResultDO<T> buildFailResultCanNotRetry(String errorCode, String errorMsg) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(errorCode);
        res.setMsg(errorMsg);
        res.setCanRetry(false);
        return res;
    }
    public static <T> ResultDO<T> buildFailResultCanNotRetry(String msg) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setMsg(msg);
        res.setCanRetry(false);
        return res;
    }

    public static <T> ResultDO<T> buildFailResult(String msg) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setMsg(msg);
        return res;
    }

    public static <T> ResultDO<T> buildFailResult(ResultDO rs) {
        ResultDO<T> res = new ResultDO<>();
        res.setSuccess(false);
        res.setCode(rs.getCode());
        res.setMsg(rs.getMsg());
        res.setCanRetry(rs.getCanRetry());
        return res;
    }
}
