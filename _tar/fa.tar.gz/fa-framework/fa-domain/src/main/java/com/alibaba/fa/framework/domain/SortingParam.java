package com.alibaba.fa.framework.domain;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wb-wmf250057 on 2017/12/5.
 * 排序参数
 */
public class SortingParam implements Serializable {

    private String field;

    private Boolean asc = true;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Boolean getAsc() {
        return asc;
    }

    public void setAsc(Boolean asc) {
        this.asc = asc;
    }

    /**
     * 构造order by字符串，如：field1 desc
     * @param sortingParam
     * @return
     */
    public static String buildOrderByClause(SortingParam sortingParam){
        if(null == sortingParam || StringUtils.isBlank(sortingParam.getField())){
            return "";
        }
        return Boolean.TRUE.equals(sortingParam.getAsc()) ? sortingParam.getField().trim()+" asc" : sortingParam.getField().trim()+" desc";
    }

    /**
     * 构造order by字符串，如：field1 desc, field2 asc
     * @param sortingParams
     * @return
     */
    public static String buildOrderByClause(List<SortingParam> sortingParams){
        if(CollectionUtils.isEmpty(sortingParams)){
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(SortingParam sortingParam : sortingParams){
            if(StringUtils.isBlank(sortingParam.getField())){
                continue;
            }
            if(sb.length() > 0){
                sb.append(", ");
            }
            sb.append(sortingParam.getField().trim()).append(Boolean.TRUE.equals(sortingParam.getAsc()) ? " asc" : " desc");
        }
        return sb.toString();
    }
}
