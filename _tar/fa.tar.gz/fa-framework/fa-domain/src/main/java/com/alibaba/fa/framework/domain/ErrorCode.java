package com.alibaba.fa.framework.domain;


import com.alibaba.fa.framework.util.Exceptions;

import java.io.Serializable;

/**
 * Created by wb-zxz248731 on 2017/4/10.
 */
public class ErrorCode implements Serializable {

	/**
	 * 错误码（英文单词表示）
	 */
	private String errCode;

	/**
	 * 系统内部错误描述
	 */
	private String errMsg;

	public ErrorCode(String errCode, String errMsg) {
		this.setErrCode(errCode);
		this.setErrMsg(errMsg);
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public void fillResult(BaseResult rs){
		rs.setSuccess(false);
		rs.setCode(this.getErrCode());
		rs.setMsg(this.getErrMsg());
	}

	public ErrorCode format(Object... objs){
		this.errMsg = String.format(this.errMsg, objs);
		return this;
	}

	public static ErrorCode buildExceptionErrorCode(Exception e){
		if(null == e){
			return null;
		}
		return new ErrorCode("THROW_EXCEPTION", Exceptions.getStackTraceAsString(e));
	}

	public static ErrorCode buildErrorCode(String errCode, String errMsg){
		return new ErrorCode(errCode, errMsg);
	}
}
